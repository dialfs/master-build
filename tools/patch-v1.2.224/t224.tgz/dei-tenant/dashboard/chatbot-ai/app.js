/* DEI Chatbot Dashboard logic */
(function () {
  'use strict';

  /* ====================================================================== *
   *  LUCIDE ICON SYSTEM (v1.1.9) — inline SVG, no CDN, MIT-licensed paths
   *  Usage: ico('save') → '<svg ...>...</svg>'  |  ico('save', 18) for size
   * ====================================================================== */
  var ICONS = {
    // Sidebar nav
    'bar-chart-3':       '<path d="M3 3v18h18"/><path d="M8 17V9"/><path d="M13 17V5"/><path d="M18 17v-3"/>',
    'message-circle':    '<path d="M7.9 20A9 9 0 1 0 4 16.1L2 22Z"/>',
    'book-open':         '<path d="M12 7v14"/><path d="M3 18a1 1 0 0 1-1-1V4a1 1 0 0 1 1-1h5a4 4 0 0 1 4 4 4 4 0 0 1 4-4h5a1 1 0 0 1 1 1v13a1 1 0 0 1-1 1h-6a3 3 0 0 0-3 3 3 3 0 0 0-3-3z"/>',
    'pencil':            '<path d="M21.174 6.812a1 1 0 0 0-3.986-3.987L3.842 16.174a2 2 0 0 0-.5.83l-1.321 4.352a.5.5 0 0 0 .623.622l4.353-1.32a2 2 0 0 0 .83-.497z"/><path d="m15 5 4 4"/>',   // v1.2.200: edit-hapus-pesan
    'pen-tool':          '<path d="M15.707 21.293a1 1 0 0 1-1.414 0l-1.586-1.586a1 1 0 0 1 0-1.414l5.586-5.586a1 1 0 0 1 1.414 0l1.586 1.586a1 1 0 0 1 0 1.414z"/><path d="m18 13-1.375-6.874a1 1 0 0 0-.746-.776L3.235 2.028a1 1 0 0 0-1.207 1.207L5.35 15.879a1 1 0 0 0 .776.746L13 18"/><path d="m2.3 2.3 7.286 7.286"/><circle cx="11" cy="11" r="2"/>',
    'flask-conical':     '<path d="M14 2v6a2 2 0 0 0 .245.96l5.51 10.08A2 2 0 0 1 18 22H6a2 2 0 0 1-1.755-2.96l5.51-10.08A2 2 0 0 0 10 8V2"/><path d="M6.453 15h11.094"/><path d="M8.5 2h7"/>',
    'settings':          '<path d="M12.22 2h-.44a2 2 0 0 0-2 2v.18a2 2 0 0 1-1 1.73l-.43.25a2 2 0 0 1-2 0l-.15-.08a2 2 0 0 0-2.73.73l-.22.38a2 2 0 0 0 .73 2.73l.15.1a2 2 0 0 1 1 1.72v.51a2 2 0 0 1-1 1.74l-.15.09a2 2 0 0 0-.73 2.73l.22.38a2 2 0 0 0 2.73.73l.15-.08a2 2 0 0 1 2 0l.43.25a2 2 0 0 1 1 1.73V20a2 2 0 0 0 2 2h.44a2 2 0 0 0 2-2v-.18a2 2 0 0 1 1-1.73l.43-.25a2 2 0 0 1 2 0l.15.08a2 2 0 0 0 2.73-.73l.22-.39a2 2 0 0 0-.73-2.73l-.15-.08a2 2 0 0 1-1-1.74v-.5a2 2 0 0 1 1-1.74l.15-.09a2 2 0 0 0 .73-2.73l-.22-.38a2 2 0 0 0-2.73-.73l-.15.08a2 2 0 0 1-2 0l-.43-.25a2 2 0 0 1-1-1.73V4a2 2 0 0 0-2-2z"/><circle cx="12" cy="12" r="3"/>',
    'users':             '<path d="M16 21v-2a4 4 0 0 0-4-4H6a4 4 0 0 0-4 4v2"/><circle cx="9" cy="7" r="4"/><path d="M22 21v-2a4 4 0 0 0-3-3.87"/><path d="M16 3.13a4 4 0 0 1 0 7.75"/>',
    'rocket':            '<path d="M4.5 16.5c-1.5 1.26-2 5-2 5s3.74-.5 5-2c.71-.84.7-2.13-.09-2.91a2.18 2.18 0 0 0-2.91-.09z"/><path d="m12 15-3-3a22 22 0 0 1 2-3.95A12.88 12.88 0 0 1 22 2c0 2.72-.78 7.5-6 11a22.35 22.35 0 0 1-4 2z"/><path d="M9 12H4s.55-3.03 2-4c1.62-1.08 5 0 5 0"/><path d="M12 15v5s3.03-.55 4-2c1.08-1.62 0-5 0-5"/>',
    // Card headers
    'activity':          '<path d="M22 12h-2.48a2 2 0 0 0-1.93 1.46l-2.35 8.36a.5.5 0 0 1-.96 0L9.24 2.18a.5.5 0 0 0-.96 0l-2.35 8.36A2 2 0 0 1 4 12H2"/>',
    'wallet':            '<path d="M19 7V5a2 2 0 0 0-2-2H5a2 2 0 0 0 0 4h15a1 1 0 0 1 1 1v4"/><path d="M3 5v14a2 2 0 0 0 2 2h15a1 1 0 0 0 1-1v-4"/><path d="M18 12a2 2 0 0 0 0 4h4v-4Z"/>',
    'shield-check':      '<path d="M20 13c0 5-3.5 7.5-7.66 8.95a1 1 0 0 1-.67-.01C7.5 20.5 4 18 4 13V6a1 1 0 0 1 1-1c2 0 4.5-1.2 6.24-2.72a1.17 1.17 0 0 1 1.52 0C14.51 3.81 17 5 19 5a1 1 0 0 1 1 1z"/><path d="m9 12 2 2 4-4"/>',
    'save':              '<path d="M15.2 3a2 2 0 0 1 1.4.6l3.8 3.8a2 2 0 0 1 .6 1.4V19a2 2 0 0 1-2 2H5a2 2 0 0 1-2-2V5a2 2 0 0 1 2-2z"/><path d="M17 21v-7a1 1 0 0 0-1-1H8a1 1 0 0 0-1 1v7"/><path d="M7 3v4a1 1 0 0 0 1 1h7"/>',
    'trash-2':           '<path d="M3 6h18"/><path d="M19 6v14a2 2 0 0 1-2 2H7a2 2 0 0 1-2-2V6"/><path d="M8 6V4a2 2 0 0 1 2-2h4a2 2 0 0 1 2 2v2"/><line x1="10" x2="10" y1="11" y2="17"/><line x1="14" x2="14" y1="11" y2="17"/>',
    'log-out':           '<path d="M9 21H5a2 2 0 0 1-2-2V5a2 2 0 0 1 2-2h4"/><polyline points="16 17 21 12 16 7"/><line x1="21" x2="9" y1="12" y2="12"/>',
    // Banners / status
    'octagon-alert':     '<path d="M12 16h.01"/><path d="M12 8v4"/><path d="M15.312 2a2 2 0 0 1 1.414.586l4.688 4.688A2 2 0 0 1 22 8.688v6.624a2 2 0 0 1-.586 1.414l-4.688 4.688a2 2 0 0 1-1.414.586H8.688a2 2 0 0 1-1.414-.586l-4.688-4.688A2 2 0 0 1 2 15.312V8.688a2 2 0 0 1 .586-1.414l4.688-4.688A2 2 0 0 1 8.688 2z"/>',
    'triangle-alert':    '<path d="m21.73 18-8-14a2 2 0 0 0-3.48 0l-8 14A2 2 0 0 0 4 21h16a2 2 0 0 0 1.73-3"/><path d="M12 9v4"/><path d="M12 17h.01"/>',
    'clock-3':           '<circle cx="12" cy="12" r="10"/><polyline points="12 6 12 12 16.5 12"/>',
    'alarm-clock':       '<circle cx="12" cy="13" r="8"/><path d="M12 9v4l2 2"/><path d="M5 3 2 6"/><path d="m22 6-3-3"/><path d="M6.38 18.7 4 21"/><path d="M17.64 18.67 20 21"/>',   // v1.2.153: jadwal-kirim
    'ban':               '<circle cx="12" cy="12" r="10"/><path d="m4.9 4.9 14.2 14.2"/>',
    'check-circle-2':    '<circle cx="12" cy="12" r="10"/><path d="m9 12 2 2 4-4"/>',
    // Avatar Icon Mode (v1.1.9 hybrid)
    'bot':               '<path d="M12 8V4H8"/><rect width="16" height="12" x="4" y="8" rx="2"/><path d="M2 14h2"/><path d="M20 14h2"/><path d="M15 13v2"/><path d="M9 13v2"/>',
    'hand':              '<path d="M18 11V6a2 2 0 0 0-2-2a2 2 0 0 0-2 2"/><path d="M14 10V4a2 2 0 0 0-2-2a2 2 0 0 0-2 2v2"/><path d="M10 10.5V6a2 2 0 0 0-2-2a2 2 0 0 0-2 2v8"/><path d="M18 8a2 2 0 1 1 4 0v6a8 8 0 0 1-8 8h-2c-2.8 0-4.5-.86-5.99-2.34l-3.6-3.6a2 2 0 0 1 2.83-2.82L7 15"/>',
    'smile':             '<circle cx="12" cy="12" r="10"/><path d="M8 14s1.5 2 4 2 4-2 4-2"/><line x1="9" x2="9.01" y1="9" y2="9"/><line x1="15" x2="15.01" y1="9" y2="9"/>',
    'headphones':        '<path d="M3 14h3a2 2 0 0 1 2 2v3a2 2 0 0 1-2 2H4a1 1 0 0 1-1-1zm18 0h-3a2 2 0 0 0-2 2v3a2 2 0 0 0 2 2h2a1 1 0 0 0 1-1zM3 14a9 9 0 0 1 18 0"/>',
    'user-round':        '<circle cx="12" cy="8" r="5"/><path d="M20 21a8 8 0 0 0-16 0"/>',
    'briefcase-business':'<path d="M12 12h.01"/><path d="M16 6V4a2 2 0 0 0-2-2h-4a2 2 0 0 0-2 2v2"/><path d="M22 13a18.15 18.15 0 0 1-20 0"/><rect width="20" height="14" x="2" y="6" rx="2"/>',
    'phone':             '<path d="M22 16.92v3a2 2 0 0 1-2.18 2 19.79 19.79 0 0 1-8.63-3.07 19.5 19.5 0 0 1-6-6 19.79 19.79 0 0 1-3.07-8.67A2 2 0 0 1 4.11 2h3a2 2 0 0 1 2 1.72c.127.96.361 1.903.7 2.81a2 2 0 0 1-.45 2.11L8.09 9.91a16 16 0 0 0 6 6l1.27-1.27a2 2 0 0 1 2.11-.45c.907.339 1.85.573 2.81.7A2 2 0 0 1 22 16.92z"/>',
    'sparkles':          '<path d="M9.937 15.5A2 2 0 0 0 8.5 14.063l-6.135-1.582a.5.5 0 0 1 0-.962L8.5 9.936A2 2 0 0 0 9.937 8.5l1.582-6.135a.5.5 0 0 1 .963 0L14.063 8.5A2 2 0 0 0 15.5 9.937l6.135 1.581a.5.5 0 0 1 0 .964L15.5 14.063a2 2 0 0 0-1.437 1.437l-1.582 6.135a.5.5 0 0 1-.963 0z"/><path d="M20 3v4"/><path d="M22 5h-4"/><path d="M4 17v2"/><path d="M5 18H3"/>',
    'mail':              '<rect width="20" height="16" x="2" y="4" rx="2"/><path d="m22 7-8.97 5.7a1.94 1.94 0 0 1-2.06 0L2 7"/>',
    'life-buoy':         '<circle cx="12" cy="12" r="10"/><path d="m4.93 4.93 4.24 4.24"/><path d="m14.83 9.17 4.24-4.24"/><path d="m14.83 14.83 4.24 4.24"/><path d="m9.17 14.83-4.24 4.24"/><circle cx="12" cy="12" r="4"/>',
    'crown':             '<path d="M11.562 3.266a.5.5 0 0 1 .876 0L15.39 8.87a1 1 0 0 0 1.516.294L21.183 5.5a.5.5 0 0 1 .798.519l-2.834 10.246a1 1 0 0 1-.956.734H5.81a1 1 0 0 1-.957-.734L2.02 6.02a.5.5 0 0 1 .798-.519l4.276 3.664a1 1 0 0 0 1.516-.294z"/><path d="M5 21h14"/>',
  };
  /* v1.2.26: ikon tambahan. Ditaruh di objek TERPISAH lalu digabungkan,
     supaya peta ICONS asli tidak perlu disentuh. */
  var ICONS_EXTRA = {
    'palette': '<circle cx="13.5" cy="6.5" r=".5" fill="currentColor"/><circle cx="17.5" cy="10.5" r=".5" fill="currentColor"/><circle cx="8.5" cy="7.5" r=".5" fill="currentColor"/><circle cx="6.5" cy="12.5" r=".5" fill="currentColor"/><path d="M12 2C6.5 2 2 6.5 2 12s4.5 10 10 10c.926 0 1.648-.746 1.648-1.688 0-.437-.18-.835-.437-1.125-.29-.289-.438-.652-.438-1.125a1.64 1.64 0 0 1 1.668-1.668h1.996c3.051 0 5.555-2.503 5.555-5.554C21.965 6.012 17.461 2 11.994 2z"/>',   // v1.2.169: tema-warna
    'bookmark':          '<path d="m19 21-7-4-7 4V5a2 2 0 0 1 2-2h10a2 2 0 0 1 2 2v16z"/>',   // v1.2.164: cari-simpan
    'star':              '<polygon points="12 2 15.09 8.26 22 9.27 17 14.14 18.18 21.02 12 17.77 5.82 21.02 7 14.14 2 9.27 8.91 8.26 12 2"/>',   // v1.2.131: ikon-dd
    'message-square-heart': '<path d="M21 15a2 2 0 0 1-2 2H7l-4 4V5a2 2 0 0 1 2-2h14a2 2 0 0 1 2 2z"/><path d="M14.8 7.5a1.84 1.84 0 0 0-2.6 0l-.2.3-.3-.3a1.84 1.84 0 1 0-2.4 2.8L12 13l2.7-2.7c.9-.9.8-2.1.1-2.8"/>',   // v1.2.131: ikon-dd
    'circle':            '<circle cx="12" cy="12" r="10"/>',   // v1.2.90
    'send':              '<path d="M14.536 21.686a.5.5 0 0 0 .937-.024l6.5-19a.496.496 0 0 0-.635-.635l-19 6.5a.5.5 0 0 0-.024.937l7.93 3.18a2 2 0 0 1 1.112 1.11z"/><path d="m21.854 2.147-10.94 10.939"/>',
    'monitor-smartphone': '<path d="M18 8V5a1 1 0 0 0-1-1H3a1 1 0 0 0-1 1v11a1 1 0 0 0 1 1h9"/><path d="M7 19h5"/><path d="M10 16v3"/><rect width="6" height="10" x="16" y="11" rx="2"/>',
    'target':            '<circle cx="12" cy="12" r="10"/><circle cx="12" cy="12" r="6"/><circle cx="12" cy="12" r="2"/>',
    'user':              '<path d="M19 21v-2a4 4 0 0 0-4-4H9a4 4 0 0 0-4 4v2"/><circle cx="12" cy="7" r="4"/>',
    'search':        '<circle cx="11" cy="11" r="8"/><path d="m21 21-4.3-4.3"/>',
    'circle-help':   '<circle cx="12" cy="12" r="10"/><path d="M9.09 9a3 3 0 0 1 5.83 1c0 2-3 3-3 3"/><path d="M12 17h.01"/>',
    'file-text':     '<path d="M15 2H6a2 2 0 0 0-2 2v16a2 2 0 0 0 2 2h12a2 2 0 0 0 2-2V7Z"/><path d="M14 2v4a2 2 0 0 0 2 2h4"/><path d="M10 9H8"/><path d="M16 13H8"/><path d="M16 17H8"/>',
    'upload':        '<path d="M21 15v4a2 2 0 0 1-2 2H5a2 2 0 0 1-2-2v-4"/><polyline points="17 8 12 3 7 8"/><line x1="12" x2="12" y1="3" y2="15"/>',
    'user-plus':     '<path d="M16 21v-2a4 4 0 0 0-4-4H6a4 4 0 0 0-4 4v2"/><circle cx="9" cy="7" r="4"/><line x1="19" x2="19" y1="8" y2="14"/><line x1="22" x2="16" y1="11" y2="11"/>',
    'download':      '<path d="M21 15v4a2 2 0 0 1-2 2H5a2 2 0 0 1-2-2v-4"/><polyline points="7 10 12 15 17 10"/><line x1="12" x2="12" y1="15" y2="3"/>',
    'copy':          '<rect width="14" height="14" x="8" y="8" rx="2" ry="2"/><path d="M4 16c-1.1 0-2-.9-2-2V4c0-1.1.9-2 2-2h10c1.1 0 2 .9 2 2"/>',
    'clipboard-list':'<rect width="8" height="4" x="8" y="2" rx="1" ry="1"/><path d="M16 4h2a2 2 0 0 1 2 2v14a2 2 0 0 1-2 2H6a2 2 0 0 1-2-2V6a2 2 0 0 1 2-2h2"/><path d="M12 11h4"/><path d="M12 16h4"/><path d="M8 11h.01"/><path d="M8 16h.01"/>',
    'bell':          '<path d="M6 8a6 6 0 0 1 12 0c0 7 3 9 3 9H3s3-2 3-9"/><path d="M10.3 21a1.94 1.94 0 0 0 3.4 0"/>',
    'bell-off':      '<path d="M8.7 3A6 6 0 0 1 18 8a21.3 21.3 0 0 0 .6 5"/><path d="M17 17H3s3-2 3-9a4.67 4.67 0 0 1 .3-1.7"/><path d="M10.3 21a1.94 1.94 0 0 0 3.4 0"/><path d="m2 2 20 20"/>',
    'rotate-cw':     '<path d="M21 12a9 9 0 1 1-9-9c2.52 0 4.93 1 6.74 2.74L21 8"/><path d="M21 3v5h-5"/>',
    'corner-up-left':'<polyline points="9 14 4 9 9 4"/><path d="M20 20v-7a4 4 0 0 0-4-4H4"/>',
    'wrench':        '<path d="M14.7 6.3a1 1 0 0 0 0 1.4l1.6 1.6a1 1 0 0 0 1.4 0l3.77-3.77a6 6 0 0 1-7.94 7.94l-6.91 6.91a2.12 2.12 0 0 1-3-3l6.91-6.91a6 6 0 0 1 7.94-7.94l-3.76 3.76z"/>',
    'x':             '<path d="M18 6 6 18"/><path d="m6 6 12 12"/>',
    'arrow-left':    '<path d="m12 19-7-7 7-7"/><path d="M19 12H5"/>',
    'globe':         '<circle cx="12" cy="12" r="10"/><path d="M12 2a14.5 14.5 0 0 0 0 20 14.5 14.5 0 0 0 0-20"/><path d="M2 12h20"/>',
    'paperclip':     '<path d="m21.44 11.05-9.19 9.19a6 6 0 0 1-8.49-8.49l8.57-8.57A4 4 0 1 1 18 8.84l-8.59 8.57a2 2 0 0 1-2.83-2.83l8.49-8.48"/>',
    'menu':          '<line x1="4" x2="20" y1="12" y2="12"/><line x1="4" x2="20" y1="6" y2="6"/><line x1="4" x2="20" y1="18" y2="18"/>',
    'chevron-down':  '<path d="m6 9 6 6 6-6"/>',
    'more-horizontal': '<circle cx="12" cy="12" r="1"/><circle cx="19" cy="12" r="1"/><circle cx="5" cy="12" r="1"/>',   // v1.2.125: wa-tampilan-sama
    'tag':           '<path d="M12.6 2.6A2 2 0 0 0 11.2 2H4a2 2 0 0 0-2 2v7.2a2 2 0 0 0 .6 1.4l8.7 8.7a2.4 2.4 0 0 0 3.4 0l6.6-6.6a2.4 2.4 0 0 0 0-3.4z"/><circle cx="7.5" cy="7.5" r=".5" fill="currentColor"/>',   // v1.2.124: wa-layout-penuh
    'layers':        '<path d="m12.83 2.18a2 2 0 0 0-1.66 0L2.6 6.08a1 1 0 0 0 0 1.83l8.58 3.91a2 2 0 0 0 1.66 0l8.58-3.9a1 1 0 0 0 0-1.83Z"/><path d="m22 17.65-9.17 4.16a2 2 0 0 1-1.66 0L2 17.65"/><path d="m22 12.65-9.17 4.16a2 2 0 0 1-1.66 0L2 12.65"/>'   // v1.2.167: unit-bisnis
  };
  for (var _ikey in ICONS_EXTRA) {
    if (Object.prototype.hasOwnProperty.call(ICONS_EXTRA, _ikey)) ICONS[_ikey] = ICONS_EXTRA[_ikey];
  }

  function ico(name, size, extraAttrs) {
    var path = ICONS[name];
    if (!path) return '';
    var sz = size || 18;
    var attrs = extraAttrs || '';
    return '<svg xmlns="http://www.w3.org/2000/svg" width="' + sz + '" height="' + sz +
           '" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" class="lucide" ' + attrs + '>' +
           path + '</svg>';
  }
  if (!ICONS.archive) ICONS.archive = '<rect width="20" height="5" x="2" y="3" rx="1"/><path d="M4 8v11a2 2 0 0 0 2 2h12a2 2 0 0 0 2-2V8"/><path d="M10 12h4"/>';   // v1.2.213: wa-arsip
  if (!ICONS['list-todo']) ICONS['list-todo'] = '<rect x="3" y="5" width="6" height="6" rx="1"/><path d="m3 17 2 2 4-4"/><path d="M13 6h8"/><path d="M13 12h8"/><path d="M13 18h8"/>';   // v1.2.214: task
  if (!ICONS['sticky-note']) ICONS['sticky-note'] = '<path d="M16 3H5a2 2 0 0 0-2 2v14a2 2 0 0 0 2 2h14a2 2 0 0 0 2-2V8Z"/><path d="M15 3v4a2 2 0 0 0 2 2h4"/>';
  if (!ICONS.calendar) ICONS.calendar = '<path d="M8 2v4"/><path d="M16 2v4"/><rect width="18" height="18" x="3" y="4" rx="2"/><path d="M3 10h18"/>';
  if (!ICONS['trending-up']) ICONS['trending-up'] = '<polyline points="22 7 13.5 15.5 8.5 10.5 2 17"/><polyline points="16 7 22 7 22 13"/>';   // v1.2.221: laporan-sales
  if (!ICONS.plus) ICONS.plus = '<path d="M5 12h14"/><path d="M12 5v14"/>';
  if (!ICONS['trash-2']) ICONS['trash-2'] = '<path d="M3 6h18"/><path d="M19 6v14c0 1-1 2-2 2H7c-1 0-2-1-2-2V6"/><path d="M8 6V4c0-1 1-2 2-2h4c1 0 2 1 2 2v2"/>';   // v1.2.215: crm-aktivitas
  if (!ICONS.eye) ICONS.eye = '<path d="M2 12s3-7 10-7 10 7 10 7-3 7-10 7-10-7-10-7Z"/><circle cx="12" cy="12" r="3"/>';   // v1.2.219: divisi-sales
  // Expose for inline replacement of static markup
  window._ico = ico;

  /* v1.2.73: brand per instalasi (window.DEI_BRAND dari action=brand_js; null = DEI) */
  var BRAND = window.DEI_BRAND || null;
  var BRAND_VENDOR = BRAND ? BRAND.vendor : 'DEI';
  var BRAND_C1 = (BRAND && BRAND.c1) || '#140383';
  var BRAND_C2 = (BRAND && BRAND.c2) || '#a855f7';

  /* ---- base + api ------------------------------------------------------ */
  var path = window.location.pathname;
  var idx = path.indexOf('/dashboard/chatbot-ai');
  var base = idx >= 0 ? path.slice(0, idx) : path.replace(/\/[^\/]*$/, '');
  var SITE_BASE = window.location.origin + base;        // e.g. https://domain.com
  var API = SITE_BASE + '/api/index.php';
  var TK = 'dei_token@' + base, UK = 'dei_user@' + base;   // v1.2.180: sesi-per-tenant — kunci sesi per tenant (satu domain banyak tenant)
  try { if (!localStorage.getItem(TK) && localStorage.getItem('dei_token')) { localStorage.setItem(TK, localStorage.getItem('dei_token')); localStorage.setItem(UK, localStorage.getItem('dei_user') || 'null'); } } catch (e) {}   // v1.2.180: sesi-per-tenant: migrasi sekali dari kunci lama

  var token = localStorage.getItem(TK);
  var user = JSON.parse(localStorage.getItem(UK) || 'null');
  if (!token || !user) { location.href = 'login.html'; return; }

  function logout() {
    localStorage.removeItem(TK);
    localStorage.removeItem(UK);
    location.href = 'login.html';
  }

  function api(action, opts) {
    opts = opts || {};
    var sep = '&_=' + Date.now();   // cache-buster: dodge any server/proxy caching of repeated API URLs
    var url = API + '?action=' + action + (opts.query || '') + sep;
    var conf = { method: opts.method || 'GET', headers: { 'X-Auth-Token': token }, cache: 'no-store' };
    if (opts.body) { conf.headers['Content-Type'] = 'application/json'; conf.body = JSON.stringify(opts.body); }
    return fetch(url, conf).then(function (r) {
      // Rotate token if server provided a refreshed one (idle window slid forward).
      var fresh = r.headers.get('X-Auth-Refresh');
      if (fresh) {
        try { token = fresh; localStorage.setItem(TK, fresh); } catch (e) {}
      }
      if (r.status === 401) { logout(); throw new Error('unauth'); }
      return r.text().then(function (txt) {
        if (!txt) { console.warn('[api] respons kosong untuk', action); return { ok: false, error: 'Respons kosong dari server.' }; }
        try { return JSON.parse(txt); }
        catch (e) { console.warn('[api] JSON tidak valid untuk', action, '-', txt.slice(0, 120)); return { ok: false, error: 'Respons tidak valid.' }; }
      });
    });
  }


  /* ---- v1.2.176: meta-campaign — token Meta Ads ---- */
  function maStatus() {
    if (!$('#ma_status')) return;
    api('meta_ads_get').then(function (r) {
      if (!r || !r.ok) { $('#ma_status').textContent = (r && r.error) || 'Tidak bisa memuat.'; return; }
      $('#ma_status').textContent = r.token_set
        ? 'Token tersimpan (' + r.masked + (r.who ? ' · ' + r.who : '') + '). Iklan dikenali: ' + r.ads_known + (r.last_err ? ' · Error terakhir: ' + r.last_err : '')
        : 'Belum ada token — campaign chat dari iklan CTWA memakai headline iklan.';   // v1.2.177: headline-iklan
    });
  }
  function maShow(r) {
    if (!r || !r.ok) { toast((r && r.error) || 'Gagal.', true); $('#ma_result').textContent = (r && r.error) || ''; return; }
    if (r.cleared) { toast('Token dihapus.'); $('#ma_result').textContent = ''; maStatus(); return; }
    var ads = (r.ads || []).map(function (a) { return 'iklan ' + a.ad_id + ' → ' + (a.campaign || ('gagal: ' + (a.err || '-'))); });
    $('#ma_result').textContent = 'Token valid' + (r.who ? ' (' + r.who + ')' : '') + '.' + (ads.length ? ' ' + ads.join(' · ') : ' Belum ada chat iklan CTWA baru untuk diuji.');
    toast('Token Meta valid.'); maStatus();
  }
  function maBind() {
    if (!$('#ma_save') || $('#ma_save').__b) return; $('#ma_save').__b = 1;
    $('#ma_save').onclick = function () {
      var v = $('#ma_token').value.trim(); if (!v) { toast('Tempel token dulu.', true); return; }
      api('meta_ads_save', { method: 'POST', body: { token: v } }).then(function (r) { if (r && r.ok) $('#ma_token').value = ''; maShow(r); });
    };
    $('#ma_test').onclick = function () { api('meta_ads_test', { method: 'POST', body: {} }).then(maShow); };
    $('#ma_clear').onclick = function () { if (confirm('Hapus token Meta Ads?')) api('meta_ads_save', { method: 'POST', body: { token: '' } }).then(maShow); };
  }

  /* ---- helpers --------------------------------------------------------- */
  var $ = function (s) { return document.querySelector(s); };
  var $$ = function (s) { return Array.prototype.slice.call(document.querySelectorAll(s)); };
  function esc(s) { return String(s == null ? '' : s).replace(/[&<>"']/g, function (c) { return { '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#39;' }[c]; }); }
  var toastT;
  function toast(msg, isErr) {
    var t = $('#toast'); t.textContent = msg; t.className = 'toast show' + (isErr ? ' err' : '');
    clearTimeout(toastT); toastT = setTimeout(function () { t.className = 'toast'; }, isErr ? 5500 : 2600);   // v1.2.60: error lebih lama terbaca
  }

  /* ---- role + nav ------------------------------------------------------ */
  var role = user.role || 'admin';
  var ROLE_LABEL = { super_admin: 'Super Admin', admin: 'Admin', supervisor: 'Supervisor', wa_agent: 'WA Agent', sales: 'Sales' };   // v1.2.216: pipeline-sales
  function can(allowed) {           // allowed = "role1,role2,..." or array
    if (!allowed || allowed === 'any') return true;
    var arr = Array.isArray(allowed) ? allowed : String(allowed).split(',');
    return arr.indexOf(role) !== -1;
  }
  $('#whoName').textContent = user.name || user.username;
  $('#whoRole').textContent = ROLE_LABEL[role] || role;
  document.body.classList.add('role-' + role);   // v1.2.216: pipeline-sales
  $('#logout').onclick = logout;
  // v1.1.8: Mobile sidebar — backdrop, click-outside-to-close, auto-close on tab switch
  function toggleSide(force) {
    var side = document.getElementById('side');
    var willOpen = force !== undefined ? force : !side.classList.contains('open');
    side.classList.toggle('open', willOpen);
    document.body.classList.toggle('side-open', willOpen);
  }
  $('#menuBtn').onclick = function () { toggleSide(); };
  // Click backdrop (anywhere outside sidebar when open) → close
  document.addEventListener('click', function (e) {
    if (!document.body.classList.contains('side-open')) return;
    var side = document.getElementById('side');
    var btn = document.getElementById('menuBtn');
    if (!side.contains(e.target) && !btn.contains(e.target)) toggleSide(false);
  });
  // ESC to close
  document.addEventListener('keydown', function (e) {
    if (e.key === 'Escape' && document.body.classList.contains('side-open')) toggleSide(false);
  });

  // hide nav items not allowed for this role
  $$('#nav button').forEach(function (b) {
    if (!can(b.dataset.role)) b.classList.add('hide');
    // v1.1.9: inject Lucide icon
    var iconName = b.dataset.icon;
    if (iconName) {
      var icSpan = b.querySelector('.ic');
      if (icSpan) icSpan.innerHTML = ico(iconName, 18);
    }
  });
  // v1.2.26: isi semua elemen ber-atribut data-ico dengan ikonnya.
  // Menyusul pola nav sidebar — markup HTML cukup menyebut nama ikonnya.
  function fillDataIcons(scope) {
    var akar = scope || document;
    Array.prototype.slice.call(akar.querySelectorAll('[data-ico]')).forEach(function (el) {
      if (el.dataset.icoDone) return;
      var svg = ico(el.dataset.ico, +(el.dataset.icoSize || 15), 'style="vertical-align:-3px"');
      if (svg) { el.innerHTML = svg; el.dataset.icoDone = '1'; }
    });
  }
  window._fillDataIcons = fillDataIcons;
  fillDataIcons();

  // hide secret-only cards (API/WA Cloud API/Telegram) for non super_admin
  $$('[data-role-card]').forEach(function (el) {
    if (!can(el.dataset.roleCard)) el.classList.add('hide');
  });

  var loaded = {};
  function showTab(tab) {
    $$('#nav button').forEach(function (b) { b.classList.toggle('active', b.dataset.tab === tab); });
    $$('.panel').forEach(function (p) { p.classList.remove('active'); });
    var panel = $('#panel-' + tab);
    if (panel) panel.classList.add('active');
    $('#side').classList.remove('open');
    document.body.classList.remove('side-open');   // v1.1.8: also drop backdrop
    // v1.2.39 fase7b: loader di baris bawah hanya jalan SEKALI per tab
    // (dijaga oleh loaded[tab]), jadi reset tampilan mobile HARUS di sini --
    // showTab() selalu jalan tiap menu dipilih. Memilih menu "Percakapan WA"
    // diperlakukan sama dengan menekan tombol Back: kembali ke DAFTAR
    // percakapan di posisi paling atas, bukan nyangkut di thread terakhir.
    document.body.classList.toggle('wa-full', tab === 'wachat');   // v1.2.124: wa-layout-penuh
    if (tab === 'wachat') {
      var _wrapNav = document.querySelector('.wachat-wrap');
      if (_wrapNav) _wrapNav.classList.remove('showing-thread');
      if (window.scrollTo) window.scrollTo(0, 0);
    }
    if (!loaded[tab]) { loaded[tab] = true; if (loaders[tab]) loaders[tab](); }
    else if (tab === 'kontak') fetchContacts();   // v1.2.106: kontak-sinkron (data Kontak selalu segar)
    else if (tab === 'qrtpl' && qrtplRefresh) qrtplRefresh();   // v1.2.199: template-menu
    else if (tab === 'tasks') tkFetch214(tkRender214);   // v1.2.214: task
  }
  $$('#nav button').forEach(function (b) { b.onclick = function () { showTab(b.dataset.tab); }; });

  /* ====================================================================== *
   *  REPORTS
   * ====================================================================== */
  function reportQuery() {
    var f = $('#repFrom') ? $('#repFrom').value : '';
    var t = $('#repTo') ? $('#repTo').value : '';
    var c = $('#repChannel') ? $('#repChannel').value : 'all';
    return '&from=' + encodeURIComponent(f) + '&to=' + encodeURIComponent(t) + '&channel=' + encodeURIComponent(c);
  }

  function utmRows(arr) {
    return arr.length
      ? arr.map(function (r) {
          return '<tr><td><span class="tag' + (r.label.charAt(0) === '(' ? ' none' : '') + '">' + esc(r.label) + '</span></td>' +
            '<td style="text-align:right" class="mono">' + r.count + '</td>' +
            '<td style="text-align:right" class="mono">' + (r.users != null ? r.users : '–') + '</td></tr>';
        }).join('')
      : emptyRow(3);
  }

  /* v1.2.155: statistik-kontak — kartu Kontak WhatsApp */
  var csData = null, csPer = 'today', csWired = false;
  try { var _cp = localStorage.getItem('dei_cs_per'); if (['today', 'week', 'month'].indexOf(_cp) !== -1) csPer = _cp; } catch (e) {}
  function csCard(v, l, h) { return '<div class="stat"><div class="v">' + v + '</div><div class="l">' + l + '</div><div class="h">' + h + '</div></div>'; }
  function csRender() {
    var wrap = $('#contactStats'), box = $('#contactCards');
    if (!wrap || !box) return;
    if (!csData) { wrap.style.display = 'none'; return; }
    wrap.style.display = '';
    if (!csWired) {
      csWired = true;
      $$('#csPresets button').forEach(function (b) {
        b.addEventListener('click', function () {
          csPer = b.getAttribute('data-p');
          try { localStorage.setItem('dei_cs_per', csPer); } catch (e) {}
          csRender();
        });
      });
    }
    var d = csData[csPer] || {}, w = { today: 'hari ini', week: 'minggu ini', month: 'bulan ini' }[csPer];
    var n = function (v) { return (+v || 0).toLocaleString('id-ID'); };
    box.innerHTML =
      csCard(n(d['new']), 'Kontak Baru', 'Nomor yang pertama kali chat ' + w) +
      csCard(n(d.active), 'Kontak Aktif', 'Nomor yang berinteraksi ' + w + ' (pelanggan, bot, atau agent)') +
      csCard(n(d.conversations), 'Percakapan', 'Percakapan WhatsApp yang dimulai ' + w) +
      csCard(n(d.unique), 'Kontak Unik', 'Nomor WhatsApp unik yang mengirim chat ' + w);
    $$('#csPresets button').forEach(function (b) { b.classList.toggle('on', b.getAttribute('data-p') === csPer); });
    var desc = $('#csDesc');
    if (desc) desc.textContent = (csPer === 'today' ? '' : 'Sejak ' + d.from + '. ') + 'Tidak terpengaruh filter tanggal di bawah.';
  }

  function loadReports() {
    api('report', { query: reportQuery() }).then(function (res) {
      if (!res.ok) return;
      var s = res.stats;
      $('#statCards').innerHTML =
        statCard(s.total, 'Total Pesan') +          // v1.2.155: statistik-kontak: dulu 'Total Percakapan' (isinya jumlah pesan)
        statCard(s.today, 'Pesan Hari Ini') +
        statCard(s.kb_entries, 'Entri KB') +
        statCard(s.unique_ips, 'Pengunjung Unik');
      csData = res.contacts || null; csRender();   // v1.2.155: statistik-kontak

      $('#tblSource').innerHTML   = utmRows(res.by_source || []);
      $('#tblMedium').innerHTML   = utmRows(res.by_medium || []);
      $('#tblSrcMed').innerHTML   = utmRows(res.by_source_medium || []);
      $('#tblCampaign').innerHTML = utmRows(res.by_campaign || []);

      if ($('#tblChannel')) {
        var byCh = res.by_channel || [];
        $('#tblChannel').innerHTML = byCh.length
          ? byCh.map(function (r) { var lbl = r.label === 'whatsapp' ? ico('message-circle',13) + ' WhatsApp' : (r.label === 'web' ? ico('globe',13) + ' Web' : esc(r.label)); return '<tr><td>' + lbl + '</td><td style="text-align:right" class="mono">' + r.count + '</td></tr>'; }).join('')
          : emptyRow(2);
      }

      $('#pieSrcMed').innerHTML  = svgPie(res.by_source_medium || []);
      $('#lineTrend').innerHTML  = svgTrend(res.trend || []);
    });
    // v1.2.66: log percakapan pindah ke sub-tab "Log Percakapan" (lgLoad)
  }

  /* ---- inline SVG charts (no external libs) ---------------------------- */
  var PIE_COLORS = (BRAND && BRAND.palette && BRAND.palette.length) ? BRAND.palette : ['#140383', '#4338ca', '#6366f1', '#8b5cf6', '#a855f7', '#c084fc', '#e879f9', '#94a3b8'];

  function svgPie(arr) {
    var data = arr.slice(0, 7);
    var rest = arr.slice(7).reduce(function (a, r) { return a + r.count; }, 0);
    if (rest > 0) data.push({ label: 'lainnya', count: rest });
    var total = data.reduce(function (a, r) { return a + r.count; }, 0);
    if (!total) return '<div style="color:var(--muted);padding:24px;text-align:center">Belum ada data.</div>';
    var cx = 90, cy = 90, r = 80, ang = -Math.PI / 2, seg = '';
    data.forEach(function (d, i) {
      var frac = d.count / total, a2 = ang + frac * 2 * Math.PI;
      var x1 = cx + r * Math.cos(ang), y1 = cy + r * Math.sin(ang);
      var x2 = cx + r * Math.cos(a2), y2 = cy + r * Math.sin(a2);
      var large = frac > 0.5 ? 1 : 0;
      if (frac >= 0.9999) { // single slice = full circle
        seg += '<circle cx="' + cx + '" cy="' + cy + '" r="' + r + '" fill="' + PIE_COLORS[i % PIE_COLORS.length] + '"/>';
      } else {
        seg += '<path d="M' + cx + ',' + cy + ' L' + x1.toFixed(2) + ',' + y1.toFixed(2) + ' A' + r + ',' + r + ' 0 ' + large + ',1 ' + x2.toFixed(2) + ',' + y2.toFixed(2) + ' Z" fill="' + PIE_COLORS[i % PIE_COLORS.length] + '"/>';
      }
      ang = a2;
    });
    var legend = data.map(function (d, i) {
      var pct = Math.round(d.count / total * 100);
      return '<div style="display:flex;align-items:center;gap:6px;font-size:12px;margin:2px 0">' +
        '<span style="width:10px;height:10px;border-radius:2px;background:' + PIE_COLORS[i % PIE_COLORS.length] + ';display:inline-block"></span>' +
        '<span style="flex:1;overflow:hidden;text-overflow:ellipsis;white-space:nowrap">' + esc(d.label) + '</span>' +
        '<span class="mono" style="color:var(--muted)">' + d.count + ' · ' + pct + '%</span></div>';
    }).join('');
    return '<div style="display:flex;gap:16px;align-items:center;flex-wrap:wrap">' +
      '<svg viewBox="0 0 180 180" width="180" height="180">' + seg + '</svg>' +
      '<div style="flex:1;min-width:160px">' + legend + '</div></div>';
  }

  function svgTrend(arr) {
    if (!arr.length) return '<div style="color:var(--muted);padding:24px;text-align:center">Belum ada data.</div>';
    var W = 520, H = 200, padL = 30, padB = 22, padT = 10, padR = 10;
    var max = Math.max(1, arr.reduce(function (m, d) { return Math.max(m, d.count, d.users); }, 0));
    var n = arr.length;
    var xw = (W - padL - padR), yh = (H - padT - padB);
    function X(i) { return padL + (n <= 1 ? xw / 2 : (i / (n - 1)) * xw); }
    function Y(v) { return padT + yh - (v / max) * yh; }
    function poly(key, color) {
      var pts = arr.map(function (d, i) { return X(i).toFixed(1) + ',' + Y(d[key]).toFixed(1); }).join(' ');
      var dots = arr.map(function (d, i) { return '<circle cx="' + X(i).toFixed(1) + '" cy="' + Y(d[key]).toFixed(1) + '" r="2.5" fill="' + color + '"/>'; }).join('');
      return '<polyline points="' + pts + '" fill="none" stroke="' + color + '" stroke-width="2"/>' + dots;
    }
    var grid = '', steps = 4;
    for (var g = 0; g <= steps; g++) {
      var yy = padT + (g / steps) * yh, val = Math.round(max * (1 - g / steps));
      grid += '<line x1="' + padL + '" y1="' + yy.toFixed(1) + '" x2="' + (W - padR) + '" y2="' + yy.toFixed(1) + '" stroke="var(--line)" stroke-width="1"/>';
      grid += '<text x="' + (padL - 4) + '" y="' + (yy + 3).toFixed(1) + '" text-anchor="end" font-size="9" fill="var(--muted)">' + val + '</text>';
    }
    var labels = '';
    var every = Math.ceil(n / 8);
    arr.forEach(function (d, i) {
      if (i % every === 0 || i === n - 1) labels += '<text x="' + X(i).toFixed(1) + '" y="' + (H - 6) + '" text-anchor="middle" font-size="8.5" fill="var(--muted)">' + d.date.slice(5) + '</text>';
    });
    return '<svg viewBox="0 0 ' + W + ' ' + H + '" width="100%" style="max-width:540px">' + grid + poly('count', BRAND_C1) + poly('users', BRAND_C2) + labels + '</svg>' +
      '<div style="display:flex;gap:16px;font-size:12px;margin-top:6px">' +
      '<span style="display:flex;align-items:center;gap:5px"><span style="width:14px;height:3px;background:' + BRAND_C1 + ';display:inline-block"></span>Pesan</span>' +
      '<span style="display:flex;align-items:center;gap:5px"><span style="width:14px;height:3px;background:' + BRAND_C2 + ';display:inline-block"></span>Pengunjung unik</span></div>';
  }
  function statCard(v, l) { return '<div class="stat"><div class="v">' + v + '</div><div class="l">' + l + '</div></div>'; }
  function emptyRow(cols) { return '<tr><td colspan="' + cols + '" style="color:var(--muted);text-align:center;padding:24px">Belum ada data.</td></tr>'; }

  function loadLogs() {
    api('get_logs', { query: '&limit=200' }).then(function (res) {
      if (!res.ok) return;
      var b = $('#tblLogs');
      if (!res.logs.length) { b.innerHTML = emptyRow(6); return; }
      b.innerHTML = res.logs.map(function (l) {
        var src = l.utm_source ? '<span class="tag">' + esc(l.utm_source) + '</span>' : '<span class="tag none">(direct)</span>';
        var med = l.utm_medium ? '<span class="tag">' + esc(l.utm_medium) + '</span>' : '<span class="tag none">(none)</span>';
        return '<tr>' +
          '<td class="mono" style="white-space:nowrap;font-size:11.5px">' + esc(l.ts) + '</td>' +
          '<td class="q">' + esc(l.q) + '</td>' +
          '<td class="a">' + esc((l.a || '').slice(0, 160)) + ((l.a || '').length > 160 ? '…' : '') + '</td>' +
          '<td>' + src + '</td><td>' + med + '</td>' +
          '<td class="mono" style="font-size:11.5px;color:var(--muted)">' + esc(l.page || '') + '</td>' +
          '</tr>';
      }).join('');
    });
  }

  /* ====================================================================== *
   *  LOG PERCAKAPAN (v1.2.66) — filter + facet + paginasi + detail
   * ====================================================================== */
  var LG_ST = { ai: ['Dijawab AI', BRAND_C1], awaiting: ['Menunggu balasan', '#d97706'], manual: ['Balasan agent', '#16a34a'], closing: ['Closing otomatis', '#94a3b8'], error: ['Gagal / error', '#dc2626'], call: ['Telepon masuk', '#0891b2'] };   // v1.2.108: tolak-telepon
  var LG_CH = { web: 'Web', whatsapp: 'WhatsApp' };
  var lg = { page: 1, per: 25, status: '', preset: '30', rows: [], wired: false, t: null, seq: 0 };
  try { var _lp = +localStorage.getItem('dei_lg_per'); if ([25, 50, 100].indexOf(_lp) !== -1) lg.per = _lp; } catch (e) {}
  function lgYmd(d) { return d.getFullYear() + '-' + ('0' + (d.getMonth() + 1)).slice(-2) + '-' + ('0' + d.getDate()).slice(-2); }
  function lgApplyPreset(p) {
    var now = new Date(), from = '', to = lgYmd(now);
    if (p === 'today') from = to;
    else if (p === '7') from = lgYmd(new Date(now.getTime() - 6 * 864e5));
    else if (p === '30') from = lgYmd(new Date(now.getTime() - 29 * 864e5));
    else if (p === 'month') from = lgYmd(new Date(now.getFullYear(), now.getMonth(), 1));
    else if (p === 'all') { from = ''; to = ''; }
    $('#lgFrom').value = from; $('#lgTo').value = to;
    lg.preset = p;
    $$('#lgPresets button').forEach(function (b) { b.classList.toggle('on', b.dataset.p === p); });
  }
  function lgParams() {
    return '&from=' + encodeURIComponent($('#lgFrom').value) + '&to=' + encodeURIComponent($('#lgTo').value) +
      '&channel=' + encodeURIComponent($('#lgChannel').value) + '&source=' + encodeURIComponent($('#lgSource').value) +
      '&medium=' + encodeURIComponent($('#lgMedium').value) + '&campaign=' + encodeURIComponent($('#lgCampaign').value) +
      '&status=' + encodeURIComponent(lg.status) + '&q=' + encodeURIComponent($('#lgQ').value.trim());
  }
  function lgFillSelect(sel, items, labels) {
    var cur = sel.value, seen = false, total = 0;
    items.forEach(function (it) { total += it.count; });
    var h = '<option value="">Semua (' + total + ')</option>';
    items.forEach(function (it) {
      if (it.value === cur) seen = true;
      h += '<option value="' + esc(it.value) + '">' + esc((labels && labels[it.value]) || it.value) + ' (' + it.count + ')</option>';
    });
    if (cur && !seen) h += '<option value="' + esc(cur) + '">' + esc((labels && labels[cur]) || cur) + ' (0)</option>';
    sel.innerHTML = h; sel.value = cur;
  }
  function lgTsParts(ts) {
    var m = /^(\d{4})-(\d{2})-(\d{2})[ T](\d{2}:\d{2})/.exec(ts || '');
    if (!m) return [ts || '–', ''];
    var B = ['Jan', 'Feb', 'Mar', 'Apr', 'Mei', 'Jun', 'Jul', 'Agu', 'Sep', 'Okt', 'Nov', 'Des'];
    return [(+m[3]) + ' ' + B[+m[2] - 1] + ' ' + m[1].slice(2), m[4]];
  }
  function lgWho(r) {
    if (r.channel === 'whatsapp') return { main: r.name || ('+' + r.who), sub: r.name ? '+' + r.who : '' };
    var ip = r.who || '';
    return { main: ip.length > 18 ? ip.slice(0, 16) + '…' : (ip || 'Pengunjung'), sub: r.page || '' };
  }
  function lgStatus(st) { var x = LG_ST[st] || [st, '#999']; return '<span class="lg-st ' + esc(st) + '">' + esc(x[0]) + '</span>'; }
  function lgChan(ch) { return '<span class="lg-ch ' + esc(ch) + '">' + ico(ch === 'whatsapp' ? 'message-circle' : 'globe', 12) + ' ' + esc(LG_CH[ch] || ch) + '</span>'; }
  function lgRender(res) {
    var f = res.facets || {};
    lgFillSelect($('#lgChannel'), f.channel || [], LG_CH);
    lgFillSelect($('#lgSource'), f.source || []);
    lgFillSelect($('#lgMedium'), f.medium || []);
    lgFillSelect($('#lgCampaign'), f.campaign || []);
    // chip status (facet, mengabaikan filter status itu sendiri)
    var sc = {}, all = 0;
    (f.status || []).forEach(function (it) { sc[it.value] = it.count; all += it.count; });
    var ch = '<button type="button" class="lg-chip' + (lg.status === '' ? ' on' : '') + '" data-s="">Semua <b>' + all + '</b></button>';
    Object.keys(LG_ST).forEach(function (k) {
      if (!sc[k] && lg.status !== k) return;
      ch += '<button type="button" class="lg-chip' + (lg.status === k ? ' on' : '') + '" data-s="' + k + '"><span class="dot" style="background:' + LG_ST[k][1] + '"></span>' + LG_ST[k][0] + ' <b>' + (sc[k] || 0) + '</b></button>';
    });
    $('#lgChips').innerHTML = ch;
    $$('#lgChips .lg-chip').forEach(function (b) { b.onclick = function () { lg.status = b.dataset.s; lg.page = 1; lgLoad(); }; });

    lg.rows = res.rows || [];
    var from = $('#lgFrom').value, to = $('#lgTo').value;
    $('#lgCount').textContent = res.total.toLocaleString('id-ID') + ' percakapan';
    $('#lgSub').textContent = (from || to) ? (from ? lgTsParts(from + ' 00:00')[0] : 'awal') + ' – ' + (to ? lgTsParts(to + ' 00:00')[0] : 'sekarang') : 'Semua waktu';
    if (!lg.rows.length) {
      $('#lgBody').innerHTML = '<tr><td colspan="7" class="lg-empty">Tidak ada percakapan yang cocok dengan filter ini.</td></tr>';
    } else {
      $('#lgBody').innerHTML = lg.rows.map(function (r, i) {
        var t = lgTsParts(r.ts), w = lgWho(r);
        var ans = r.a ? esc(r.a.slice(0, 220)) : '<i style="opacity:.7">' + (r.status === 'awaiting' ? 'belum dibalas' : '—') + '</i>';
        var srcMed = (r.source === '(direct)' && r.medium === '(none)') ? '<span style="color:var(--muted)">(direct)</span>' : esc(r.source) + '<small>' + esc(r.medium) + '</small>';
        return '<tr data-i="' + i + '">' +
          '<td class="c-ts"><div class="lg-ts"><b>' + esc(t[0]) + '</b><span>' + esc(t[1]) + '</span></div></td>' +
          '<td class="c-ch">' + lgChan(r.channel) + '</td>' +
          '<td class="c-who"><div class="lg-who lg-clip"><b class="lg-clip">' + esc(w.main) + '</b><span class="lg-clip">' + esc(w.sub) + '</span></div></td>' +
          '<td class="lg-clip lg-q" title="' + esc((r.q || '').slice(0, 300)) + '">' + (r.q ? esc(r.q.slice(0, 220)) : (r.call_txt ? esc(r.call_txt) : '<i style="opacity:.6">(tanpa pesan)</i>')) + '</td>' +
          '<td class="lg-clip lg-a">' + ans + '</td>' +
          '<td class="c-src lg-clip lg-src">' + srcMed + '</td>' +
          '<td class="c-st">' + lgStatus(r.status) + '</td></tr>';
      }).join('');
      $$('#lgBody tr[data-i]').forEach(function (tr) { tr.onclick = function () { lgOpen(+tr.dataset.i); }; });
    }
    var a = res.total ? (res.page - 1) * res.per + 1 : 0, b = Math.min(res.total, res.page * res.per);
    lg.page = res.page;
    $('#lgPageInfo').textContent = a + '–' + b + ' dari ' + res.total.toLocaleString('id-ID') + ' · hal. ' + res.page + '/' + res.pages;
    $('#lgPrev').disabled = res.page <= 1;
    $('#lgNext').disabled = res.page >= res.pages;
  }
  function lgLoad() {
    var my = ++lg.seq;
    $('#lgBody').style.opacity = '.55';
    api('logs_query', { query: lgParams() + '&page=' + lg.page + '&per=' + lg.per }).then(function (res) {
      if (my !== lg.seq) return;          // abaikan respons lama
      $('#lgBody').style.opacity = '';
      if (!res || !res.ok) { $('#lgBody').innerHTML = '<tr><td colspan="7" class="lg-empty">' + esc((res && res.error) || 'Gagal memuat log.') + '</td></tr>'; return; }
      lgRender(res);
    }).catch(function () { $('#lgBody').style.opacity = ''; });
  }
  function lgOpen(i) {
    var r = lg.rows[i]; if (!r) return;
    var t = lgTsParts(r.ts), w = lgWho(r);
    $('#lgDrTitle').textContent = w.main;
    var meta = [
      ['Waktu', esc(t[0] + ' · ' + t[1] + ' WIB')], ['Channel', lgChan(r.channel)], ['Status', lgStatus(r.status)],
      [r.channel === 'whatsapp' ? 'Nomor' : 'IP', esc(r.channel === 'whatsapp' ? '+' + r.who : r.who)],
      ['Source', esc(r.source)], ['Medium', esc(r.medium)], ['Campaign', esc(r.campaign)]
    ];
    if (r.page) meta.push(['Halaman', esc(r.page)]);
    if (r.referrer) meta.push(['Referrer', esc(r.referrer)]);
    $('#lgDrBody').innerHTML =
      (r.q ? '<div class="lg-bub q"><small>Pengunjung</small>' + esc(r.q) + '</div>' : '') +
      (r.call_txt ? '<div class="lg-bub q"><small>Telepon</small>' + esc(r.call_txt) + '</div>' : '') +   // v1.2.108: tolak-telepon
      '<div class="lg-bub a"><small>' + (r.status === 'manual' ? 'Balasan agent' : (r.status === 'closing' ? 'Pesan closing' : (r.status === 'call' ? 'Pesan balasan telepon' : 'Jawaban AI'))) + '</small>' + (r.a ? esc(r.a) : '<i>' + (r.status === 'awaiting' ? 'Belum dibalas.' : '—') + '</i>') + '</div>' +
      '<dl class="lg-meta">' + meta.map(function (m) { return '<dt>' + m[0] + '</dt><dd>' + m[1] + '</dd>'; }).join('') + '</dl>';
    var foot = '';
    if (r.channel === 'whatsapp') foot += '<button class="btn sm" type="button" id="lgGoWa">' + ico('message-circle', 14) + ' Buka Percakapan WA</button>';
    foot += '<button class="btn ghost sm" type="button" id="lgCopy">' + ico('copy', 14) + ' Salin teks</button>';
    $('#lgDrFoot').innerHTML = foot;
    if ($('#lgGoWa')) $('#lgGoWa').onclick = function () { lgClose(); showTab('wachat'); };
    $('#lgCopy').onclick = function () {
      var txt = (r.q ? 'Q: ' + r.q + '\n' : '') + 'A: ' + (r.a || '');
      try { navigator.clipboard.writeText(txt).then(function () { toast('Teks disalin.'); }); } catch (e) {}
    };
    $('#lgDrawer').classList.add('open');
    $('#lgDrawer').setAttribute('aria-hidden', 'false');
  }
  function lgClose() { $('#lgDrawer').classList.remove('open'); $('#lgDrawer').setAttribute('aria-hidden', 'true'); }
  function lgInit() {
    if (lg.wired) { lgLoad(); return; }
    lg.wired = true;
    $('#lgPer').value = String(lg.per);
    lgApplyPreset('30');
    $$('#lgPresets button').forEach(function (b) { b.onclick = function () { lgApplyPreset(b.dataset.p); lg.page = 1; lgLoad(); }; });
    ['#lgFrom', '#lgTo'].forEach(function (id) {
      $(id).onchange = function () { lg.preset = ''; $$('#lgPresets button').forEach(function (b) { b.classList.remove('on'); }); lg.page = 1; lgLoad(); };
    });
    ['#lgChannel', '#lgSource', '#lgMedium', '#lgCampaign'].forEach(function (id) { $(id).onchange = function () { lg.page = 1; lgLoad(); }; });
    $('#lgQ').oninput = function () { clearTimeout(lg.t); lg.t = setTimeout(function () { lg.page = 1; lgLoad(); }, 350); };
    $('#lgPer').onchange = function () { lg.per = +this.value; try { localStorage.setItem('dei_lg_per', lg.per); } catch (e) {} lg.page = 1; lgLoad(); };
    $('#lgPrev').onclick = function () { if (lg.page > 1) { lg.page--; lgLoad(); } };
    $('#lgNext').onclick = function () { lg.page++; lgLoad(); };
    $('#lgReset').onclick = function () {
      ['#lgChannel', '#lgSource', '#lgMedium', '#lgCampaign'].forEach(function (id) { $(id).value = ''; });
      $('#lgQ').value = ''; lg.status = ''; lg.page = 1; lgApplyPreset('30'); lgLoad();
    };
    $('#lgExport').onclick = function () {
      window.location.href = API + '?action=export_logs&token=' + encodeURIComponent(token) + lgParams();
      toast('Mengunduh CSV sesuai filter…');
    };
    $$('#lgDrawer [data-close]').forEach(function (el) { el.onclick = lgClose; });
    document.addEventListener('keydown', function (e) { if (e.key === 'Escape' && $('#lgDrawer').classList.contains('open')) lgClose(); });
    lgLoad();
  }
  /* ====================================================================== *
   *  SCAN TOPIK (v1.2.67) — topik percakapan per periode (AI)
   * ====================================================================== */
  var TP_PER = [[7, '7 hari'], [14, '14 hari'], [30, '30 hari'], [60, '60 hari'], [90, '90 hari'], [180, '6 bulan'], [365, '1 tahun']];
  var TP_SENT = { positif: 'Positif', netral: 'Netral', negatif: 'Negatif' };
  var TP_COL = (BRAND && BRAND.palette && BRAND.palette.length) ? BRAND.palette : ['#140383', '#3b2fb8', '#5b4fe0', '#7c6ff0', '#8b5cf6', '#a855f7', '#c084fc', '#6366f1', '#4338ca', '#818cf8'];
  var tp = { days: 30, scans: {}, loaded: false, busy: false, logLimit: 500, quota: null };
  try { var _td = +localStorage.getItem('dei_tp_days'); if (TP_PER.some(function (p) { return p[0] === _td; })) tp.days = _td; } catch (e) {}
  function tpKey() { return tp.days + '|' + ($('#tpChannel').value || 'all'); }
  function tpDate(d) { var x = lgTsParts((d || '') + ' 00:00'); return x[0]; }
  function tpRenderPeriods() {
    var ch = $('#tpChannel').value || 'all';
    $('#tpPeriods').innerHTML = TP_PER.map(function (p) {
      var has = !!tp.scans[p[0] + '|' + ch];
      return '<button type="button" data-d="' + p[0] + '" class="' + (p[0] === tp.days ? 'on' : '') + '">' + p[1] + (has ? '<i class="tp-has" title="Sudah pernah dipindai"></i>' : '') + '</button>';
    }).join('');
    $$('#tpPeriods button').forEach(function (b) {
      b.onclick = function () { if (tp.busy) return; tp.days = +b.dataset.d; try { localStorage.setItem('dei_tp_days', tp.days); } catch (e) {} tpRenderPeriods(); tpRender(); };
    });
  }
  function tpQuotaOut() { var q = tp.quota; return !!(q && q.limit > 0 && q.used >= q.limit); }
  function tpRenderQuota() {
    var el = $('#tpQuota'), q = tp.quota;
    if (!q) { el.style.display = 'none'; return; }
    el.style.display = '';
    if (!(q.limit > 0)) { el.className = 'tp-quota'; el.textContent = 'Kuota scan: tanpa batas'; el.title = 'Terpakai ' + q.used + ' kali bulan ini'; return; }
    var left = Math.max(0, q.limit - q.used);
    el.className = 'tp-quota' + (left === 0 ? ' out' : (left <= Math.max(1, Math.round(q.limit * 0.2)) ? ' low' : ''));
    el.textContent = 'Kuota scan: ' + left + '/' + q.limit + ' tersisa';
    el.title = 'Terpakai ' + q.used + ' dari ' + q.limit + ' scan bulan ini. Direset ' + tpDate(q.reset) + '.';
  }
  function tpRender() {
    tpRenderQuota();
    var r = tp.scans[tpKey()];
    var lbl = (TP_PER.filter(function (p) { return p[0] === tp.days; })[0] || [0, ''])[1];
    var canRun = can('super_admin,admin');
    $('#tpRun').style.display = canRun ? '' : 'none';
    $('#tpRun').innerHTML = ico('sparkles', 15) + (r ? ' Scan ulang' : ' Scan topik');
    $('#tpRun').disabled = tpQuotaOut();
    $('#tpRun').title = tpQuotaOut() ? 'Kuota scan topik bulan ini habis. Direset ' + tpDate(tp.quota.reset) + '.' : '';
    if (!r) {
      $('#tpNote').innerHTML = '';
      $('#tpResult').innerHTML = '<div class="tp-empty">' + ico('sparkles', 28) + '<b>Belum ada hasil scan untuk ' + esc(lbl) + '</b>' +
        '<span>' + (tpQuotaOut() ? 'Kuota scan topik bulan ini sudah habis (' + tp.quota.used + '/' + tp.quota.limit + '). Kuota direset ' + esc(tpDate(tp.quota.reset)) + '. Hubungi ' + BRAND_VENDOR + ' untuk menambah kuota.' : canRun ? 'Tekan <b>Scan topik</b>. AI akan membaca percakapan pelanggan di periode ini dan mengelompokkannya menjadi topik (sekitar 15–60 detik, memakai kuota AI).' : 'Minta Admin menjalankan scan topik.') + '</span></div>';
      return;
    }
    var note = [];
    if (r.oldest_log && r.from < r.oldest_log && r.log_entries >= tp.logLimit * 0.98) note.push(ico('triangle-alert', 13, 'style="vertical-align:-2px"') + ' Log terlama yang masih tersimpan dari <b>' + esc(tpDate(r.oldest_log)) + '</b> (batas ' + tp.logLimit + ' entri sudah penuh), jadi periode ini belum tercakup penuh.' + (role === 'super_admin' ? ' Naikkan <i>Batas log</i> di Widget &amp; API untuk periode panjang.' : ''));
    $('#tpNote').innerHTML = note.join('<br>');
    var head = '<div class="tp-stats">' +
      '<div><small>Periode</small><b>' + esc(tpDate(r.from)) + ' – ' + esc(tpDate(r.to)) + '</b></div>' +
      '<div><small>Percakapan</small><b>' + r.total.toLocaleString('id-ID') + '</b></div>' +
      '<div><small>Dianalisis AI</small><b>' + r.sampled.toLocaleString('id-ID') + (r.sampled < r.total ? ' <em>sampel</em>' : '') + '</b></div>' +
      '<div><small>Web · WhatsApp</small><b>' + (r.by_channel.web || 0) + ' · ' + (r.by_channel.whatsapp || 0) + '</b></div>' +
      '<div><small>Dipindai</small><b>' + esc(lgTsParts(r.scanned_at).join(' · ')) + '</b></div></div>';
    if (r.empty || !r.topics.length) {
      $('#tpResult').innerHTML = head + '<div class="tp-empty"><b>Percakapan di periode ini terlalu sedikit untuk dianalisis.</b><span>Coba periode yang lebih panjang.</span></div>';
      return;
    }
    var max = Math.max.apply(null, r.topics.map(function (t) { return t.pct; }));
    var html = head + (r.insight ? '<div class="tp-insight">' + ico('sparkles', 16) + '<p>' + esc(r.insight) + '</p></div>' : '') + '<div class="tp-list">';
    r.topics.forEach(function (t, i) {
      var col = t.unassigned || t.name.toLowerCase() === 'lainnya' ? '#94a3b8' : TP_COL[i % TP_COL.length];
      var wa = t.by_channel.whatsapp || 0, web = t.by_channel.web || 0;
      html += '<div class="tp-item" data-i="' + i + '">' +
        '<button type="button" class="tp-row">' +
          '<span class="tp-rank">' + (i + 1) + '</span>' +
          '<span class="tp-main"><span class="tp-name">' + esc(t.name) + '</span>' +
            '<span class="tp-track"><span class="tp-fill" style="width:' + Math.max(3, t.pct / max * 100).toFixed(1) + '%;background:' + col + '"></span></span></span>' +
          '<span class="tp-num"><b>' + t.pct.toLocaleString('id-ID') + '%</b><small>≈ ' + t.est.toLocaleString('id-ID') + ' chat</small></span>' +
          '<span class="tp-sent ' + esc(t.sentiment) + '">' + esc(TP_SENT[t.sentiment] || t.sentiment) + '</span>' +
          '<span class="tp-chev">' + ico('chevron-down', 16) + '</span>' +
        '</button>' +
        '<div class="tp-det">' +
          (t.summary ? '<p>' + esc(t.summary) + '</p>' : '') +
          (t.action ? '<div class="tp-act"><b>Saran</b> ' + esc(t.action) + '</div>' : '') +
          '<div class="tp-split">' + ico('message-circle', 13) + ' WhatsApp ' + wa + ' &nbsp;·&nbsp; ' + ico('globe', 13) + ' Web ' + web + ' <span>(dari sampel)</span></div>' +
          (t.examples && t.examples.length ? '<div class="tp-ex"><small>Contoh pesan pelanggan</small>' + t.examples.map(function (e) {
            return '<blockquote>“' + esc(e.text) + '”<cite>' + (e.ch === 'whatsapp' ? 'WA' : 'Web') + ' · ' + esc(tpDate(e.day)) + '</cite></blockquote>';
          }).join('') + '</div>' : '') +
        '</div></div>';
    });
    html += '</div>';
    $('#tpResult').innerHTML = html;
    $$('#tpResult .tp-row').forEach(function (b) { b.onclick = function () { b.parentNode.classList.toggle('open'); }; });
    var first = document.querySelector('#tpResult .tp-item'); if (first) first.classList.add('open');
  }
  function tpRun() {
    if (tp.busy || tpQuotaOut()) return;
    var q = tp.quota;
    if (q && q.limit > 0 && !confirmTpOnce(q)) return;
    tp.busy = true;
    var btn = $('#tpRun'); btn.disabled = true;
    btn.innerHTML = '<span class="tp-spin"></span> Menganalisis…';
    $('#tpResult').classList.add('tp-loading');
    api('topic_scan_run', { method: 'POST', body: { days: tp.days, channel: $('#tpChannel').value } }).then(function (res) {
      tp.busy = false; btn.disabled = false; $('#tpResult').classList.remove('tp-loading');
      if (res && res.quota) tp.quota = res.quota;
      if (!res || !res.ok) { toast((res && res.error) || 'Scan topik gagal.', true); tpRender(); return; }
      tp.scans[tpKey()] = res.scan;
      tpRenderPeriods(); tpRender();
      toast('Scan topik selesai.');
    }).catch(function () { tp.busy = false; btn.disabled = false; $('#tpResult').classList.remove('tp-loading'); tpRender(); toast('Koneksi terputus saat scan.', true); });
  }
  // Konfirmasi ringan (tanpa dialog browser): klik pertama mengubah tombol jadi "Yakin? pakai 1 kuota", klik kedua menjalankan.
  var tpArmT = null;
  function confirmTpOnce(q) {
    var btn = $('#tpRun');
    if (btn.dataset.armed === '1') { btn.dataset.armed = ''; clearTimeout(tpArmT); return true; }
    btn.dataset.armed = '1';
    btn.innerHTML = ico('sparkles', 15) + ' Klik lagi: pakai 1 kuota (sisa ' + Math.max(0, q.limit - q.used) + ')';
    tpArmT = setTimeout(function () { btn.dataset.armed = ''; tpRender(); }, 4000);
    return false;
  }
  function tpInit() {
    if (!tp.wired) {
      tp.wired = true;
      $('#tpRun').onclick = tpRun;
      $('#tpChannel').onchange = function () { tpRenderPeriods(); tpRender(); };
    }
    tpRenderPeriods(); tpRender();
    api('topic_scan_get').then(function (res) {
      if (!res || !res.ok) return;
      tp.scans = res.scans || {}; tp.logLimit = res.log_limit || 500; tp.quota = res.quota || null;
      if (!tp.busy) { tpRenderPeriods(); tpRender(); }
    });
  }

  /* ====================================================================== *
   *  v1.2.101: percakapan — Laporan › Kinerja Layanan
   * ====================================================================== */
  var sv = { wired: false, kind: '', page: 1, per: 25, last: null };
  var SV_STATUS = { open: ['Ditangani bot', '#e0e7ff', '#3730a3'], handover: ['Menunggu agent', '#fee2e2', '#b91c1c'], assigned: ['Ditangani agent', '#fef3c7', '#92400e'],
                    resolved: ['Selesai', '#dcfce7', '#166534'], expired: ['Kedaluwarsa', '#e5e7eb', '#374151'] };
  var SV_REASON = { keyword: 'Kata kunci handoff', ai_limit: 'Batas balasan AI', ai_fail: 'AI gagal menjawab', manual_mode: 'Mode Manual', mode_human: 'Nomor sudah mode manusia',
                    takeover: 'Diambil alih admin', agent_reply: 'Agent langsung membalas', assign: 'Di-assign admin/routing', claimed: 'Masih dipegang agent',
                    escalation: 'Eskalasi darurat', outbound: 'Agent memulai chat', lainnya: 'Lainnya' };
  var SV_DAYS = ['', 'Senin', 'Selasa', 'Rabu', 'Kamis', 'Jumat', 'Sabtu', 'Minggu'];
  function svDur(s) {
    if (s == null) return '–';
    s = Math.max(0, Math.round(s));
    if (s < 60) return s + ' dtk';
    var d = Math.floor(s / 86400), h = Math.floor(s % 86400 / 3600), m = Math.floor(s % 3600 / 60), x = s % 60;
    if (d) return d + ' hari ' + h + ' jam';
    if (h) return h + ' jam ' + m + ' mnt';
    return m + ' mnt ' + x + ' dtk';
  }
  function svNum(n) { return n == null ? '–' : Number(n).toLocaleString('id-ID'); }
  function svPct(n) { return n == null ? '–' : String(n).replace('.', ',') + '%'; }
  // selisih vs periode sebelumnya. lowerBetter: waktu (makin kecil makin baik)
  function svDelta(cur, prev, isTime, lowerBetter) {
    if (!sv.last || !sv.last.prev || !sv.last.prev.has_data || cur == null || prev == null) return '<div class="sv-d">–</div>';
    var diff = cur - prev;
    if (diff === 0) return '<div class="sv-d">sama dengan periode lalu</div>';
    var good = lowerBetter ? diff < 0 : diff > 0;
    var txt;
    if (isTime) txt = (diff < 0 ? 'lebih cepat ' : 'lebih lambat ') + svDur(Math.abs(diff));
    else txt = (diff > 0 ? '▲ ' : '▼ ') + svNum(Math.abs(diff)) + (prev ? ' (' + Math.round(Math.abs(diff) * 100 / prev) + '%)' : '');
    return '<div class="sv-d ' + (good ? 'up' : 'down') + '">' + txt + '</div>';
  }
  function svCard(label, value, sub, delta, tip, kind) {
    return '<div class="sv-c' + (kind ? ' sv-click' : '') + '"' + (kind ? ' data-kind="' + kind + '"' : '') + (tip ? ' title="' + esc(tip) + '"' : '') + '>' +
      '<div class="sv-l">' + label + '</div><div class="sv-v">' + value + '</div>' +
      (sub ? '<div class="sv-s">' + sub + '</div>' : '') + (delta || '') + '</div>';
  }
  function svBars(vals, labels, color, fmt) {
    var max = Math.max(1, Math.max.apply(null, vals));
    var W = 520, H = 170, pl = 30, pb = 22, pt = 14, n = vals.length, bw = (W - pl - 6) / n;
    var g = '';
    for (var k = 0; k <= 4; k++) {
      var yy = pt + (H - pt - pb) * k / 4;
      g += '<line x1="' + pl + '" y1="' + yy + '" x2="' + W + '" y2="' + yy + '" stroke="var(--line)"/><text x="' + (pl - 4) + '" y="' + (yy + 3) + '" text-anchor="end" font-size="9" fill="var(--muted)">' + Math.round(max * (1 - k / 4)) + '</text>';
    }
    vals.forEach(function (v, i) {
      var h = (H - pt - pb) * v / max, x = pl + i * bw + bw * 0.15;
      g += '<rect x="' + x.toFixed(1) + '" y="' + (H - pb - h).toFixed(1) + '" width="' + (bw * 0.7).toFixed(1) + '" height="' + h.toFixed(1) + '" rx="2" fill="' + color + '"><title>' + esc(labels[i]) + ': ' + (fmt ? fmt(v) : v) + '</title></rect>';
      if (n <= 8 || i % 3 === 0) g += '<text x="' + (x + bw * 0.35).toFixed(1) + '" y="' + (H - 7) + '" text-anchor="middle" font-size="9" fill="var(--muted)">' + esc(labels[i]) + '</text>';
    });
    return '<svg viewBox="0 0 ' + W + ' ' + H + '" width="100%" style="max-width:560px;display:block">' + g + '</svg>';
  }
  function svLines(rows, series) {
    if (!rows.length) return '<div style="color:var(--muted);padding:24px;text-align:center">Belum ada data.</div>';
    var W = 520, H = 190, pl = 30, pb = 22, pt = 10, pr = 8, n = rows.length;
    var max = 1; rows.forEach(function (d) { series.forEach(function (s) { max = Math.max(max, d[s.key]); }); });
    function X(i) { return pl + (n <= 1 ? (W - pl - pr) / 2 : i / (n - 1) * (W - pl - pr)); }
    function Y(v) { return pt + (H - pt - pb) * (1 - v / max); }
    var g = '';
    for (var k = 0; k <= 4; k++) { var yy = pt + (H - pt - pb) * k / 4; g += '<line x1="' + pl + '" y1="' + yy + '" x2="' + (W - pr) + '" y2="' + yy + '" stroke="var(--line)"/><text x="' + (pl - 4) + '" y="' + (yy + 3) + '" text-anchor="end" font-size="9" fill="var(--muted)">' + Math.round(max * (1 - k / 4)) + '</text>'; }
    series.forEach(function (s) {
      g += '<polyline fill="none" stroke="' + s.color + '" stroke-width="2" points="' + rows.map(function (d, i) { return X(i).toFixed(1) + ',' + Y(d[s.key]).toFixed(1); }).join(' ') + '"/>';
      if (n <= 45) g += rows.map(function (d, i) { return '<circle cx="' + X(i).toFixed(1) + '" cy="' + Y(d[s.key]).toFixed(1) + '" r="2.4" fill="' + s.color + '"><title>' + d.date + ' · ' + s.label + ': ' + d[s.key] + '</title></circle>'; }).join('');
    });
    var ev = Math.ceil(n / 8);
    rows.forEach(function (d, i) { if (i % ev === 0 || i === n - 1) g += '<text x="' + X(i).toFixed(1) + '" y="' + (H - 6) + '" text-anchor="middle" font-size="8.5" fill="var(--muted)">' + d.date.slice(8) + '/' + d.date.slice(5, 7) + '</text>'; });
    var lg = series.map(function (s) { return '<span style="display:inline-flex;align-items:center;gap:5px;margin-right:14px"><span style="width:14px;height:3px;border-radius:2px;background:' + s.color + '"></span>' + s.label + '</span>'; }).join('');
    return '<div style="font-size:12px;color:var(--muted);margin-bottom:6px">' + lg + '</div><svg viewBox="0 0 ' + W + ' ' + H + '" width="100%" style="max-width:560px;display:block">' + g + '</svg>';
  }
  function svQuery() {
    var q = '&from=' + encodeURIComponent($('#svFrom').value) + '&to=' + encodeURIComponent($('#svTo').value);
    if ($('#svCh') && $('#svCh').value) q += '&ch=' + encodeURIComponent($('#svCh').value);
    return q;
  }
  function svLoad() {
    $('#svConv').innerHTML = '<div style="color:var(--muted);padding:8px">Memuat…</div>';
    api('conv_report', { query: svQuery() }).then(function (r) {
      if (!r || !r.ok) { $('#svConv').innerHTML = '<div style="color:#b91c1c;padding:8px">' + esc((r && r.error) || 'Gagal memuat laporan.') + '</div>'; return; }
      sv.last = r; svRender(r);
      sv.page = 1; svList();
    });
  }
  function svRender(r) {
    var T = r.totals, A = r.avg, P = r.prev.totals, PA = r.prev.avg;
    var chs = r.channels_all || [];
    if (chs.length > 1 && $('#svCh').options.length <= 1) {
      $('#svCh').innerHTML = '<option value="">Semua nomor</option>' + chs.map(function (c) { return '<option value="' + esc(c.id) + '">' + esc(c.label) + '</option>'; }).join('');
      $('#svChWrap').style.display = '';
    }
    var since = r.tracking_since ? new Date(r.tracking_since * 1000).toLocaleDateString('id-ID', { day: 'numeric', month: 'long', year: 'numeric' }) : null;
    $('#svNote').innerHTML = (since ? 'Data percakapan tercatat sejak <b>' + since + '</b>. ' : 'Belum ada percakapan tercatat — data mulai terkumpul sejak pembaruan ini terpasang. ') +
      'Dibandingkan dengan ' + esc(r.prev.from) + ' s/d ' + esc(r.prev.to) + '. Percakapan selesai otomatis bila pelanggan diam ' + r.timeout_hours + ' jam setelah balasan terakhir; pesan dalam ' + r.reopen_minutes + ' menit setelah selesai membuka percakapan yang sama.';
    var dl = function (k, lb) { return svDelta(T[k], P[k], false, lb); };
    var dt = function (k) { return svDelta(A[k], PA[k], true, true); };
    // v1.2.126: respon-median — median jadi angka utama (tidak terseret satu-dua chat sangat lama)
    var M = r.med || {}, X = r.max || {}, PM = r.prev.med || {};
    var dtm = function (k) { return svDelta(M[k], PM[k], true, true); };
    // v1.2.127: respon-kata — kalimat sederhana; rata-rata di tooltip
    var subm = function (pre, k) { return pre + (X[k] != null && X[k] > (M[k] || 0) ? ' · paling lama ' + svDur(X[k]) : ''); };
    var tipm = function (who, k) { return 'Separuh chat dibalas ' + who + ' dalam ' + svDur(M[k]) + ' atau lebih cepat (median).' + (A[k] != null ? ' Rata-rata ' + svDur(A[k]) + (A[k] > (M[k] || 0) * 3 ? ' — terseret beberapa chat yang sangat lama.' : '.') : ''); };
    $('#svConv').innerHTML =
      svCard('Total Percakapan', svNum(T.total), svNum(T.customers) + ' pelanggan · ' + svNum(T.outbound) + ' dimulai agent', dl('total'), '', 'all') +
      svCard('Belum Di-assign', svNum(T.unassigned), 'menunggu agent saat ini', '', 'Sudah diserahkan ke manusia tapi belum ada agent yang memegang.', 'unassigned') +
      svCard('Di-assign ke Agent', svNum(T.assigned), svNum(T.in_progress) + ' masih berjalan', dl('assigned'), '', 'assigned') +
      svCard('Diselesaikan', svNum(T.resolved), svPct(A.resolved_rate) + ' · ' + svNum(T.resolved_agent) + ' ditandai agent', dl('resolved'), 'Ditandai Selesai oleh agent, pelanggan pamit, atau pelanggan diam 24 jam setelah dibalas.', 'resolved');
    $('#svTime').innerHTML =
      svCard('Respon Pertama Bot', svDur(M.frt_bot), subm('umumnya', 'frt_bot'), dtm('frt_bot'), tipm('bot', 'frt_bot') + ' Dihitung dari pesan pertama pelanggan.') +
      svCard('Respon Pertama Agent', svDur(M.frt_agent), subm('umumnya, sejak diserahkan', 'frt_agent'), dtm('frt_agent'), tipm('agent', 'frt_agent') + ' Dihitung sejak chat diserahkan ke agent.') +
      svCard('Waktu Antre', svDur(A.wait), 'sampai di-assign', dt('wait'), 'Rata-rata jeda dari diserahkan ke manusia sampai ada agent yang memegang.') +
      svCard('Waktu Respon Agent', svDur(A.resp_agent), 'tiap pesan pelanggan', dt('resp_agent'), 'Rata-rata jeda setiap pesan pelanggan sampai dibalas agent.') +
      svCard('Waktu Penyelesaian', svDur(A.resolution), 'dibuka → selesai', dt('resolution'), 'Rata-rata dari percakapan dibuka sampai selesai.');
    $('#svBot').innerHTML = T.bot_handled === 0
      ? '<div class="sv-c" style="grid-column:1/-1;color:var(--muted)">Belum ada percakapan yang dijawab bot pada periode ini' + (T.total ? ' (Mode Manual / bot WhatsApp nonaktif).' : '.') + '</div>'
      : svCard('Ditangani Bot', svNum(T.bot_handled), 'percakapan dibalas bot', dl('bot_handled')) +
        svCard('Diselesaikan Bot', svNum(T.bot_resolved), svPct(A.bot_rate) + ' tanpa bantuan agent', dl('bot_resolved'), '', 'bot_resolved') +
        svCard('Diserahkan ke Agent', svNum(T.to_agent), svPct(A.handover_rate) + ' dari yang ditangani bot', dl('to_agent', true), '', 'to_agent') +
        svCard('Waktu Selesai oleh Bot', svDur(A.bot_resolution), 'dibuka → selesai', dt('bot_resolution'));
    $('#svTrend').innerHTML = svLines(r.daily, [{ key: 'bot_resolved', label: 'Diselesaikan bot', color: BRAND_C1 }, { key: 'to_agent', label: 'Diserahkan ke agent', color: '#f59e0b' }, { key: 'total', label: 'Total', color: '#94a3b8' }]);
    var rs = Object.keys(r.handover_reasons || {}), rtot = rs.reduce(function (a, k) { return a + r.handover_reasons[k]; }, 0);
    $('#svReasons').innerHTML = rs.length ? rs.map(function (k) {
      var v = r.handover_reasons[k], p = Math.round(v * 100 / rtot);
      return '<div style="margin:8px 0"><div style="display:flex;justify-content:space-between;font-size:13px"><span>' + esc(SV_REASON[k] || k) + '</span><span class="mono" style="color:var(--muted)">' + v + ' · ' + p + '%</span></div>' +
        '<div style="height:7px;background:var(--brand-soft);border-radius:4px;margin-top:4px"><div style="height:100%;width:' + p + '%;background:var(--brand);border-radius:4px"></div></div></div>';
    }).join('') : '<div style="color:var(--muted);padding:24px;text-align:center">Tidak ada percakapan yang diserahkan ke agent.</div>';
    var hl = []; for (var h = 0; h < 24; h++) hl.push((h < 10 ? '0' : '') + h);
    $('#svHourly').innerHTML = svBars(r.hourly, hl, BRAND_C1);
    var pk = r.hourly.indexOf(Math.max.apply(null, r.hourly));
    $('#svHourlyNote').textContent = T.inbound ? 'Paling ramai pukul ' + hl[pk] + ':00–' + hl[(pk + 1) % 24] + ':00 WIB.' : '';
    $('#svWeekday').innerHTML = svBars(r.weekday.map(function (w) { return w.avg; }), r.weekday.map(function (w) { return SV_DAYS[w.day].slice(0, 3); }), BRAND_C2, function (v) { return String(v).replace('.', ',') + ' per hari'; });
    $('#svAgents').innerHTML = r.agents.length ? r.agents.map(function (a) {
      return '<tr><td><b>' + esc(a.name || a.agent) + '</b>' + (a.name && a.name !== a.agent ? ' <span style="color:var(--muted);font-size:12px">' + esc(a.agent) + '</span>' : '') + '</td>' +
        '<td class="mono r">' + svNum(a.assigned) + '</td><td class="mono r">' + svNum(a.resolved) + '</td><td class="mono r">' + svNum(a.in_progress) + '</td>' +
        '<td class="mono r">' + svDur(a.frt) + '</td><td class="mono r">' + svDur(a.resp) + '</td><td class="mono r">' + svDur(a.resolution) + '</td><td class="mono r">' + svNum(a.msgs) + '</td></tr>';
    }).join('') : emptyRow(8);
    $('#svChCard').style.display = (r.channels.length > 1 || chs.length > 1) ? '' : 'none';
    $('#svChans').innerHTML = r.channels.length ? r.channels.map(function (c) {
      return '<tr><td><b>' + esc(c.label) + '</b></td><td class="mono r">' + svNum(c.total) + '</td><td class="mono r">' + svNum(c.bot_resolved) + '</td><td class="mono r">' + svNum(c.to_agent) + '</td>' +
        '<td class="mono r">' + svNum(c.unassigned) + '</td><td class="mono r">' + svNum(c.resolved) + '</td><td class="mono r">' + svDur(c.frt) + '</td><td class="mono r">' + svDur(c.frt_agent) + '</td><td class="mono r">' + svDur(c.resolution) + '</td></tr>';
    }).join('') : emptyRow(9);
    $$('#repService .sv-click').forEach(function (el) { el.onclick = function () { svSetKind(el.dataset.kind === 'all' ? '' : el.dataset.kind); $('#svListCard').scrollIntoView({ behavior: 'smooth', block: 'start' }); }; });
  }
  function svSetKind(k) {
    sv.kind = k; sv.page = 1;
    $$('#svChips .lg-chip').forEach(function (b) { b.classList.toggle('on', b.dataset.k === k); });
    svList();
  }
  function svList() {
    api('conv_list', { query: svQuery() + '&kind=' + encodeURIComponent(sv.kind) + '&page=' + sv.page + '&per=' + sv.per }).then(function (r) {
      if (!r || !r.ok) { $('#svRows').innerHTML = emptyRow(7); return; }
      var RB = { agent: 'Agent', guest_bye: 'Pelanggan pamit', timeout: 'Otomatis (diam 24 jam)' };
      $('#svRows').innerHTML = r.rows.length ? r.rows.map(function (c) {
        var st = SV_STATUS[c.status] || [c.status, '#eee', '#333'];
        var opened = new Date(c.opened_at * 1000);
        var tgl = opened.toLocaleDateString('id-ID', { day: '2-digit', month: 'short' }) + ' ' + opened.toLocaleTimeString('id-ID', { hour: '2-digit', minute: '2-digit' });
        var frt = c.first_reply_at ? c.first_reply_at - c.opened_at : null;
        var res = c.resolved_at ? c.resolved_at - c.opened_at : null;
        var by = c.status === 'resolved' ? (RB[c.resolved_by] || c.resolved_by) + (c.resolved_by === 'agent' && c.resolver ? ' (' + esc(c.resolver) + ')' : '') : '';
        return '<tr class="sv-row" data-num="' + esc(c.num) + '"><td class="mono" style="white-space:nowrap">' + esc(tgl) + '</td>' +
          '<td><b>' + esc(c.name || ('+' + c.num)) + '</b>' + (c.name ? '<div style="color:var(--muted);font-size:12px">+' + esc(c.num) + '</div>' : '') +
          (c.origin === 'outbound' ? ' <span class="tag" style="background:#ede9fe;color:#5b21b6">dimulai agent</span>' : '') + (c.reopen_n ? ' <span class="tag">dibuka ulang ' + c.reopen_n + 'x</span>' : '') + '</td>' +
          '<td><span class="tag" style="background:' + st[1] + ';color:' + st[2] + '">' + st[0] + '</span>' + (c.handover_reason ? '<div style="color:var(--muted);font-size:11.5px;margin-top:3px">' + esc(SV_REASON[c.handover_reason] || c.handover_reason) + '</div>' : '') + '</td>' +
          '<td>' + esc(c.agent || '–') + '</td><td class="mono r">' + svDur(frt) + '</td><td class="mono r">' + svDur(res) + '</td><td style="font-size:12.5px">' + (by || '–') + '</td></tr>';
      }).join('') : emptyRow(7);
      var pages = Math.max(1, Math.ceil(r.total / r.per));
      $('#svPageInfo').textContent = svNum(r.total) + ' percakapan · hal ' + r.page + '/' + pages;
      $('#svPrev').disabled = r.page <= 1; $('#svNext').disabled = r.page >= pages;
      $$('#svRows .sv-row').forEach(function (tr) { tr.onclick = function () { openLeadConv(tr.dataset.num); }; });
    });
  }
  function svInit() {
    if (sv.wired) { if (!sv.last) svLoad(); return; }
    sv.wired = true;
    var now = new Date(Date.now() + 7 * 3600e3), today = now.toISOString().slice(0, 10);
    $('#svFrom').value = today.slice(0, 8) + '01'; $('#svTo').value = today;
    $$('#svPresets button').forEach(function (b) {
      b.onclick = function () {
        var p = b.dataset.p, t = new Date(Date.now() + 7 * 3600e3), f;
        if (p === 'month') f = t.toISOString().slice(0, 8) + '01';
        else if (p === 'last') { var d = new Date(Date.UTC(t.getUTCFullYear(), t.getUTCMonth(), 0)); $('#svTo').value = d.toISOString().slice(0, 10); f = d.toISOString().slice(0, 8) + '01'; }
        else f = new Date(t.getTime() - (+p - 1) * 864e5).toISOString().slice(0, 10);
        $('#svFrom').value = f; if (p !== 'last') $('#svTo').value = t.toISOString().slice(0, 10);
        $$('#svPresets button').forEach(function (x) { x.classList.toggle('on', x === b); });
        svLoad();
      };
    });
    $('#svApply').onclick = svLoad;
    $('#svCh').onchange = svLoad;
    $('#svExport').onclick = function () {
      window.location.href = API + '?action=conv_export&token=' + encodeURIComponent(token) + svQuery() + '&kind=' + encodeURIComponent(sv.kind);
      toast('Mengunduh CSV…');
    };
    $$('#svChips .lg-chip').forEach(function (b) { b.onclick = function () { svSetKind(b.dataset.k); }; });
    $('#svPrev').onclick = function () { if (sv.page > 1) { sv.page--; svList(); } };
    $('#svNext').onclick = function () { sv.page++; svList(); };
    svLoad();
  }

  // v1.2.101: tombol Selesai di thread WA
  function resolveConv(num) {
    var b = $('#waResolveBtn'); if (b) b.disabled = true;
    var li = waConvOf140(num) || {};   // v1.2.131: log-selesai; v1.2.148: selesai-tanpa-flag
    api('wa_resolve', { method: 'POST', body: { number: num, prev_flag: li.flag || '', waiting_sec: li.waiting_sec || 0, last_msg: li.last_q || '' } }).then(function (res) {
      if (res && res.ok) {
        (waState.res148 = waState.res148 || {})[String(num)] = li.last_ts || true;   // v1.2.148: diingat untuk mode cadangan
        if (li.number !== undefined) {   // v1.2.148: selesai-tanpa-flag — jangan tunggu polling
          li.flag = 'done'; li.flag_note = 'Ditandai selesai' + (waState.me ? ' oleh ' + waState.me : '');
          li.needs_attention = false; li.awaiting = false; li.waiting_sec = 0; li.claim = null;
          if (li.status === 'claimed' || li.status === 'human_unclaimed' || li.status === 'takeover_requested') { li.status = 'bot'; li.mode = 'bot'; }
        }
        toast('Percakapan ditandai selesai.'); fetchWaThread(num); fetchWaConvs(); if ($('#waResLogBox') && $('#waResLogBox').style.display !== 'none') refreshResLog(); }
      else { toast((res && res.error) || 'Gagal menandai selesai.', true); if (b) b.disabled = false; }
    });
  }

  function repView(v) {
    if (['summary', 'logs', 'topics', 'service', 'agent', 'sales', 'periodic'].indexOf(v) === -1) v = 'summary';   // v1.2.223: laporan-pdf   // v1.2.101: + service; v1.2.205: laporan-pindah
    $$('#repSeg button').forEach(function (b) { b.classList.toggle('on', b.dataset.v === v); });
    $('#repSummary').style.display = v === 'summary' ? '' : 'none';
    $('#repLogs').style.display = v === 'logs' ? '' : 'none';
    $('#repTopics').style.display = v === 'topics' ? '' : 'none';
    $('#repService').style.display = v === 'service' ? '' : 'none';   // v1.2.101
    $('#repAgent').style.display = v === 'agent' ? '' : 'none';   // v1.2.205: laporan-pindah
    $('#repSales').style.display = v === 'sales' ? '' : 'none';
    if ($('#repPeriodic')) $('#repPeriodic').style.display = v === 'periodic' ? '' : 'none';   // v1.2.223: laporan-pdf
    try { localStorage.setItem('dei_rep_view', v); } catch (e) {}
    if (v === 'logs') lgInit();
    if (v === 'topics') tpInit();   // v1.2.67
    if (v === 'service') svInit();   // v1.2.101: percakapan
    if (v === 'agent') arInit205();   // v1.2.205: laporan-pindah
    if (v === 'sales') slRepInit205();
    if (v === 'periodic') rpInit223();   // v1.2.223: laporan-pdf
  }
  $$('#repSeg button').forEach(function (b) { b.onclick = function () { repView(b.dataset.v); }; });

  function initReportsControls() {
    var today = new Date().toISOString().slice(0, 10);
    var monthAgo = new Date(Date.now() - 30 * 864e5).toISOString().slice(0, 10);
    if ($('#repFrom')) $('#repFrom').value = monthAgo;
    if ($('#repTo')) $('#repTo').value = today;
    if ($('#btnApply')) $('#btnApply').onclick = loadReports;
    $('#btnExport').onclick = function () {
      var from = $('#repFrom') ? $('#repFrom').value : '';
      var to = $('#repTo') ? $('#repTo').value : '';
      var url = API + '?action=export_logs&token=' + encodeURIComponent(token) +
        '&from=' + encodeURIComponent(from) + '&to=' + encodeURIComponent(to);
      window.location.href = url;
      toast('Mengunduh CSV…');
    };
  }

  /* ====================================================================== *
   *  KNOWLEDGE BASE
   * ====================================================================== */
  /* ---- v1.2.13: daftar kategori notif (dinamis) ---------------------- */
  var deiCatList  = ['Sales', 'Operation', 'Marketing', 'Engineering', 'Owner', 'IT'];  // fallback sebelum fetch
  var deiCatFixed = ['Sales', 'Operation', 'Marketing', 'Engineering', 'Owner', 'IT'];
  var deiCatLoaded = false;
  function ensureCategories(cb) {
    if (deiCatLoaded) { cb && cb(); return; }
    api('get_categories').then(function (res) {
      if (res && res.ok) {
        deiCatList  = res.categories || deiCatList;
        deiCatFixed = res.fixed || deiCatFixed;
        deiCatLoaded = true;
      }
      cb && cb();
    });
  }
  // Bangun checkbox kategori di form pengguna dari daftar dinamis
  function renderUserCategories(selected) {
    var box = document.getElementById('u_categories');
    if (!box) return;
    var sel = selected || [];
    box.innerHTML = deiCatList.map(function (c) {
      var checked = (sel.indexOf(c) !== -1) ? ' checked' : '';
      return '<label style="display:flex;gap:5px;align-items:center;font-size:13px;cursor:pointer">' +
             '<input type="checkbox" class="u_cat" value="' + esc(c) + '"' + checked + '> ' + esc(c) + '</label>';
    }).join('') || '<span class="help">Belum ada kategori.</span>';
  }
  // Manager kategori (panel KB, super_admin only)
  function renderCatManager() {
    var box = document.getElementById('catManager');
    if (!box) return;
    if (user.role !== 'super_admin') { box.style.display = 'none'; return; }
    box.style.display = '';
    var list = document.getElementById('catList');
    list.innerHTML = deiCatList.map(function (c) {
      var isFixed = deiCatFixed.indexOf(c) !== -1;
      var del = isFixed ? '' : ' <a href="#" class="cat-del" data-c="' + esc(c) + '" style="text-decoration:none" title="Hapus">&times;</a>';
      var bg = isFixed ? '#e5e7eb' : '#dbeafe';
      return '<span class="tag" style="background:' + bg + ';padding:5px 10px">' + esc(c) + del + '</span>';
    }).join('');
    Array.prototype.slice.call(list.querySelectorAll('.cat-del')).forEach(function (a) {
      a.onclick = function (ev) {
        ev.preventDefault();
        var c = a.dataset.c;
        if (!confirm('Hapus kategori "' + c + '"?')) return;
        api('delete_category', { method: 'POST', body: { category: c } }).then(function (r) {
          if (r.ok) { deiCatList = r.categories || deiCatList; toast('Kategori dihapus.'); renderCatManager(); renderKb(); }
          else toast(r.error || 'Gagal menghapus.', true);
        });
      };
    });
    var btn = document.getElementById('btnAddCat');
    if (btn) btn.onclick = function () {
      var input = document.getElementById('catNew');
      var v = (input.value || '').trim();
      if (!v) { toast('Nama kategori wajib diisi.', true); return; }
      api('add_category', { method: 'POST', body: { category: v } }).then(function (r) {
        if (r.ok) { deiCatList = r.categories || deiCatList; input.value = ''; toast('Kategori ditambahkan.'); renderCatManager(); renderKb(); }
        else toast(r.error || 'Gagal menambah.', true);
      });
    };
  }
  var kbData = [], kbRev = '';   // v1.2.181: kb-simpan-aman
  window.addEventListener('beforeunload', function (ev) { if (kbDirty) { ev.preventDefault(); ev.returnValue = ''; } });   // v1.2.181: kb-simpan-aman: peringatan perubahan KB belum disimpan
  function loadKb() {
    ensureCategories(function () {   // v1.2.13: kategori dulu supaya dropdown topik lengkap
      renderCatManager();
      if (kbDirty && kbData.length) { renderKb(); return; }   // v1.2.181: kb-simpan-aman: buka ulang tab KB tidak menimpa perubahan yang belum disimpan
      api('get_kb').then(function (res) { if (res.ok) { kbData = res.kb || []; kbRev = res.rev || ''; renderKb(); } });
    });
    $('#btnAddKb').onclick = function () {
      var nid = 'kb_' + Date.now();
      kbData.unshift({ id: nid, category: kbCatFilter && kbCatFilter !== 'Tanpa kategori' ? kbCatFilter : '', title: '', content: '', topic: '' });
      kbSelId = nid; $('#kbSearch').value = ''; kbMarkDirty(); renderKb();
      var t = document.querySelector('#kbList .kb-title'); if (t) t.focus();
    };
    $('#btnSaveKb').onclick = saveKb;
    $('#kbSearch').oninput = renderKb;
    $('#btnImportCsv').onclick = function () { var f = $('#kbCsvFile'); f.value = ''; f.click(); };
    $('#kbCsvFile').onchange = function (e) { importKbCsv(e.target.files && e.target.files[0]); e.target.value = ''; };
    $('#btnCsvTemplate').onclick = function (e) { e.preventDefault(); downloadKbTemplate(); };
    // v1.2.22: tab daftar harga
    $$('.kb-tab').forEach(function (b) {
      b.onclick = function () { switchKbTab(b.dataset.kbtab); };
    });
    $('#btnAddPrice').onclick = function () {
      var nid = 'pr_' + Date.now();
      priceData.unshift({ id: nid, item: '', price: '', note: '', variants: [] });   // v1.2.171: produk-varian
      prSelId = nid; var ps = $('#priceSearch'); if (ps) ps.value = ''; prMarkDirty(); renderPricelist();
      var t = document.querySelector('#priceList .pr-item'); if (t) t.focus();
    };
    $('#btnSavePrice').onclick = savePricelist;
    var _ps = $('#priceSearch'); if (_ps) _ps.oninput = renderPricelist;   // v1.2.64
    $('#btnImportPdf').onclick = function () { var f = $('#kbPdfFile'); f.value = ''; f.click(); };   // v1.2.62
    $('#kbPdfFile').onchange = function (e) { importKbPdf(e.target.files && e.target.files[0]); e.target.value = ''; };
    var _bku = $('#btnImportUrl'); if (_bku) _bku.onclick = function () { openKbUrl(''); };   // v1.2.132: kb-url
    if (!window._kbSaveKey) {   // v1.2.63: Ctrl/Cmd+S simpan KB
      window._kbSaveKey = true;
      document.addEventListener('keydown', function (ev) {
        if ((ev.ctrlKey || ev.metaKey) && (ev.key === 's' || ev.key === 'S')) {
          var p = document.getElementById('panel-kb'), t = document.getElementById('kbTabEntri');
          if (p && p.classList.contains('active') && t && t.style.display !== 'none') { ev.preventDefault(); saveKb(); }
          var th = document.getElementById('kbTabHarga');
          if (p && p.classList.contains('active') && th && th.style.display !== 'none') { ev.preventDefault(); savePricelist(); }
        }
      });
    }
    $('#btnFindDup').onclick = findKbDuplicates;   // v1.2.23
    $('#btnFindGaps').onclick = findKbGaps;       // v1.2.24
  }
  /* ---- v1.2.24/25: pertanyaan belum terjawab ------------------------- */
  var gapData = [];
  var gapVerdict = {};   // indeks -> true kalau AI menilai benar-benar gagal

  function findKbGaps(showHidden) {
    var box = document.getElementById('gapResult');
    box.style.display = '';
    box.innerHTML = '<div style="color:var(--muted)">Memindai log percakapan...</div>';
    gapVerdict = {};
    api('kb_find_gaps', { query: showHidden ? '&show_hidden=1' : '' }).then(function (res) {
      if (!res || !res.ok) {
        box.innerHTML = '<div style="color:#b91c1c">' + esc((res && res.error) || 'Gagal memindai.') + '</div>';
        return;
      }
      gapData = res.gaps || [];
      renderKbGaps(res, showHidden);
    });
  }

  function renderKbGaps(res, showHidden) {
    var box = document.getElementById('gapResult');
    if (!gapData.length) {
      box.innerHTML = '<strong>Tidak ada pertanyaan yang gagal dijawab.</strong><br>' +
        '<span class="help">Dari ' + res.scanned + ' percakapan yang dipindai.' +
        (res.hidden ? ' (' + res.hidden + ' disembunyikan)' : '') + '</span>' +
        (res.hidden ? '<br><button class="btn ghost sm" id="btnShowHidden" style="margin-top:8px">Tampilkan yang disembunyikan</button>' : '');
      if (res.hidden) document.getElementById('btnShowHidden').onclick = function () { findKbGaps(true); };
      return;
    }

    var h = '<h3 style="margin-top:0">Pertanyaan Belum Terjawab</h3>' +
      '<p style="margin:0 0 4px">Dari <strong>' + res.scanned + '</strong> percakapan, ada <strong>' +
      gapData.length + '</strong> pertanyaan berbeda.' +
      (res.hidden ? ' <span class="help">(' + res.hidden + ' disembunyikan)</span>' : '') + '</p>' +
      '<p style="color:var(--muted);font-size:13px;line-height:1.5;margin:0 0 10px">' +
      'Diurutkan dari yang paling sering ditanyakan. Menambahkan membuat entri KB berisi ' +
      'pertanyaannya saja &mdash; <strong>jawabannya Anda yang tulis</strong>. Entri tanpa jawaban ' +
      'tidak dikirim ke bot, jadi aman menumpuk dulu.</p>' +
      '<div class="toolbar" style="margin-bottom:10px">' +
        '<button class="btn ghost sm" id="btnVerifyGaps">' + ico('sparkles',14) + ' Saring dengan AI</button>' +
        (showHidden ? '<button class="btn ghost sm" id="btnRestoreGaps">Pulihkan semua yang disembunyikan</button>' : '') +
        '<span class="help" id="gapVerifyInfo" style="margin-left:auto"></span>' +
      '</div>';

    h += gapData.map(function (g, i) {
      var kanal = (g.channels || []).join(', ');
      var v = gapVerdict[i];
      var redup = (v === false) ? 'opacity:.45;' : '';
      var tanda = (v === false)
        ? ' <span class="tag" style="background:#e5e7eb;color:#374151;font-size:11px">AI: sudah terjawab</span>'
        : (v === true ? ' <span class="tag" style="background:#fee2e2;color:#b91c1c;font-size:11px">Jawaban kurang akurat</span>' : '');
      return '<div class="row" data-gap="' + i + '" style="align-items:center;gap:10px;padding:6px 0;border-bottom:1px solid var(--line);' + redup + '">' +
        '<span class="tag" style="background:#fef3c7;color:#92400e;min-width:44px;text-align:center">' + g.count + '&times;</span>' +
        '<div style="flex:1">' + esc(g.question) + tanda +
          '<div class="help" style="font-size:11px">' + esc(kanal) +
          (g.last_ts ? ' &middot; terakhir ' + esc(g.last_ts.slice(0, 10)) : '') + '</div>' +
        '</div>' +
        '<button class="btn ghost sm gap-add">+ Tambah ke KB</button>' +
        '<button class="btn ghost sm gap-hide" title="Sembunyikan, jangan tampilkan lagi">&times;</button>' +
      '</div>';
    }).join('');
    box.innerHTML = h;

    document.getElementById('btnVerifyGaps').onclick = verifyKbGaps;
    var btnRestore = document.getElementById('btnRestoreGaps');
    if (btnRestore) btnRestore.onclick = function () {
      if (!confirm('Tampilkan kembali semua pertanyaan yang pernah disembunyikan?')) return;
      api('kb_restore_gaps', { method: 'POST' }).then(function (r) {
        if (r && r.ok) { toast('Dipulihkan.'); findKbGaps(false); }
      });
    };

    Array.prototype.slice.call(box.querySelectorAll('.row[data-gap]')).forEach(function (row) {
      var i = +row.dataset.gap;
      var g = gapData[i];
      row.querySelector('.gap-add').onclick = function () {
        var btn = this;
        btn.disabled = true;
        api('kb_add_gap', { method: 'POST', body: { question: g.question } }).then(function (r) {
          if (r && r.ok) {
            btn.textContent = '\u2713 Ditambahkan';
            toast('Ditambahkan ke KB kategori "Perlu Diisi" \u2014 isinya masih kosong.');
            api('get_kb').then(function (k) { if (k.ok) { kbData = k.kb || []; kbRev = k.rev || ''; kbDirty = false; kbSaveUi(); renderKb(); } });   // v1.2.181: kb-simpan-aman
          } else { btn.disabled = false; toast((r && r.error) || 'Gagal.', true); }
        });
      };
      row.querySelector('.gap-hide').onclick = function () {
        api('kb_dismiss_gap', { method: 'POST', body: { key: g.key } }).then(function (r) {
          if (r && r.ok) { row.style.display = 'none'; toast('Disembunyikan.'); }
          else toast((r && r.error) || 'Gagal.', true);
        });
      };
    });
  }

  // AI hanya MEMILAH — tidak menulis jawaban, tidak menghapus apa pun.
  // Satu panggilan untuk seluruh daftar = 1 jatah kuota.
  function verifyKbGaps() {
    if (!gapData.length) return;
    if (!confirm('Saring ' + gapData.length + ' pertanyaan dengan AI?\n\nMemakai 1 jatah kuota chat.')) return;
    var info = document.getElementById('gapVerifyInfo');
    info.textContent = 'Menyaring...';
    var kirim = gapData.map(function (g) { return { question: g.question, sample_a: g.sample_a || '' }; });
    api('kb_verify_gaps', { method: 'POST', body: { items: kirim } }).then(function (r) {
      if (!r || !r.ok) { info.textContent = ''; toast((r && r.error) || 'Penyaringan gagal.', true); return; }
      gapVerdict = {};
      for (var i = 0; i < gapData.length; i++) gapVerdict[i] = (r.failed.indexOf(i) !== -1);
      var jmlGagal = r.failed.length;
      var jmlSalah = gapData.length - jmlGagal;
      renderKbGaps({ scanned: '-', hidden: 0 }, false);
      document.getElementById('gapVerifyInfo').textContent =
        jmlGagal + ' benar gagal, ' + jmlSalah + ' sebenarnya sudah terjawab';
      if (jmlSalah) {
        toast(jmlSalah + ' pertanyaan ditandai sudah terjawab \u2014 diredupkan, bisa disembunyikan.');
      }
    });
  }

  /* ---- v1.2.23: analisa duplikat KB ---------------------------------- */
  function findKbDuplicates() {
    var box = document.getElementById('dupResult');
    box.style.display = '';
    box.innerHTML = '<div style="color:var(--muted)">Menganalisa...</div>';
    api('kb_find_duplicates').then(function (res) {
      if (!res || !res.ok) {
        box.innerHTML = '<div style="color:#b91c1c">' + esc((res && res.error) || 'Gagal menganalisa.') + '</div>';
        return;
      }
      if (!res.removed) {
        box.innerHTML = '<strong>Tidak ada duplikat.</strong><br>' +
          '<span class="help">' + res.total + ' entri, semuanya berisi teks berbeda.</span>';
        return;
      }
      var h = '<h3 style="margin-top:0">Hasil Analisa Duplikat</h3>' +
        '<div class="grid2" style="margin-bottom:10px">' +
          '<div><span class="help">Entri sekarang</span><br><strong style="font-size:18px">' + res.total + '</strong></div>' +
          '<div><span class="help">Setelah digabung</span><br><strong style="font-size:18px">' + res.unique + '</strong></div>' +
        '</div>' +
        '<p style="margin:0 0 10px">Ada <strong>' + res.removed + '</strong> entri kembar dalam ' +
        res.group_count + ' kelompok. Isinya sama persis, hanya kalimat tanyanya berbeda.</p>';

      if (res.groups && res.groups.length) {
        h += '<div style="margin-bottom:10px"><span class="help">Yang paling banyak digandakan:</span><br>';
        h += res.groups.map(function (g) {
          return '<div style="font-size:13px;padding:2px 0">' +
                 '<span class="tag" style="background:#e5e7eb;color:#374151">' + g.count + '&times;</span> ' +
                 esc(g.title) + '</div>';
        }).join('');
        h += '</div>';
      }

      if (res.conflicts && res.conflicts.length) {
        h += '<p style="color:#b91c1c;font-size:13px">Perhatian: ' + res.conflicts.length +
             ' kelompok punya tag topik berbeda antar duplikatnya. Yang pertama akan dipakai.</p>';
      }

      h += '<p style="color:var(--muted);font-size:13px;line-height:1.5">' +
           'Penggabungan menyimpan satu entri per isi, memakai judul terpendek, dan ' +
           'mempertahankan tag topik yang sudah ada. Jawaban bot tidak berubah &mdash; ' +
           'yang dihapus hanya salinan kalimat tanya. Cadangan dibuat otomatis.</p>' +
           '<button class="btn" id="btnMergeDup">Gabungkan ' + res.total + ' &rarr; ' + res.unique + '</button>';
      box.innerHTML = h;

      document.getElementById('btnMergeDup').onclick = function () {
        if (!confirm('Gabungkan ' + res.total + ' entri jadi ' + res.unique + '?\n\n' +
                     res.removed + ' entri kembar akan dihapus.\nCadangan dibuat otomatis di server.')) return;
        api('kb_merge_duplicates', { method: 'POST' }).then(function (r) {
          if (r && r.ok) {
            toast('Digabungkan: ' + r.before + ' -> ' + r.after + ' entri.');
            box.innerHTML = '<strong>Selesai.</strong> ' + r.before + ' &rarr; ' + r.after +
              ' entri.<br><span class="help">Cadangan: ' + esc(r.backup) + '</span>';
            api('get_kb').then(function (k) { if (k.ok) { kbData = k.kb || []; kbRev = k.rev || ''; kbDirty = false; kbSaveUi(); renderKb(); } });   // v1.2.181: kb-simpan-aman
          } else {
            toast((r && r.error) || 'Gagal menggabungkan.', true);
          }
        });
      };
    });
  }

  /* ---- v1.2.167: unit-bisnis ------------------------------------------ */
  var buData = null, buChannels = [], buCats = [], buDirty = false, buMax = 10;
  function buName(id) { var u = (buData || []).filter(function (x) { return x.id === id; })[0]; return u ? (u.name || '(tanpa nama)') : ''; }
  function fetchUnits(cb) {
    api('get_units').then(function (res) {
      if (!res || !res.ok) { toast((res && res.error) || 'Gagal memuat unit bisnis.', true); return; }
      buData = res.units || []; buChannels = res.channels || []; buCats = res.categories || []; buMax = res.max != null ? +res.max : 10; buDirty = false;   /* v1.2.168: kuota-unit */
      var m = document.getElementById('unitMeta');
      if (m) m.textContent = 'Kuota paket: ' + buData.length + '/' + buMax + ' unit' + (res.updated_at ? (' · Diperbarui ' + res.updated_at.slice(0, 16) + (res.updated_by ? ' oleh ' + res.updated_by : '')) : '');
      if (cb) cb(); else renderUnits();
    });
  }
  function buMark() { buDirty = true; var b = document.getElementById('btnSaveUnits'); if (b) b.classList.add('kb-dirty'); }
  function renderUnits() {
    var wrap = document.getElementById('unitList'); if (!wrap) return;
    var bs = document.getElementById('btnSaveUnits'); if (bs) { bs.classList.toggle('kb-dirty', buDirty); bs.onclick = saveUnits; }
    var ba = document.getElementById('btnAddUnit');
    if (ba) ba.onclick = function () {
      if (buData.length >= buMax) { toast(buMax ? 'Paket Anda maksimal ' + buMax + ' unit bisnis. Hubungi DEI untuk upgrade.' : 'Unit Bisnis tersedia mulai paket Growth (3 unit), Business (5), Pro (10).', true); return; }
      buData.push({ id: 'u_' + Date.now().toString(36), name: '', channels: [], categories: [], instructions: '' });
      buMark(); renderUnits();
      var ins = wrap.querySelectorAll('.bu-name'); if (ins.length) ins[ins.length - 1].focus();
    };
    if (ba) ba.style.display = (!buMax && !buData.length) ? 'none' : '';   // v1.2.168: kuota-unit
    if (!buMax && !buData.length) {
      wrap.innerHTML = '<div class="card kb-empty" style="padding:40px 20px;text-align:center">Unit Bisnis belum termasuk paket Anda.<br>Tersedia mulai paket <b>Growth</b> (3 unit), <b>Business</b> (5 unit), dan <b>Pro</b> (10 unit). Hubungi tim DEI untuk upgrade.' + planBtn() + '</div>';   // v1.2.172: trial-paket
      return;
    }
    if (!buData.length) {
      wrap.innerHTML = '<div class="card kb-empty" style="padding:40px 20px;text-align:center">Belum ada unit bisnis. Semua nomor WA &amp; widget memakai seluruh Knowledge Base.<br>Klik <b>+ Tambah Unit</b> bila tenant ini punya lebih dari satu usaha.</div>';
      return;
    }
    var chOwner = {};
    buData.forEach(function (u) { (u.channels || []).forEach(function (c) { if (!chOwner[c]) chOwner[c] = u; }); });
    var allCats = buCats.slice(), seen = {};
    allCats.forEach(function (c) { seen[c.toLowerCase()] = 1; });
    buData.forEach(function (u) { (u.categories || []).forEach(function (c) { if (!seen[c.toLowerCase()]) { seen[c.toLowerCase()] = 1; allCats.push(c); } }); });
    wrap.innerHTML = buData.map(function (u, i) {
      var chs = buChannels.map(function (c) {
        var on = (u.channels || []).indexOf(c.id) !== -1, ow = chOwner[c.id];
        return '<label class="bu-chk"><input type="checkbox" class="bu-ch" data-i="' + i + '" value="' + esc(c.id) + '"' + (on ? ' checked' : '') + '> ' + esc(c.label) +
          (!on && ow ? ' <small>(dipakai ' + esc(ow.name || 'unit lain') + ')</small>' : '') + '</label>';
      }).join('') || '<span class="help">Belum ada kanal.</span>';
      var mine = {}; (u.categories || []).forEach(function (c) { mine[c.toLowerCase()] = 1; });
      var cats = allCats.map(function (c) {
        var others = buData.filter(function (x, k) { return k !== i && (x.categories || []).some(function (y) { return y.toLowerCase() === c.toLowerCase(); }); })
          .map(function (x) { return x.name || 'unit lain'; });
        var gone = buCats.every(function (y) { return y.toLowerCase() !== c.toLowerCase(); });
        return '<label class="bu-chk"><input type="checkbox" class="bu-cat" data-i="' + i + '" value="' + esc(c) + '"' + (mine[c.toLowerCase()] ? ' checked' : '') + '> ' + esc(c) +
          (others.length ? ' <small>(juga ' + esc(others.join(', ')) + ')</small>' : '') + (gone ? ' <small>(tidak ada di KB)</small>' : '') + '</label>';
      }).join('') || '<span class="help">KB belum punya kategori. Isi kolom kategori di entri KB dulu (mis. Rental Mobil, Villa, Fashion).</span>';
      var nCh = (u.channels || []).length, nCat = (u.categories || []).length;
      var off = i >= buMax;   // v1.2.168: kuota-unit
      return '<div class="card bu-card"' + (off ? ' style="opacity:.6"' : '') + '>' +
        '<h3>' + ico('layers', 16) + ' ' + (esc(u.name) || '<i style="color:var(--muted)">Unit baru</i>') +
          (off ? ' <span style="font-size:12px;font-weight:600;color:#b45309;background:#fef3c7;border-radius:6px;padding:2px 8px">Nonaktif: di luar kuota paket (' + buMax + ' unit)</span>' : '') + '</h3>' +
        '<div class="row"><label class="fl">Nama unit</label><input type="text" class="bu-name" data-i="' + i + '" maxlength="60" value="' + esc(u.name || '') + '" placeholder="mis. Rental Mobil"></div>' +
        '<div class="row"><label class="fl">Kanal yang dilayani unit ini</label><div class="bu-chks">' + chs + '</div>' +
          (!nCh ? '<div class="help" style="margin-top:4px">Belum ada kanal: unit ini hanya bisa dicoba lewat Tes Chatbot.</div>' : '') + '</div>' +
        '<div class="row"><label class="fl">Kategori KB milik unit ini</label><div class="bu-chks">' + cats + '</div>' +
          (!nCat ? '<div class="help" style="margin-top:4px">Tanpa kategori: unit ini hanya memakai kategori umum.</div>' : '') + '</div>' +
        '<div class="row"><label class="fl">Instruksi khusus (opsional)</label><textarea class="bu-ins" data-i="' + i + '" maxlength="2000" style="min-height:90px" placeholder="mis. Kamu melayani sewa mobil lepas kunci &amp; dengan sopir. Untuk villa, arahkan ke WA 0812-xxxx.">' + esc(u.instructions || '') + '</textarea></div>' +
        '<div style="text-align:right"><button class="btn danger sm bu-del" data-i="' + i + '">' + ico('trash-2', 14) + ' Hapus unit</button></div>' +
      '</div>';
    }).join('');
    $$('#unitList .bu-name').forEach(function (el) { el.oninput = function () { buData[+el.dataset.i].name = el.value; buMark(); }; el.onchange = renderUnits; });
    $$('#unitList .bu-ins').forEach(function (el) { el.oninput = function () { buData[+el.dataset.i].instructions = el.value; buMark(); }; });
    $$('#unitList .bu-ch').forEach(function (el) {
      el.onchange = function () {
        var i = +el.dataset.i, v = el.value;
        buData.forEach(function (u, k) {   // satu kanal hanya milik satu unit
          u.channels = (u.channels || []).filter(function (c) { return c !== v; });
          if (k === i && el.checked) u.channels.push(v);
        });
        buMark(); renderUnits();
      };
    });
    $$('#unitList .bu-cat').forEach(function (el) {
      el.onchange = function () {
        var u = buData[+el.dataset.i], v = el.value;
        u.categories = (u.categories || []).filter(function (c) { return c.toLowerCase() !== v.toLowerCase(); });
        if (el.checked) u.categories.push(v);
        buMark(); renderUnits();
      };
    });
    $$('#unitList .bu-del').forEach(function (el) {
      el.onclick = function () {
        var u = buData[+el.dataset.i];
        if (!confirm('Hapus unit "' + (u.name || 'tanpa nama') + '"?\nKanalnya kembali memakai seluruh KB.')) return;
        buData.splice(+el.dataset.i, 1); buMark(); renderUnits();
      };
    });
  }
  function saveUnits() {
    var kosong = buData.filter(function (u) { return !(u.name || '').trim(); }).length;
    if (kosong && !confirm(kosong + ' unit belum diberi nama dan tidak akan disimpan. Lanjut?')) return;
    api('save_units', { method: 'POST', body: { units: buData } }).then(function (res) {
      if (res && res.ok) { toast('Unit bisnis disimpan (' + (res.units || []).length + ' unit).'); fetchUnits(); }
      else toast((res && res.error) || 'Gagal menyimpan.', true);
    });
  }

  /* ---- v1.2.22: daftar harga ----------------------------------------- */
  var priceData = [];

  function switchKbTab(which) {
    $$('.kb-tab').forEach(function (b) { b.classList.toggle('active', b.dataset.kbtab === which); });
    var entri = document.getElementById('kbTabEntri');
    var harga = document.getElementById('kbTabHarga');
    if (entri) entri.style.display = (which === 'entri') ? '' : 'none';
    if (harga) harga.style.display = (which === 'harga') ? '' : 'none';
    var unitT = document.getElementById('kbTabUnit');   // v1.2.167: unit-bisnis
    if (unitT) unitT.style.display = (which === 'unit') ? '' : 'none';
    if (which === 'unit') { if (buData === null || !buDirty) fetchUnits(); else renderUnits(); }
    if (which === 'harga' && buData === null) fetchUnits(function () { renderPricelist(); });
    if (which === 'harga' && !priceData.length) fetchPricelist();
  }

  function fetchPricelist() {
    api('get_pricelist').then(function (res) {
      if (!res || !res.ok) { toast((res && res.error) || 'Gagal memuat daftar produk.', true); return; }
      priceData = res.items || [];
      var meta = document.getElementById('priceMeta');
      if (meta) {
        meta.textContent = res.updated_at
          ? ('Diperbarui ' + res.updated_at.slice(0, 16) + (res.updated_by ? ' oleh ' + res.updated_by : ''))
          : 'Belum pernah disimpan';
      }
      renderPricelist();
    });
  }

  /* ---- v1.2.64: Daftar Harga master-detail (sama dengan KB) ---- */
  var prSelId = null, prDirty = false;
  function prIdx(id) { for (var i = 0; i < priceData.length; i++) if (priceData[i].id === id) return i; return -1; }
  function prSaveUi() {
    var b = document.getElementById('btnSavePrice'); if (b) b.classList.toggle('kb-dirty', prDirty);
    var eb = document.querySelector('#priceList .pr-save'), h = document.querySelector('#priceList .kb-save-hint');
    if (eb) eb.classList.toggle('kb-dirty', prDirty);
    if (h) h.textContent = prDirty ? 'Ada perubahan belum disimpan' : 'Tersimpan';
  }
  function prMarkDirty() { prDirty = true; prSaveUi(); }
  function prAmt(p) {   // v1.2.171: produk-varian
    var v = (p.variants || []).filter(function (x) { return (x.name || '').trim() || (x.price || '').trim(); });
    return v.length ? v.length + ' varian' : (p.price || '').trim();
  }
  function renderPricelist() {
    var term = (($('#priceSearch') || {}).value || '').toLowerCase();
    var shown = [];
    priceData.forEach(function (p, i) {
      if (term && ((p.item || '') + ' ' + (p.price || '') + ' ' + (p.note || '') + ' ' + (p.variants || []).map(function (v) { return (v.name || '') + ' ' + (v.price || ''); }).join(' ')).toLowerCase().indexOf(term) === -1) return;
      shown.push(i);
    });
    if (prSelId && prIdx(prSelId) === -1) prSelId = null;
    var wide = window.matchMedia('(min-width: 861px)').matches;
    if (!prSelId && wide && shown.length) prSelId = priceData[shown[0]].id;
    var items = shown.map(function (i) {
      var p = priceData[i];
      return '<button class="kb-item' + (p.id === prSelId ? ' on' : '') + '" data-id="' + esc(p.id) + '">' +
        '<span class="pr-row"><b>' + (esc(p.item) || '<i style="color:var(--muted)">(tanpa nama)</i>') + '</b>' +
        '<span class="pr-amt' + (prAmt(p) ? '' : ' empty') + '">' + (esc(prAmt(p)) || 'belum ada harga') + '</span></span>' +
        (p.note ? '<small>' + esc(p.note.length > 120 ? p.note.slice(0, 120) + '…' : p.note) + '</small>' : '') + (p.unit && buName(p.unit) ? '<span class="pr-unit-tag">' + esc(buName(p.unit)) + '</span>' : '') + '</button>';   // v1.2.167
    }).join('') || '<div class="kb-empty">' + (priceData.length ? 'Tidak ada produk yang cocok.' : 'Belum ada produk. Klik "+ Tambah Produk" untuk mulai.') + '</div>';
    var si = prSelId ? prIdx(prSelId) : -1, ed;
    if (si === -1) {
      ed = '<div class="kb-empty" style="padding:60px 20px">Pilih produk di kiri untuk melihat &amp; mengedit,<br>atau klik <b>+ Tambah Produk</b>.</div>';
    } else {
      var p = priceData[si];
      var pv = Array.isArray(p.variants) ? p.variants : (p.variants = []);   // v1.2.171: produk-varian
      ed = '<div class="kb-ed-head"><button class="btn ghost sm kb-back">&larr; Daftar</button>' +
          '<span class="help">Produk ' + (shown.indexOf(si) + 1 || '-') + ' dari ' + shown.length + '</span>' +
          '<span style="margin-left:auto;display:flex;gap:6px">' +
          '<button class="btn ghost sm kb-prev" title="Sebelumnya">&uarr;</button>' +
          '<button class="btn ghost sm kb-next" title="Berikutnya">&darr;</button></span></div>' +
        '<div class="row"><label class="fl">Nama produk</label><input type="text" class="pr-item" maxlength="150" value="' + esc(p.item || '') + '" placeholder="mis. Deluxe Room / Audiobook Lunas Hutang"></div>' +   // v1.2.171: produk-varian
        (pv.length ? '' : '<div class="row"><label class="fl">Harga</label><input type="text" class="pr-price" maxlength="100" value="' + esc(p.price || '') + '" placeholder="mis. Rp 750.000 / malam"></div>') +
        '<div class="row"><label class="fl">Varian' + (pv.length ? ' (nama &amp; harga)' : ' (opsional)') + '</label>' +
          pv.map(function (v, k) {
            return '<div class="pv-row"><input type="text" class="pv-name" data-k="' + k + '" maxlength="100" value="' + esc(v.name || '') + '" placeholder="Nama varian, mis. Paket A">' +
              '<input type="text" class="pv-price" data-k="' + k + '" maxlength="100" value="' + esc(v.price || '') + '" placeholder="Harga, mis. Rp 100.000">' +
              '<button type="button" class="btn ghost sm pv-del" data-k="' + k + '" title="Hapus varian">' + ico('x', 13) + '</button></div>';
          }).join('') +
          '<button type="button" class="btn ghost sm pv-add">+ Tambah varian</button>' +
          (pv.length ? '' : '<div class="help" style="margin-top:4px">Pakai varian kalau produk punya beberapa pilihan harga (ukuran, paket, durasi).</div>') + '</div>' +
        '<div class="row"><label class="fl">Detail produk (opsional)</label><textarea class="pr-note" maxlength="2000" style="min-height:140px" placeholder="Isi, manfaat, spesifikasi, cara pakai, syarat…">' + esc(p.note || '') + '</textarea>' +
          '<div class="help" style="margin-top:4px">Bot memakai detail ini untuk menjawab pertanyaan tentang produk ini. Maks 2.000 karakter.</div></div>' +
        ((buData && buData.length) || p.unit ? '<div class="row"><label class="fl">Unit bisnis</label><select class="pr-unit"><option value="">Umum (semua unit)</option>' +   // v1.2.167: unit-bisnis
          (buData || []).map(function (u) { return '<option value="' + esc(u.id) + '"' + (p.unit === u.id ? ' selected' : '') + '>' + esc(u.name) + '</option>'; }).join('') +
          (p.unit && !buName(p.unit) ? '<option value="' + esc(p.unit) + '" selected>(unit dihapus)</option>' : '') + '</select></div>' : '') +
        '<div class="kb-ed-foot"><button class="btn danger sm pr-del">' + ico('trash-2',14) + ' Hapus produk</button>' +
        '<span class="help kb-save-hint">' + (prDirty ? 'Ada perubahan belum disimpan' : 'Tersimpan') + '</span>' +
        '<button class="btn pr-save' + (prDirty ? ' kb-dirty' : '') + '">' + ico('save',14) + ' Simpan</button></div>';
    }
    var wrap = $('#priceList');
    wrap.innerHTML = '<div class="kb-md' + (si !== -1 ? ' has-sel' : '') + '">' +
        '<div class="kb-side"><div class="kb-count">' + shown.length + ' produk</div><div class="kb-items">' + items + '</div></div>' +
        '<div class="kb-ed card">' + ed + '</div></div>';
    $$('#priceList .kb-item').forEach(function (it) {
      it.onclick = function () { prSelId = it.dataset.id; renderPricelist(); var t = wrap.querySelector('.kb-ed'); if (t && !wide) t.scrollIntoView({ block: 'start' }); };
    });
    if (si === -1) return;
    var edEl = wrap.querySelector('.kb-ed');
    var li = function () { return wrap.querySelector('.kb-item.on'); };
    edEl.querySelector('.pr-item').oninput = function (ev) {
      priceData[si].item = ev.target.value; prMarkDirty();
      var l = li(); if (l) l.querySelector('b').textContent = ev.target.value || '(tanpa nama)';
    };
    var _pp = edEl.querySelector('.pr-price'); if (_pp) _pp.oninput = function (ev) {   // v1.2.171: produk-varian — tidak ada bila bervarian
      priceData[si].price = ev.target.value; prMarkDirty();
      var l = li(); if (l) { var a = l.querySelector('.pr-amt'); a.textContent = ev.target.value || 'belum ada harga'; a.classList.toggle('empty', !ev.target.value.trim()); }
    };
    edEl.querySelector('.pr-note').oninput = function (ev) { priceData[si].note = ev.target.value; prMarkDirty(); };
    var pvAmt = function () { var l = li(); if (!l) return; var a = l.querySelector('.pr-amt'), t = prAmt(priceData[si]); a.textContent = t || 'belum ada harga'; a.classList.toggle('empty', !t); };   // v1.2.171: produk-varian
    $$('#priceList .pv-name').forEach(function (el) { el.oninput = function () { priceData[si].variants[+el.dataset.k].name = el.value; prMarkDirty(); pvAmt(); }; });   // v1.2.171: produk-varian
    $$('#priceList .pv-price').forEach(function (el) { el.oninput = function () { priceData[si].variants[+el.dataset.k].price = el.value; prMarkDirty(); pvAmt(); }; });
    $$('#priceList .pv-del').forEach(function (el) { el.onclick = function () { priceData[si].variants.splice(+el.dataset.k, 1); prMarkDirty(); renderPricelist(); }; });
    edEl.querySelector('.pv-add').onclick = function () {
      var pp = priceData[si]; if (!Array.isArray(pp.variants)) pp.variants = [];
      if (!pp.variants.length && (pp.price || '').trim()) { pp.variants.push({ name: '', price: pp.price }); pp.price = ''; }   // harga lama jadi varian pertama
      pp.variants.push({ name: '', price: '' }); prMarkDirty(); renderPricelist();
      var ins = [].slice.call(document.querySelectorAll('#priceList .pv-name')).filter(function (x) { return !x.value; }); if (ins.length) ins[0].focus();
    };
    var _pu = edEl.querySelector('.pr-unit'); if (_pu) _pu.onchange = function (ev) { priceData[si].unit = ev.target.value; prMarkDirty(); renderPricelist(); };   // v1.2.167
    edEl.querySelector('.pr-del').onclick = function () {
      if (!confirm('Hapus produk "' + (priceData[si].item || 'tanpa nama') + '"?')) return;
      var pos = shown.indexOf(si), rest = shown.filter(function (x) { return x !== si; });
      var nx = rest.length ? rest[Math.min(pos, rest.length - 1)] : null;
      var nxId = nx != null ? priceData[nx].id : null;
      priceData.splice(si, 1); prMarkDirty(); prSelId = nxId; renderPricelist();
    };
    edEl.querySelector('.pr-save').onclick = function () { savePricelist(); };
    edEl.querySelector('.kb-back').onclick = function () { prSelId = null; renderPricelist(); };
    var step = function (d) { var q = shown.indexOf(si) + d; if (q >= 0 && q < shown.length) { prSelId = priceData[shown[q]].id; renderPricelist(); } };
    edEl.querySelector('.kb-prev').onclick = function () { step(-1); };
    edEl.querySelector('.kb-next').onclick = function () { step(1); };
  }

  function savePricelist() {
    // baris tanpa nama item dibuang di backend; peringatkan kalau ada harga kosong
    var tanpaHarga = priceData.filter(function (p) {
      return (p.item || '').trim() && !(p.price || '').trim() && !(p.variants || []).some(function (v) { return (v.price || '').trim(); });   // v1.2.171: produk-varian
    }).length;
    if (tanpaHarga && !confirm(tanpaHarga + ' produk belum punya harga.\nBot akan bilang harganya belum tersedia (produk tanpa harga dan tanpa detail tidak dipakai bot). Tetap simpan?')) return;
    api('save_pricelist', { method: 'POST', body: { items: priceData } }).then(function (res) {
      if (res && res.ok) { prDirty = false; prSaveUi(); toast('Produk disimpan (' + res.count + ' produk).'); fetchPricelist(); }
      else toast((res && res.error) || 'Gagal menyimpan.', true);
    });
  }

  // v1.2.12: build <option> untuk dropdown topik KB
  function kbTopicOptions(selected) {
    var topics = [''].concat(deiCatList);  // v1.2.13: dinamis
    return topics.map(function (t) {
      var label = t || '— Umum —';
      var sel = (selected === t) ? ' selected' : '';
      return '<option value="' + t + '"' + sel + '>' + label + '</option>';
    }).join('');
  }
  /* ---- v1.2.62: KB tampilan master-detail (daftar ringkas + editor) ---- */
  var kbSelId = null, kbCatFilter = '', kbDirty = false;
  function kbMarkDirty() {
    kbDirty = true;
    var b = document.getElementById('btnSaveKb'); if (b) b.classList.add('kb-dirty');
    kbSaveUi();
  }
  function kbSaveUi() {   // v1.2.63: sinkron tombol Simpan di editor
    var eb = document.querySelector('#kbList .kb-save'), h = document.querySelector('#kbList .kb-save-hint');
    if (eb) eb.classList.toggle('kb-dirty', kbDirty);
    if (h) h.textContent = kbDirty ? 'Ada perubahan belum disimpan' : 'Tersimpan';
  }
  function kbIdx(id) { for (var i = 0; i < kbData.length; i++) if (kbData[i].id === id) return i; return -1; }
  /* v1.2.95: kb-foto — foto entri KB yang dikirim bot WhatsApp */
  function kbImgUrl(f) { return API + '?action=kb_media&f=' + encodeURIComponent(f) + '&token=' + encodeURIComponent(token); }
  function kbImgsHtml(e) {
    var imgs = e.images || [];
    return '<div class="kb-imgs" style="display:flex;flex-wrap:wrap;gap:8px;margin-bottom:6px">' +
      imgs.map(function (im, i) {
        return '<div style="position:relative;width:84px;height:84px;border-radius:8px;overflow:hidden;border:1px solid var(--line)">' +
          '<a href="' + kbImgUrl(im.file) + '" target="_blank" rel="noopener"><img src="' + kbImgUrl(im.file) + '" alt="" style="width:100%;height:100%;object-fit:cover;display:block"></a>' +
          '<button type="button" class="kb-img-del" data-i="' + i + '" title="Hapus foto" style="position:absolute;top:3px;right:3px;width:22px;height:22px;border-radius:50%;border:0;background:rgba(0,0,0,.65);color:#fff;cursor:pointer;font-size:14px;line-height:22px;padding:0">&times;</button></div>';
      }).join('') +
      (imgs.length < 6 ? '<label style="width:84px;height:84px;border:1px dashed var(--muted);border-radius:8px;display:flex;flex-direction:column;align-items:center;justify-content:center;cursor:pointer;font-size:12px;color:var(--muted);text-align:center;gap:2px">' +
        '<span style="font-size:22px;line-height:1">+</span>Tambah foto<input type="file" class="kb-img-in" accept="image/jpeg,image/png,image/webp,image/*" multiple style="display:none"></label>' : '') +
      '</div>' + (imgs.length ? '<label style="display:flex;align-items:center;gap:6px;margin:4px 0 6px;font-size:13px;cursor:pointer"><input type="checkbox" class="kb-foto-auto"' + (e.foto_auto ? ' checked' : '') + '> Kirim otomatis tanpa diminta</label>' : '') +   // v1.2.178: foto-otomatis
      '<div class="help">' + (e.foto_auto ? 'Dikirim bot WhatsApp <b>otomatis</b> setiap kali bot menjawab memakai info entri ini (sekali per percakapan), walau pelanggan tidak minta foto.' : 'Dikirim bot WhatsApp bila pelanggan minta, mis. <i>"bisa kirim foto kamarnya?"</i>, <i>"ada foto menunya?"</i>, <i>"kirim QR pembayarannya"</i>. Centang <b>Kirim otomatis</b> agar foto langsung ikut terkirim tanpa diminta.') + ' Maks 6 foto per entri. Tulis judul & isi yang jelas supaya bot tahu foto ini tentang apa, lalu klik <b>Simpan</b>.</div>';
  }
  // Foto besar dikecilkan (maks 1600px, JPEG). PNG kecil (mis. QR) dikirim apa adanya supaya tetap tajam.
  function kbPrepImage(file) {
    return new Promise(function (resolve, reject) {
      if (!/^image\//.test(file.type || '')) return reject(new Error(file.name + ' bukan file gambar'));
      var rd = new FileReader();
      rd.onerror = function () { reject(new Error('File tidak terbaca')); };
      rd.onload = function () {
        if (file.type === 'image/png' && file.size <= 1500000) return resolve(rd.result);
        var img = new Image();
        img.onerror = function () { reject(new Error('Format gambar ' + file.name + ' tidak didukung')); };
        img.onload = function () {
          var w = img.naturalWidth, h = img.naturalHeight, r = Math.min(1, 1600 / Math.max(w, h));
          var c = document.createElement('canvas'); c.width = Math.max(1, Math.round(w * r)); c.height = Math.max(1, Math.round(h * r));
          var x = c.getContext('2d'); x.fillStyle = '#fff'; x.fillRect(0, 0, c.width, c.height); x.drawImage(img, 0, 0, c.width, c.height);
          resolve(c.toDataURL('image/jpeg', 0.88));
        };
        img.src = rd.result;
      };
      rd.readAsDataURL(file);
    });
  }

  function renderKb() {
    var term = ($('#kbSearch').value || '').toLowerCase();
    var cats = {};
    kbData.forEach(function (e) { var c = (e.category || '').trim() || 'Tanpa kategori'; cats[c] = (cats[c] || 0) + 1; });
    var catNames = Object.keys(cats).sort(function (x, y) { return x.localeCompare(y); });
    if (kbCatFilter && !cats[kbCatFilter]) kbCatFilter = '';
    var chips = '<button class="kb-chip' + (kbCatFilter ? '' : ' on') + '" data-cat="">Semua <span>' + kbData.length + '</span></button>' +
      catNames.map(function (c) {
        return '<button class="kb-chip' + (kbCatFilter === c ? ' on' : '') + '" data-cat="' + esc(c) + '">' + esc(c) + ' <span>' + cats[c] + '</span></button>';
      }).join('');
    var shown = [];
    kbData.forEach(function (e, i) {
      var c = (e.category || '').trim() || 'Tanpa kategori';
      if (kbCatFilter && c !== kbCatFilter) return;
      if (term && ((e.title || '') + ' ' + (e.content || '') + ' ' + (e.category || '')).toLowerCase().indexOf(term) === -1) return;
      shown.push(i);
    });
    if (kbSelId && kbIdx(kbSelId) === -1) kbSelId = null;
    var wide = window.matchMedia('(min-width: 861px)').matches;
    if (!kbSelId && wide && shown.length) kbSelId = kbData[shown[0]].id;
    var items = shown.map(function (i) {
      var e = kbData[i];
      var snip = (e.content || '').replace(/\s+/g, ' ').slice(0, 90);
      return '<button class="kb-item' + (e.id === kbSelId ? ' on' : '') + '" data-id="' + esc(e.id) + '">' +
        '<b>' + (esc(e.title) || '<i style="color:var(--muted)">(tanpa judul)</i>') + '</b>' +
        '<small>' + (e.category ? '<em>' + esc(e.category) + '</em> · ' : '') + ((e.images && e.images.length) ? '<em>' + e.images.length + ' foto</em> · ' : '') + (esc(snip) || '—') + '</small></button>';   // v1.2.95
    }).join('') || '<div class="kb-empty">Tidak ada entri yang cocok.</div>';
    var si = kbSelId ? kbIdx(kbSelId) : -1, ed;
    if (si === -1) {
      ed = '<div class="kb-empty" style="padding:60px 20px">Pilih entri di kiri untuk melihat &amp; mengedit,<br>atau klik <b>+ Tambah Entri</b>.</div>';
    } else {
      var e = kbData[si];
      ed = '<div class="kb-ed-head"><button class="btn ghost sm kb-back">&larr; Daftar</button>' +
          '<span class="help">Entri ' + (shown.indexOf(si) + 1 || '-') + ' dari ' + shown.length + '</span>' +
          '<span style="margin-left:auto;display:flex;gap:6px">' +
          '<button class="btn ghost sm kb-prev" title="Sebelumnya">&uarr;</button>' +
          '<button class="btn ghost sm kb-next" title="Berikutnya">&darr;</button></span></div>' +
        '<div class="row"><label class="fl">Judul / Pertanyaan</label><input type="text" class="kb-title" value="' + esc(e.title) + '"></div>' +
        '<div class="grid2">' +
          '<div class="row"><label class="fl">Kategori</label><input type="text" class="kb-cat" list="kbCatDl" value="' + esc(e.category) + '"></div>' +
          '<div class="row"><label class="fl">Topik (routing notif)</label><select class="kb-topic">' + kbTopicOptions(e.topic || '') + '</select></div>' +
        '</div>' +
        '<div class="row"><label class="fl">Isi / Jawaban</label><textarea class="kb-content">' + esc(e.content) + '</textarea></div>' +
        '<div class="row"><label class="fl">Foto untuk WhatsApp</label>' + kbImgsHtml(e) + '</div>' +   // v1.2.95: kb-foto
        '<datalist id="kbCatDl">' + catNames.filter(function (c) { return c !== 'Tanpa kategori'; }).map(function (c) { return '<option value="' + esc(c) + '">'; }).join('') + '</datalist>' +
        '<div class="kb-ed-foot"><button class="btn danger sm kb-del">' + ico('trash-2',14) + ' Hapus entri</button>' +
        '<span class="help kb-save-hint">' + (kbDirty ? 'Ada perubahan belum disimpan' : 'Tersimpan') + '</span>' +
        '<button class="btn kb-save' + (kbDirty ? ' kb-dirty' : '') + '">' + ico('save',14) + ' Simpan</button></div>';
    }
    var wrap = $('#kbList');
    var _ks = $('#kbSearch'), _ksFoc = _ks && document.activeElement === _ks, _ksPos = _ks ? _ks.selectionStart : 0;   // v1.2.133: kb-cari
    wrap.innerHTML =
      '<div class="kb-chips">' + chips + '</div>' +
      '<div class="kb-md' + (si !== -1 ? ' has-sel' : '') + '">' +
        '<div class="kb-side"><div class="kb-search"></div><div class="kb-count">' + shown.length + ' entri' + (term ? ' cocok dari ' + kbData.length : '') + '</div><div class="kb-items">' + items + '</div></div>' +
        '<div class="kb-ed card">' + ed + '</div>' +
      '</div>';
    var _kslot = wrap.querySelector('.kb-search');   // v1.2.133: kb-cari: pindahkan input yang sama (fokus & kursor tetap)
    if (_ks && _kslot) { _kslot.appendChild(_ks); if (_ksFoc) { _ks.focus(); try { _ks.setSelectionRange(_ksPos, _ksPos); } catch (e) {} } }
    $$('#kbList .kb-chip').forEach(function (c) { c.onclick = function () { kbCatFilter = c.dataset.cat; kbSelId = null; renderKb(); }; });
    $$('#kbList .kb-item').forEach(function (it) {
      it.onclick = function () { kbSelId = it.dataset.id; renderKb(); var t = wrap.querySelector('.kb-ed'); if (t && !wide) t.scrollIntoView({ block: 'start' }); };
    });
    var sel = wrap.querySelector('.kb-item.on'); if (sel && sel.scrollIntoViewIfNeeded) sel.scrollIntoViewIfNeeded(false);
    if (si === -1) return;
    var edEl = wrap.querySelector('.kb-ed');
    var listItem = function () { return wrap.querySelector('.kb-item.on'); };
    edEl.querySelector('.kb-title').oninput = function (ev) {
      kbData[si].title = ev.target.value; kbMarkDirty();
      var li = listItem(); if (li) li.querySelector('b').textContent = ev.target.value || '(tanpa judul)';
    };
    edEl.querySelector('.kb-cat').oninput = function (ev) { kbData[si].category = ev.target.value; kbMarkDirty(); };
    edEl.querySelector('.kb-cat').onchange = function () { renderKb(); };
    edEl.querySelector('.kb-content').oninput = function (ev) { kbData[si].content = ev.target.value; kbMarkDirty(); };
    edEl.querySelector('.kb-topic').onchange = function (ev) { kbData[si].topic = ev.target.value; kbMarkDirty(); };
    var kbFa = edEl.querySelector('.kb-foto-auto');   // v1.2.178: foto-otomatis
    if (kbFa) kbFa.onchange = function () { kbData[si].foto_auto = kbFa.checked; kbMarkDirty(); renderKb(); saveKb(); };   // v1.2.181: kb-simpan-aman: centang langsung tersimpan
    edEl.querySelectorAll('.kb-img-del').forEach(function (b) {   // v1.2.95: kb-foto
      b.onclick = function () { (kbData[si].images || []).splice(+b.dataset.i, 1); kbMarkDirty(); renderKb(); };
    });
    var kbImgIn = edEl.querySelector('.kb-img-in');
    if (kbImgIn) kbImgIn.onchange = function () {
      var id = kbData[si].id;
      var files = Array.prototype.slice.call(kbImgIn.files || []).slice(0, Math.max(0, 6 - (kbData[si].images || []).length));
      if (!files.length) return;
      toast('Mengunggah ' + files.length + ' foto…');
      var added = 0;
      files.reduce(function (p, f) {
        return p.then(function () { return kbPrepImage(f); })
          .then(function (data) { return api('kb_image_upload', { method: 'POST', body: { data: data } }); })
          .then(function (res) {
            if (!res || !res.ok) { toast((res && res.error) || 'Gagal mengunggah foto.', true); return; }
            var k = kbIdx(id); if (k === -1) return;
            kbData[k].images = (kbData[k].images || []).concat([{ file: res.file }]); added++; kbMarkDirty();
          });
      }, Promise.resolve())
        .catch(function (err) { toast((err && err.message) || 'Gagal mengunggah foto.', true); })
        .then(function () { renderKb(); if (added) toast(added + ' foto ditambahkan — klik Simpan.'); });
    };
    edEl.querySelector('.kb-del').onclick = function () {
      if (!confirm('Hapus entri "' + (kbData[si].title || 'tanpa judul') + '"?')) return;
      var pos = shown.indexOf(si);
      var rest = shown.filter(function (x) { return x !== si; });
      var nxIdx = rest.length ? rest[Math.min(pos, rest.length - 1)] : null;
      var nxId = nxIdx != null ? kbData[nxIdx].id : null;
      kbData.splice(si, 1); kbMarkDirty();
      kbSelId = nxId;
      renderKb();
    };
    edEl.querySelector('.kb-save').onclick = function () { saveKb(); };   // v1.2.63
    edEl.querySelector('.kb-back').onclick = function () { kbSelId = null; renderKb(); };
    var step = function (d) { var p = shown.indexOf(si) + d; if (p >= 0 && p < shown.length) { kbSelId = kbData[shown[p]].id; renderKb(); } };
    edEl.querySelector('.kb-prev').onclick = function () { step(-1); };
    edEl.querySelector('.kb-next').onclick = function () { step(1); };
  }
  /* ---- v1.2.62: impor PDF -> entri KB (ekstrak teks di browser, AI menyusun entri) ---- */
  var PDFJS_VER = '3.11.174';
  function loadPdfJs() {
    if (window.pdfjsLib) return Promise.resolve(window.pdfjsLib);
    return new Promise(function (ok, fail) {
      var sc = document.createElement('script');
      sc.src = 'https://cdnjs.cloudflare.com/ajax/libs/pdf.js/' + PDFJS_VER + '/pdf.min.js';
      sc.onload = function () {
        window.pdfjsLib.GlobalWorkerOptions.workerSrc = 'https://cdnjs.cloudflare.com/ajax/libs/pdf.js/' + PDFJS_VER + '/pdf.worker.min.js';
        ok(window.pdfjsLib);
      };
      sc.onerror = function () { fail(new Error('Gagal memuat pembaca PDF (cek koneksi internet).')); };
      document.head.appendChild(sc);
    });
  }
  function pdfExtractText(file, onPage) {
    return loadPdfJs().then(function (lib) {
      return file.arrayBuffer().then(function (buf) { return lib.getDocument({ data: buf }).promise; });
    }).then(function (pdf) {
      var pages = [], n = pdf.numPages, chain = Promise.resolve();
      for (var p = 1; p <= n; p++) (function (p) {
        chain = chain.then(function () { return pdf.getPage(p); }).then(function (pg) { return pg.getTextContent(); })
          .then(function (tc) {
            var out = '', lastY = null;
            tc.items.forEach(function (it) {
              var y = it.transform ? Math.round(it.transform[5]) : null;
              if (lastY !== null && y !== null && Math.abs(y - lastY) > 2) out += '\n';
              out += it.str + (it.hasEOL ? '\n' : '');
              lastY = y;
            });
            pages.push(out.replace(/[ \t]+/g, ' ').replace(/\n{3,}/g, '\n\n').trim());
            if (onPage) onPage(p, n);
          });
      })(p);
      return chain.then(function () { return pages; });
    });
  }
  function chunkText(pages, max) {
    var chunks = [], cur = '';
    pages.forEach(function (pg) {
      pg.split(/\n{2,}/).forEach(function (para) {
        while (para.length > max) {           // paragraf raksasa: potong paksa
          if (cur) { chunks.push(cur); cur = ''; }
          chunks.push(para.slice(0, max)); para = para.slice(max);
        }
        if ((cur + '\n\n' + para).length > max && cur) { chunks.push(cur); cur = ''; }
        cur += (cur ? '\n\n' : '') + para;
      });
    });
    if (cur.trim()) chunks.push(cur);
    return chunks;
  }
  function importKbPdf(file) {
    if (!file) return;
    if (file.size > 25 * 1024 * 1024) { toast('PDF terlalu besar (maks 25 MB).', true); return; }
    var box = document.getElementById('pdfResult');
    var src = file.name.replace(/\.pdf$/i, '');
    var stop = false;
    box.style.display = '';
    var show = function (html) { box.innerHTML = '<h3 style="margin-top:0">Impor PDF: ' + esc(file.name) + '</h3>' + html; };
    show('<p class="help">Membaca PDF…</p>');
    pdfExtractText(file, function (p, n) { show('<p class="help">Membaca halaman ' + p + ' / ' + n + '…</p>'); })
    .then(function (pages) {
      var total = pages.join('').replace(/\s/g, '').length;
      if (total < 50) {
        show('<p style="color:var(--warn)">PDF ini tidak memuat teks yang bisa dibaca (kemungkinan hasil scan/gambar). ' +
             'Gunakan PDF hasil ekspor dari Word/Google Docs, atau jalankan OCR dulu.</p>');
        return;
      }
      var chunks = chunkText(pages, 7000);
      if (chunks.length > 40 && !confirm('Dokumen ini besar (' + chunks.length + ' bagian, ' + pages.length + ' halaman). ' +
          'Proses akan memakai kuota AI cukup banyak. Lanjutkan?')) { box.style.display = 'none'; return; }
      var added = 0, failed = 0, i = 0, lastErr = '';
      var progress = function () {
        show('<div style="display:flex;align-items:center;gap:12px">' +
          '<div style="flex:1;height:8px;background:var(--bg);border-radius:6px;overflow:hidden">' +
          '<div style="height:100%;width:' + Math.round(i / chunks.length * 100) + '%;background:var(--brand);transition:width .3s"></div></div>' +
          '<span class="help">' + i + ' / ' + chunks.length + ' bagian · ' + added + ' entri</span>' +
          '<button class="btn ghost sm" id="btnPdfStop">Hentikan</button></div>' +
          '<p class="help" style="margin-top:8px">AI sedang menyusun entri dari ' + pages.length + ' halaman. Jangan tutup halaman ini.</p>');
        var b = document.getElementById('btnPdfStop'); if (b) b.onclick = function () { stop = true; b.disabled = true; b.textContent = 'Menghentikan…'; };
      };
      var next = function () {
        if (stop || i >= chunks.length) return finish();
        progress();
        return api('kb_from_text', { method: 'POST', body: { text: chunks[i], source: src } }).then(function (res) {
          if (res && res.ok) {
            (res.entries || []).forEach(function (e, k) {
              kbData.unshift({ id: 'kb_' + Date.now() + '_' + i + '_' + k, category: e.category || src, title: e.title || '', content: e.content || '', topic: '' });
              added++;
            });
            if ((res.entries || []).length) { kbMarkDirty(); renderKb(); }
          } else {
            failed++; lastErr = (res && res.error) || 'Respons tidak valid dari server.';
            if (/API key|belum dikonfigurasi/i.test(lastErr)) stop = true;   // salah konfigurasi: jangan buang waktu ke bagian berikutnya
          }
        }).catch(function (er) { failed++; lastErr = (er && er.message) || 'Koneksi gagal.'; }).then(function () { i++; return next(); });
      };
      var finish = function () {
        progress();
        show('<p><b>' + added + ' entri</b> ditambahkan dari ' + esc(file.name) + (stop ? ' (dihentikan di bagian ' + i + ' dari ' + chunks.length + ')' : '') + '.' +
          (failed ? ' <span style="color:var(--warn)">' + failed + ' bagian gagal diproses.</span>' : '') + '</p>' +
          (lastErr ? '<p style="color:var(--warn);margin-top:6px">Penyebab: ' + esc(lastErr) + '</p>' : '') +
          '<p class="help" style="margin-top:6px">Entri belum tersimpan. Periksa isinya di daftar, jalankan <b>Analisa Duplikat</b> bila perlu, lalu klik <b>Simpan Perubahan</b>.</p>' +
          '<button class="btn ghost sm" id="btnPdfClose" style="margin-top:10px">Tutup</button>');
        document.getElementById('btnPdfClose').onclick = function () { box.style.display = 'none'; };
        if (added) toast(added + ' entri dari PDF ditambahkan — klik "Simpan Perubahan" untuk menyimpan.');
      };
      return next();
    })
    .catch(function (err) {
      show('<p style="color:var(--warn)">Gagal membaca PDF: ' + esc(err && err.message ? err.message : 'format tidak dikenali') + '</p>');
    });
  }
  /* ---- v1.2.132: kb-url — impor dari URL halaman website (server ambil teks, AI menyusun entri via kb_from_text) ---- */
  var KB_URL_MAX = 10;
  function openKbUrl(prefill) {
    var box = document.getElementById('pdfResult');
    box.style.display = '';
    box.innerHTML = '<h3 style="margin-top:0">' + ico('globe', 16) + ' Impor dari URL Website</h3>' +
      '<p class="help" style="margin:0 0 8px">Tempel link halaman (satu per baris, maks ' + KB_URL_MAX + '). Sistem membaca isi halaman lalu AI menyusun entri KB. ' +
      'Halaman yang isinya dimuat lewat JavaScript atau dilindungi login mungkin tidak terbaca.</p>' +
      '<textarea id="kbUrlInput" rows="4" style="width:100%" placeholder="https://contoh.com/fasilitas&#10;https://contoh.com/harga">' + esc(prefill || '') + '</textarea>' +
      '<div style="display:flex;gap:8px;margin-top:10px"><button class="btn" id="btnKbUrlGo">Ambil &amp; Susun Entri</button>' +
      '<button class="btn ghost" id="btnKbUrlCancel">Batal</button></div>';
    var ta = document.getElementById('kbUrlInput'); ta.focus();
    document.getElementById('btnKbUrlCancel').onclick = function () { box.style.display = 'none'; };
    document.getElementById('btnKbUrlGo').onclick = function () {
      var seen = {}, urls = ta.value.split(/[\s,]+/).map(function (u) { return u.trim(); })
        .filter(function (u) { if (!u || seen[u]) return false; seen[u] = 1; return /^(https?:\/\/)?[^\s\/]+\.[^\s\/]+/i.test(u); });
      if (!urls.length) { toast('Masukkan minimal satu link halaman.', true); return; }
      if (urls.length > KB_URL_MAX) { toast('Maksimal ' + KB_URL_MAX + ' link sekali impor. ' + urls.length + ' link dimasukkan.', true); return; }
      importKbUrls(urls);
    };
  }
  function importKbUrls(urls) {
    var box = document.getElementById('pdfResult');
    var stop = false, added = 0, ui = 0, phase = '', pct = 0, results = [], found = {}, done = {};
    box.style.display = '';
    var show = function (html) { box.innerHTML = '<h3 style="margin-top:0">' + ico('globe', 16) + ' Impor dari URL Website</h3>' + html; };
    var progress = function () {
      show('<div style="display:flex;align-items:center;gap:12px">' +
        '<div style="flex:1;height:8px;background:var(--bg);border-radius:6px;overflow:hidden">' +
        '<div style="height:100%;width:' + pct + '%;background:var(--brand);transition:width .3s"></div></div>' +
        '<span class="help">Halaman ' + Math.min(ui + 1, urls.length) + ' / ' + urls.length + ' · ' + added + ' entri</span>' +
        '<button class="btn ghost sm" id="btnUrlStop">Hentikan</button></div>' +
        '<p class="help" style="margin-top:8px;word-break:break-all">' + esc(phase) + '</p>');
      var b = document.getElementById('btnUrlStop'); if (b) b.onclick = function () { stop = true; b.disabled = true; b.textContent = 'Menghentikan…'; };
    };
    var one = function (url) {
      var r = { url: url, title: '', entries: 0, error: '', note: '' };
      results.push(r);
      phase = 'Mengambil ' + url + ' …'; pct = Math.round(ui / urls.length * 100); progress();
      return api('kb_fetch_url', { method: 'POST', body: { url: url } }).then(function (res) {
        if (!res || !res.ok) { r.error = (res && res.error) || 'Respons tidak valid dari server.'; return; }
        r.url = res.url || url; r.title = res.title || '';
        done[String(r.url).replace(/\/$/, '')] = 1; done[String(url).replace(/\/$/, '')] = 1;
        (res.links || []).forEach(function (l) { var k = String(l.url).replace(/\/$/, ''); if (!found[k]) found[k] = l; });
        if ((res.chars || 0) < 80) { r.note = 'Teks halaman hampir kosong — kemungkinan dimuat lewat JavaScript. Salin isinya manual atau gunakan PDF.'; return; }
        if (res.truncated) r.note = 'Halaman sangat panjang; hanya 60.000 karakter pertama yang diproses.';
        var host = ''; try { host = new URL(r.url).hostname.replace(/^www\./, ''); } catch (e) {}
        var src = (r.title || host || 'Website').slice(0, 80);
        var chunks = chunkText([res.text], 7000), ci = 0;
        var nextChunk = function () {
          if (stop || ci >= chunks.length) return;
          phase = 'AI menyusun entri dari "' + src + '" (bagian ' + (ci + 1) + ' / ' + chunks.length + ') …';
          pct = Math.round((ui + (ci + 0.5) / chunks.length) / urls.length * 100); progress();
          return api('kb_from_text', { method: 'POST', body: { text: chunks[ci], source: src + ' — ' + r.url } }).then(function (rs) {
            if (rs && rs.ok) {
              (rs.entries || []).forEach(function (e, k) {
                kbData.unshift({ id: 'kb_' + Date.now() + '_' + ui + '_' + ci + '_' + k, category: e.category || host || 'Website', title: e.title || '', content: e.content || '', topic: '' });
                added++; r.entries++;
              });
              if ((rs.entries || []).length) { kbMarkDirty(); renderKb(); }
            } else {
              r.error = (rs && rs.error) || 'Respons tidak valid dari server.';
              if (/API key|belum dikonfigurasi/i.test(r.error)) stop = true;
            }
          }).catch(function (er) { r.error = (er && er.message) || 'Koneksi gagal.'; }).then(function () { ci++; return nextChunk(); });
        };
        return nextChunk();
      }).catch(function (er) { r.error = (er && er.message) || 'Koneksi gagal.'; });
    };
    var next = function () {
      if (stop || ui >= urls.length) return finish();
      return one(urls[ui]).then(function () { ui++; return next(); });
    };
    var finish = function () {
      var rows = results.map(function (r) {
        var st = r.error ? '<span style="color:var(--warn)">' + esc(r.error) + '</span>'
          : (r.entries ? '<b>' + r.entries + ' entri</b>' : '<span class="help">0 entri</span>');
        return '<li style="margin:4px 0;word-break:break-all">' + (r.title ? esc(r.title) + ' — ' : '') + '<span class="help">' + esc(r.url) + '</span> · ' + st +
          (r.note ? '<br><span class="help" style="color:var(--warn)">' + esc(r.note) + '</span>' : '') + '</li>';
      }).join('');
      var more = Object.keys(found).filter(function (k) { return !done[k]; }).slice(0, 60).map(function (k) { return found[k]; });
      var moreHtml = more.length ? '<details style="margin-top:12px"' + (added ? '' : ' open') + '><summary><b>Halaman lain di situs ini (' + more.length + ')</b> — centang untuk ikut diimpor</summary>' +
        '<div style="max-height:260px;overflow:auto;margin:8px 0;border:1px solid var(--line, #e5e7eb);border-radius:8px;padding:6px 10px">' +
        more.map(function (l, i) {
          return '<label style="display:flex;gap:8px;align-items:flex-start;margin:4px 0;font-size:13px;cursor:pointer"><input type="checkbox" class="kb-url-more" value="' + esc(l.url) + '" style="margin-top:3px">' +
            '<span style="word-break:break-all">' + (l.text ? esc(l.text) + ' <span class="help">' + esc(l.url) + '</span>' : esc(l.url)) + '</span></label>';
        }).join('') + '</div><button class="btn sm" id="btnUrlMore">Impor halaman terpilih</button></details>' : '';
      show('<p><b>' + added + ' entri</b> ditambahkan dari ' + results.length + ' halaman' + (stop ? ' (dihentikan)' : '') + '.</p>' +
        '<ul style="margin:6px 0 0;padding-left:18px">' + rows + '</ul>' +
        '<p class="help" style="margin-top:8px">Entri belum tersimpan. Periksa isinya di daftar, jalankan <b>Analisa Duplikat</b> bila perlu, lalu klik <b>Simpan Perubahan</b>.</p>' +
        moreHtml +
        '<div style="display:flex;gap:8px;margin-top:10px"><button class="btn ghost sm" id="btnUrlAgain">Impor URL lain</button><button class="btn ghost sm" id="btnUrlClose">Tutup</button></div>');
      document.getElementById('btnUrlClose').onclick = function () { box.style.display = 'none'; };
      document.getElementById('btnUrlAgain').onclick = function () { openKbUrl(''); };
      var bm = document.getElementById('btnUrlMore');
      if (bm) bm.onclick = function () {
        var sel = $$('#pdfResult .kb-url-more').filter(function (c) { return c.checked; }).map(function (c) { return c.value; });
        if (!sel.length) { toast('Centang minimal satu halaman.', true); return; }
        if (sel.length > KB_URL_MAX) { toast('Maksimal ' + KB_URL_MAX + ' halaman sekali impor.', true); return; }
        importKbUrls(sel);
      };
      if (added) toast(added + ' entri dari website ditambahkan — klik "Simpan Perubahan" untuk menyimpan.');
    };
    return next();
  }
  function saveKb(force) {   // v1.2.181: kb-simpan-aman
    api('save_kb', { method: 'POST', body: { kb: kbData, rev: kbRev, force: force === true } }).then(function (res) {
      if (res && res.conflict) {   // v1.2.181: kb-simpan-aman
        if (confirm(res.error + '\n\nOK = muat ulang (perubahan di halaman ini dibuang)\nBatal = tetap simpan versi halaman ini (menimpa perubahan dari tab/perangkat lain)')) {
          api('get_kb').then(function (k) { if (k.ok) { kbData = k.kb || []; kbRev = k.rev || ''; kbDirty = false; kbSaveUi(); renderKb(); toast('Knowledge Base dimuat ulang.'); } });
        } else saveKb(true);
        return;
      }
      if (res.ok) { kbRev = res.rev || kbRev; kbDirty = false; var sb = document.getElementById('btnSaveKb'); if (sb) sb.classList.remove('kb-dirty'); kbSaveUi(); toast('Knowledge base disimpan (' + res.count + ' entri).'); }
      else toast(res.error || 'Gagal menyimpan.', true);
    });
  }

  /* ---- CSV import: kolom category, question, answer ---- */
  function parseCsv(text) {
    text = String(text).replace(/^\uFEFF/, '');           // buang BOM
    var head = (text.split(/\r\n|\n|\r/)[0] || '');
    var nC = (head.match(/,/g) || []).length,
        nS = (head.match(/;/g) || []).length,
        nT = (head.match(/\t/g) || []).length;
    var delim = ',';
    if (nS >= nC && nS >= nT && nS > 0) delim = ';';
    else if (nT > nC && nT > nS) delim = '\t';
    var rows = [], row = [], field = '', i = 0, inQ = false;
    while (i < text.length) {
      var ch = text[i];
      if (inQ) {
        if (ch === '"') {
          if (text[i + 1] === '"') { field += '"'; i += 2; continue; }
          inQ = false; i++; continue;
        }
        field += ch; i++; continue;
      }
      if (ch === '"') { inQ = true; i++; continue; }
      if (ch === delim) { row.push(field); field = ''; i++; continue; }
      if (ch === '\r') { i++; continue; }
      if (ch === '\n') { row.push(field); rows.push(row); row = []; field = ''; i++; continue; }
      field += ch; i++;
    }
    if (field !== '' || row.length) { row.push(field); rows.push(row); }
    return rows;
  }

  function importKbCsv(file) {
    if (!file) return;
    var reader = new FileReader();
    reader.onerror = function () { toast('Gagal membuka file.', true); };
    reader.onload = function () {
      try {
        var rows = parseCsv(reader.result);
        if (!rows.length) { toast('File CSV kosong.', true); return; }
        var first = rows[0].map(function (c) { return String(c).trim().toLowerCase(); });
        var headerWords = ['category', 'question', 'answer', 'kategori', 'pertanyaan', 'jawaban'];
        var hasHeader = first.some(function (c) { return headerWords.indexOf(c) !== -1; });
        var added = 0, skipped = 0;
        for (var r = hasHeader ? 1 : 0; r < rows.length; r++) {
          var cols = rows[r] || [];
          var category = (cols[0] || '').trim();
          var question = (cols[1] || '').trim();
          var answer = (cols[2] || '').trim();
          if (!category && !question && !answer) continue;   // baris kosong
          if (!answer) { skipped++; continue; }               // wajib ada jawaban
          kbData.unshift({ id: 'kb_' + Date.now() + '_' + r, category: category, title: question, content: answer, topic: '' });
          added++; kbMarkDirty();
        }
        renderKb();
        if (added) {
          var msg = added + ' entri ditambahkan dari CSV — klik "Simpan Perubahan" untuk menyimpan.';
          if (skipped) msg += ' (' + skipped + ' baris dilewati karena kolom answer kosong.)';
          toast(msg);
        } else {
          toast('Tidak ada baris valid. Pastikan urutan kolom: category, question, answer.', true);
        }
      } catch (err) {
        toast('Gagal membaca CSV: ' + (err && err.message ? err.message : 'format tidak dikenali'), true);
      }
    };
    reader.readAsText(file, 'UTF-8');
  }

  function downloadKbTemplate() {
    var csv = '\uFEFF' + 'category,question,answer\r\n' +
      '"Layanan","Apa saja layanan yang Anda tawarkan?","Kami menyediakan layanan konsultasi, pelatihan, dan pendampingan."\r\n' +
      '"Harga","Berapa biaya layanannya?","Biaya menyesuaikan kebutuhan. Silakan hubungi kami untuk penawaran."\r\n' +
      '"Kontak","Bagaimana cara menghubungi tim Anda?","Anda bisa menghubungi kami via WhatsApp pada jam kerja 09.00-17.00 WIB."\r\n';
    var blob = new Blob([csv], { type: 'text/csv;charset=utf-8' });
    var a = document.createElement('a');
    a.href = URL.createObjectURL(blob);
    a.download = 'template-knowledge-base.csv';
    document.body.appendChild(a); a.click();
    setTimeout(function () { document.body.removeChild(a); URL.revokeObjectURL(a.href); }, 0);
  }

  /* ====================================================================== *
   *  CONTENT (Reply & Appearance)
   * ====================================================================== */
  var settingsCache = null;
  function loadContent() {
    api('get_settings').then(function (res) {
      if (!res.ok) return;
      settingsCache = res.settings;
      fillContent(res.settings);
    });
    $('#btnAddQuick').onclick = function () { addQuickRow(''); };
    $('#btnSaveContent').onclick = saveContent;
    $('#c_color').oninput = function () { $('#c_color_hex').value = $('#c_color').value; };
    $('#c_color_hex').oninput = function () { var v = $('#c_color_hex').value; if (/^#[0-9a-fA-F]{6}$/.test(v)) $('#c_color').value = v; };

    // v1.1.6+v1.1.9: Avatar event wiring
    document.getElementById('c_avatar_type_emoji').onchange = function () { toggleAvatarRows('emoji'); };
    document.getElementById('c_avatar_type_icon').onchange  = function () { toggleAvatarRows('icon'); };
    document.getElementById('c_avatar_type_image').onchange = function () { toggleAvatarRows('image'); };
    document.getElementById('c_avatar_emoji_picker').onchange = updateEmojiPreview;
    document.getElementById('c_avatar_emoji_custom').oninput = updateEmojiPreview;
    document.getElementById('c_avatar_icon_picker').onchange = updateIconPreview;
    document.getElementById('c_avatar_file').onchange = handleAvatarFile;
    document.getElementById('c_avatar_image_clear').onclick = function () {
      document.getElementById('c_avatar_image').value = '';
      document.getElementById('c_avatar_image_preview').style.display = 'none';
      this.style.display = 'none';
      document.getElementById('c_avatar_file').value = '';
      document.getElementById('c_avatar_image_status').textContent = 'Maks 2 MB · Otomatis di-resize jadi 96×96 px PNG (crop center) · Format: PNG/JPG/WEBP';
      document.getElementById('c_avatar_image_status').style.color = '';
    };
  }

  /**
   * v1.1.6: Client-side avatar resize via Canvas API, then upload.
   *
   * Flow: read file → validate size/type → load as Image → draw on 96×96 canvas
   * (crop center, like CSS background-size:cover) → toBlob PNG → POST to upload_avatar.
   * Server validates again + writes file → returns relative URL.
   */
  function handleAvatarFile(ev) {
    var file = ev.target.files[0];
    var statusEl = document.getElementById('c_avatar_image_status');
    if (!file) return;
    if (file.size > 2 * 1024 * 1024) {
      statusEl.textContent = '✗ Ukuran file melebihi 2 MB.';
      statusEl.style.color = '#c4302b';
      ev.target.value = '';
      return;
    }
    if (!/^image\/(png|jpe?g|webp)$/.test(file.type)) {
      statusEl.textContent = '✗ Format harus PNG, JPG, atau WEBP.';
      statusEl.style.color = '#c4302b';
      ev.target.value = '';
      return;
    }
    statusEl.textContent = 'Memproses gambar…';
    statusEl.style.color = '';
    var reader = new FileReader();
    reader.onload = function (e) {
      var img = new Image();
      img.onload = function () {
        // Crop center to square, then scale to 96×96
        var size = Math.min(img.naturalWidth, img.naturalHeight);
        var sx = (img.naturalWidth - size) / 2;
        var sy = (img.naturalHeight - size) / 2;
        var canvas = document.createElement('canvas');
        canvas.width = 96; canvas.height = 96;
        var ctx = canvas.getContext('2d');
        ctx.imageSmoothingQuality = 'high';
        ctx.drawImage(img, sx, sy, size, size, 0, 0, 96, 96);
        // Preview immediately
        var previewUrl = canvas.toDataURL('image/png');
        var prev = document.getElementById('c_avatar_image_preview');
        prev.src = previewUrl;
        prev.style.display = '';

        canvas.toBlob(function (blob) {
          var fd = new FormData();
          fd.append('avatar', blob, 'avatar.png');
          var xhr = new XMLHttpRequest();
          xhr.open('POST', 'api/index.php?action=upload_avatar');
          xhr.setRequestHeader('X-Auth-Token', token);
          xhr.onload = function () {
            try {
              var res = JSON.parse(xhr.responseText);
              if (res.ok) {
                document.getElementById('c_avatar_image').value = res.url;
                document.getElementById('c_avatar_image_clear').style.display = '';
                statusEl.textContent = '✓ Tersimpan: ' + res.url + ' · ' + Math.round((res.size || 0)/1024) + ' KB. Klik Simpan untuk apply.';
                statusEl.style.color = '#16a34a';
              } else {
                statusEl.textContent = '✗ ' + (res.error || 'Upload gagal.');
                statusEl.style.color = '#c4302b';
              }
            } catch (e) {
              statusEl.textContent = '✗ Server error (lihat console).';
              statusEl.style.color = '#c4302b';
              console.error(xhr.responseText);
            }
          };
          xhr.onerror = function () {
            statusEl.textContent = '✗ Network error.';
            statusEl.style.color = '#c4302b';
          };
          xhr.send(fd);
        }, 'image/png');
      };
      img.onerror = function () {
        statusEl.textContent = '✗ Gagal memuat gambar.';
        statusEl.style.color = '#c4302b';
      };
      img.src = e.target.result;
    };
    reader.onerror = function () {
      statusEl.textContent = '✗ Gagal membaca file.';
      statusEl.style.color = '#c4302b';
    };
    reader.readAsDataURL(file);
  }
  function fillContent(s) {
    var b = s.bot || {}, a = s.appearance || {};
    $('#c_bot_name').value = b.bot_name || '';
    $('#c_greeting').value = b.greeting || '';
    $('#c_birthday_greeting').value = b.birthday_greeting || '';
    // v1.2.39 fase8: field ucapan ulang tahun hanya relevan kalau WhatsApp
    // Bot aktif (provider apa pun -- Meta atau Fonnte).
    // v1.2.39 fase8b: hanya Fonnte -- Meta menolak teks bebas di luar
    // jendela 24 jam, jadi ucapan ulang tahun tidak bisa diandalkan.
    var _waOnBd = !!(s.whatsapp_api && s.whatsapp_api.enabled && (s.whatsapp_api.provider === 'fonnte' || s.whatsapp_api.provider === 'waha'));   // v1.2.76
    if ($('#row_birthday_greeting'))  $('#row_birthday_greeting').style.display  = _waOnBd ? '' : 'none';
    if ($('#hint_birthday_greeting')) $('#hint_birthday_greeting').style.display = _waOnBd ? '' : 'none';
    $('#c_prompt').value = b.system_prompt || '';

    // v1.2.3: populate structured fields
    (function fillStructured() {
      if ($('#c_user_address'))   $('#c_user_address').value   = b.user_address   || '';
      if ($('#c_language_style')) $('#c_language_style').value = b.language_style || '';

      // Languages multi-select
      var langs = Array.isArray(b.languages) ? b.languages : [];
      document.querySelectorAll('.c_lang').forEach(function(cb) {
        cb.checked = langs.indexOf(cb.value) !== -1;
      });
      var behaviorRow = document.getElementById('c_lang_behavior_row');
      if (behaviorRow) behaviorRow.style.display = (langs.length > 1) ? '' : 'none';
      if ($('#c_language_prompt_behavior')) $('#c_language_prompt_behavior').value = b.language_prompt_behavior || 'ask_user';

      // Response rules
      var rules = b.response_rules || {};
      if ($('#c_rule_no_asterisk'))  $('#c_rule_no_asterisk').checked  = !!rules.no_asterisk;
      if ($('#c_rule_one_question')) $('#c_rule_one_question').checked = !!rules.one_question_at_a_time;
      if ($('#c_rule_summary'))      $('#c_rule_summary').checked      = !!rules.summary_before_confirm;
      if ($('#c_rule_emoji'))        $('#c_rule_emoji').checked        = !!rules.use_emoji;
      if ($('#c_rule_concise'))      $('#c_rule_concise').checked      = !!rules.concise_response;

      // Fallback behavior
      var fallback = b.fallback_behavior || '';
      document.querySelectorAll('input[name="c_fallback"]').forEach(function(r) {
        r.checked = (r.value === fallback);
      });

      // Wire language checkbox change -> show/hide behavior dropdown
      document.querySelectorAll('.c_lang').forEach(function(cb) {
        cb.onchange = function() {
          var checkedCount = document.querySelectorAll('.c_lang:checked').length;
          document.getElementById('c_lang_behavior_row').style.display = (checkedCount > 1) ? '' : 'none';
        };
      });

      // Wire preview button
      var btn = document.getElementById('btnPreviewPrompt');
      if (btn && !btn.dataset.wired) {
        btn.onclick = previewGeneratedPrompt;
        btn.dataset.wired = 'true';
      }
    })();
    $('#quickRows').innerHTML = '';
    _quickRepliesData = (b.quick_replies || []).slice();
    renderQuickRows();
    $('#c_color').value = a.primary_color || '#140383';
    $('#c_color_hex').value = a.primary_color || '#140383';
    $('#c_position').value = a.position || 'right';

    // v1.1.6+v1.1.9: Avatar — radio type (emoji/icon/image) + 3 picker
    var atype = a.avatar_type
              || (a.avatar_image ? 'image' : (a.avatar_icon_name ? 'icon' : 'emoji'));
    var ae = a.avatar_emoji || '🤖';
    var aiName = a.avatar_icon_name || 'bot';
    var ai = a.avatar_image || '';
    document.getElementById('c_avatar_type_emoji').checked = atype === 'emoji';
    document.getElementById('c_avatar_type_icon').checked  = atype === 'icon';
    document.getElementById('c_avatar_type_image').checked = atype === 'image';
    toggleAvatarRows(atype);

    // Emoji: kalau ada di dropdown preset, pakai; kalau tidak, mode custom
    var picker = document.getElementById('c_avatar_emoji_picker');
    var custom = document.getElementById('c_avatar_emoji_custom');
    var presetVals = [];
    for (var i=0; i<picker.options.length; i++) presetVals.push(picker.options[i].value);
    if (presetVals.indexOf(ae) !== -1) {
      picker.value = ae;
      custom.style.display = 'none';
      custom.value = '';
    } else if (ae) {
      picker.value = '__custom__';
      custom.style.display = '';
      custom.value = ae;
    } else {
      picker.value = '🤖';
    }
    updateEmojiPreview();

    // Icon picker (v1.1.9)
    var iconPicker = document.getElementById('c_avatar_icon_picker');
    var iconOpts = [];
    for (var j=0; j<iconPicker.options.length; j++) iconOpts.push(iconPicker.options[j].value);
    iconPicker.value = iconOpts.indexOf(aiName) !== -1 ? aiName : 'bot';
    updateIconPreview();

    // Image preview kalau ada
    document.getElementById('c_avatar_image').value = ai;
    var imgPrev = document.getElementById('c_avatar_image_preview');
    var clearBtn = document.getElementById('c_avatar_image_clear');
    if (ai) {
      imgPrev.src = ai + (ai.indexOf('?')<0 ? '?t=' + Date.now() : '');
      imgPrev.style.display = '';
      clearBtn.style.display = '';
    } else {
      imgPrev.style.display = 'none';
      clearBtn.style.display = 'none';
    }

    $('#c_offset_bottom').value = a.offset_bottom != null ? a.offset_bottom : 24;
    $('#c_offset_right').value = a.offset_right != null ? a.offset_right : 24;
  }

  function toggleAvatarRows(type) {
    document.getElementById('c_avatar_emoji_row').style.display = type === 'emoji' ? '' : 'none';
    document.getElementById('c_avatar_icon_row').style.display  = type === 'icon'  ? '' : 'none';
    document.getElementById('c_avatar_image_row').style.display = type === 'image' ? '' : 'none';
  }

  function updateEmojiPreview() {
    var picker = document.getElementById('c_avatar_emoji_picker');
    var custom = document.getElementById('c_avatar_emoji_custom');
    var preview = document.getElementById('c_avatar_emoji_preview');
    if (picker.value === '__custom__') {
      custom.style.display = '';
      preview.textContent = custom.value || '🤖';
    } else {
      custom.style.display = 'none';
      preview.textContent = picker.value;
    }
  }

  function updateIconPreview() {
    var picker = document.getElementById('c_avatar_icon_picker');
    var preview = document.getElementById('c_avatar_icon_preview');
    if (picker && preview) preview.innerHTML = ico(picker.value, 28);
  }

  function currentEmojiValue() {
    var picker = document.getElementById('c_avatar_emoji_picker');
    var custom = document.getElementById('c_avatar_emoji_custom');
    return picker.value === '__custom__' ? (custom.value.trim() || '🤖') : picker.value;
  }
  // v1.1.10 fix: array-based quick replies (avoid DOM sync bugs)
  var _quickRepliesData = [];
  function addQuickRow(val) {
    _quickRepliesData.push(val || '');
    renderQuickRows();
  }
  function renderQuickRows() {
    var container = $('#quickRows');
    container.innerHTML = '';
    _quickRepliesData.forEach(function (val, idx) {
      var row = document.createElement('div'); row.className = 'qr';
      var inp = document.createElement('input'); inp.type = 'text'; inp.value = val || '';
      inp.oninput = function () { _quickRepliesData[idx] = this.value; };
      var del = document.createElement('button'); del.type = 'button'; del.innerHTML = ico('x',14);
      del.onclick = function () {
        _quickRepliesData.splice(idx, 1);
        renderQuickRows();
      };
      row.appendChild(inp); row.appendChild(del); container.appendChild(row);
    });
  }
  function collectContent() {
    var quicks = _quickRepliesData.map(function (v) { return String(v || '').trim(); }).filter(Boolean);
    var avatarType = 'emoji';
    if (document.getElementById('c_avatar_type_icon').checked)  avatarType = 'icon';
    if (document.getElementById('c_avatar_type_image').checked) avatarType = 'image';
    return {
      bot: {
        bot_name: $('#c_bot_name').value,
        greeting: $('#c_greeting').value,
        birthday_greeting: $('#c_birthday_greeting').value,
        quick_replies: quicks,
        system_prompt: $('#c_prompt').value,
        // v1.2.3: structured fields
        user_address: ($('#c_user_address') ? $('#c_user_address').value : ''),
        language_style: ($('#c_language_style') ? $('#c_language_style').value : ''),
        languages: Array.prototype.slice.call(document.querySelectorAll('.c_lang:checked')).map(function(cb){return cb.value;}),
        language_prompt_behavior: ($('#c_language_prompt_behavior') ? $('#c_language_prompt_behavior').value : 'ask_user'),
        response_rules: {
          no_asterisk:            ($('#c_rule_no_asterisk')  && $('#c_rule_no_asterisk').checked),
          one_question_at_a_time: ($('#c_rule_one_question') && $('#c_rule_one_question').checked),
          summary_before_confirm: ($('#c_rule_summary')      && $('#c_rule_summary').checked),
          use_emoji:              ($('#c_rule_emoji')        && $('#c_rule_emoji').checked),
          concise_response:       ($('#c_rule_concise')      && $('#c_rule_concise').checked)
        },
        fallback_behavior: (function(){
          var r = document.querySelector('input[name="c_fallback"]:checked');
          return r ? r.value : '';
        })()
      },
      appearance: {
        primary_color: $('#c_color_hex').value || '#140383',
        position: $('#c_position').value,
        avatar_type:      avatarType,
        avatar_emoji:     currentEmojiValue(),
        avatar_icon_name: document.getElementById('c_avatar_icon_picker').value || 'bot',
        avatar_image:     document.getElementById('c_avatar_image').value || '',
        offset_bottom: +$('#c_offset_bottom').value || 24,
        offset_right: +$('#c_offset_right').value || 24
      }
    };
  }
  // v1.2.3: Generate prompt preview (mirror backend buildStructuredPromptPrefix)
  function previewGeneratedPrompt() {
    var data = collectContent();
    var b = data.bot;
    var parts = [];
    // v1.2.53: aturan bahasa tidak lagi di sini — ditempel PALING AKHIR (lihat ekorPrompt di bawah)
    if (b.user_address) parts.push('Sapa user dengan "' + b.user_address + '".');
    var styleMap = {formal:'Gunakan bahasa formal profesional.', semi_formal:'Gunakan bahasa semi-formal, ramah namun tetap profesional.', casual:'Gunakan bahasa casual friendly, seperti teman.', enthusiastic:'Gunakan bahasa antusias dengan energy tinggi.'};
    if (styleMap[b.language_style]) parts.push(styleMap[b.language_style]);
    var r = b.response_rules || {};
    if (r.no_asterisk)            parts.push("JANGAN pakai tanda * atau ** di jawaban (no markdown formatting).");
    if (r.one_question_at_a_time) parts.push("Tanya hanya 1 pertanyaan per turn, jangan langsung banyak.");
    if (r.summary_before_confirm) parts.push("Buat summary sebelum minta konfirmasi user.");
    if (r.use_emoji)              parts.push("Gunakan emoji ramah secukupnya.");
    if (r.concise_response)       parts.push("Jawaban maksimal 3 kalimat.");
    var fallMap = {
      say_dont_know: "Kalau tidak tahu jawaban dari knowledge base, katakan dengan sopan bahwa Anda belum memiliki info.",
      ask_contact:   'PENTING: Kalau tidak tahu jawaban dari knowledge base, JANGAN bilang "tidak tahu" atau "tidak memiliki info detail". Langsung tanyakan nama dan no HP user untuk dihubungi kembali oleh tim kami.',
      redirect_wa:   "Kalau tidak tahu jawaban, arahkan user untuk chat langsung dengan admin via WhatsApp."
    };
    if (fallMap[b.fallback_behavior]) parts.push(fallMap[b.fallback_behavior]);

    // v1.2.53: cermin deiAturanBahasa() di backend — ditempel paling akhir (SETELAH persona)
    var ekorBahasa = "";
    if (b.languages && b.languages.length > 1) {
      var lmap = {id:'Bahasa Indonesia', en:'English', zh:'Mandarin', ar:'Arabic', ja:'Japanese'};
      var smap = {id:'Bapak/Ibu', en:'Sir/Madam', zh:'\u5148\u751F/\u5973\u58EB', ar:'sayyidi/sayyidati', ja:'\u304A\u5BA2\u69D8'};
      var nms = b.languages.map(function(l){return lmap[l]||l;});
      var sps = b.languages.filter(function(l){return smap[l];}).map(function(l){return smap[l]+' untuk '+(lmap[l]||l);});
      var t = "=== ATURAN BAHASA (PALING UTAMA \u2014 MENGALAHKAN SEMUA ATURAN DI ATAS) ===\n";
      t += "Bahasa yang didukung: " + nms.join(', ') + ".\n";
      if (b.language_prompt_behavior === 'ask_user') {
        t += "1. HANYA pada pesan pertama percakapan, tanyakan tamu ingin memakai bahasa apa. Setelah tamu menjawab (atau kalau bahasa pesannya sudah jelas), JANGAN bertanya lagi.\n";
      } else {
        t += "1. Kenali bahasa dari pesan TERAKHIR tamu, lalu tulis SELURUH jawaban dalam bahasa itu. JANGAN PERNAH menanyakan tamu ingin memakai bahasa apa.\n";
      }
      t += "2. Instruksi di atas, contoh-contoh kalimatnya, dan seluruh Knowledge Base ditulis dalam Bahasa Indonesia. Itu bahasa SUMBER, BUKAN bahasa jawaban. Terjemahkan isinya ke bahasa tamu \u2014 jangan menyalin kalimat Bahasa Indonesia apa adanya.\n";
      if (sps.length) t += "3. Sapaan hormat mengikuti bahasa jawaban: " + sps.join(', ') + ". JANGAN memakai sapaan Bahasa Indonesia ketika menjawab dalam bahasa lain.\n";
      t += "4. Kalau tamu berganti bahasa di tengah percakapan, ikut berganti mulai jawaban berikutnya.\n";
      t += "5. Nama tempat, nama menu, dan tautan tetap ditulis apa adanya, tidak diterjemahkan.\n";
      ekorBahasa = t;
    }

    var prefix = parts.join("\n");
    var persona = b.system_prompt || '';
    var final = prefix ? (prefix + "\n\n=== INSTRUKSI TAMBAHAN ===\n" + persona) : persona;
    if (ekorBahasa) final += "\n\n" + ekorBahasa;   // v1.2.53: urutan persis seperti generateAnswer()

    if (!prefix) {
      alert('Struktur kosong — sistem akan pakai Persona/Instruksi AI existing di textarea.\n\nPreview persona sekarang:\n\n' + (persona.slice(0, 500) + (persona.length > 500 ? '...(truncated)' : '')));
    } else {
      alert('=== GENERATED PROMPT PREVIEW ===\n\n' + final.slice(0, 4000) + (final.length > 4000 ? '\n\n...(dipotong untuk pratinjau)' : ''));
    }

  }

  function saveContent() {
    // v1.2.3: warn kalau textarea system_prompt dikosongkan
    var promptText = ($('#c_prompt').value || '').trim();
    if (promptText === '' && settingsCache && settingsCache.bot && (settingsCache.bot.system_prompt || '').trim() !== '') {
      if (!confirm('Anda mengosongkan "Persona / Instruksi AI" (System Prompt).\n\nInstruksi custom Anda akan hilang. Chatbot akan lebih generic.\n\nLanjutkan simpan?')) return;
    }
    api('save_settings', { method: 'POST', body: { settings: collectContent() } }).then(function (res) {
      if (res.ok) toast('Tersimpan.'); else toast(res.error || 'Gagal menyimpan.', true);
    });
  }

  /* ====================================================================== *
   *  TEST CHATBOT (uses public chat endpoint with live settings)
   * ====================================================================== */
  var testHist = [];
  function initTest() {
    $('#testSend').onclick = testSend;
    $('#testClear').onclick = function () { testHist = []; $('#test-body').innerHTML = ''; };
    $('#testInput').addEventListener('keydown', function (e) { if (e.key === 'Enter') testSend(); });
    api('get_units').then(function (res) {   // v1.2.167: unit-bisnis — uji sebagai unit
      var sel = document.getElementById('testUnit'); if (!sel || !res || !res.ok) return;
      var us = (res.units || []).slice(0, res.max != null ? +res.max : 10), cur = sel.value;   // v1.2.168: kuota-unit
      if (!us.length) { sel.style.display = 'none'; sel.innerHTML = ''; return; }
      sel.innerHTML = '<option value="">Otomatis (seperti widget web)</option><option value="#">Tanpa unit (semua KB)</option>' +
        us.map(function (u) { return '<option value="#' + esc(u.id) + '">Unit: ' + esc(u.name) + '</option>'; }).join('');
      sel.value = cur; if (sel.value !== cur) sel.value = '';
      sel.style.display = '';
      sel.onchange = function () { testHist = []; $('#test-body').innerHTML = ''; };
    });
  }
  function testAdd(role, text) {
    var d = document.createElement('div'); d.className = 'tm ' + role;
    var b = document.createElement('div'); b.className = 'tm-b'; b.textContent = text;
    d.appendChild(b); $('#test-body').appendChild(d); $('#test-body').scrollTop = $('#test-body').scrollHeight; return d;
  }
  function testSend() {
    var v = $('#testInput').value.trim(); if (!v) return;
    $('#testInput').value = '';
    testAdd('user', v); testHist.push({ role: 'user', content: v });
    var t = testAdd('bot', '…');
    // v1.2.4: X-Auth-Token supaya backend detect admin test (bypass chatbot_enabled check)
    fetch(API + '?action=chat', { method: 'POST', headers: { 'Content-Type': 'application/json', 'X-Auth-Token': localStorage.getItem(TK) || '' }, body: JSON.stringify({ message: v, history: testHist.slice(-8), unit_test: (($('#testUnit') || {}).value || ''), utm: { utm_source: 'dashboard', utm_medium: 'test', page: '/dashboard/test' } }) })   // v1.2.167: unit_test
      .then(function (r) { return r.json(); })
      .then(function (res) {
        if (res.ok) { t.querySelector('.tm-b').textContent = res.answer; testHist.push({ role: 'assistant', content: res.answer }); }
        else t.querySelector('.tm-b').textContent = res.error || 'Gangguan.';
      })
      .catch(function () { t.querySelector('.tm-b').textContent = 'Koneksi bermasalah.'; });
  }

  /* ====================================================================== *
   *  WIDGET & API (admin only)
   * ====================================================================== */
  // v1.2.36: tampilkan hanya kolom milik penyedia terpilih, supaya tidak ada
  // yang bingung mengisi kolom yang tidak terpakai.
  function waTampilkanBlokPenyedia(prov) {
    // v1.2.76: WAHA — tiga penyedia
    var meta = (prov !== 'fonnte' && prov !== 'waha');
    $$('.wa-meta-only').forEach(function (el)   { el.style.display = meta ? '' : 'none'; });
    $$('.wa-fonnte-only').forEach(function (el) { el.style.display = prov === 'fonnte' ? '' : 'none'; });
    $$('.wa-waha-only').forEach(function (el)   { el.style.display = prov === 'waha' ? '' : 'none'; });
    waMetaHookRows();   // v1.2.128: wa-campur
  }
  // v1.2.128: wa-campur — Callback URL, Verify Token & App Secret tetap tampil bila ada nomor tambahan Meta
  function waMetaHookRows() {
    if (typeof _wn === 'undefined' || !_wn || !_wn.hasMeta) return;
    ['#wa_verify', '#wa_secret', '#wa_webhook_url'].forEach(function (id) { var el = $(id), r = el && el.closest('.wa-meta-only'); if (r) r.style.display = ''; });
  }

  // v1.2.75: koneksi perangkat Fonnte dari dashboard — admin cukup scan QR.
  var _fonc = { poll: null, qrT: null, stopT: null, waitT: null, mode: 'qr', action: 'fonnte_conn', ch: 'utama' };   // v1.2.98: multi-nomor (ch)
  function foncBody(b) { if (_fonc.action === 'waha_conn' && _fonc.ch && _fonc.ch !== 'utama') b.ch = _fonc.ch; return b; }
  function foncStop() {
    clearInterval(_fonc.poll); clearInterval(_fonc.qrT); clearTimeout(_fonc.stopT); clearTimeout(_fonc.waitT);
    _fonc.poll = _fonc.qrT = _fonc.stopT = null;
    var b = $('#fonc_box'); if (b) b.classList.add('hide');
  }
  function foncSet(st) {
    var p = $('#fonc_pill'), inf = $('#fonc_info');
    if (!p) return;
    if (st.error) { p.className = 'pill off'; p.textContent = 'Status tidak diketahui'; inf.textContent = st.error; wsShow(false); return; }
    p.className = 'pill ' + (st.connected ? 'on' : 'off');
    p.textContent = st.connected ? 'Tersambung' : 'Belum tersambung';
    var bits = [];
    if (st.device) bits.push('Nomor ' + st.device);
    if (st.package) bits.push('Paket ' + st.package);
    if (st.quota !== null && st.quota !== undefined && st.quota !== '') bits.push('Kuota ' + st.quota);
    if (st.expired) bits.push('Aktif s/d ' + st.expired);
    if (st.name) bits.push(st.name);
    if (st.session) bits.push('Sesi ' + st.session);
    if (!st.connected && st.status) bits.push('Status ' + st.status);
    inf.textContent = bits.join(' · ');
    $('#fonc_connect').style.display = st.connected ? 'none' : '';
    $('#fonc_code').style.display = st.connected ? 'none' : '';
    $('#fonc_disconnect').style.display = st.connected ? '' : 'none';
    if (st.connected) $('#fonc_numrow').classList.add('hide');
    wsShow(!!st.connected);   // v1.2.105: riwayat-wa-waha
  }
  function foncStatus(silent) {
    return api(_fonc.action, { method: 'POST', body: foncBody({ op: 'status' }) }).then(function (r) {
      if (!r.ok) { if (!silent) foncSet({ error: r.error || 'Gagal membaca status.' }); return null; }
      var wasPolling = !!_fonc.poll;
      foncSet(r);
      if (r.connected && wasPolling) { foncStop(); toast('WhatsApp tersambung.'); if (_fonc.action === 'waha_conn') wsStartScan(); }   // v1.2.105
      return r;
    }).catch(function () { if (!silent) foncSet({ error: 'Koneksi bermasalah.' }); });
  }
  function foncFetch(num) {
    var body = foncBody({ op: 'qr' });
    if (_fonc.mode === 'code') { body.type = 'code'; body.whatsapp = num; }
    return api(_fonc.action, { method: 'POST', body: body }).then(function (r) {
      if (!_fonc.poll) return;   // sudah ditutup
      if (!r.ok) { foncStop(); toast(r.error || 'Gagal mengambil QR.', true); return; }
      if (r.connected) { foncStop(); foncStatus(); return; }
      var img = $('#fonc_qr'), cv = $('#fonc_codeval'), h = $('#fonc_hint');
      if (r.qr) {
        img.src = r.qr; img.style.display = 'block'; cv.style.display = 'none';
        h.textContent = 'Di HP: WhatsApp › Perangkat Tertaut › Tautkan Perangkat, lalu scan. QR diperbarui otomatis.';
      } else if (r.code) {
        cv.textContent = r.code; cv.style.display = ''; img.style.display = 'none';
        h.textContent = 'Di HP: WhatsApp › Perangkat Tertaut › Tautkan Perangkat › Tautkan dengan nomor telepon, lalu masukkan kode ini.';
      } else {
        // v1.2.76: sesi masih disiapkan (WAHA: STARTING) — coba lagi sebentar lagi
        h.textContent = 'Menyiapkan sesi WhatsApp' + (r.status ? ' (' + r.status + ')' : '') + '… tunggu sebentar.';
        clearTimeout(_fonc.waitT);
        _fonc.waitT = setTimeout(function () { if (_fonc.poll) foncFetch(num); }, 3000);
      }
    }).catch(function () { $('#fonc_hint').textContent = 'Koneksi bermasalah, mencoba lagi…'; });
  }
  function foncStart(mode, num) {
    foncStop();
    _fonc.mode = mode;
    $('#fonc_box').classList.remove('hide');
    $('#fonc_qr').style.display = 'none'; $('#fonc_codeval').style.display = 'none';
    $('#fonc_hint').textContent = mode === 'code' ? 'Meminta kode tautan…' : 'Mengambil QR…';
    _fonc.poll = setInterval(function () { foncStatus(true); }, 4000);
    if (mode === 'qr') _fonc.qrT = setInterval(function () { foncFetch(); }, 30000);   // QR WA cepat kedaluwarsa
    _fonc.stopT = setTimeout(function () {
      if (!_fonc.poll) return;
      foncStop(); toast('Waktu habis. Klik Hubungkan lagi bila belum tersambung.', true);
    }, 180000);
    foncFetch(num);
  }
  function foncInit(wa) {
    var card = $('#fonConnCard'); if (!card) return;
    _fonc.action = (wa.provider === 'waha') ? 'waha_conn' : 'fonnte_conn';   // v1.2.76: WAHA
    var on = ((wa.provider === 'fonnte') && !!wa.fonnte_token_is_set)
          || ((wa.provider === 'waha') && !!wa.waha_url && !!wa.waha_api_key_is_set);
    card.style.display = on ? '' : 'none';
    var _lg = $('#fonc_legacy'); if (_lg) _lg.style.display = (wa.provider === 'fonnte') ? '' : 'none';   // v1.2.92: fonnte-off
    if (!on) { foncStop(); return; }
    if (card.dataset.wired !== '1') {
      card.dataset.wired = '1';
      $('#fonc_connect').onclick = function () { $('#fonc_numrow').classList.add('hide'); foncStart('qr'); };
      $('#fonc_code').onclick = function () { $('#fonc_numrow').classList.toggle('hide'); $('#fonc_num').focus(); };
      $('#fonc_code_go').onclick = function () {
        var n = $('#fonc_num').value.replace(/\D/g, '');
        if (n.length < 9) { toast('Isi nomor WhatsApp yang akan ditautkan.', true); return; }
        foncStart('code', n);
      };
      $('#fonc_refresh').onclick = function () { foncStatus(); };
      $('#fonc_cancel').onclick = function () { foncStop(); };
      $('#fonc_disconnect').onclick = function () {
        if (!confirm('Putuskan WhatsApp dari chatbot? Bot berhenti membalas sampai disambungkan lagi.')) return;
        api(_fonc.action, { method: 'POST', body: foncBody({ op: 'disconnect' }) }).then(function (r) {
          toast(r.ok ? 'WhatsApp diputuskan.' : (r.error || 'Gagal memutuskan.'), !r.ok);
          foncStatus();
        });
      };
      $('#fonc_webhook').onclick = function () {
        var b = this; b.disabled = true;
        api(_fonc.action, { method: 'POST', body: foncBody({ op: 'webhook' }) }).then(function (r) {
          b.disabled = false;
          toast(r.ok ? 'Webhook terpasang.' : (r.error || 'Gagal memasang webhook.'), !r.ok);
        }).catch(function () { b.disabled = false; });
      };
    }
    foncStatus();
  }


  /* v1.2.98: multi-nomor — kartu "Nomor WhatsApp" */
  var _wn = { prov: 'meta', rows: [], max: 9 };
  function wnInit(wa) {
    var card = $('#waNumsCard'); if (!card) return;
    var prov = (wa && wa.provider) || 'meta';
    _wn.prov = prov;
    if (prov !== 'meta' && prov !== 'waha') { card.style.display = 'none'; return; }
    card.style.display = '';
    $$('#waNumsCard .wn-meta').forEach(function (el) { el.style.display = prov === 'meta' ? '' : 'none'; });
    $$('#waNumsCard .wn-waha').forEach(function (el) { el.style.display = prov === 'waha' ? '' : 'none'; });
    if (card.dataset.wired !== '1') {
      card.dataset.wired = '1';
      $('#wn_add').onclick = function () { wnForm(null); };
      $('#wn_cancel').onclick = function () { $('#wn_form').classList.add('hide'); };
      $('#wn_save').onclick = wnSave;
      $('#wn_prov').onchange = function () { wnFormProv(false); };   // v1.2.128: wa-campur
      $('#wn_pick').onclick = wnPick;
      $('#wn_pick_sel').onchange = function () {
        var o = this.options[this.selectedIndex]; if (!o || !o.value) return;
        $('#wn_pnid').value = o.value;
        if (!$('#wn_label').value.trim() && o.dataset.name) $('#wn_label').value = o.dataset.name;
      };
      $('#wn_list').onclick = function (ev) {
        var b = ev.target.closest('button[data-wn]'); if (!b) return;
        var id = b.dataset.id, row = _wn.rows.filter(function (r) { return r.id === id; })[0];
        if (b.dataset.wn === 'edit') wnForm(row);
        else if (b.dataset.wn === 'del') wnDelete(row);
        else if (b.dataset.wn === 'qr') wnConnect(row);
        else if (b.dataset.wn === 'health') whOpen(row);   // v1.2.104
        else if (b.dataset.wn === 'call') wcOpen(row);   // v1.2.108: tolak-telepon
      };
    }
    wnLoad();
  }
  /* v1.2.104: skor-risiko-wa — lencana & panel Kesehatan nomor (WAHA) */
  var WH_LV = { aman: ['Aman', '#dcfce7', '#166534'], waspada: ['Waspada', '#fef3c7', '#92400e'], bahaya: ['Bahaya', '#fee2e2', '#991b1b'] };
  function whBadge(h, id) {
    if (!h) return '<button class="btn ghost sm" type="button" data-wn="health" data-id="' + esc(id) + '" title="Belum ada skor — dihitung tiap 15 menit">Cek</button>';
    var lv = WH_LV[h.level] || WH_LV.aman;
    return '<button type="button" data-wn="health" data-id="' + esc(id) + '" title="' + esc((h.top || []).join('\n') || 'Tidak ada faktor risiko') + '" style="border:0;cursor:pointer;border-radius:999px;padding:3px 10px;font:600 12px/1.4 inherit;background:' + lv[1] + ';color:' + lv[2] + '">' +
      h.score + ' · ' + lv[0] + (h.partial ? '*' : '') + '</button>';
  }
  function whOpen(row) {
    var box = $('#wn_health'); if (!box || !row) return;
    box.classList.remove('hide');
    box.innerHTML = '<div class="help">Menghitung skor…</div>';
    api('wa_health', { query: '&ch=' + encodeURIComponent(row.id) }).then(function (r) {
      if (!r || !r.ok) { box.innerHTML = '<div class="help">' + esc((r && r.error) || 'Gagal memuat.') + '</div>'; return; }
      var h = r.health, m = h.m || {}, lv = WH_LV[h.level] || WH_LV.aman;
      var pct = function (v) { return v == null ? '—' : v + '%'; };
      var max = 1; (h.series || []).forEach(function (d) { max = Math.max(max, d.in, d.out); });
      var bars = (h.series || []).map(function (d) {
        var hi = Math.round(d.in / max * 60), ho = Math.round(d.out / max * 60), hn = Math.round(d['new'] / max * 60);
        return '<div style="flex:1;text-align:center;min-width:0"><div style="height:62px;display:flex;align-items:flex-end;justify-content:center;gap:2px">' +
          '<span title="Masuk ' + d.in + '" style="width:9px;height:' + hi + 'px;background:#93c5fd;border-radius:2px 2px 0 0"></span>' +
          '<span title="Keluar ' + d.out + ' (chat duluan ' + d['new'] + ')" style="width:9px;height:' + ho + 'px;background:linear-gradient(to top,#f97316 ' + (ho ? Math.round(hn / ho * 100) : 0) + '%,#a5b4fc 0);border-radius:2px 2px 0 0"></span></div>' +
          '<div class="help" style="margin:2px 0 0;font-size:10.5px">' + esc(d.d.slice(8)) + '/' + esc(d.d.slice(5, 7)) + '</div></div>';
      }).join('');
      var stat = function (k, v) { return '<div style="padding:8px 10px;border:1px solid var(--line);border-radius:8px"><div class="help" style="margin:0;font-size:11px">' + k + '</div><b>' + v + '</b></div>'; };
      var since = h.since ? new Date((h.since + 7 * 3600) * 1000).toISOString().slice(0, 10) : '';
      var evs = (h.events || []).slice(0, 6).map(function (e) {
        var t = new Date((e[0] + 7 * 3600) * 1000).toISOString().replace('T', ' ').slice(5, 16);
        return '<li>' + esc(t) + ' — ' + esc(e[1]) + (e[2] ? ' <b style="color:#b91c1c">(' + esc({ logout: 'logout paksa', failed: 'gagal', drop: 'putus' }[e[2]] || e[2]) + ')</b>' : '') + '</li>';
      }).join('');
      box.innerHTML =
        '<div style="display:flex;align-items:center;gap:12px;flex-wrap:wrap;margin-bottom:10px">' +
          '<div style="font-size:30px;font-weight:700;color:' + lv[2] + '">' + h.score + '<span style="font-size:14px;color:var(--muted)">/100</span></div>' +
          '<div><b>' + esc(r.label) + '</b>' + (m.number && String(r.label).indexOf(m.number) < 0 ? ' <span class="mono">+' + esc(m.number) + '</span>' : '') + '<br><span class="tag" style="background:' + lv[1] + ';color:' + lv[2] + '">' + lv[0] + '</span>' +
          (m.status ? ' <span class="help" style="margin:0">Sesi: ' + esc(m.status) + '</span>' : '') + '</div>' +
          '<button class="btn ghost sm" type="button" id="wh_close" style="margin-left:auto">Tutup</button></div>' +
        (h.partial ? '<div class="help" style="color:#92400e">* Data belum 24 jam — skor masih bisa berubah.</div>' : '') +
        (!h.cfg_ok ? '<div class="help" style="background:#fef3c7;color:#92400e;padding:8px 10px;border-radius:8px">Status centang (terkirim/dibaca) belum dipantau untuk sesi ini. Dipasang otomatis jam 01–04 WIB, atau ' +
          (r.can_edit ? '<a href="#" id="wh_cfg">pasang sekarang</a> (sesi WAHA restart beberapa detik).' : 'minta Admin memasangnya.') + '</div>' : '') +
        '<h4 style="margin:12px 0 6px">Faktor risiko</h4>' +
        (h.factors.length ? '<ul style="margin:0;padding-left:18px">' + h.factors.map(function (f) { return '<li><b>+' + f.p + '</b> ' + esc(f.t) + '</li>'; }).join('') + '</ul>'
          : '<div class="help">Tidak ada faktor risiko terdeteksi. Pola penggunaan wajar (membalas chat masuk).</div>') +
        '<div style="display:grid;grid-template-columns:repeat(auto-fill,minmax(130px,1fr));gap:8px;margin-top:12px">' +
          stat('Masuk 24 jam', m.in) + stat('Keluar 24 jam', m.out + ' <span class="help" style="margin:0;font-weight:400">bot ' + m.out_bot + ' · agent ' + m.out_agent + ' · HP ' + m.out_hp + '</span>') +
          stat('Chat duluan 24 jam', m.out_new) + stat('Dibalas (chat duluan 7h)', pct(m.reply_pct)) +
          stat('Centang 1 > 6 jam', m.ack_on ? pct(m.stuck_pct) : '—') + stat('Dibaca', m.ack_on ? pct(m.read_pct) : '—') +
          stat('Gagal kirim 24 jam', m.fail) + stat('Umur nomor', m.age_days == null ? 'tidak diketahui' : m.age_days + ' hari') +
        '</div>' +
        '<h4 style="margin:14px 0 4px">7 hari terakhir</h4><div class="help" style="margin:0 0 4px"><span style="color:#3b82f6">■</span> masuk &nbsp; <span style="color:#818cf8">■</span> keluar &nbsp; <span style="color:#f97316">■</span> chat duluan</div>' +
        '<div style="display:flex;gap:4px;padding:6px 0;border-bottom:1px solid var(--line)">' + bars + '</div>' +
        (evs ? '<h4 style="margin:14px 0 4px">Riwayat sesi</h4><ul style="margin:0;padding-left:18px;font-size:12.5px">' + evs + '</ul>' : '') +
        (r.can_edit ? '<div class="row" style="margin-top:12px"><label class="fl">Nomor mulai dipakai sejak</label><div style="display:flex;gap:8px;flex-wrap:wrap"><input type="date" id="wh_since" value="' + esc(since) + '" style="max-width:180px"><button class="btn ghost sm" type="button" id="wh_since_save">Simpan</button></div>' +
          '<div class="help">Untuk menghitung umur nomor. Terisi otomatis saat nomor baru di-scan; nomor yang terhubung sebelum pemantauan perlu diisi manual.</div></div>' : '') +
        '<div class="help" style="margin-top:10px">Skor ini perkiraan dari pola penggunaan, bukan data resmi WhatsApp — laporan/report pengguna tidak terbaca. Tips aman: hindari chat duluan massal dari HP, jangan kirim teks sama ke banyak nomor, naikkan volume nomor baru bertahap.</div>';
      $('#wh_close').onclick = function () { box.classList.add('hide'); };
      var cf = $('#wh_cfg');
      if (cf) cf.onclick = function (e) {
        e.preventDefault();
        if (!confirm('Pasang ulang webhook sesi ini? Sesi WAHA restart beberapa detik (pesan masuk saat itu tetap diterima setelah tersambung).')) return;
        api('wa_health', { method: 'POST', body: { op: 'apply_cfg', ch: row.id } }).then(function (x) { if (x && x.ok) { toast('Pemantauan centang aktif.'); whOpen(row); } else toast((x && x.error) || 'Gagal.', true); });
      };
      var sv = $('#wh_since_save');
      if (sv) sv.onclick = function () {
        api('wa_health', { method: 'POST', body: { op: 'set_since', ch: row.id, date: $('#wh_since').value } }).then(function (x) { if (x && x.ok) { toast('Tersimpan.'); whOpen(row); wnLoad(); } else toast((x && x.error) || 'Gagal.', true); });
      };
    });
  }
  /* v1.2.108: tolak-telepon — panel "Telepon masuk" per nomor (WAHA) */
  var WC_DAYS = ['Sen', 'Sel', 'Rab', 'Kam', 'Jum', 'Sab', 'Min'];
  function wcNowTxt(r) {
    if (r.now_reject) return 'Saat ini telepon masuk <b>ditolak otomatis</b>' + (r.now_why === 'outside_hours' ? ' (di luar jam operasional).' : '.');
    if (r.now_why === 'in_hours') return 'Saat ini jam operasional: telepon <b>tidak ditolak</b> (HP berdering seperti biasa).';
    return 'Tolak otomatis <b>mati</b>: telepon hanya dicatat, HP berdering seperti biasa.';
  }
  function wcOpen(row) {
    var box = $('#wn_call'); if (!box || !row) return;
    box.classList.remove('hide');
    box.innerHTML = '<div class="help">Memuat…</div>';
    api('wa_calls', { query: '&ch=' + encodeURIComponent(row.id) }).then(function (r) {
      if (!r || !r.ok) { box.innerHTML = '<div class="help">' + esc((r && r.error) || 'Gagal memuat.') + '</div>'; return; }
      var c = r.conf || {}, ed = !!r.can_edit, dis = ed ? '' : ' disabled';
      var days = (c.days || []).map(Number);
      var dayH = WC_DAYS.map(function (n, i) {
        var v = i + 1;
        return '<label style="display:inline-flex;align-items:center;gap:4px;margin:0 12px 4px 0;font-weight:400"><input type="checkbox" class="wc_day" value="' + v + '"' + (days.indexOf(v) >= 0 ? ' checked' : '') + dis + '> ' + n + '</label>';
      }).join('');
      var rec = (r.recent || []).map(function (x) {
        return '<li><span class="mono">' + esc(String(x.ts).slice(5, 16)) + '</span> · +' + esc(x.num) + ' — ' + esc(String(x.txt).replace(/^\S+\s/, '')) + (x.replied ? ' · <span style="color:#166534">pesan terkirim</span>' : '') + '</li>';
      }).join('');
      box.innerHTML =
        '<div style="display:flex;align-items:center;gap:10px;flex-wrap:wrap;margin-bottom:8px"><b>' + ico('phone', 15, 'style="vertical-align:-2px"') + ' Telepon masuk — ' + esc(r.label) + '</b>' +
          '<button class="btn ghost sm" type="button" id="wc_close" style="margin-left:auto">Tutup</button></div>' +
        '<div class="help" style="margin-top:0">WAHA tidak bisa mengangkat telepon. Telepon yang ditolak otomatis tetap berdering sebentar di HP, lalu putus di sisi penelepon. Semua telepon masuk tercatat di Percakapan WA &amp; Log.</div>' +
        (!r.cfg_ok ? '<div class="help" style="background:#fef3c7;color:#92400e;padding:8px 10px;border-radius:8px">Sesi ini belum menerima event telepon dari WAHA. Dipasang otomatis jam 01–04 WIB, atau ' +
          (ed ? '<a href="#" id="wc_cfg">pasang sekarang</a> (sesi WAHA restart beberapa detik).' : 'minta Admin memasangnya.') + '</div>' : '') +
        '<div class="help" id="wc_now" style="background:var(--soft,#f4f5f9);padding:8px 10px;border-radius:8px">' + wcNowTxt(r) + '</div>' +
        '<div class="row"><label style="display:flex;align-items:center;gap:8px;font-weight:600"><input type="checkbox" id="wc_on"' + (c.on ? ' checked' : '') + dis + '> Tolak telepon otomatis</label></div>' +
        '<div id="wc_opts">' +
          '<div class="row"><label class="fl">Kapan ditolak</label>' +
            '<label style="display:flex;align-items:center;gap:6px;font-weight:400"><input type="radio" name="wc_when" value="always"' + (c.when !== 'hours' ? ' checked' : '') + dis + '> Selalu</label>' +
            '<label style="display:flex;align-items:center;gap:6px;font-weight:400"><input type="radio" name="wc_when" value="hours"' + (c.when === 'hours' ? ' checked' : '') + dis + '> Hanya di luar jam operasional</label></div>' +
          '<div class="row" id="wc_hours"><label class="fl">Jam operasional (WIB)</label><div>' + dayH + '</div>' +
            '<div style="display:flex;gap:8px;align-items:center;flex-wrap:wrap;margin-top:4px"><input type="time" id="wc_start" value="' + esc(c.start || '08:00') + '" style="max-width:130px"' + dis + '> s/d <input type="time" id="wc_end" value="' + esc(c.end || '17:00') + '" style="max-width:130px"' + dis + '></div>' +
            '<div class="help">Di dalam jam ini telepon dibiarkan berdering (CS bisa mengangkat dari HP). Jam selesai lebih kecil dari jam mulai = lewat tengah malam.</div></div>' +
          '<div class="row"><label style="display:flex;align-items:center;gap:8px;font-weight:400"><input type="checkbox" id="wc_reply"' + (c.reply_on ? ' checked' : '') + dis + '> Kirim pesan setelah menolak</label>' +
            '<textarea id="wc_msg" rows="3" style="width:100%;margin-top:6px"' + dis + '>' + esc(c.msg || '') + '</textarea>' +
            '<div class="help">Dikirim maksimal sekali per 10 menit ke nomor yang sama (telepon beruntun tidak memicu pesan berulang).</div></div>' +
        '</div>' +
        (ed ? '<div style="display:flex;gap:8px"><button class="btn sm" type="button" id="wc_save">Simpan</button></div>' : '') +
        '<h4 style="margin:14px 0 4px">Telepon terakhir</h4>' +
        (rec ? '<ul style="margin:0;padding-left:18px;font-size:12.5px">' + rec + '</ul>' : '<div class="help">Belum ada telepon masuk tercatat.</div>');
      var sync = function () {
        var on = $('#wc_on').checked, hrs = (box.querySelector('input[name="wc_when"]:checked') || {}).value === 'hours';
        $('#wc_opts').style.opacity = on ? '' : '.55';
        $('#wc_hours').style.display = hrs ? '' : 'none';
        $('#wc_msg').style.display = $('#wc_reply').checked ? '' : 'none';
      };
      box.querySelectorAll('#wc_on,#wc_reply,input[name="wc_when"]').forEach(function (el) { el.onchange = sync; });
      sync();
      $('#wc_close').onclick = function () { box.classList.add('hide'); };
      var cf = $('#wc_cfg');
      if (cf) cf.onclick = function (e) {
        e.preventDefault();
        if (!confirm('Pasang ulang webhook sesi ini? Sesi WAHA restart beberapa detik (pesan masuk saat itu tetap diterima setelah tersambung).')) return;
        api('wa_health', { method: 'POST', body: { op: 'apply_cfg', ch: row.id } }).then(function (x) { if (x && x.ok) { toast('Webhook terpasang.'); wcOpen(row); } else toast((x && x.error) || 'Gagal.', true); });
      };
      var sv = $('#wc_save');
      if (sv) sv.onclick = function () {
        var conf = {
          on: $('#wc_on').checked,
          when: (box.querySelector('input[name="wc_when"]:checked') || {}).value || 'always',
          days: Array.prototype.map.call(box.querySelectorAll('.wc_day:checked'), function (x) { return +x.value; }),
          start: $('#wc_start').value, end: $('#wc_end').value,
          reply_on: $('#wc_reply').checked, msg: $('#wc_msg').value
        };
        sv.disabled = true;
        api('wa_calls', { method: 'POST', body: { op: 'save', ch: row.id, conf: conf } }).then(function (x) {
          sv.disabled = false;
          if (x && x.ok) { toast('Pengaturan telepon disimpan.'); $('#wc_now').innerHTML = wcNowTxt(x); }
          else toast((x && x.error) || 'Gagal menyimpan.', true);
        }).catch(function () { sv.disabled = false; });
      };
    });
  }
  function wnLoad() {
    return api('wa_numbers').then(function (r) {
      if (!r || !r.ok) { $('#wn_list').innerHTML = '<div class="help">' + esc((r && r.error) || 'Gagal memuat nomor.') + '</div>'; return; }
      _wn.rows = r.numbers || []; _wn.max = (r.limit != null) ? r.limit : (r.max || 0);   // v1.2.99: lisensi-nomor (batas paket)
      _wn.teams = r.teams || [];   // v1.2.100: routing
      var _wh = r.health || {};   // v1.2.104: skor-risiko-wa
      var _tn = {}; _wn.teams.forEach(function (t) { _tn[t.username] = t.name || t.username; });
      var sa = role === 'super_admin' || role === 'admin';   // v1.2.165: admin-nomor
      // v1.2.128: wa-campur — penyedia per nomor
      _wn.hasMeta = _wn.rows.some(function (x) { return !x.locked && (x.provider || r.provider) === 'meta'; });
      _wn.hasWaha = _wn.rows.some(function (x) { return !x.locked && (x.provider || r.provider) === 'waha'; });
      _wn.mainWahaOk = !!r.main_waha_ok;
      var mixed = _wn.hasMeta && _wn.hasWaha, waha = _wn.hasWaha;
      var extra = _wn.rows.length - 1;
      $('#wn_list').innerHTML = '<div class="tbl-wrap"><table class="tbl" style="width:100%"><thead><tr><th>Label</th><th>Nomor</th><th>' + (mixed ? 'Penyedia · ID' : (waha ? 'Sesi WAHA' : 'Phone Number ID')) + '</th><th>Tim</th>' + (waha ? '<th>Kesehatan</th>' : '') + '<th></th></tr></thead><tbody>' +   // v1.2.100: routing; v1.2.104: kesehatan
        _wn.rows.map(function (x) {
          var xw = (x.provider || r.provider) === 'waha';
          var idc = xw ? (x.waha_session || '') : (x.phone_number_id || (sa ? '' : '••••'));
          var acts = '';
          if (xw && x.id !== 'utama') acts += '<button class="btn ghost sm" type="button" data-wn="qr" data-id="' + esc(x.id) + '">Koneksi</button> ';
          if (xw && !x.locked) acts += '<button class="btn ghost sm" type="button" data-wn="call" data-id="' + esc(x.id) + '" title="Tolak telepon otomatis">Telepon</button> ';   // v1.2.108: tolak-telepon
          if (sa) acts += '<button class="btn ghost sm" type="button" data-wn="edit" data-id="' + esc(x.id) + '">Ubah</button> ';
          if (sa && !x.primary) acts += '<button class="btn ghost sm" type="button" data-wn="del" data-id="' + esc(x.id) + '">Hapus</button>';
          return '<tr' + (x.locked ? ' style="opacity:.6"' : '') + '><td>' + (x.primary ? '<span class="tag" style="margin-right:4px">Utama</span>' : '') + esc(x.label || (x.primary ? 'Nomor utama' : '')) +
            (x.locked ? ' <span class="tag" style="background:#fee2e2;color:#991b1b" title="Di luar batas paket: nomor ini tidak menerima & tidak mengirim pesan">Terkunci</span>' : '') + '</td>' +   // v1.2.99
            '<td class="mono">' + (x.number ? '+' + esc(x.number) : '<span style="color:var(--muted)">—</span>') + (x.verified_name ? '<div class="help" style="margin:0">' + esc(x.verified_name) + '</div>' : '') + '</td>' +
            '<td class="mono" style="font-size:12px">' + (mixed ? '<span class="tag" style="margin-right:4px">' + (xw ? 'WAHA' : 'Meta') + '</span>' : '') + esc(idc) + '</td><td style="font-size:12px">' + (x.team ? esc(_tn[x.team] || x.team) : '<span style="color:var(--muted)">Semua</span>') + '</td>' + (waha ? '<td>' + (x.locked || !xw ? '' : whBadge(_wh[x.id], x.id)) + '</td>' : '') + '<td style="white-space:nowrap;text-align:right">' + acts + '</td></tr>';
        }).join('') + '</tbody></table></div>';
      $('#wn_add').disabled = extra >= _wn.max;   // v1.2.99: lisensi-nomor
      var vend = r.vendor || 'tim kami';
      $('#wn_hint').innerHTML = (_wn.max > 0
        ? 'Paket: ' + extra + ' / ' + _wn.max + ' nomor tambahan terpakai.' + (extra > _wn.max ? ' <b style="color:#b91c1c">' + (extra - _wn.max) + ' nomor terkunci.</b>' : (extra >= _wn.max ? ' Hubungi ' + esc(vend) + ' untuk menambah.' : ''))
        : 'Paket Anda belum termasuk nomor tambahan. Hubungi ' + esc(vend) + ' untuk menambahkan.' + (extra > 0 ? ' <b style="color:#b91c1c">' + extra + ' nomor terkunci.</b>' : ''))
        + ' <a href="#" id="wn_sync">Sinkron ulang</a>';
      $('#wn_sync').onclick = function (e) { e.preventDefault(); api('refresh_seats', { method: 'POST', body: {} }).then(function () { wnLoad(); toast('Paket disinkronkan.'); }); };
      foncChannels(r.channels || []);
      waMetaHookRows();   // v1.2.128: wa-campur
    });
  }
  function wnForm(row) {
    var f = $('#wn_form'); f.classList.remove('hide');
    var isPrim = !!(row && row.primary);
    $('#wn_id').value = row ? row.id : '';
    $('#wn_label').value = row ? (row.label || '') : '';
    $('#wn_team').innerHTML = '<option value="">Semua agent</option>' + (_wn.teams || []).map(function (t) { return '<option value="' + esc(t.username) + '">Tim ' + esc(t.name || t.username) + '</option>'; }).join('');   // v1.2.100
    $('#wn_team').value = row ? (row.team || '') : '';
    $('#wn_pnid').value = row ? (row.phone_number_id || '') : '';
    $('#wn_token').value = ''; $('#wn_token').placeholder = (row && row.token_is_set) ? '•••• (terisi — kosongkan untuk tidak mengubah)' : 'kosong = pakai token nomor utama';
    $('#wn_waba').value = row ? (row.waba_id || '') : '';
    $('#wn_sess').value = row ? (row.waha_session || '') : '';
    $('#wn_wurl').value = row ? (row.waha_url || '') : '';
    $('#wn_wkey').value = ''; $('#wn_wkey').placeholder = (row && row.waha_key_is_set) ? '•••• (terisi — kosongkan untuk tidak mengubah)' : 'kosong = API key nomor utama';
    $('#wn_pick_sel').classList.add('hide');
    // nomor utama: hanya label (kredensialnya diatur di kartu WhatsApp Bot)
    _wn.editRow = row || null;   // v1.2.128: wa-campur — penyedia per nomor
    $('#wn_prov_row').style.display = isPrim ? 'none' : '';
    $('#wn_prov').value = (row && row.provider) || _wn.prov;
    wnFormProv(isPrim);
    $('#wn_label').focus();
  }
  function wnFormProv(isPrim) {   // v1.2.128: wa-campur
    var p = $('#wn_prov').value, row = _wn.editRow, same = (p === _wn.prov);
    $$('#waNumsCard .wn-meta, #waNumsCard .wn-waha').forEach(function (el) { el.style.display = 'none'; });
    if (isPrim) return;
    $$(p === 'waha' ? '#waNumsCard .wn-waha' : '#waNumsCard .wn-meta').forEach(function (el) { el.style.display = ''; });
    $('#wn_token').placeholder = (row && row.token_is_set) ? '•••• (terisi — kosongkan untuk tidak mengubah)' : (same ? 'kosong = pakai token nomor utama' : 'wajib diisi');
    $('#wn_waba').placeholder = same ? 'kosong = WABA nomor utama' : 'wajib untuk Blast template';
    $('#wn_wurl').placeholder = same ? 'kosong = server nomor utama' : (_wn.mainWahaOk ? 'kosong = server WAHA yang tersimpan' : 'wajib diisi, mis. https://wa.domain.com');
    $('#wn_wkey').placeholder = (row && row.waha_key_is_set) ? '•••• (terisi — kosongkan untuk tidak mengubah)' : (same ? 'kosong = API key nomor utama' : (_wn.mainWahaOk ? 'kosong = API key yang tersimpan' : 'wajib diisi'));
    var n = $('#wn_meta_note');
    if (n) n.innerHTML = same ? 'Nomor tambahan di WABA yang sama cukup diisi Phone Number ID — token &amp; webhook memakai milik nomor utama.'
      : 'Nomor utama memakai WAHA, jadi isi Access Token (dan WABA ID untuk Blast) nomor ini. Daftarkan webhook di Meta App memakai Callback URL &amp; Verify Token di kartu <b>WhatsApp Bot</b>, lalu subscribe field <code>messages</code>.';
  }
  function wnSave() {
    var id = $('#wn_id').value, b = $('#wn_save');
    var body = { op: 'save', id: id, label: $('#wn_label').value.trim(), team: $('#wn_team').value };   // v1.2.100: team
    if (id !== 'utama') {
      body.provider = $('#wn_prov').value;   // v1.2.128: wa-campur
      if (body.provider === 'waha') {
        body.waha_session = $('#wn_sess').value.trim(); body.waha_url = $('#wn_wurl').value.trim(); body.waha_api_key = $('#wn_wkey').value.trim();
        if (!body.waha_session) { toast('Isi nama sesi WAHA.', true); return; }
      } else {
        body.phone_number_id = $('#wn_pnid').value.trim(); body.access_token = $('#wn_token').value.trim(); body.waba_id = $('#wn_waba').value.trim();
        if (!body.phone_number_id) { toast('Isi Phone Number ID.', true); return; }
      }
    }
    b.disabled = true;
    api('wa_numbers', { method: 'POST', body: body }).then(function (r) {
      b.disabled = false;
      if (!r || !r.ok) { toast((r && r.error) || 'Gagal menyimpan.', true); return; }
      $('#wn_form').classList.add('hide');
      toast(r.warning ? ('Tersimpan. ' + r.warning) : ('Nomor tersimpan.' + (r.note ? ' ' + r.note : '')), !!r.warning);   // v1.2.128
      wnLoad().then(function () {
        if (body.provider === 'waha' && !id && r.id) { var nr = _wn.rows.filter(function (x) { return x.id === r.id; })[0]; if (nr) wnConnect(nr); }
      });
    }).catch(function () { b.disabled = false; toast('Koneksi bermasalah.', true); });
  }
  function wnDelete(row) {
    if (!row || !confirm('Hapus nomor "' + (row.label || row.number || row.id) + '" dari chatbot? Pelanggan nomor ini selanjutnya dibalas dari nomor utama.' + ((row.provider || _wn.prov) === 'waha' ? ' Sesi WAHA tidak dihapus dari server.' : ''))) return;
    api('wa_numbers', { method: 'POST', body: { op: 'delete', id: row.id } }).then(function (r) {
      toast(r && r.ok ? 'Nomor dihapus.' : ((r && r.error) || 'Gagal menghapus.'), !(r && r.ok));
      wnLoad();
    });
  }
  function wnPick() {
    var b = $('#wn_pick'), sel = $('#wn_pick_sel');
    b.disabled = true;
    api('wa_numbers', { method: 'POST', body: { op: 'meta_phones', id: $('#wn_id').value, waba_id: $('#wn_waba').value.trim(), access_token: $('#wn_token').value.trim() } }).then(function (r) {
      b.disabled = false;
      if (!r || !r.ok) { toast((r && r.error) || 'Gagal membaca WABA.', true); return; }
      var ph = r.phones || [];
      if (!ph.length) { toast('Tidak ada nomor di WABA ini.', true); return; }
      sel.innerHTML = '<option value="">— Pilih nomor dari WABA ' + esc(r.waba_id) + ' —</option>' + ph.map(function (p) {
        var used = p.used_by ? (p.used_by === 'utama' ? ' (nomor utama)' : ' (sudah terdaftar)') : '';
        return '<option value="' + esc(p.phone_number_id) + '" data-name="' + esc(p.verified_name || '') + '"' + (p.used_by ? ' disabled' : '') + '>+' + esc(p.number) + ' · ' + esc(p.verified_name || '') + used + '</option>';
      }).join('');
      sel.classList.remove('hide');
    }).catch(function () { b.disabled = false; });
  }
  function wnConnect(row) {
    var sel = $('#fonc_ch'), card = $('#fonConnCard');
    if (!sel || !card || card.style.display === 'none') { toast('Isi URL & API Key WAHA nomor utama dulu.', true); return; }
    sel.value = row.id; _fonc.ch = row.id; foncStop(); foncStatus();
    card.scrollIntoView({ behavior: 'smooth', block: 'start' });
  }
  // Pilihan nomor di kartu Koneksi WhatsApp (WAHA)
  function foncChannels(chs) {
    var sel = $('#fonc_ch'); if (!sel) return;
    chs = (chs || []).filter(function (c) { return (c.prov || _wn.prov) === 'waha'; });   // v1.2.128: wa-campur — hanya nomor WAHA
    if (_wn.prov !== 'waha') {
      var card128 = $('#fonConnCard');
      if (!chs.length) { sel.classList.add('hide'); return; }
      if (!chs.some(function (c) { return c.id === _fonc.ch; })) _fonc.ch = chs[0].id;
      if (card128 && card128.style.display === 'none') foncInit({ provider: 'waha', waha_url: '1', waha_api_key_is_set: true });
    } else if (chs.length < 2) { sel.classList.add('hide'); if (_fonc.ch && _fonc.ch !== 'utama') { _fonc.ch = 'utama'; foncStatus(); } return; }
    var cur = _fonc.ch || chs[0].id;
    sel.innerHTML = chs.map(function (c) { return '<option value="' + esc(c.id) + '">' + esc(c.label) + '</option>'; }).join('');
    if (!chs.some(function (c) { return c.id === cur; })) cur = chs[0].id;
    sel.value = cur; _fonc.ch = cur;
    sel.classList.remove('hide');
    if (sel.dataset.wired !== '1') {
      sel.dataset.wired = '1';
      sel.onchange = function () { _fonc.ch = this.value; foncStop(); foncStatus(); };
    }
  }

  // v1.2.54: Embedded Signup coexistence (WA Business App + Cloud API di satu nomor)
  var _esCaptured = { phone_number_id: '', waba_id: '' };
  function esSessionInfoListener(event) {
    if (typeof event.data !== 'string') return;
    if (event.origin && event.origin.indexOf('facebook.com') === -1) return;
    var data; try { data = JSON.parse(event.data); } catch (e) { return; }
    if (!data || data.type !== 'WA_EMBEDDED_SIGNUP') return;
    if (data.data) {
      _esCaptured.phone_number_id = data.data.phone_number_id || _esCaptured.phone_number_id;
      _esCaptured.waba_id        = data.data.waba_id || _esCaptured.waba_id;
    }
  }
  function esLoadSdk(appId, version) {
    if (window.FB) { try { FB.init({ appId: appId, autoLogAppEvents: true, xfbml: false, version: version }); } catch (e) {} return; }
    window.fbAsyncInit = function () { try { FB.init({ appId: appId, autoLogAppEvents: true, xfbml: false, version: version }); } catch (e) {} };
    if (!document.getElementById('facebook-jssdk')) {
      var js = document.createElement('script');
      js.id = 'facebook-jssdk'; js.src = 'https://connect.facebook.net/en_US/sdk.js'; js.async = true; js.defer = true; js.crossOrigin = 'anonymous';
      document.head.appendChild(js);
    }
  }
  function esWire(version) {
    var btn = $('#btnEsConnect'); if (!btn) return;
    if (!window._esListenerAdded) { window.addEventListener('message', esSessionInfoListener); window._esListenerAdded = true; }
    var appId = ($('#es_app_id') && $('#es_app_id').value.trim()) || '';
    if (appId) esLoadSdk(appId, version);
    btn.onclick = function () {
      var aid = $('#es_app_id').value.trim(), cid = $('#es_config_id').value.trim();
      if (!aid || !cid) { toast('Isi App ID dan Config ID dulu.'); return; }
      if (!window.FB) { esLoadSdk(aid, version); toast('SDK Facebook belum siap — coba klik lagi sebentar.'); return; }
      _esCaptured = { phone_number_id: '', waba_id: '' };
      var st = $('#es_status'); if (st) { st.textContent = 'Membuka Embedded Signup…'; st.style.color = ''; }
      FB.login(function (response) {
        var code = response && response.authResponse && response.authResponse.code;
        if (!code) { if (st) { st.textContent = 'Dibatalkan / gagal.'; st.style.color = '#b42318'; } return; }
        if (st) st.textContent = 'Menukar token…';
        api('wa_es_exchange', { method: 'POST', body: { code: code, phone_number_id: _esCaptured.phone_number_id, waba_id: _esCaptured.waba_id } }).then(function (r) {
          if (!r || !r.ok) { if (st) { st.textContent = 'Gagal: ' + ((r && r.error) || 'tidak diketahui'); st.style.color = '#b42318'; } return; }
          if (st) { st.textContent = 'Terhubung: ' + (r.phone_number_id || _esCaptured.phone_number_id || '(nomor tersimpan)'); st.style.color = '#1a7f37'; }
          if (r.warning) toast(r.warning);
          if (typeof loadWidget === 'function') loadWidget();
        });
      }, { config_id: cid, response_type: 'code', override_default_response_type: true, extras: { featureType: 'whatsapp_business_app_onboarding' } });
    };
  }
  /* v1.2.91: wa-api — kartu permintaan WhatsApp API resmi */
  var WAAPI_ST = { baru: 'Terkirim — menunggu dihubungi tim kami', proses: 'Sedang diproses tim kami', selesai: 'Selesai — WhatsApp API sudah terhubung', batal: 'Dibatalkan' };
  function waApiInit(s) {
    var card = $('#waApiCard'); if (!card) return;
    var ob = (s && s.onboarding) || {}, wa = (s && s.whatsapp_api) || {};
    var show = (role === 'super_admin' || role === 'admin') && (!!ob.enabled || wa.provider === 'waha');
    card.style.display = show ? '' : 'none';
    if (!show) return;
    if (!$('#waapi_contact').value) $('#waapi_contact').value = (user && user.name) || '';
    function render(r) {
      var st = $('#waapi_status'), q = r && r.request;
      if (!q) { st.innerHTML = ''; $('#waapi_form').style.display = ''; return; }
      var done = q.status === 'selesai';
      st.innerHTML = '<span class="pill ' + (done ? 'on' : 'off') + '">' + esc(WAAPI_ST[q.status] || q.status) + '</span> '
        + '<span>Nomor ' + esc(q.phone) + ' · dikirim ' + esc(q.at_wib || '') + '</span>'
        + (q.admin_note ? '<div style="margin-top:6px">Catatan tim: ' + esc(q.admin_note) + '</div>' : '')
        + (q.status !== 'selesai' && q.status !== 'batal' ? '' : ' <a href="#" id="waapi_again">Kirim permintaan baru</a>');
      $('#waapi_form').style.display = (q.status === 'selesai' || q.status === 'batal') ? 'none' : 'none';
      var ag = $('#waapi_again'); if (ag) ag.onclick = function (e) { e.preventDefault(); $('#waapi_form').style.display = ''; };
    }
    api('wa_api_request', { method: 'POST', body: { op: 'status' } }).then(render).catch(function () {});
    if (card.dataset.wired === '1') return;
    card.dataset.wired = '1';
    $('#waapi_send').onclick = function () {
      var b = this, ph = $('#waapi_phone').value.replace(/\D/g, '');
      if (ph.length < 9) { toast('Isi nomor WhatsApp bisnis yang akan dihubungkan.', true); return; }
      b.disabled = true;
      api('wa_api_request', { method: 'POST', body: { op: 'send', phone: ph, contact: $('#waapi_contact').value, contact_phone: $('#waapi_cphone').value,
        meta_bm: $('#waapi_bm').value, number_in_app: $('#waapi_inapp').value, note: $('#waapi_note').value } }).then(function (r) {
        b.disabled = false;
        if (!r || !r.ok) { toast((r && r.error) || 'Gagal mengirim permintaan.', true); return; }
        toast('Permintaan terkirim. Tim kami akan menghubungi Anda.');
        render(r);
      }).catch(function () { b.disabled = false; toast('Koneksi bermasalah.', true); });
    };
  }
  function loadWidget() {
    api('get_settings').then(function (res) {
      if (!res.ok) return;
      var s = res.settings, w = s.widget || {}, a = s.api || {};
      foncInit(s.whatsapp_api || {});   // v1.2.75
      wnInit(s.whatsapp_api || {});     // v1.2.98: multi-nomor
      waApiInit(s);                     // v1.2.91
      $('#w_chatbot').checked = w.chatbot_enabled !== false;
      $('#w_whatsapp').checked = w.whatsapp_enabled !== false;
      if ($('#w_wa_attr')) $('#w_wa_attr').checked = w.wa_attr !== false;   // v1.2.175: wa-atribusi
      if ($('#w_web_human')) $('#w_web_human').checked = !!(w.web_human && w.web_human.enabled);   // v1.2.195: web-balas
      if ($('#ma_status') && user && user.role === 'super_admin') { maBind(); maStatus(); }   // v1.2.176: meta-campaign
      $('#w_wa_number').value = w.whatsapp_number || '';
      $('#w_wa_msg').value = w.whatsapp_message || '';
      loadWhiteLabel(s);   // v1.2.58
      // v1.2.53: Form Data Pengunjung
      var lf = w.lead_form || {};
      $('#lf_enabled').checked         = lf.enabled === true;
      $('#lf_allow_skip').checked      = lf.allow_skip === true;
      $('#lf_consent_enabled').checked = lf.consent_enabled !== false;
      $('#lf_save_contact').checked    = lf.save_contact !== false;
      $('#lf_title').value        = lf.title        || '';
      $('#lf_subtitle').value     = lf.subtitle     || '';
      $('#lf_name_label').value   = lf.name_label   || '';
      $('#lf_phone_label').value  = lf.phone_label  || '';
      $('#lf_submit_text').value  = lf.submit_text  || '';
      $('#lf_skip_text').value    = lf.skip_text    || '';
      $('#lf_consent_text').value = lf.consent_text || '';
      $('#a_key').value = a.claude_api_key || '';       // masked from server
      $('#a_key').placeholder = a.key_is_set ? '•••• (terisi — kosongkan untuk tidak mengubah)' : 'sk-ant-...';
      (function(){ var ms = $('#a_model'), v = a.model || 'claude-haiku-5-5', ada = false; // v1.2.103: model-terbaru
        for (var i = 0; i < ms.options.length; i++) { if (ms.options[i].value === v) { ada = true; break; } }
        if (!ada) { var o = document.createElement('option'); o.value = v; o.textContent = v + ' (tersimpan)'; ms.appendChild(o); }
        ms.value = v; })();
      $('#a_maxtok').value = a.max_tokens || 400;
      $('#a_rate').value = a.rate_limit || 20;
      $('#a_kbmax').value = a.kb_max_results || 5;
      $('#a_loglimit').value = a.log_limit || 500;
      // v1.2.49: provider AI + OpenRouter
      $('#a_provider').value = a.provider || 'anthropic';
      $('#a_or_key').value = a.openrouter_api_key || '';
      $('#a_or_key').placeholder = a.openrouter_key_is_set ? '•••• (terisi — kosongkan untuk tidak mengubah)' : 'sk-or-...';
      setOrModel(a.openrouter_model || 'anthropic/claude-haiku-5.5');
      (function(){ // v1.2.80: model cadangan
        var fs = $('#a_fallback'); if (!fs) return;
        var d = $('#a_fallback_default');
        if (d) d.textContent = a.server_fallback ? ('Bawaan server (' + a.server_fallback + ')') : 'Bawaan (tidak ada cadangan)';
        var v = a.fallback || '';
        var ada = false; for (var i = 0; i < fs.options.length; i++) { if (fs.options[i].value === v) { ada = true; break; } }
        if (!ada && v) { var o = document.createElement('option'); o.value = v; o.textContent = v; fs.appendChild(o); }
        fs.value = v;
      })();
      wireAiProvider();
      wireOrModel();
      toggleAiProvider();

      var wa = s.whatsapp_api || {};
      $('#wa_enabled').checked = wa.enabled === true;
      if ($('#wa_groups')) $('#wa_groups').checked = wa.wa_groups === true;   // v1.2.170: grup-wa
      if ($('#wa_media_days')) $('#wa_media_days').value = String([7, 14, 30].indexOf(+wa.media_days) !== -1 ? +wa.media_days : 7);   // v1.2.94: media-days
      $('#wa_token').value = wa.access_token || '';   // masked from server
      $('#wa_token').placeholder = wa.token_is_set ? '•••• (terisi — kosongkan untuk tidak mengubah)' : 'EAAG...';
      $('#wa_pnid').value = wa.phone_number_id || '';
      $('#wa_waba').value = wa.waba_id || '';
      $('#wa_verify').value = wa.verify_token || '';
      $('#wa_secret').value = wa.app_secret || '';     // masked from server
      $('#wa_rate').value = (+wa.rate_limit_per_number && +wa.rate_limit_per_number !== 20) ? wa.rate_limit_per_number : 60;   // v1.2.158: rl-wa
      $('#wa_ctx').checked = wa.keep_context !== false;
      $('#wa_webhook_url').value = API + '?action=wa_webhook';
      // v1.2.36: penyedia + kolom Fonnte
      var _prov = wa.provider || 'meta';
      var _fo = document.querySelector('#wa_provider option[value="fonnte"]');   // v1.2.92: fonnte-off
      if (_fo) { _fo.hidden = _prov !== 'fonnte'; _fo.disabled = _prov !== 'fonnte'; }
      $('#wa_provider').value = _prov;
      $('#fon_token').value = wa.fonnte_token || '';   // disamarkan server
      $('#fon_token').placeholder = wa.fonnte_token_is_set
        ? '•••• (terisi — kosongkan untuk tidak mengubah)' : 'token dari panel Fonnte';
      $('#fon_device').value = wa.fonnte_device || '';
      // v1.2.76: WAHA
      $('#waha_url').value = wa.waha_url || '';
      $('#waha_session').value = wa.waha_session || '';
      $('#waha_key').value = wa.waha_api_key || '';   // disamarkan server
      $('#waha_key').placeholder = wa.waha_api_key_is_set ? '•••• (terisi — kosongkan untuk tidak mengubah)' : 'nilai WAHA_API_KEY';
      $('#waha_webhook_url').value = (wa.waha_webhook_key && wa.waha_webhook_key.indexOf('•') === -1)
        ? (API + '?action=wa_webhook_waha&key=' + encodeURIComponent(wa.waha_webhook_key))
        : '(kunci dibuat otomatis setelah disimpan dengan penyedia WAHA)';
      $('#btnCopyWahaWebhook').onclick = function () { var f = $('#waha_webhook_url'); f.select(); copyText(f.value, 'Webhook WAHA disalin.'); };
      $('#fon_webhook_url').value = wa.fonnte_webhook_key
        ? (API + '?action=wa_webhook_fonnte&key=' + encodeURIComponent(wa.fonnte_webhook_key))
        : '(kunci dibuat otomatis setelah disimpan dengan penyedia Fonnte)';
      waTampilkanBlokPenyedia(_prov);
      $('#wa_provider').onchange = function () { waTampilkanBlokPenyedia(this.value); };
      $('#btnCopyFonWebhook').onclick = function () {
        var f = $('#fon_webhook_url'); f.select();
        copyText(f.value, 'Webhook Fonnte disalin.');
      };
      // v1.2.54: Embedded Signup coexistence
      $('#es_app_id').value    = wa.es_app_id || '';
      $('#es_config_id').value = wa.es_config_id || '';
      (function () {
        var pnid = (wa.provider === 'meta' && wa.phone_number_id && String(wa.phone_number_id).indexOf('•') === -1) ? wa.phone_number_id : '';
        var st = $('#es_status');
        if (st) { st.textContent = pnid ? ('Terhubung: ' + pnid) : 'Belum terhubung.'; st.style.color = pnid ? '#1a7f37' : ''; }
      })();
      esWire(wa.es_graph_version || 'v21.0');

      var tg = s.telegram || {};
      $('#tg_enabled').checked = tg.enabled === true;
      $('#tg_token').value = '';
      $('#tg_token').placeholder = tg.token_is_set ? '•••• (terisi — kosongkan untuk tidak mengubah)' : '123456:ABC-DEF...';
      $('#tg_chatid').value = tg.chat_id || '';
      $('#tg_wa').checked = tg.notify_whatsapp !== false;
      $('#tg_web').checked = tg.notify_web !== false;
      if ($('#wa_alert_phone')) $('#wa_alert_phone').value = (s.wa_alert && s.wa_alert.phone) || '';   // v1.2.179: notif-putus-wa
      warLoad209();   // v1.2.209: autoreply-hp

      var ho = s.handoff || {};
      $('#ho_enabled').checked = ho.enabled !== false;
      $('#ho_keywords').value = (ho.keywords || []).join('\n');
    });
    $('#btnSaveWidget').onclick = saveWidget;
    $('#btnCopyWebhook').onclick = function () {
      var f = $('#wa_webhook_url'); f.select();
      try { document.execCommand('copy'); toast('URL webhook disalin.'); }
      catch (e) { toast('Salin manual: ' + f.value); }
    };
  }
  function toggleAiProvider() {
    var p = $('#a_provider') ? $('#a_provider').value : 'anthropic';
    document.querySelectorAll('.ai-anthropic').forEach(function(el){ el.style.display = (p==='anthropic')?'':'none'; });
    document.querySelectorAll('.ai-openrouter').forEach(function(el){ el.style.display = (p==='openrouter')?'':'none'; });
  }
  function wireAiProvider() {
    if ($('#a_provider') && !$('#a_provider').dataset.wired) {
      $('#a_provider').dataset.wired='1';
      $('#a_provider').onchange = toggleAiProvider;
    }
  }

  function setOrModel(val) {
    var sel=$('#a_or_model_sel'), cust=$('#a_or_model');
    if (!sel || !cust) return;
    var found=false;
    for (var i=0;i<sel.options.length;i++){ if (sel.options[i].value===val){ found=true; break; } }
    if (found && val!=='__custom__') { sel.value=val; cust.style.display='none'; cust.value=''; }
    else { sel.value='__custom__'; cust.style.display='block'; cust.value=val||''; }
  }
  function getOrModel() {
    var sel=$('#a_or_model_sel'), cust=$('#a_or_model');
    if (!sel) return '';
    if (sel.value==='__custom__') return (cust?cust.value.trim():'') || 'anthropic/claude-haiku-5.5';
    return sel.value;
  }
  function wireOrModel() {
    var sel=$('#a_or_model_sel'), cust=$('#a_or_model');
    if (sel && !sel.dataset.wired) {
      sel.dataset.wired='1';
      sel.onchange=function(){ if (cust) cust.style.display=(this.value==='__custom__')?'block':'none'; };
    }
  }

  function saveWidget() {
    var keyField = $('#a_key').value.trim();
    var apiBlock = {
      provider: $('#a_provider') ? $('#a_provider').value : 'anthropic',
      model: $('#a_model').value,
      openrouter_model: getOrModel(),
      fallback: $('#a_fallback') ? $('#a_fallback').value : '',   // v1.2.80
      max_tokens: +$('#a_maxtok').value || 400,
      rate_limit: +$('#a_rate').value || 20,
      kb_max_results: +$('#a_kbmax').value || 5,
      log_limit: +$('#a_loglimit').value || 500
    };
    // Only send keys if user typed a fresh one (not the masked bullet value)
    if (keyField && keyField.indexOf('•') === -1) apiBlock.claude_api_key = keyField;
    var orKeyField = $('#a_or_key') ? $('#a_or_key').value.trim() : '';
    if (orKeyField && orKeyField.indexOf('•') === -1) apiBlock.openrouter_api_key = orKeyField;

    var waBlock = {
      enabled: $('#wa_enabled').checked,
      wa_groups: $('#wa_groups') ? $('#wa_groups').checked : false,   // v1.2.170: grup-wa
      media_days: $('#wa_media_days') ? +$('#wa_media_days').value || 7 : 7,   // v1.2.94: media-days
      phone_number_id: $('#wa_pnid').value.trim(),
      waba_id: $('#wa_waba').value.trim(),
      verify_token: $('#wa_verify').value.trim(),
      keep_context: $('#wa_ctx').checked,
      rate_limit_per_number: +$('#wa_rate').value || 60,   // v1.2.158: rl-wa
      provider: $('#wa_provider').value,                                          // v1.2.36
      fonnte_device: $('#fon_device').value.trim(),
      waha_url: $('#waha_url').value.trim(),                                         // v1.2.76
      waha_session: $('#waha_session').value.trim(),
      waha_api_key: ($('#waha_key').value.indexOf('•') !== -1) ? '' : $('#waha_key').value.trim(),
      es_app_id: ($('#es_app_id') ? $('#es_app_id').value.trim() : ''),
      es_config_id: ($('#es_config_id') ? $('#es_config_id').value.trim() : ''),
      es_graph_version: 'v21.0',
      // tersamar atau kosong -> kirim kosong; backend mempertahankan nilai lama
      fonnte_token: ($('#fon_token').value.indexOf('•') !== -1) ? '' : $('#fon_token').value.trim()
    };
    var waToken = $('#wa_token').value.trim();
    if (waToken && waToken.indexOf('•') === -1) waBlock.access_token = waToken;
    var waSecret = $('#wa_secret').value.trim();
    if (waSecret && waSecret.indexOf('•') === -1) waBlock.app_secret = waSecret;

    var tgBlock = {
      enabled: $('#tg_enabled').checked,
      chat_id: $('#tg_chatid').value.trim(),
      notify_whatsapp: $('#tg_wa').checked,
      notify_web: $('#tg_web').checked
    };
    var tgToken = $('#tg_token').value.trim();
    if (tgToken && tgToken.indexOf('•') === -1) tgBlock.bot_token = tgToken;

    var hoBlock = {
      enabled: $('#ho_enabled').checked,
      keywords: $('#ho_keywords').value.split('\n').map(function (k) { return k.trim(); }).filter(function (k) { return k !== ''; })
    };

    var body = { settings: {
      widget: {
        chatbot_enabled: $('#w_chatbot').checked,
        whatsapp_enabled: $('#w_whatsapp').checked,
        wa_attr: $('#w_wa_attr') ? $('#w_wa_attr').checked : true,   // v1.2.175: wa-atribusi
        web_human: { enabled: $('#w_web_human') ? $('#w_web_human').checked : false },   // v1.2.195: web-balas
        whatsapp_number: $('#w_wa_number').value.trim(),
        whatsapp_message: $('#w_wa_msg').value,
        // v1.2.53: Form Data Pengunjung
        lead_form: {
          enabled:         $('#lf_enabled').checked,
          allow_skip:      $('#lf_allow_skip').checked,
          consent_enabled: $('#lf_consent_enabled').checked,
          save_contact:    $('#lf_save_contact').checked,
          title:        $('#lf_title').value.trim()        || 'Sebelum mulai chat',
          subtitle:     $('#lf_subtitle').value.trim()     || 'Isi data singkat berikut supaya kami bisa membantu Anda lebih baik.',
          name_label:   $('#lf_name_label').value.trim()   || 'Nama',
          phone_label:  $('#lf_phone_label').value.trim()  || 'No. HP / WhatsApp',
          submit_text:  $('#lf_submit_text').value.trim()  || 'Mulai Chat',
          skip_text:    $('#lf_skip_text').value.trim()    || 'Lewati',
          consent_text: $('#lf_consent_text').value.trim() || 'Saya bersedia dihubungi melalui WhatsApp.'
        }
      },
      api: apiBlock,
      whatsapp_api: waBlock,
      telegram: tgBlock,
      handoff: hoBlock
    } };
    if ($('#wa_alert_phone')) body.settings.wa_alert = { phone: $('#wa_alert_phone').value.trim() };   // v1.2.179: notif-putus-wa
    if (role === 'super_admin' && $('#wl_subtitle')) {   // v1.2.58: white-label
      body.settings.white_label = {
        subtitle: $('#wl_subtitle').value.trim(),
        header_logo: $('#wl_logo').value.trim(),
        hide_branding: $('#wl_hide').checked
      };
    }
    api('save_settings', { method: 'POST', body: body }).then(function (res) {
      if (res.ok) { toast('Konfigurasi tersimpan.'); loaded.widget = false; loadWidget(); }
      else toast(res.error || 'Gagal menyimpan.', true);
    });
  }

  /* ====================================================================== *
   *  USERS (admin only)
   * ====================================================================== */
  // v1.2.2: Profil Saya — self-service password change
  function loadProfile() {
    var user = JSON.parse(localStorage.getItem(UK) || '{}');
    if ($('#profileUsername')) $('#profileUsername').textContent = user.username || '-';
    if ($('#profileName'))     $('#profileName').textContent     = user.name || user.username || '-';
    var roleMap = {'super_admin':'Super Admin', 'admin':'Admin', 'supervisor':'Supervisor', 'wa_agent':'WA Agent', 'sales':'Sales'};
    if ($('#profileRole'))     $('#profileRole').textContent     = roleMap[user.role] || user.role || '-';
    if ($('#profileCurrentPw')) $('#profileCurrentPw').value = '';
    if ($('#profileNewPw'))     $('#profileNewPw').value = '';
    if ($('#profileConfirmPw')) $('#profileConfirmPw').value = '';
    // Wire button (idempotent)
    var btn = $('#btnChangePassword');
    if (btn && !btn.dataset.wired) {
      btn.onclick = changeOwnPassword;
      btn.dataset.wired = 'true';
    }
    loadMyLoginLog();   // v1.2.112
    loadProfileEmail();   // v1.2.184: lupa-password
  }
  // v1.2.184: lupa-password — email pemulihan di Profil Saya
  function peNote(em) {
    if ($('#profileEmailView')) $('#profileEmailView').textContent = em || '— (belum diisi)';
    var n = $('#peNote'); if (!n) return;
    n.textContent = em ? ('Tautan reset dikirim ke ' + em + '.') : 'Belum ada email — fitur Lupa password belum bisa dipakai untuk akun ini.';
    n.style.color = em ? '' : '#b45309';
  }
  function loadProfileEmail() {
    var b = $('#btnSaveEmail'); if (!b) return;
    if (!b.dataset.wired) { b.dataset.wired = '1'; b.onclick = saveOwnEmail; }
    $('#profileEmailPw').value = '';
    api('me').then(function (res) {
      if (!res || !res.ok) return;
      var u = res.user || {};
      $('#profileEmail').value = u.email || '';
      peNote(u.reset_email || '');
    }).catch(function () {});
  }
  function saveOwnEmail() {
    var em = $('#profileEmail').value.trim(), pw = $('#profileEmailPw').value;
    if (em && !/^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(em)) { toast('Format email tidak valid.', true); $('#profileEmail').focus(); return; }
    if (!pw) { toast('Masukkan password Anda untuk konfirmasi.', true); $('#profileEmailPw').focus(); return; }
    var b = $('#btnSaveEmail'); b.disabled = true;
    api('update_own_email', { method: 'POST', body: { email: em, current_password: pw } }).then(function (res) {
      b.disabled = false;
      if (!res || !res.ok) { toast((res && res.error) || 'Gagal menyimpan email.', true); return; }
      $('#profileEmailPw').value = '';
      toast(em ? 'Email pemulihan disimpan.' : 'Email pemulihan dihapus.');
      peNote(res.reset_email || '');
    }).catch(function () { b.disabled = false; });
  }
  function changeOwnPassword() {
    var cur = $('#profileCurrentPw').value;
    var newPw = $('#profileNewPw').value;
    var conf = $('#profileConfirmPw').value;
    if (!cur || !newPw || !conf) { toast('Semua field wajib diisi.', true); return; }
    if (newPw !== conf) { toast('Konfirmasi password tidak cocok.', true); return; }
    var pwBad2 = pwProblem(newPw);   // v1.2.60: aturan lengkap, sama dengan server
    if (pwBad2) { toast(pwBad2, true); return; }
    if (newPw === cur) { toast('Password baru tidak boleh sama dengan yang lama.', true); return; }
    var btn = $('#btnChangePassword');
    btn.disabled = true;
    btn.textContent = 'Menyimpan...';
    api('update_own_password', {
      method: 'POST',
      body: { current_password: cur, new_password: newPw }
    }).then(function(res) {
      if (!res.ok) {
        toast(res.error || 'Gagal ganti password.', true);
        btn.disabled = false;
        btn.textContent = 'Simpan Password';
        return;
      }
      toast('Password berhasil diganti. Anda akan logout otomatis...');
      setTimeout(function() {
        localStorage.removeItem(TK);
        localStorage.removeItem(UK);
        location.href = 'login.html';
      }, 2000);
    });
  }

  // v1.2.60: aturan password sama dengan server (checkPasswordStrength)
  var PW_RULE_MSG = 'Password minimal 8 karakter, harus mengandung huruf besar, huruf kecil, dan angka.';
  function pwProblem(pw) {
    var miss = [];
    if (pw.length < 8) miss.push('minimal 8 karakter');
    if (!/[A-Z]/.test(pw)) miss.push('huruf besar');
    if (!/[a-z]/.test(pw)) miss.push('huruf kecil');
    if (!/[0-9]/.test(pw)) miss.push('angka');
    return miss.length ? ('Password harus minimal 8 karakter, ada huruf besar, huruf kecil, dan angka (kurang: ' + miss.join(', ') + ').') : '';
  }
  function pwLiveHint() {
    var el = document.getElementById('u_pw_rule'), pw = $('#u_password').value;
    if (!el) return;
    var bad = pw ? pwProblem(pw) : '';
    el.textContent = bad || PW_RULE_MSG;
    el.style.color = bad ? '#b91c1c' : (pw ? '#15803d' : '');
  }
  // v1.2.60: peringatan kursi penuh langsung di form (sebelum klik Simpan)
  var lastSeats = null, editingUser = null;
  function seatFull(role) {
    var se = lastSeats; if (!se) return '';
    if (editingUser && editingUser.role === role) return '';   // edit akun yang sudah di peran itu tetap boleh
    var max = role === 'wa_agent' ? se.max_agents : (role === 'supervisor' ? se.max_supervisors : 0);
    var used = role === 'wa_agent' ? se.used_agents : (role === 'supervisor' ? se.used_supervisors : 0);
    if (!(max > 0) || used < max) return '';
    var lbl = role === 'wa_agent' ? 'WA Agent' : 'Supervisor';
    return ico('ban', 14) + ' <b>Kursi ' + lbl + ' penuh (' + used + '/' + max + ').</b> ' +
      (user.role === 'super_admin'
        ? 'Hapus akun ' + lbl + ' yang tidak dipakai, atau minta ' + BRAND_VENDOR + ' menambah kursi paket.'
        : 'Hapus akun ' + lbl + ' yang tidak dipakai, atau minta Super Admin/' + BRAND_VENDOR + ' menambah kursi paket.') +
      (se.source === 'pusat' ? '' : ' <a href="#" class="seat-sync">Sinkron ulang dari pusat</a>');
  }
  function updateSeatWarn() {
    var box = document.getElementById('userSeatWarn'), btn = $('#btnSaveUser');
    if (!box) return;
    var msg = seatFull($('#u_role').value);
    box.innerHTML = msg; box.style.display = msg ? '' : 'none';
    if (btn) { btn.disabled = !!msg; btn.title = msg ? 'Kursi paket penuh' : ''; }
  }
  document.addEventListener('click', function (e) {
    var a = e.target && e.target.closest && e.target.closest('.seat-sync');
    if (a) { e.preventDefault(); syncSeats(); }
  });
  function syncSeats() {
    toast('Menyinkronkan kursi dari server pusat...');
    api('refresh_seats', { method: 'POST', body: {} }).then(function (r) {
      if (!r.ok) { toast(r.error || 'Gagal sinkron.', true); return; }
      if (r.note) toast(r.note, true); else toast('Kursi tersinkron dari server pusat.');
      renderUsers();
    });
  }

  /* ---- v1.2.112: login-log — Riwayat Login (tab Pengguna) & Riwayat Login Saya (Profil) ---- */
  var LL_REASON = { wrong_password: 'Password salah', unknown_user: 'Username tidak dikenal', locked: 'Terkunci sementara (5x gagal)',
    seat_limit: 'Di luar kursi paket', not_sa: 'Bukan Super Admin', not_admin: 'Bukan Admin' };
  var LL_METHOD = { password: 'Password', sso: 'Tautan dari Pusat', sso_grup: 'Dashboard Grup' };   // v1.2.185: master-grup
  var llRowsCache = [];
  function llStatusHtml(e) {
    return e.ok ? '<span class="tag" style="background:#dcfce7;color:#166534">Berhasil</span>'
      : '<span class="tag" style="background:#fee2e2;color:#b91c1c">Gagal</span>' +
        (e.r ? ' <span class="help" style="font-size:11px">' + esc(LL_REASON[e.r] || e.r) + '</span>' : '');
  }
  function loadLoginLog() {
    var card = $('#llCard');
    if (!card) return;
    if (!can('super_admin,admin')) { card.style.display = 'none'; return; }
    card.style.display = '';
    if (!card.dataset.wired) {
      card.dataset.wired = '1';
      ['#llUser', '#llStatus', '#llDays'].forEach(function (s) { $(s).onchange = loadLoginLog; });
      $('#llRefresh').onclick = loadLoginLog;
      $('#llCsv').onclick = llCsv;
    }
    var q = '&limit=300&days=' + encodeURIComponent($('#llDays').value) +
      '&status=' + encodeURIComponent($('#llStatus').value) + '&user=' + encodeURIComponent($('#llUser').value);
    $('#llRows').innerHTML = '<tr><td colspan="6" class="help">Memuat…</td></tr>';
    api('login_log', { query: q }).then(function (res) {
      if (!res.ok) { $('#llRows').innerHTML = '<tr><td colspan="6" style="color:#b91c1c">' + esc(res.error || 'Gagal memuat riwayat login') + '</td></tr>'; return; }
      var sel = $('#llUser'), cur = sel.value;
      sel.innerHTML = '<option value="">Semua pengguna</option>' + (res.usernames || []).map(function (u) {
        return '<option value="' + esc(u) + '">' + esc(u) + '</option>';
      }).join('');
      sel.value = cur;
      var st = res.stats || {};
      $('#llStats').innerHTML = '24 jam terakhir: <b style="color:#166534">' + (st.ok24 || 0) + '</b> berhasil · <b style="color:#b91c1c">' + (st.fail24 || 0) + '</b> gagal';
      llRowsCache = res.entries || [];
      $('#llRows').innerHTML = llRowsCache.length ? llRowsCache.map(function (e) {
        return '<tr><td class="mono" style="white-space:nowrap">' + esc(e.ts) + '</td>' +
          '<td>' + esc(e.u) + (e.name && e.name !== e.u ? ' <span class="help" style="font-size:11px">' + esc(e.name) + '</span>' : '') +
            (e['in'] ? ' <span class="tag">Tim DEI</span>' : '') + '</td>' +
          '<td>' + llStatusHtml(e) + '</td>' +
          '<td>' + esc(LL_METHOD[e.m] || e.m || '') + '</td>' +
          '<td class="mono">' + esc(e.ip || '') + '</td>' +
          '<td title="' + esc(e.ua || '') + '">' + esc(e.dev || '—') + '</td></tr>';
      }).join('') : '<tr><td colspan="6" class="help">Belum ada catatan login pada rentang ini.</td></tr>';
      $('#llMore').textContent = res.total > llRowsCache.length
        ? ('Menampilkan ' + llRowsCache.length + ' dari ' + res.total + ' catatan. Persempit filter untuk melihat sisanya.')
        : (res.total ? res.total + ' catatan.' : '');
    });
  }
  function llCsv() {
    if (!llRowsCache.length) { toast('Tidak ada data untuk diunduh.', true); return; }
    var cell = function (v) {
      v = String(v == null ? '' : v);
      if (/^[=+\-@]/.test(v)) v = "'" + v;   // cegah formula injection di Excel
      return '"' + v.replace(/"/g, '""') + '"';
    };
    var rows = [['Waktu (WIB)', 'Username', 'Nama', 'Peran', 'Status', 'Alasan', 'Metode', 'IP', 'Perangkat', 'User Agent']]
      .concat(llRowsCache.map(function (e) {
        return [e.ts, e.u, e.name || '', e.role || '', e.ok ? 'Berhasil' : 'Gagal', e.r ? (LL_REASON[e.r] || e.r) : '',
          LL_METHOD[e.m] || e.m || '', e.ip || '', e.dev || '', e.ua || ''];
      }));
    var blob = new Blob(['﻿' + rows.map(function (r) { return r.map(cell).join(','); }).join('\r\n')], { type: 'text/csv;charset=utf-8' });
    var a = document.createElement('a');
    a.href = URL.createObjectURL(blob);
    a.download = 'riwayat-login-' + new Date().toISOString().slice(0, 10) + '.csv';
    document.body.appendChild(a); a.click();
    setTimeout(function () { URL.revokeObjectURL(a.href); a.remove(); }, 500);
  }
  function loadMyLoginLog() {
    var box = $('#myLlRows');
    if (!box) return;
    api('my_login_log').then(function (res) {
      if (!res.ok) { box.innerHTML = esc(res.error || 'Gagal memuat riwayat login.'); return; }
      var en = res.entries || [];
      box.innerHTML = en.length
        ? '<div class="scroll"><table class="tbl"><thead><tr><th>Waktu (WIB)</th><th>Status</th><th>IP</th><th>Perangkat</th></tr></thead><tbody>' +
          en.map(function (e) {
            return '<tr><td class="mono" style="white-space:nowrap">' + esc(e.ts) + '</td><td>' + llStatusHtml(e) + '</td>' +
              '<td class="mono">' + esc(e.ip || '') + '</td><td>' + esc(e.dev || '—') + '</td></tr>';
          }).join('') + '</tbody></table></div>'
        : 'Belum ada catatan login (riwayat mulai tercatat sejak v1.2.112).';
    });
  }
  /* ---- /v1.2.112 ---- */
  function loadUsers() {
    uSalesLoad216();   // v1.2.216: pipeline-sales
    ensureCategories(function () { renderUserCategories([]); renderUsers(); });  // v1.2.13
    renderUserReplyStages([]);   // v1.2.119: agent-stage
    applyRoleDropdownRestriction();
    $('#btnSaveUser').onclick = saveUser;
    $('#btnResetUser').onclick = resetUserForm;
    if ($('#u_role')) $('#u_role').onchange = function () { toggleSpvRow(); updateSeatWarn(); };   // v1.2.59 / v1.2.60
    if ($('#u_password')) $('#u_password').oninput = pwLiveHint;   // v1.2.60
    toggleSpvRow();
    loadLoginLog();   // v1.2.112
  }
  // v1.2.59: supervisor atasan WA Agent — dipilih Super Admin/Admin; akun yang
  // dibuat Supervisor otomatis masuk timnya (dropdown disembunyikan).
  function toggleSpvRow() {
    // v1.2.119: agent-stage — baris Lead Rating untuk WA Agent
    var isAg = $('#u_role') && $('#u_role').value === 'wa_agent';
    if (document.getElementById('u_rs_row')) { document.getElementById('u_rs_row').style.display = isAg ? '' : 'none'; document.getElementById('u_rs_help').style.display = isAg ? '' : 'none'; }
    ['u_div_row', 'u_sales_help'].forEach(function (id) { var e = document.getElementById(id); if (e) e.style.display = ($('#u_role') && $('#u_role').value === 'sales') ? '' : 'none'; });   // v1.2.220: sales-di-pengguna
    var sc219 = document.getElementById('u_scope_row'); if (sc219) sc219.style.display = ($('#u_role') && $('#u_role').value === 'sales') ? '' : 'none';   // v1.2.219: divisi-sales
    var sr216 = document.getElementById('u_sales_row'); if (sr216) { var isS216 = $('#u_role') && $('#u_role').value === 'sales'; sr216.style.display = isS216 ? '' : 'none'; if (isS216 && !uSales216.length) uSalesLoad216(); }   // v1.2.216: pipeline-sales
    var row = document.getElementById('u_spv_row');
    if (!row) return;
    var show = (user.role === 'super_admin' || user.role === 'admin') && $('#u_role').value === 'wa_agent';
    row.style.display = show ? '' : 'none';
  }
  var RS_EXTRA = { vip: 'VIP' };
  function rsLabel(k) { return CONTACT_STAGE[k] ? CONTACT_STAGE[k].label : (RS_EXTRA[k] || k); }
  function rsKeys() { var ks = []; CONTACT_STAGE_ORDER.forEach(function (k) { if (k !== '__sep__') ks.push(k); }); ks.push('vip'); return ks; }
  function rsAllowed(al, stage, vip) { return !al || !al.length || al.indexOf(stage || 'new') > -1 || (!!vip && al.indexOf('vip') > -1); }
  function renderUserReplyStages(sel) {
    var box = document.getElementById('u_reply_stages');
    if (!box) return;
    sel = sel || [];
    box.innerHTML = rsKeys().map(function (k) {
      return '<label style="display:flex;gap:5px;align-items:center;font-size:13px;cursor:pointer">' +
        '<input type="checkbox" class="u_rs" value="' + k + '"' + (sel.indexOf(k) > -1 ? ' checked' : '') + '> ' + esc(rsLabel(k)) + '</label>';
    }).join('');
  }
  function fillSpvOptions(users) {
    var sel = document.getElementById('u_supervisor');
    if (!sel) return;
    var cur = sel.value;
    sel.innerHTML = '<option value="">— Tanpa supervisor (terlihat semua SPV) —</option>' +
      users.filter(function (x) { return x.role === 'supervisor'; }).map(function (x) {
        return '<option value="' + esc(x.username) + '">' + esc(x.name || x.username) + ' (' + esc(x.username) + ')</option>';
      }).join('');
    sel.value = cur;
  }
  // v1.2.6: role-aware user management
  window.ROLE_LABELS_V126 = { super_admin: 'Super Admin', admin: 'Admin', supervisor: 'Supervisor', wa_agent: 'WA Agent', sales: 'Sales' };
  function applyRoleDropdownRestriction() {
    var sel = document.getElementById('u_role');
    if (!sel) return;
    var note = document.getElementById('u_role_note');
    if (user.role === 'admin') {   // v1.2.61: Admin boleh buat WA Agent & Supervisor
      var cur = sel.value;
      sel.innerHTML = '<option value="wa_agent">WA Agent — hanya balas chat WhatsApp</option>' +
        '<option value="supervisor">Supervisor (SPV) — lihat chat timnya, assign ke agent, laporan tim, kelola agent</option>' +
        '<option value="sales">Sales — hanya lead &amp; task miliknya (paket Growth)</option>';   // v1.2.216: pipeline-sales
      sel.value = (cur === 'supervisor' || cur === 'sales') ? cur : 'wa_agent';
      sel.disabled = false;
      if (note) { note.textContent = 'Admin dapat menambah WA Agent dan Supervisor. Admin & Super Admin hanya bisa dibuat oleh Super Admin.'; note.style.display = ''; }
    } else if (user.role === 'supervisor') {   // v1.2.58
      sel.innerHTML = '<option value="wa_agent">WA Agent — hanya balas chat WhatsApp</option>';
      sel.value = 'wa_agent';
      sel.disabled = true;
      if (note) { note.textContent = 'Supervisor hanya dapat menambah WA Agent (otomatis masuk tim Anda).'; note.style.display = ''; }
    }
  }
  function renderUsers() {
    api('get_users').then(function (res) {
      if (!res.ok) return;
      // v1.2.58: kursi paket
      var se = res.seats || null;
      if ($('#usersSeats')) {
        $('#usersSeats').innerHTML = se ? seatText(se) : '';
      }
      lastSeats = se; updateSeatWarn();   // v1.2.60
      fillSpvOptions(res.users);   // v1.2.59
      var nmBy = {};
      res.users.forEach(function (x) { nmBy[x.username] = x.name || x.username; });
      $('#tblUsers').innerHTML = res.users.map(function (u) {
        return '<tr>' +
          '<td class="mono">' + esc(u.username) + (u.email && u.email !== u.username ? '<div style="font-size:11px;color:var(--muted);font-family:inherit" title="Email pemulihan">' + esc(u.email) + '</div>' : '') + '</td>' +   // v1.2.184
          '<td>' + esc(u.name) + '</td>' +
          '<td><span class="tag">' + (window.ROLE_LABELS_V126[u.role] || u.role) + '</span>' +
            (u.seat_locked ? ' <span class="tag" style="background:#fee2e2;color:#b91c1c" title="Di luar batas kursi paket — tidak bisa login">' + ico('ban',12) + ' terkunci</span>' : '') +
            ((u.role === 'wa_agent' && (u.reply_stages || []).length) ? '<div style="font-size:11px;color:var(--muted);margin-top:3px" title="Hanya boleh membalas Lead Rating ini">Balas: ' + esc(u.reply_stages.map(rsLabel).join(', ')) + '</div>' : '') + '</td>' +   // v1.2.119
          '<td>' + (u.role === 'wa_agent' ? (u.supervisor ? esc(nmBy[u.supervisor] || u.supervisor) : '<span class="help" style="font-size:11px">—</span>') : (u.role === 'sales' ? '<span class="help" style="font-size:11px">' + (u.sales_div ? 'Divisi ' + esc(u.sales_div) : 'Tanpa divisi') + ' · ' + ({ own: 'lihat miliknya', division: 'lihat satu divisi', all: 'lihat semua sales' }[u.sales_scope || 'own']) + '</span>' : '')) + '</td>' +
          '<td class="mono" style="font-size:12px;white-space:nowrap;color:var(--muted)">' + (u.last_login ? esc(u.last_login) : '—') + '</td>' +
          '<td style="text-align:right;white-space:nowrap">' +
            ((user.role === 'super_admin' || ((user.role === 'admin' || user.role === 'supervisor') && u.role === 'wa_agent') || (user.role === 'admin' && u.role === 'sales') ||
              (user.role === 'admin' && u.role === 'supervisor'))   // v1.2.61
              ? ('<button class="btn ghost sm u-edit" data-u="' + esc(u.username) + '" data-n="' + esc(u.name) + '" data-e="' + esc(u.email || '') + '" data-r="' + esc(u.role) + '" data-s="' + esc(u.supervisor || '') + '" data-cats="' + esc(JSON.stringify(u.categories || [])) + '" data-rs="' + esc(JSON.stringify(u.reply_stages || [])) + '" data-sid="' + esc(u.sales_id || '') + '" data-scope="' + esc(u.sales_scope || 'own') + '" data-div="' + esc(u.sales_div || '') + '">Edit</button> ' +
                 (u.username === user.username ? '' : '<button class="btn danger sm u-del" data-u="' + esc(u.username) + '">Hapus</button>'))
              : '<span class="help" style="font-size:11px">read-only</span>') +
          '</td></tr>';
      }).join('');
      $$('.u-edit').forEach(function (b) { b.onclick = function () {
        $('#userFormTitle').textContent = 'Edit Pengguna';
        $('#u_username').value = b.dataset.u; $('#u_username').readOnly = true; $('#u_username').dataset.edit = '1';
        editingUser = { username: b.dataset.u, role: b.dataset.r };   // v1.2.60
        $('#u_name').value = b.dataset.n; if ($('#u_email')) $('#u_email').value = b.dataset.e || '';   /* v1.2.184 */ $('#u_role').value = b.dataset.r; $('#u_password').value = '';
        if ($('#u_supervisor')) $('#u_supervisor').value = b.dataset.s || '';   // v1.2.59
        if ($('#u_sales_id')) { if (b.dataset.sid && !$('#u_sales_id').querySelector('option[value="' + b.dataset.sid + '"]')) $('#u_sales_id').insertAdjacentHTML('beforeend', '<option value="' + esc(b.dataset.sid) + '">' + esc(uSalesName216(b.dataset.sid)) + '</option>'); $('#u_sales_id').value = b.dataset.sid || ''; }   // v1.2.216: pipeline-sales
        if ($('#u_sales_scope')) $('#u_sales_scope').value = b.dataset.scope || 'own';   // v1.2.219: divisi-sales
        uDivSet220(b.dataset.div || '');   // v1.2.220: sales-di-pengguna
        toggleSpvRow(); updateSeatWarn(); pwLiveHint();
        // v1.2.12: populate kategori checkbox
        var editCats = [];
        try { editCats = JSON.parse(b.dataset.cats || '[]'); } catch (e) { editCats = []; }
        renderUserCategories(editCats);   // v1.2.13: rebuild dari daftar dinamis
        var editRs = []; try { editRs = JSON.parse(b.dataset.rs || '[]'); } catch (e) { editRs = []; }
        renderUserReplyStages(editRs);   // v1.2.119: agent-stage
        window.scrollTo({ top: 0, behavior: 'smooth' });
      }; });
      $$('.u-del').forEach(function (b) { b.onclick = function () {
        if (!confirm('Hapus pengguna "' + b.dataset.u + '"?')) return;
        api('delete_user', { method: 'POST', body: { username: b.dataset.u } }).then(function (r) {
          if (r.ok) { toast('Pengguna dihapus.'); renderUsers(); } else toast(r.error || 'Gagal.', true);
        });
      }; });
    });
  }
  function resetUserForm() {
    $('#userFormTitle').textContent = 'Tambah Pengguna';
    $('#u_username').value = ''; $('#u_username').readOnly = false; delete $('#u_username').dataset.edit;
    editingUser = null;   // v1.2.60
    $('#u_name').value = ''; $('#u_password').value = '';
    if ($('#u_email')) $('#u_email').value = '';   // v1.2.184: lupa-password
    $('#u_role').value = (user.role === 'admin' || user.role === 'supervisor') ? 'wa_agent' : 'admin';
    renderUserCategories([]);  // v1.2.13: rebuild kosong
    renderUserReplyStages([]);   // v1.2.119: agent-stage
    applyRoleDropdownRestriction();
    if ($('#u_supervisor')) $('#u_supervisor').value = '';   // v1.2.59
    if ($('#u_sales_id')) $('#u_sales_id').value = '';   // v1.2.216: pipeline-sales
    if ($('#u_sales_scope')) $('#u_sales_scope').value = 'own';   // v1.2.219: divisi-sales
    uDivSet220('');   // v1.2.220: sales-di-pengguna
    toggleSpvRow(); updateSeatWarn(); pwLiveHint();
  }
  function saveUser() {
    var body = {
      username: $('#u_username').value.trim(),
      name: $('#u_name').value.trim(),
      password: $('#u_password').value,
      role: $('#u_role').value,
      categories: Array.prototype.slice.call(document.querySelectorAll('.u_cat:checked')).map(function(c){return c.value;})  // v1.2.12: categories
    };
    if (!body.username) { toast('Username wajib diisi.', true); return; }
    if ($('#u_email')) {   // v1.2.184: lupa-password
      body.email = $('#u_email').value.trim();
      if (body.email && !/^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(body.email)) { toast('Format email tidak valid.', true); $('#u_email').focus(); return; }
    }
    // v1.2.60: cegah simpan ke akun sendiri (biasanya karena autofill browser)
    if (!editingUser && body.username === user.username) { toast('Username "' + body.username + '" adalah akun Anda sendiri — kemungkinan terisi otomatis oleh browser. Ganti dengan username baru.', true); return; }
    if (!editingUser && !body.password) { toast('Password wajib diisi untuk pengguna baru. ' + PW_RULE_MSG, true); $('#u_password').focus(); return; }
    var pwBad = body.password ? pwProblem(body.password) : '';
    if (pwBad) { toast(pwBad, true); pwLiveHint(); $('#u_password').focus(); return; }
    var seatMsg = seatFull(body.role);
    if (seatMsg) { updateSeatWarn(); toast('Kursi paket penuh — pengguna tidak bisa ditambahkan.', true); return; }
    if ($('#u_spv_row') && $('#u_spv_row').style.display !== 'none') body.supervisor = $('#u_supervisor').value;   // v1.2.59
    if (body.role === 'sales' && $('#u_sales_scope')) body.sales_scope = $('#u_sales_scope').value;   // v1.2.219: divisi-sales
    if (body.role === 'sales') { body.sales_id = ($('#u_sales_id') || {}).value || ''; body.sales_div = uDivGet220(); if (body.sales_div === null) { toast('Isi nama divisi baru.', true); $('#u_sales_div_new').focus(); return; } }   /* v1.2.220: sales-di-pengguna */   // v1.2.216: pipeline-sales
    if (body.role === 'wa_agent') body.reply_stages = Array.prototype.slice.call(document.querySelectorAll('.u_rs:checked')).map(function (c) { return c.value; });   // v1.2.119
    api('save_user', { method: 'POST', body: body }).then(function (res) {
      if (res.ok) { toast('Pengguna disimpan.'); resetUserForm(); renderUsers(); uSalesLoad216(); }   // v1.2.220: sales-di-pengguna
      else toast(res.error || 'Gagal menyimpan.', true);
    });
  }

  /* ====================================================================== *
   *  INSTALL (GTM snippet)
   * ====================================================================== */
  function loadInstall() {
    var gtm =
'<!-- DEI AI Chatbot -->\n' +
'<script>\n' +
'  window.DEI_CHATBOT_BASE = "' + SITE_BASE + '";\n' +
'  (function(){var s=document.createElement("script");\n' +
'    s.src=window.DEI_CHATBOT_BASE+"/assets/js/chat-widget.js";\n' +
'    s.defer=true;document.body.appendChild(s);})();\n' +
'<\/script>';
    var direct =
'<script>window.DEI_CHATBOT_BASE="' + SITE_BASE + '";<\/script>\n' +
'<script src="' + SITE_BASE + '/assets/js/chat-widget.js" defer><\/script>';
    $('#gtmCode').textContent = gtm;
    $('#directCode').textContent = direct;
    $('#btnCopyGtm').onclick = function () { copy(gtm, 'Kode GTM disalin.'); };
    $('#btnCopyDirect').onclick = function () { copy(direct, 'Kode disalin.'); };
  }
  function copy(text, msg) {
    if (navigator.clipboard) navigator.clipboard.writeText(text).then(function () { toast(msg); }, fallback);
    else fallback();
    function fallback() {
      var ta = document.createElement('textarea'); ta.value = text; document.body.appendChild(ta);
      ta.select(); try { document.execCommand('copy'); toast(msg); } catch (e) { toast('Salin manual.', true); }
      ta.remove();
    }
  }

  /* ====================================================================== *
   *  WHATSAPP CONVERSATIONS (handoff inbox)
   * ====================================================================== */
  var waState = { current: null, timer: null, lastAwaiting: -1, convs: [] };

/* ============================================================================
 *  v1.2.0 WA Claim System — Frontend UI
 *  REPLACES: loadWachat, fetchWaConvs, renderWaConvs, renderWaThread
 *  ADDS: filter bar, claim/release/takeover UI, audit log viewer
 * ============================================================================ */

  // Extend waState (existing) — safe to add properties, existing code still works
  // (waState declared elsewhere; if not, this becomes: var waState = window.waState || {...})
  window.waState = window.waState || {};
  waState.filter = waState.filter || 'all';
  waState.counts = waState.counts || { all: 0, mine: 0, unclaimed: 0, others: 0, takeover_requests: 0, today: 0, attention: 0, unreplied: 0, done: 0, full_bot: 0 };
  waState.replyMode = waState.replyMode || 'ai';   // v1.2.58
  waState.agents = waState.agents || [];
  waState.me = waState.me || '';
  waState.isAdmin = waState.isAdmin || false;
  waState.claimDetails = waState.claimDetails || {}; // number → claim object cache
  waState.currentThreadClaim = null;

  /* ============================================================
   * v1.2.8: web push + PWA subscribe
   * ============================================================ */
  var DEI_VAPID_PUBLIC = 'BCLUf1Mk_6nts_qsCK2Gxw88b2cXTLKZztuo-fZohcrl0oqTh2YIfwd1qVWpb3rXFbC0vropFPzmHtXhzNk6sbg';
  var deiSwReg = null;

  function urlBase64ToUint8Array(base64String) {
    var padding = '='.repeat((4 - base64String.length % 4) % 4);
    var base64 = (base64String + padding).replace(/-/g, '+').replace(/_/g, '/');
    var raw = window.atob(base64);
    var arr = new Uint8Array(raw.length);
    for (var i = 0; i < raw.length; i++) arr[i] = raw.charCodeAt(i);
    return arr;
  }

  function initPushNotif() {
    var btn = document.getElementById('btnNotif');
    if (!btn) return;

    // Cek support
    if (!('serviceWorker' in navigator) || !('PushManager' in window) || !('Notification' in window)) {
      btn.style.display = 'none';
      return;
    }

    // Register service worker
    navigator.serviceWorker.register('./sw.js').then(function (reg) {
      deiSwReg = reg;
      updateNotifButton();
    }).catch(function (err) {
      console.warn('SW register gagal:', err);
    });

    btn.onclick = function () {
      if (Notification.permission === 'denied') {
        toast('Notifikasi diblokir. Aktifkan lewat setting browser.', true);
        return;
      }
      if (!deiSwReg) { toast('Service worker belum siap, coba lagi.', true); return; }

      // Cek sudah subscribe atau belum
      deiSwReg.pushManager.getSubscription().then(function (sub) {
        if (sub) {
          // Sudah aktif → unsubscribe (matikan)
          var endpoint = sub.endpoint;
          sub.unsubscribe().then(function () {
            api('delete_push_subscription', { method: 'POST', body: { endpoint: endpoint } });
            toast('Notifikasi dimatikan.');
            updateNotifButton();
          });
        } else {
          // Belum → minta permission + subscribe
          Notification.requestPermission().then(function (perm) {
            if (perm !== 'granted') { toast('Izin notifikasi ditolak.', true); return; }
            deiSwReg.pushManager.subscribe({
              userVisibleOnly: true,
              applicationServerKey: urlBase64ToUint8Array(DEI_VAPID_PUBLIC)
            }).then(function (sub) {
              api('save_push_subscription', {
                method: 'POST',
                body: { subscription: sub.toJSON(), ua: navigator.userAgent }
              }).then(function (res) {
                if (res.ok) { toast('Notifikasi aktif!'); updateNotifButton(); }
                else toast(res.error || 'Gagal simpan subscription.', true);
              });
            }).catch(function (err) {
              console.error('Subscribe gagal:', err);
              toast('Gagal aktifkan notifikasi.', true);
            });
          });
        }
      });
    };
  }

  function updateNotifButton() {
    var btn = document.getElementById('btnNotif');
    if (!btn || !deiSwReg) return;
    deiSwReg.pushManager.getSubscription().then(function (sub) {
      if (sub && Notification.permission === 'granted') {
        btn.innerHTML = ico('bell',15) + ' Notif Aktif';
        btn.style.opacity = '1';
      } else {
        btn.innerHTML = ico('bell-off',15) + ' Notifikasi';
        btn.style.opacity = '0.7';
      }
    });
  }

  /* ---- Web Conversations (v1.2.45) ---- */
  var webState = { convs: [], current: null, timer: null, stage: '', stageCounts: null };   // v1.2.117: filter-lead-rating

  /* ---- Blast WA (v1.2.47) ---- */
  var blastState = { templates: [], current: null, sending: false };

  function loadBlast() {
    // filter tag dari kontak
    var stageSel = $('#blastStage');
    if (stageSel && stageSel.options.length <= 1) {
      [['','Semua kontak'],['new','Baru'],['warm','Warm'],['hot','Hot'],['active_customer','Pelanggan'],['lost','Lost']].forEach(function(o){
        if (o[0]==='') return;
        var op=document.createElement('option'); op.value=o[0]; op.textContent=o[1]; stageSel.appendChild(op);
      });
    }
    if ($('#blastSource') && !$('#blastSource').dataset.wired) {
      $('#blastSource').dataset.wired='1';
      $('#blastSource').onchange=function(){
        var csv=this.value==='csv';
        $('#blastCsvRow').style.display=csv?'':'none';
        $('#blastStageRow').style.display=csv?'none':'';
      };
    }
    if ($('#blastReloadTpl') && !$('#blastReloadTpl').dataset.wired) {
      $('#blastReloadTpl').dataset.wired='1';
      $('#blastReloadTpl').onclick=fetchBlastTemplates;
    }
    if ($('#blastTemplate') && !$('#blastTemplate').dataset.wired) {
      $('#blastTemplate').dataset.wired='1';
      $('#blastTemplate').onchange=renderBlastTemplate;
    }
    if ($('#blastSendBtn') && !$('#blastSendBtn').dataset.wired) {
      $('#blastSendBtn').dataset.wired='1';
      $('#blastSendBtn').onclick=startBlast;
    }
    if (!blastState.templates.length) fetchBlastTemplates();
    loadBlastHistory();
  }

  function fetchBlastTemplates() {
    var hint=$('#blastTplHint');
    if (hint) hint.textContent='Memuat template dari Meta…';
    var _bch = $('#blastCh') ? $('#blastCh').value : '';   // v1.2.98: multi-nomor
    api('wa_templates', { query: _bch ? '&ch=' + encodeURIComponent(_bch) : '' }).then(function(res){
      if (!res.ok) { if(hint) hint.textContent = res.error || 'Gagal memuat template.'; return; }
      var chs = res.channels || [], cs = $('#blastCh');   // v1.2.98: multi-nomor
      if (cs) {
        $('#blastChRow').style.display = chs.length > 1 ? '' : 'none';
        if (chs.length > 1 && cs.options.length !== chs.length) {
          cs.innerHTML = chs.map(function (c) { return '<option value="' + esc(c.id) + '">' + esc(c.label) + '</option>'; }).join('');
          cs.value = res.ch || 'utama';
        }
        if (!cs.dataset.wired) { cs.dataset.wired = '1'; cs.onchange = fetchBlastTemplates; }
      }
      blastState.templates = (res.templates||[]).filter(function(t){ return (t.status||'').toUpperCase()==='APPROVED'; });
      var sel=$('#blastTemplate');
      sel.innerHTML='<option value="">— Pilih template —</option>';
      blastState.templates.forEach(function(t,i){
        var op=document.createElement('option'); op.value=String(i);
        op.textContent=t.name+'  ('+(t.language||'')+' · '+(t.category||'')+')';
        sel.appendChild(op);
      });
      if (hint) hint.textContent = blastState.templates.length ? (blastState.templates.length+' template approved.') : 'Tidak ada template approved. Buat & submit dulu di Meta.';
    }).catch(function(){ if(hint) hint.textContent='Gagal memuat template.'; });
  }

  function renderBlastTemplate() {
    var i=$('#blastTemplate').value;
    var t=blastState.templates[+i];
    blastState.current=t||null;
    var prev=$('#blastPreview'), vars=$('#blastVars');
    if (!t) { prev.style.display='none'; vars.innerHTML=''; return; }
    prev.style.display='block'; prev.textContent=t.body||'(template tanpa body text)';
    var n=t.var_count||0;
    var h='';
    for (var k=1;k<=n;k++){
      h+='<div class="row"><label class="fl">Variabel {{'+k+'}}</label><input type="text" id="blastVar'+k+'" placeholder="isi untuk {{'+k+'}} — boleh pakai {nama}"></div>';
    }
    vars.innerHTML=h;
  }

  function startBlast() {
    if (blastState.sending) return;
    var t=blastState.current;
    if (!t) { toast('Pilih template dulu.', true); return; }
    var vars=[];
    for (var k=1;k<=(t.var_count||0);k++){ vars.push(($('#blastVar'+k)||{}).value||''); }
    var source=$('#blastSource').value;
    var body={ template_name:t.name, language:t.language||'id', vars:vars, source:source };
    if ($('#blastCh') && $('#blastCh').value) body.ch = $('#blastCh').value;   // v1.2.98: multi-nomor
    if (source==='csv') {
      var raw=$('#blastCsv').value||'';
      var nums=raw.split(/[\s,;]+/).map(function(x){return x.replace(/[^0-9]/g,'');}).filter(function(x){return x.length>=8;});
      if (!nums.length) { toast('Isi nomor dulu.', true); return; }
      body.numbers=nums;
    } else {
      body.stage=$('#blastStage').value;
    }
    if (!confirm('Kirim blast template "'+t.name+'"? Pastikan penerima sudah opt-in.')) return;
    blastState.sending=true; $('#blastSendBtn').disabled=true;
    $('#blastProgress').style.display='block';
    setBlastBar(0,0,0,'Menyiapkan…');
    api('wa_blast_start',{method:'POST',body:body}).then(function(res){
      if (!res.ok) { toast(res.error||'Gagal mulai blast.', true); blastState.sending=false; $('#blastSendBtn').disabled=false; return; }
      runBlastLoop(res.job_id, res.total);
    }).catch(function(){ blastState.sending=false; $('#blastSendBtn').disabled=false; toast('Gagal mulai blast.', true); });
  }

  function runBlastLoop(jobId, total) {
    function step() {
      api('wa_blast_run',{method:'POST',body:{job_id:jobId,size:10}}).then(function(res){
        if (!res.ok) { toast(res.error||'Blast terhenti.', true); blastState.sending=false; $('#blastSendBtn').disabled=false; return; }
        var done=res.sent+res.failed;
        setBlastBar(res.sent, res.failed, total, done+' / '+total+' terkirim ('+res.failed+' gagal)');
        if (res.done) {
          toast('Blast selesai: '+res.sent+' terkirim, '+res.failed+' gagal.');
          blastState.sending=false; $('#blastSendBtn').disabled=false;
          loadBlastHistory();
        } else {
          setTimeout(step, 300);
        }
      }).catch(function(){ blastState.sending=false; $('#blastSendBtn').disabled=false; toast('Blast terputus.', true); });
    }
    step();
  }

  function setBlastBar(sent, failed, total, text) {
    var pct = total ? Math.round((sent+failed)/total*100) : 0;
    var bar=$('#blastBar'); if (bar) bar.style.width=pct+'%';
    var tx=$('#blastProgressText'); if (tx) tx.textContent=text;
  }

  function loadBlastHistory() {
    api('wa_blast_history').then(function(res){
      if (!res.ok) return;
      var el=$('#blastHistory');
      if (!res.blasts || !res.blasts.length) { el.innerHTML='<div style="color:var(--muted);font-size:13px">Belum ada blast.</div>'; return; }
      el.innerHTML=res.blasts.map(function(b){
        var st=b.status==='done'?'<span class="tag" style="background:#dcfce7;color:#14532d;padding:2px 8px;font-size:11px">selesai</span>':'<span class="tag" style="background:#fef9c3;color:#92400e;padding:2px 8px;font-size:11px">jalan</span>';
        return '<div style="padding:10px 0;border-bottom:1px solid var(--line)">'+
          '<div style="display:flex;justify-content:space-between;gap:8px"><b style="font-size:13.5px">'+esc(b.template_name)+'</b>'+st+'</div>'+
          '<div style="font-size:12px;color:var(--muted);margin-top:3px">'+esc(b.created_at)+' · '+b.sent+'/'+b.total+' terkirim'+(b.failed?(' · '+b.failed+' gagal'):'')+'</div>'+
        '</div>';
      }).join('');
    });
  }

  function loadWebchat() {
    var wrap = document.querySelector('#panel-webchat .wachat-wrap');
    if (wrap) wrap.classList.remove('showing-thread');
    if (window.scrollTo) window.scrollTo(0, 0);
    webEnsureStageBar();   // v1.2.117: filter-lead-rating
    fetchWebConvs();
    if ($('#webBackBtn')) $('#webBackBtn').onclick = function () {
      var w = document.querySelector('#panel-webchat .wachat-wrap');
      if (w) w.classList.remove('showing-thread');
    };
    if ($('#webImportBtn') && !$('#webImportBtn').dataset.wired) {
      $('#webImportBtn').dataset.wired = '1';
      $('#webImportBtn').onclick = function () {
        if (!confirm('Impor chat lama (channel web) dari Log jadi percakapan? Dikelompokkan per IP per hari.')) return;
        var btn = $('#webImportBtn');
        function runMigrate(force) {
          btn.disabled = true;
          var q = force ? '&force=1' : '';
          return api('web_conv_migrate', { method: 'POST', query: q }).then(function (res) {
            btn.disabled = false;
            if (res.ok) {
              toast('Impor selesai: ' + res.migrated + ' percakapan.');
              fetchWebConvs();
            } else if ((res.error || '').indexOf('sudah pernah') !== -1) {
              if (confirm('Impor sudah pernah dijalankan. Bangun ULANG (hapus hasil impor lama, buat lagi pakai IP + kota)?')) {
                runMigrate(true);
              }
            } else {
              toast(res.error || 'Gagal impor.', true);
            }
          }).catch(function () { btn.disabled = false; toast('Gagal impor.', true); });
        }
        runMigrate(false);
      };
    }
    if (webState.timer) clearInterval(webState.timer);
    webState.timer = setInterval(function () {
      if (!$('#panel-webchat').classList.contains('active')) return;
      fetchWebConvs(true).then(function () {
        if (webState.current) fetchWebThread(webState.current, true);
      });
    }, 8000);
  }

  // v1.2.117: filter-lead-rating — chip Lead Rating di atas daftar Percakapan Web
  function webEnsureStageBar() {
    var panel = $('#panel-webchat');
    if (!panel) return;
    if (!$('#webStageBar')) {
      var card = panel.querySelector('.card');
      if (!card) return;
      var bar = document.createElement('div');
      bar.id = 'webStageBar';
      bar.className = 'wa-filter-bar';
      bar.style.cssText = 'border:1px solid var(--line);border-radius:12px;margin-bottom:12px';
      bar.innerHTML = '<span style="font-size:12px;color:var(--muted);font-weight:600">Lead Rating:</span>' +
        stageFltKeys(true).map(function (k) {
          return '<button type="button" class="wa-filter-btn" data-wstage="' + k + '">' + esc(k ? stageFltLabel(k) : 'Semua') +
            ' <span class="wa-filter-count" data-wcount="' + (k || 'all') + '">0</span></button>';
        }).join('');
      card.parentNode.insertBefore(bar, card);
      $$('#webStageBar .wa-filter-btn').forEach(function (b) {
        b.onclick = function () { webState.stage = b.dataset.wstage; webStageBarSync(); fetchWebConvs(); };
      });
    }
    webStageBarSync();
  }
  function webStageBarSync() {
    var c = webState.stageCounts || {};
    $$('#webStageBar .wa-filter-btn').forEach(function (b) { b.classList.toggle('active', b.dataset.wstage === (webState.stage || '')); });
    $$('#webStageBar .wa-filter-count').forEach(function (el) {
      var k = el.dataset.wcount, n = c[k] || 0;
      el.textContent = Number(n).toLocaleString('id-ID');
      el.style.display = (n > 0 || k === 'all') ? 'inline-block' : 'none';
    });
  }

  function fetchWebConvs(silent) {
    var list = $('#webConvList');
    if (!silent && list) list.innerHTML = '<div style="padding:16px;color:var(--muted)">Memuat…</div>';
    var q117 = '&per_page=50' + (webState.stage ? '&stage=' + encodeURIComponent(webState.stage) : '');   // v1.2.117
    return api('web_conversations_admin', { query: q117 })
      .then(function (res) {
        if (!res.ok) return;
        webState.convs = res.conversations || [];
        webState.stageCounts = res.stage_counts || null;   // v1.2.117
        if (res.stage !== undefined) webState.stage = res.stage || '';
        webEnsureStageBar();
        renderWebConvs(webState.convs);
      })
      .catch(function () {
        if (!silent && list) list.innerHTML = '<div style="padding:16px;color:var(--err)">Gagal memuat.</div>';
      });
  }

  function renderWebConvs(convs) {
    var list = $('#webConvList');
    if (!list) return;
    if (!convs.length) {
      list.innerHTML = '<div style="padding:24px;color:var(--muted);text-align:center">' +
        (webState.stage ? 'Tidak ada percakapan dengan Lead Rating "' + esc(stageFltLabel(webState.stage)) + '".' : 'Belum ada percakapan web.') + '</div>';   // v1.2.117
      return;
    }
    list.innerHTML = convs.map(function (c) {
      var active = (String(webState.current) === String(c.id)) ? 'background:var(--brand-soft);' : '';
      var t = waConvTimeInfo(c.last_ts || c.created_at);
      var accent = t.today ? 'border-left:3px solid var(--brand);' : 'border-left:3px solid transparent;';
      var timeStyle = t.today
        ? 'font-size:12px;font-weight:600;color:var(--brand);white-space:nowrap'
        : 'font-size:12px;color:var(--muted);white-space:nowrap';
      var timeHtml = t.label ? '<span style="' + timeStyle + '">' + esc(t.label) + '</span>' : '';
      var preview = c.last_message
        ? '<span style="color:var(--ink)">Pengunjung:</span> ' + esc(c.last_message)
        : (c.last_answer ? '<span style="color:var(--muted)">Bot:</span> ' + esc(c.last_answer) : 'Belum ada pesan');
      var count = c.message_count || 0;
      var badge = '<span class="tag" style="background:var(--brand-soft);color:var(--brand);padding:2px 8px;font-size:11px">' + count + ' pesan</span>';
      var mig = c.migrated ? ' <span class="tag" style="background:#e5e7eb;color:#374151;padding:2px 8px;font-size:11px">arsip</span>' : '';
      return '<div class="wa-conv' + (String(webState.current) === String(c.id) ? ' is-open' : '') + '" data-cid="' + esc(c.id) + '" style="' + active + accent + '">' +   // v1.2.134: chat-aktif
        '<div style="display:flex;justify-content:space-between;align-items:baseline;gap:8px">' +
          '<span style="font-weight:600;white-space:nowrap;overflow:hidden;text-overflow:ellipsis">' + esc(c.title || 'Percakapan') + '</span>' + timeHtml +
        '</div>' +
        '<div style="font-size:13px;color:var(--muted);white-space:nowrap;overflow:hidden;text-overflow:ellipsis;margin-top:2px">' + preview + '</div>' +
        '<div style="margin-top:6px">' + badge + mig + webHoldTag(c) + (c.lead_number ? ' ' + contactStageBadgeHtml(c.stage, c.vip, '') : '') + '</div>' +   // v1.2.117
      '</div>';
    }).join('');
    $$('#webConvList .wa-conv').forEach(function (el) {
      el.onclick = function () { selectWebConv(el.dataset.cid); };
    });
  }

  function selectWebConv(convId) {
    webState.current = convId;
    $$('#webConvList .wa-conv').forEach(function (el) { el.classList.toggle('is-open', el.dataset.cid === String(convId)); });   // v1.2.134: chat-aktif
    var wrap = document.querySelector('#panel-webchat .wachat-wrap');
    if (wrap) wrap.classList.add('showing-thread');
    fetchWebThread(convId);
  }

  function fetchWebThread(convId, silent) {
    var head = $('#webThreadHead');
    var body = $('#webThreadBody');
    if (!silent && head) head.innerHTML = '<span style="color:var(--muted)">Memuat…</span>';
    if (!silent && body) body.innerHTML = '<div style="color:var(--muted);margin:auto">Memuat…</div>';
    return api('web_thread_admin', { query: '&conversation_id=' + encodeURIComponent(convId) })
      .then(function (res) {
        if (!res.ok) return;
        var conv = res.conversation || {};
        var msgs = res.messages || [];
        var count = msgs.length;
        var _ae117 = document.activeElement;   // v1.2.117: jangan gambar ulang saat dropdown Lead Rating dibuka
        if (head && !(silent && _ae117 && _ae117.id === 'webStageSelect')) {
          head.innerHTML =
            '<div style="display:flex;align-items:center;gap:10px;width:100%">' +
              '<div style="width:38px;height:38px;border-radius:50%;background:var(--brand-soft);display:flex;align-items:center;justify-content:center;flex-shrink:0;color:var(--brand)">' + ico('monitor-smartphone', 20) + '</div>' +
              '<div style="flex:1;min-width:0">' +
                '<div style="font-weight:600;font-size:15px;white-space:nowrap;overflow:hidden;text-overflow:ellipsis">' + esc(conv.title || 'Percakapan') + '</div>' +
                '<div style="font-size:12px;color:var(--muted)">Pengunjung web &middot; ' + count + ' pesan' + (conv.migrated ? ' &middot; arsip' : '') + webCtxLine(conv) + '</div>' +
              '</div>' +
              (conv.lead_number   // v1.2.117: Lead Rating = kontak bernomor sama (sinkron dengan Kontak & Percakapan WA)
                ? '<div style="display:flex;flex-direction:column;align-items:flex-end;gap:2px;flex-shrink:0"><span style="font-size:11px;color:var(--muted)">Lead Rating</span>' +
                  '<select id="webStageSelect" style="border-radius:6px;padding:2px 4px;font-size:11px;border:1px solid var(--line);width:118px">' + contactStageOptionsHtml(conv.stage || 'new') + '</select></div>'
                : '<span style="font-size:11px;color:var(--muted);flex-shrink:0;max-width:120px;text-align:right">Lead Rating butuh nomor HP pengunjung</span>') +
            '</div>';
          var _wss = $('#webStageSelect');
          if (_wss) _wss.onchange = function () {
            var st = this.value;
            saveContactStage(conv.lead_number, st, st === 'active_customer' ? !!conv.vip : false);
          };
        }
        if (body) {
          var lastDate = '';
          var html = msgs.map(function (m) {
            var h = '';
            var dk = waDateKey(m.ts);
            if (dk && dk !== lastDate) { h += waDateSepHtml(waDateLabel(dk)); lastDate = dk; }
            h += waBubble((m.role === 'agent' && m.by ? m.by + ': ' : '') + (m.content || ''), (m.role === 'user' ? 'in' : m.role === 'agent' ? 'manual' : 'bot'), m.ts);   // v1.2.195: web-balas
            return h;
          }).join('');
          body.innerHTML = html || '<div style="color:var(--muted);margin:auto">Belum ada pesan.</div>';
          body.scrollTop = body.scrollHeight;
        }
        webReplySync(convId, res.web);   // v1.2.195: web-balas
        renderWebConvs(webState.convs);
      })
      .catch(function () {
        if (head) head.innerHTML = '<span style="color:var(--err)">Gagal memuat.</span>';
      });
  }

  /* v1.2.195: web-balas — balas chat web dari dashboard (Claim / Balas / Kembalikan ke bot) */
  function webHoldTag(c) {
    if (c.hold === 'req') return ' <span class="tag" style="background:#fee2e2;color:#991b1b;padding:2px 8px;font-size:11px;font-weight:600">Minta tim</span>';
    if (c.hold === 'agent') return ' <span class="tag" style="background:#dcfce7;color:#14532d;padding:2px 8px;font-size:11px">Dipegang ' + esc(c.agent_name || 'tim') + '</span>';
    return '';
  }
  function webCtxLine(conv) {   // tenant Support: siapa yang bertanya (paket, versi, peran, menu)
    var x = conv && conv.ctx; if (!x) return '';
    var M = { reports: 'Laporan & Log', wachat: 'Percakapan WA', webchat: 'Percakapan Web', blast: 'Blast WA', leads: 'Leads', kontak: 'Kontak', topik: 'Topik & Divisi',
      gc: 'Customer Feedback', tim: 'Tim & Agent', kb: 'Knowledge Base', content: 'Balasan & Tampilan', test: 'Tes Chatbot', widget: 'Widget & API',
      eskalasi: 'Respon & Eskalasi', users: 'Pengguna', profile: 'Profil Saya', install: 'Pemasangan (GTM)', pembaruan: 'Pembaruan' };
    var p = [];
    if (x.tier) p.push('paket ' + x.tier + (x.trial_tier ? ' (' + x.trial_tier + ')' : ''));
    if (x.version) p.push(x.version);
    if (x.role) p.push(ROLE_LABEL[x.role] || x.role);
    if (x.tab) p.push('menu ' + (M[x.tab] || x.tab));
    if (x.wa_provider) p.push('WA ' + x.wa_provider);
    return p.length ? ' &middot; ' + esc(p.join(' · ')) : '';
  }
  function webAgo(sec) {
    sec = Math.max(0, sec | 0);
    if (sec < 60) return 'baru saja';
    if (sec < 3600) return Math.floor(sec / 60) + ' mnt lalu';
    return Math.floor(sec / 3600) + ' jam lalu';
  }
  function webReplyEl() {
    var r = $('#webReply');
    if (r) return r;
    var body = $('#webThreadBody'); if (!body) return null;
    r = document.createElement('div');
    r.id = 'webReply'; r.className = 'web-reply'; r.hidden = true;
    r.innerHTML = '<div class="wr-st" id="webReplySt"></div>' +
      '<div class="wr-in"><textarea id="webReplyInput" rows="1" maxlength="4000" placeholder="Tulis balasan untuk pengunjung…"></textarea>' +
      '<button type="button" class="btn" id="webReplySend">Kirim</button></div>';
    body.parentNode.insertBefore(r, body.nextSibling);
    $('#webReplySend').onclick = webReplySend;
    $('#webReplyInput').addEventListener('keydown', function (e) { if (e.key === 'Enter' && !e.shiftKey) { e.preventDefault(); webReplySend(); } });
    r.addEventListener('click', function (e) {
      var b = e.target.closest('[data-wr]'); if (!b || !webState.current) return;
      var act = b.dataset.wr === 'claim' ? 'web_claim' : 'web_release';
      if (act === 'web_release' && !confirm('Kembalikan percakapan ini ke asisten otomatis?')) return;
      b.disabled = true;
      api(act, { method: 'POST', body: { conversation_id: webState.current } }).then(function (res) {
        b.disabled = false;
        if (!res.ok) { toast(res.error || 'Gagal.', true); return; }
        toast(act === 'web_claim' ? 'Percakapan Anda pegang. Asisten otomatis berhenti menjawab.' : 'Dikembalikan ke asisten otomatis.');
        fetchWebThread(webState.current, true); fetchWebConvs(true);
      }).catch(function () { b.disabled = false; toast('Gagal.', true); });
    });
    return r;
  }
  function webReplySync(convId, st) {
    var r = webReplyEl(); if (!r) return;
    if (!st || st.archived || st.hold === undefined) { r.hidden = true; return; }
    r.hidden = false;
    var now = st.now || Math.floor(Date.now() / 1000), h = '', btn = '';
    if (st.hold === 'agent' && st.mine) {
      h = '<b style="color:#15803d">Anda memegang percakapan ini.</b> Asisten otomatis berhenti menjawab sampai dikembalikan (atau 60 menit tanpa balasan Anda).';
      btn = '<button type="button" class="btn ghost sm" data-wr="release">Kembalikan ke asisten</button>';
    } else if (st.hold === 'agent') {
      h = 'Dipegang <b>' + esc(st.agent_name || st.agent) + '</b> · aktif ' + webAgo(now - (st.agent_last || now)) + '.' + (role === 'wa_agent' ? '' : ' Membalas akan mengambil alih.');
      btn = role === 'wa_agent' ? '' : '<button type="button" class="btn ghost sm" data-wr="release">Kembalikan ke asisten</button>';
    } else if (st.hold === 'req') {
      h = '<b style="color:#b91c1c">Pengunjung minta bicara dengan tim</b> · ' + webAgo(now - (st.req_at || now)) + '. Asisten otomatis berhenti menjawab.';
      btn = '<button type="button" class="btn sm" data-wr="claim">Pegang percakapan</button> <button type="button" class="btn ghost sm" data-wr="release">Kembalikan ke asisten</button>';
    } else {
      h = 'Dijawab asisten otomatis. Membalas di sini akan mengambil alih percakapan.';
      btn = '<button type="button" class="btn ghost sm" data-wr="claim">Pegang percakapan</button>';
    }
    $('#webReplySt').innerHTML = '<span>' + h + '</span><span class="wr-btns">' + btn + '</span>';
    var locked = st.hold === 'agent' && !st.mine && role === 'wa_agent';
    $('#webReplyInput').disabled = locked; $('#webReplySend').disabled = locked;
    $('#webReplyInput').placeholder = locked ? 'Percakapan ini dipegang ' + (st.agent_name || st.agent) + '.' : 'Tulis balasan untuk pengunjung…';
  }
  function webReplySend() {
    var inp = $('#webReplyInput'), b = $('#webReplySend'), t = inp ? inp.value.trim() : '';
    if (!t || !webState.current || b.disabled) return;
    b.disabled = true;
    api('web_reply', { method: 'POST', body: { conversation_id: webState.current, text: t } }).then(function (res) {
      b.disabled = false;
      if (!res.ok) { toast(res.error || 'Gagal mengirim.', true); return; }
      inp.value = '';
      fetchWebThread(webState.current, true); fetchWebConvs(true);
    }).catch(function () { b.disabled = false; toast('Gagal mengirim.', true); });
  }

  function loadWachat() {
    // v1.2.39 fase7: membuka menu "Percakapan WA" harus diperlakukan sama
    // dengan menekan tombol Back di mobile -- balik ke DAFTAR percakapan,
    // bukan nyangkut di thread terakhir yang dibuka (lengkap dengan posisi
    // scroll-nya). Tombol Back sudah menghapus kelas ini; loadWachat()
    // sebelumnya tidak, jadi tampilan tetap menempel di thread.
    var _wrapReset = document.querySelector('.wachat-wrap');
    if (_wrapReset) _wrapReset.classList.remove('showing-thread');
    if (window.scrollTo) window.scrollTo(0, 0);
    // Filter bar (kalau belum di-render)
    ensureFilterBar();
    fetchWaConvs();
    $('#waReplySend').onclick = function () { if (waState.current) sendWaManual(waState.current); };
    waAttachInit();   // v1.2.120: wa-lampiran
    waQuoteInit();   // v1.2.121: wa-balas-kutip
    waCs164Init();   // v1.2.164: cari-simpan
    tk214WaInit();   // v1.2.214: task
    waScrollInit();   // v1.2.123: wa-scroll-stabil
    waQrInit();   // v1.2.122: template-balasan
    waSchedInit();   // v1.2.153: jadwal-kirim  (v1.2.154: hp-firm)
    if ($('#waSearch')) $('#waSearch').oninput = function () { waState.q = this.value; waGlobFetch164(this.value); renderWaConvs(); clearTimeout(waState.qT211); waState.qT211 = setTimeout(function () { waState.listLim211 = 500; fetchWaConvs(); }, 400); /* v1.2.211: list-db */ };   // v1.2.164: cari-simpan   // v1.2.125: wa-tampilan-sama
    initPushNotif();  // v1.2.8: init push notif saat buka menu WA
    // v1.2.7: back button — mobile balik ke list
    if ($('#waBackBtn')) $('#waBackBtn').onclick = function () {
      var wrap = document.querySelector('.wachat-wrap');
      if (wrap) wrap.classList.remove('showing-thread');
    };
    $('#waReplyInput').addEventListener('keydown', function (e) {
      if (e.key === 'Enter' && waState.current && !$('#waReplySend').disabled) sendWaManual(waState.current);
    });
    if (waState.timer) clearInterval(waState.timer);
    waState.timer = setInterval(function () {
      if (!$('#panel-wachat').classList.contains('active')) return;
      // v1.2.39 fase2d: tunggu fetchWaConvs selesai dulu (waState.convs
      // terisi data baru) baru gambar ulang thread -- kalau paralel,
      // thread bisa baca data lama dan tag/dropdown kelihatan balik ke
      // nilai sebelumnya beberapa detik setelah diubah, tanpa ada yang
      // menyentuh dropdown-nya lagi.
      fetchWaConvs(true).then(function () {
        if (waState.current) fetchWaThread(waState.current, true);
      });
    }, 6000);
  }

  function ensureFilterBar() {
    if ($('#waFilterBar')) return; // sudah render
    var bar = document.createElement('div');
    bar.id = 'waFilterBar';
    bar.className = 'wa-filter-bar';
    var isManual = waState.replyMode === 'manual';   // v1.2.58
    bar.innerHTML =
      '<div class="wa-chips">' +   // v1.2.142: mobile-rapi — chip status satu baris geser di mobile
      '<button class="wa-filter-btn active" data-filter="all">All <span class="wa-filter-count" data-count="all">0</span></button>' +
      '<button class="wa-filter-btn" data-filter="unreplied">Belum Dibalas <span class="wa-filter-count" data-count="unreplied">0</span></button>' +
      (isManual ? '' : '<button class="wa-filter-btn" data-filter="full_bot">Full Bot <span class="wa-filter-count" data-count="full_bot">0</span></button>') +
      '<button class="wa-filter-btn" data-filter="done">Selesai <span class="wa-filter-count" data-count="done">0</span></button>' +
      '<button class="wa-filter-btn" data-filter="today">Hari Ini <span class="wa-filter-count" data-count="today">0</span></button>' +
      '<button class="wa-filter-btn" data-filter="attention">Perlu Perhatian <span class="wa-filter-count" data-count="attention">0</span></button>' +
      '<button class="wa-filter-btn" data-filter="mine">Punya Saya <span class="wa-filter-count" data-count="mine">0</span></button>' +
      '<button class="wa-filter-btn" data-filter="unclaimed">Unclaimed <span class="wa-filter-count" data-count="unclaimed">0</span></button>' +
      '<button class="wa-filter-btn" data-filter="others">Punya Agent Lain <span class="wa-filter-count" data-count="others">0</span></button>' +
      '<button class="wa-filter-btn" data-filter="takeover_requests">Take-over Requests <span class="wa-filter-count" data-count="takeover_requests">0</span></button>' +
      '<button class="wa-filter-btn" data-filter="archived" style="display:none" title="Chat yang diarsipkan di WhatsApp — tidak tampil di daftar lain">' + ico('archive',13) + ' Arsip <span class="wa-filter-count" data-count="archived">0</span></button>' +   // v1.2.213: wa-arsip
      '</div>' +
      '<div class="wa-fbar2' + (tfOn() ? ' tf-on' : '') + '">' +   // v1.2.124: wa-layout-penuh — dropdown Nomor & Lead Rating di baris sendiri, lebih mencolok
      ((waState.channels || []).length > 1 ? '<label class="wa-dd' + (waState.ch ? ' is-on' : '') + '" title="Saring per nomor WhatsApp">' + ico('phone',14) + '<select class="wa-ch-filter"><option value="">Semua nomor</option>' +   // v1.2.98: multi-nomor
        waState.channels.map(function (c) { return '<option value="' + esc(c.id) + '"' + (waState.ch === c.id ? ' selected' : '') + '>' + esc(c.label) + '</option>'; }).join('') + '</select><span class="wa-dd-chev">' + ico('chevron-down',14) + '</span></label>' : '') +
      '<label class="wa-dd' + (waState.stage ? ' is-on' : '') + '" title="Saring per Lead Rating">' + ico('tag',14) + '<select class="wa-stage-filter' + (waState.stage ? ' is-active' : '') + '">' +   // v1.2.117: filter-lead-rating
        stageFltOptionsHtml(waState.stage || '', waState.stageCounts) + '</select><span class="wa-dd-chev">' + ico('chevron-down',14) + '</span></label>' +
      tfFilterBarHtml() +   // v1.2.138: filter-topik
      '<span class="wa-sp"></span>' +
      (waState.isAdmin === false ? '' : '<button class="wa-filter-btn wa-export-contacts" title="Unduh semua kontak WA (.vcf)">' + ico('download',14) + '<span class="wa-lbl-t"> Ekspor Kontak</span></button>') +
      (waState.isAdmin ? '<button class="wa-filter-btn wa-reslog-toggle" title="Log chat yang ditandai Selesai manual">' + ico('check-circle-2',14) + '<span class="wa-lbl-t"> Log Selesai</span></button>' : '') +   // v1.2.131: log-selesai
      (waState.isAdmin === false ? '' : '<button class="wa-filter-btn wa-audit-toggle" title="Lihat audit log">' + ico('clipboard-list',14) + '<span class="wa-lbl-t"> Audit</span></button>') +
      '</div>';
    // Insert BEFORE .wachat-wrap
    var wrap = $('#panel-wachat .wachat-wrap');
    // v1.2.58: kartu ringkasan flag (klik = filter) + penanda mode Manual
    var cards = document.createElement('div');
    cards.id = 'waFlagCards';
    var kartu = function (f, cls, icon, label) {
      return '<button type="button" class="wa-flag-card ' + cls + '" data-filter="' + f + '">' +
        '<div class="n" data-flagn="' + f + '">0</div><div class="l">' + ico(icon, 13) + ' ' + label + '</div></button>';
    };
    var _as204 = waState.aiSched || {}, _asT204 = String(_as204.hours || '').replace('-', '–');   // v1.2.204: jam-ai
    var _asOff204 = isManual && _as204.enabled && !_as204.active && !_as204.base_manual;
    cards.innerHTML =
      (isManual ? '<div class="wa-mode-pill">' + ico('user-round', 13) + (_asOff204 ? ' AI aktif ' + _asT204 + ' — sekarang di luar jam AI, semua chat dibalas agent' : ' Mode Manual — AI nonaktif, semua chat dibalas agent') + '</div>'
        : (_as204.enabled ? '<div class="wa-mode-pill" style="background:#dcfce7;color:#166534">' + ico('bot', 13) + ' Jam AI ' + _asT204 + ' — sekarang AI yang membalas</div>' : '')) +
      '<div class="wa-flag-cards" style="' + (isManual ? 'grid-template-columns:repeat(2,minmax(0,1fr))' : '') + '">' +
        kartu('unreplied', 'unreplied', 'clock-3', 'belum dibalas') +
        (isManual ? '' : kartu('full_bot', 'fullbot', 'bot', 'full bot')) +
        kartu('done', 'done', 'check-circle-2', 'selesai') +   // v1.2.101
      '</div>';
    var _ph125 = $('#panel-wachat .ph');   // v1.2.125: wa-tampilan-sama — ringkasan sebaris judul
    if (_ph125) _ph125.appendChild(cards); else wrap.parentNode.insertBefore(cards, wrap);
    $$('#waFlagCards .wa-flag-card').forEach(function (c) {
      c.onclick = function () {
        var f = (waState.filter === c.dataset.filter) ? 'all' : c.dataset.filter;
        waState.filter = f;
        fetchWaConvs();
      };
    });
    wrap.parentNode.insertBefore(bar, wrap);
    // Audit log container
    var auditBox = document.createElement('div');
    auditBox.id = 'waAuditBox';
    auditBox.className = 'wa-audit-box';
    auditBox.style.display = 'none';
    wrap.parentNode.insertBefore(auditBox, wrap);
    // v1.2.131: log-selesai: kotak Log Selesai — dipakai ulang saat bar dibangun ulang (isi & status buka tetap)
    var resLogBox = document.getElementById('waResLogBox');
    if (!resLogBox) { resLogBox = document.createElement('div'); resLogBox.id = 'waResLogBox'; resLogBox.className = 'wa-audit-box wa-reslog-box'; resLogBox.style.display = 'none'; }
    wrap.parentNode.insertBefore(resLogBox, wrap);
    // Event listeners
    // v1.2.58: bar dibangun ulang tiap muat — tandai tombol sesuai filter aktif
    $$('#waFilterBar .wa-filter-btn[data-filter]').forEach(function (b) { b.classList.toggle('active', b.dataset.filter === (waState.filter || 'all')); });
    $$('#waFlagCards .wa-flag-card').forEach(function (c) { c.classList.toggle('active', c.dataset.filter === waState.filter); });
    var _chSel = $('#waFilterBar .wa-ch-filter');   // v1.2.98: multi-nomor
    if (_chSel) _chSel.onchange = function () { waState.ch = this.value; this.parentNode.classList.toggle('is-on', !!this.value); fetchWaConvs(); };
    var _stSel = $('#waFilterBar .wa-stage-filter');   // v1.2.117: filter-lead-rating
    if (_stSel) _stSel.onchange = function () { waState.stage = this.value; this.parentNode.classList.toggle('is-on', !!this.value); fetchWaConvs(); };
    tfBindFilterBar();   // v1.2.138: filter-topik
    $$('#waFilterBar .wa-filter-btn').forEach(function (btn) {
      if (btn.classList.contains('wa-audit-toggle')) {
        btn.onclick = toggleAuditLog;
      } else if (btn.classList.contains('wa-reslog-toggle')) {   // v1.2.131: log-selesai
        btn.onclick = toggleResLog;
      } else if (btn.classList.contains('wa-export-contacts')) {   // v1.2.19
        btn.onclick = exportWaContacts;
      } else {
        btn.onclick = function () {
          waState.filter = btn.dataset.filter;
          $$('#waFilterBar .wa-filter-btn').forEach(function (b) { b.classList.remove('active'); });
          btn.classList.add('active');
          fetchWaConvs();
        };
      }
    });
  }

  function fetchWaConvs(silent) {
    var query = '&filter=' + encodeURIComponent(waState.filter || 'all');
    if (waState.ch) query += '&ch=' + encodeURIComponent(waState.ch);   // v1.2.98: multi-nomor
    if (waState.stage) query += '&stage=' + encodeURIComponent(waState.stage);   // v1.2.117: filter-lead-rating
    query += tfQuery();   // v1.2.138: filter-topik
    if (waState.lastQ140 !== query) { waState.lastQ140 = query; waState.scrollCur140 = true; waState.listLim211 = 500; }   // v1.2.141: filter-chat-terpilih
    var _q211 = String(waState.q || '').trim();   // v1.2.211: list-db — daftar per halaman (500), cari nama/nomor di server
    query += '&lim=' + (waState.listLim211 || 500) + (_q211 ? '&q=' + encodeURIComponent(_q211) : '');
    // v1.2.39: return promise-nya supaya pemanggil bisa .then() menunggu
    // waState.convs benar-benar terisi data terbaru sebelum lanjut.
    return api('wa_conversations_v2', { query: query }).then(function (res) {
      if (!res || !res.ok) {
        // Fallback to old endpoint jika v2 error (backward compat)
        if (window.console) console.warn('[v1.2.148] wa_conversations_v2 gagal, pakai daftar lama:', res);
        if (!waState.legacyWarn148 && !(res && /autentikasi/i.test(res.error || ''))) {   // v1.2.148: selesai-tanpa-flag
          waState.legacyWarn148 = true;
          toast('Daftar chat dimuat dengan mode cadangan (' + ((res && res.error) || 'server tidak merespons') + '). Status Selesai/Belum dibalas tidak tampil — muat ulang halaman.', true);
        }
        fetchWaConvsLegacy(silent);
        return;
      }
      waState.legacyWarn148 = false; waState.res148 = {};   // v1.2.148: selesai-tanpa-flag
      waState.convs = res.conversations || [];
      waState.listTotal211 = (typeof res.total === 'number') ? res.total : waState.convs.length;   // v1.2.211: list-db
      waState.convCache = waState.convCache || {};   // v1.2.141: filter-chat-terpilih — ingat data chat walau keluar dari filter
      waState.convs.forEach(function (c) { waState.convCache[String(c.number)] = c; });
      waState.counts = res.counts || waState.counts;
      waState.me = res.me || '';
      waState.isAdmin = !!res.is_admin;
      waState.replyMode = res.reply_mode || 'ai';   // v1.2.58
      waState.aiSched = res.ai_sched || null;   // v1.2.204: jam-ai
      waState.agents = res.agents || [];
      waState.schedCounts = res.sched || {};   // v1.2.153: jadwal-kirim
      waState.channels = res.channels || [];   // v1.2.98: multi-nomor
      if (waState.ch && !waState.channels.some(function (c) { return c.id === waState.ch; })) waState.ch = '';
      waState.stageCounts = res.stage_counts || null;   // v1.2.117: filter-lead-rating
      if (res.stage !== undefined) waState.stage = res.stage || '';
      tfFromList(res);   // v1.2.138: filter-topik
      // v1.2.117: jangan bangun ulang bar saat dropdown di dalamnya sedang dibuka (polling 6 dtk)
      var _ae117 = document.activeElement;
      var _selOpen117 = !!(_ae117 && _ae117.tagName === 'SELECT' && _ae117.closest && _ae117.closest('#waFilterBar'));
      if (!_selOpen117) {
      // Rebuild filter bar setelah tahu role user (hide Audit btn untuk non-admin)
      var oldBar = document.getElementById('waFilterBar');
      if (oldBar) oldBar.remove();
      var oldCards = document.getElementById('waFlagCards');   // v1.2.58
      if (oldCards) oldCards.remove();
      var oldAuditBox = document.getElementById('waAuditBox');
      if (oldAuditBox) oldAuditBox.remove();
      ensureFilterBar();
      }
      // Cache claim per number
      var _curCl140 = waState.current ? waState.claimDetails[waState.current] : undefined;   // v1.2.141: filter-chat-terpilih
      waState.claimDetails = {};
      waState.convs.forEach(function (c) {
        if (c.claim) waState.claimDetails[c.number] = c.claim;
      });
      if (waState.current && _curCl140 && !waConvInList140(waState.current)) waState.claimDetails[waState.current] = _curCl140;   // v1.2.141: filter-chat-terpilih
      updateFilterCounts();
      renderWaConvs();
      // Beep detection
      var awaiting = waState.convs.filter(function (c) { return c.awaiting || c.status === 'takeover_requested'; }).length;
      if (silent && waState.lastAwaiting >= 0 && awaiting > waState.lastAwaiting) playBeep();
      waState.lastAwaiting = awaiting;
      // Update sidebar badge
      updateSidebarBadge(res.counts);
      // Refresh audit log kalau sedang open
      if ($('#waAuditBox') && $('#waAuditBox').style.display !== 'none') {
        refreshAuditLog();
      }
    });
  }

  function fetchWaConvsLegacy(silent) {
    api('wa_conversations').then(function (res) {
      if (!res || !res.ok) {
        $('#waConvList').innerHTML = '<div style="padding:16px;color:#b91c1c;font-size:13px">Gagal memuat: ' + esc((res && res.error) || 'tidak diketahui') + '</div>';
        return;
      }
      waState.convs = res.conversations || [];
      if (!waState.isAdmin && user && ['super_admin', 'admin', 'supervisor'].indexOf(user.role) > -1) waState.isAdmin = true;   // v1.2.148: selesai-tanpa-flag
      waState.convs.forEach(function (c) {   // v1.2.148: chat yang baru ditandai Selesai tetap tampil selesai sampai ada pesan baru
        var r = (waState.res148 || {})[String(c.number)];
        if (r && (r === true || String(c.last_ts || '') <= String(r))) { c.flag = 'done'; c.flag_note = 'Ditandai selesai'; c.needs_attention = false; c.awaiting = false; }
      });
      renderWaConvs();
      var awaiting = waState.convs.filter(function (c) { return c.awaiting; }).length;
      if (silent && waState.lastAwaiting >= 0 && awaiting > waState.lastAwaiting) playBeep();
      waState.lastAwaiting = awaiting;
    });
  }

  function updateFilterCounts() {
    var c = waState.counts || {};
    var _ab213 = $('#waFilterBar .wa-filter-btn[data-filter="archived"]');   // v1.2.213: wa-arsip — chip Arsip hanya tampil bila ada
    if (_ab213) _ab213.style.display = ((c.archived || 0) > 0 || waState.filter === 'archived') ? '' : 'none';
    ['all', 'mine', 'unclaimed', 'others', 'takeover_requests', 'today', 'attention', 'unreplied', 'done', 'full_bot', 'archived'].forEach(function (f) {
      var el = $('#waFilterBar .wa-filter-count[data-count="' + f + '"]');
      if (el) {
        el.textContent = c[f] || 0;
        el.style.display = (c[f] > 0 || f === 'all') ? 'inline-block' : 'none';
      }
      var kn = $('#waFlagCards [data-flagn="' + f + '"]');   // v1.2.58
      if (kn) {
        kn.textContent = c[f] || 0;
        kn.parentNode.classList.toggle('is-zero', !(c[f] > 0));
      }
    });
  }

  function updateSidebarBadge(counts) {
    var tabBtn = document.querySelector('[data-tab="wachat"]');
    if (!tabBtn) return;
    var badge = tabBtn.querySelector('.wa-sidebar-badge');
    // v1.2.58: mode Manual -> lencana = chat yang belum dibalas
    var pending = (waState.replyMode === 'manual')
      ? ((counts.unreplied || 0) + (counts.takeover_requests || 0))
      : ((counts.unclaimed || 0) + (counts.takeover_requests || 0));
    if (pending > 0) {
      if (!badge) {
        badge = document.createElement('span');
        badge.className = 'wa-sidebar-badge';
        tabBtn.appendChild(badge);
      }
      badge.textContent = pending;
    } else if (badge) {
      badge.remove();
    }
  }

  /* ---- v1.2.16: label waktu untuk daftar percakapan ------------------- */
  // Kembalikan { label, today } untuk ditampilkan di sidebar.
  //   hari ini -> "14:23" (today=true)  |  kemarin -> "Kemarin"  |  lama -> "16 Jul"
  function waConvTimeInfo(ts) {
    var key = waDateKey(ts);
    if (!key) return { label: '', today: false };
    var p = key.split('-');
    if (p.length !== 3) return { label: '', today: false };

    var d = new Date(+p[0], +p[1] - 1, +p[2]);
    if (isNaN(d.getTime())) return { label: '', today: false };
    var today = new Date();
    today.setHours(0, 0, 0, 0);
    var diffHari = Math.round((today.getTime() - d.getTime()) / 86400000);

    if (diffHari === 0) {
      var jam = String(ts).split(' ')[1] || '';
      return { label: jam.slice(0, 5), today: true };   // "14:23"
    }
    if (diffHari === 1) return { label: 'Kemarin', today: false };

    var bulanPendek = ['Jan','Feb','Mar','Apr','Mei','Jun','Jul','Agu','Sep','Okt','Nov','Des'];
    var lbl = d.getDate() + ' ' + bulanPendek[d.getMonth()];
    if (d.getFullYear() !== new Date().getFullYear()) lbl += ' ' + d.getFullYear();
    return { label: lbl, today: false };
  }
  /* ---- v1.2.19: kontak WA — ekspor & koreksi nama --------------------- */
  // Unduhan dibangun di browser dari respons JSON, supaya token tidak pernah
  // muncul di URL (kalau pakai tautan langsung, token ikut tercatat di riwayat).
  /* v1.2.105: riwayat-wa-waha — riwayat chat sebelum nomor terhubung (ditarik dari WAHA seperti WhatsApp Web) */
  var _ws = { t: null, ch: '' };
  function wsBody(x) { x.op = 'history'; x.ch = _fonc.ch || 'utama'; return x; }
  function wsFmtTime(sec) { if (!sec) return ''; var d = new Date((sec + 7 * 3600) * 1000).toISOString(); return d.slice(8, 10) + '/' + d.slice(5, 7) + ' ' + d.slice(11, 16); }
  function wsShow(on) {
    var box = $('#fonc_hist'); if (!box) return;
    if (!on || _fonc.action !== 'waha_conn') { box.classList.add('hide'); clearTimeout(_ws.t); return; }
    box.classList.remove('hide');
    if (_ws.ch !== (_fonc.ch || 'utama') || !box.dataset.loaded) { _ws.ch = _fonc.ch || 'utama'; box.dataset.loaded = '1'; wsLoad('get'); }
  }
  function wsLoad(what, extra) {
    clearTimeout(_ws.t);
    return api('waha_conn', { method: 'POST', body: wsBody(Object.assign({ do: what }, extra || {})) }).then(function (r) {
      if (!r || !r.ok) { wsRender(null, null, (r && r.error) || 'Gagal membaca status riwayat.'); return; }
      wsRender(r.history, r.stored);
      var h = r.history;
      if (h && (h.st === 'running' || (h.st === 'pending' && h.due - Date.now() / 1000 < 120))) {
        _ws.t = setTimeout(function () { if (!$('#fonc_hist').classList.contains('hide')) wsLoad('run'); }, h.st === 'running' ? 4000 : 15000);
      }
    }).catch(function () { wsRender(null, null, 'Koneksi bermasalah.'); });
  }
  function wsRender(h, stored, err) {
    var box = $('#fonc_hist'); if (!box) return;
    var st = stored || { nums: 0, msgs: 0 };
    var btn = function (label, cls) { return '<button class="btn ' + (cls || 'ghost') + ' sm" type="button" id="ws_go">' + label + '</button>'; };
    var line = '', act = '', note = '';
    if (err) { line = esc(err); act = btn('Coba lagi'); }
    else if (!h) {
      line = st.msgs ? 'Tersimpan <b>' + st.msgs + '</b> pesan dari <b>' + st.nums + '</b> kontak.' : 'Riwayat chat sebelum terhubung belum ditarik.';
      act = btn(st.msgs ? 'Tarik ulang' : 'Tarik riwayat chat', st.msgs ? 'ghost' : '');
    } else if (h.st === 'pending') {
      line = 'Menunggu riwayat dikirim HP ke WhatsApp… penarikan mulai ' + (h.due > Date.now() / 1000 ? 'sekitar ' + wsFmtTime(h.due) : 'sebentar lagi') + '.';
    } else if (h.st === 'running') {
      line = (h.phase === 'chats' ? 'Membaca daftar chat…' : 'Menarik riwayat: ' + h.done_chats + ' / ' + h.chats + ' chat') + ' · <b>' + h.msgs + '</b> pesan baru' + (h.passes > 1 ? ' <span class="help" style="margin:0">(putaran ' + h.pass + '/' + h.passes + ')</span>' : '');
      line += '<div style="height:6px;background:var(--line);border-radius:6px;margin-top:6px;overflow:hidden"><div style="height:100%;width:' + h.pct + '%;background:var(--brand);transition:width .4s"></div></div>';
    } else if (h.st === 'error') {
      line = '<span style="color:#b91c1c">' + ico('triangle-alert', 13) + ' ' + esc(h.err || 'Penarikan riwayat gagal.') + '</span>';
      act = btn('Coba lagi');
      note = 'Bila WAHA meminta store diaktifkan: Super Admin klik <b>Pasang webhook otomatis</b>, lalu Putuskan dan scan ulang supaya HP mengirim riwayat.';
    } else {
      line = ico('check-circle-2', 13) + ' Tersimpan <b>' + st.msgs + '</b> pesan dari <b>' + st.nums + '</b> kontak' + (h.finished ? ' · ditarik ' + esc(wsFmtTime(h.finished)) : '') + '.';
      if (h.pass < h.passes) line += ' <span class="help" style="margin:0">Pengecekan lanjutan otomatis ' + esc(wsFmtTime(h.due)) + ' (riwayat dari HP bisa datang bertahap).</span>';
      act = btn('Tarik ulang');
    }
    box.innerHTML = '<div style="display:flex;gap:10px;align-items:flex-start;justify-content:space-between;flex-wrap:wrap">' +
        '<div style="flex:1;min-width:220px"><b style="font-size:13px">' + ico('clock-3', 14) + ' Riwayat chat WhatsApp</b><div style="font-size:13px;margin-top:4px">' + line + '</div></div>' + act + '</div>' +
      '<div class="help" style="margin-top:6px">' + (note || 'Seperti WhatsApp Web: HP mengirim riwayat chat saat nomor ditautkan (biasanya beberapa bulan terakhir, tergantung HP). Riwayat tampil di Percakapan WA di atas pesan baru, hanya untuk dibaca — tidak dikirim ulang, tidak memakai kuota, tidak masuk laporan. Nomor yang sudah lama tersambung hanya punya riwayat sejak ditautkan; untuk riwayat lebih lama, Putuskan lalu scan ulang (bot berhenti selama belum tersambung).') + '</div>';
    var g = $('#ws_go');
    if (g) g.onclick = function () { g.disabled = true; wsLoad('start'); };
  }
  function wsStartScan() { wsLoad('start', { reason: 'scan' }); }
  // Riwayat di atas pesan live pada thread
  function wiThreadHtml(res) {
    var im = res.history;
    if (!im || !im.msgs || !im.msgs.length) return '';
    var more = im.total > im.msgs.length;
    var h = '<div style="display:flex;justify-content:center;margin:8px 0 4px"><span style="background:#fef3c7;color:#92400e;font-size:12px;padding:5px 12px;border-radius:12px;text-align:center">' +
      ico('clock-3', 12) + ' Riwayat dari WhatsApp sebelum terhubung · ' + im.total + ' pesan' +
      (more ? ' · <a href="#" id="wiShowAll">tampilkan ' + (im.total > 5000 ? '5.000 terakhir' : 'semua') + '</a> (kini ' + im.msgs.length + ' terakhir)' : '') + '</span></div>';
    var last = '';
    im.msgs.forEach(function (m) {
      var dk = waDateKey(m.ts);
      if (dk && dk !== last) { h += waDateSepHtml(waDateLabel(dk)); last = dk; }
      var st = m.d === 'in' ? 'align-self:flex-start;background:#fff;border:1px dashed var(--line);color:var(--ink)'
        : 'align-self:flex-end;background:#f1f5f9;border:1px dashed #cbd5e1;color:#334155';
      h += '<div style="max-width:78%;' + st + ';padding:8px 12px;border-radius:12px;margin:4px 0;white-space:pre-wrap;font-size:14px;line-height:1.45">' + esc(m.t) +
        '<div style="font-size:10px;opacity:.65;margin-top:4px">' + esc((m.ts || '').slice(11, 16)) + (m.d === 'in' ? '' : ' · bisnis') + ' · riwayat</div></div>';
    });
    h += '<div style="display:flex;align-items:center;gap:8px;margin:12px 0 4px;color:var(--muted);font-size:11px"><span style="flex:1;border-top:1px dashed var(--line)"></span>akhir riwayat · pesan di bawah tercatat dashboard<span style="flex:1;border-top:1px dashed var(--line)"></span></div>';
    return h;
  }
  function wiThreadBind(res) {
    var a = document.getElementById('wiShowAll');
    if (a) a.onclick = function (ev) { ev.preventDefault(); waState.wiAll = waState.wiAll || {}; waState.wiAll[res.number] = true; fetchWaThread(res.number); };
  }

  function exportWaContacts() {
    api('export_contacts').then(function (res) {
      if (!res || !res.ok) { toast((res && res.error) || 'Gagal mengekspor.', true); return; }
      if (!res.count) { toast('Belum ada kontak untuk diekspor.', true); return; }
      try {
        var blob = new Blob([res.vcf], { type: 'text/vcard;charset=utf-8' });
        var url = URL.createObjectURL(blob);
        var a = document.createElement('a');
        var d = new Date();
        var stamp = d.getFullYear() + String(d.getMonth() + 1).padStart(2, '0') + String(d.getDate()).padStart(2, '0');
        a.href = url;
        a.download = 'kontak-wa-' + stamp + '.vcf';
        document.body.appendChild(a);
        a.click();
        document.body.removeChild(a);
        setTimeout(function () { URL.revokeObjectURL(url); }, 1000);
        toast(res.count + ' kontak diunduh. Buka file .vcf di HP untuk mengimpor.');
      } catch (e) {
        toast('Gagal membuat file unduhan.', true);
      }
    });
  }
  // Koreksi nama: kosongkan untuk kembali memakai nama profil WhatsApp.
  function editWaContactName(num) {
    var conv = (waState.convs || []).filter(function (c) { return c.number === num; })[0];
    var sekarang = (conv && conv.name) || '';
    var baru = prompt('Nama untuk +' + num + '\n(kosongkan untuk memakai nama profil WhatsApp)', sekarang);
    if (baru === null) return;
    api('save_contact', { method: 'POST', body: { number: num, name: baru.trim() } }).then(function (r) {
      if (r && r.ok) { toast('Nama disimpan.'); fetchWaConvs(); if (waState.current === num) fetchWaThread(num); }
      else toast((r && r.error) || 'Gagal menyimpan.', true);
    });
  }
  var waFilterLabelExtra = { today: 'Hari Ini', attention: 'Perlu Perhatian', unreplied: 'Belum Dibalas', done: 'Selesai', full_bot: 'Full Bot' };  // v1.2.17 + v1.2.58
  // v1.2.58: lencana flag chat
  function waDurasi(sec) {
    sec = +sec || 0;
    if (sec < 60) return '<1 mnt';
    if (sec < 3600) return Math.floor(sec / 60) + ' mnt';
    if (sec < 86400) return Math.floor(sec / 3600) + ' jam';
    return Math.floor(sec / 86400) + ' hari';
  }
  function waFlagBadgeHtml(c) {
    var h = '';
    if (c.flag === 'unreplied') {
      h += ' <span class="tag" style="background:#fee2e2;color:#b91c1c">' + ico('clock-3',12) + ' Belum dibalas' + (c.waiting_sec ? ' · ' + waDurasi(c.waiting_sec) : '') + '</span>';
    } else if (c.flag === 'done') {
      h += ' <span class="tag" style="background:#d1fae5;color:#065f46" title="' + esc(c.flag_note || '') + '">' + ico('check-circle-2',12) + ' Selesai</span>';
    }
    if (c.full_bot) h += ' <span class="tag" style="background:#dbeafe;color:#1e40af" title="Belum pernah dibalas agent">' + ico('bot',12) + ' Full bot</span>';
    return h;
  }
  // v1.2.141: filter-chat-terpilih
  function waConvInList140(num) { return (waState.convs || []).some(function (c) { return String(c.number) === String(num); }); }
  function waConvOf140(num) {
    return (waState.convs || []).filter(function (c) { return String(c.number) === String(num); })[0] || (waState.convCache || {})[String(num)] || null;
  }
  function renderWaConvs() {
    if (waState.savedView && $('#waConvList')) { waSavedRender164(); return; }   // v1.2.164: cari-simpan
    var _pin140 = null;
    if (waState.current && !waConvInList140(waState.current) && !String(waState.q || '').trim()) {
      _pin140 = (waState.convCache || {})[String(waState.current)] || { number: waState.current };
    }
    var _all140 = waState.convs;
    if (_pin140) waState.convs = [_pin140].concat(_all140);
    try { renderWaConvsInner(_pin140); } finally { waState.convs = _all140; }
    if (waState.scrollCur140) {
      waState.scrollCur140 = false;
      var _el140 = document.querySelector('#waConvList .wa-conv.is-open');
      var _ls140 = $('#waConvList');
      if (_el140 && _ls140) _ls140.scrollTop = Math.max(0, _el140.offsetTop - _ls140.offsetTop - 8);
      else if (_ls140) _ls140.scrollTop = 0;
    }
  }
  function renderWaConvsInner(_pin140) {
    if (!waState.convs.length) {
      var msg = 'Belum ada percakapan';
      if (waState.filter && waState.filter !== 'all') {
        var labels = { mine: 'Punya Saya', unclaimed: 'Unclaimed', others: 'Punya Agent Lain', takeover_requests: 'Take-over Requests' };
        msg = 'Tidak ada di filter "' + (labels[waState.filter] || waFilterLabelExtra[waState.filter] || waState.filter) + '"';
      }
      if (waState.stage) msg = ((waState.filter && waState.filter !== 'all') ? msg : 'Tidak ada percakapan') + ' dengan Lead Rating "' + stageFltLabel(waState.stage) + '"';   // v1.2.117
      if (tfOn() && (waState.tfF || waState.tfDF)) msg = ((waState.filter && waState.filter !== 'all') || waState.stage ? msg : 'Tidak ada percakapan') + tfEmptySuffix();   // v1.2.138: filter-topik
      $('#waConvList').innerHTML = '<div style="padding:16px;color:var(--muted)">' + msg + '</div>';
      return;
    }
    var _q125 = String(waState.q || '').trim().toLowerCase();   // v1.2.125: wa-tampilan-sama — kotak cari
    var _list125 = waState.convs;
    if (_q125) {
      var _qn125 = _q125.replace(/[^0-9]/g, ''); if (_qn125.charAt(0) === '0') _qn125 = '62' + _qn125.slice(1);
      _list125 = waState.convs.filter(function (c) {
        var hay = (String(c.name || '') + ' ' + String(c.last_q || c.last_text || '')).toLowerCase();
        return hay.indexOf(_q125) > -1 || (_qn125.length >= 3 && String(c.number).indexOf(_qn125) > -1);
      });
      if (!_list125.length) { $('#waConvList').innerHTML = '<div style="padding:16px;color:var(--muted)">Tidak ada kontak yang cocok dengan "' + esc(waState.q.trim()) + '"</div>' + waGlobHtml164(); waGlobBind164(); return; }   // v1.2.164: cari-simpan
    }
    $('#waConvList').innerHTML = _list125.map(function (c) {
      var badge = statusBadgeHtml(c);
      // v1.2.58: "menunggu" digantikan lencana "Belum dibalas" bila flag tersedia
      var awa = (c.awaiting && !c.flag) ? ' <span class="tag" style="background:#fecaca;color:#991b1b">menunggu</span>' : '';
      // v1.2.17: tanda kalau butuh manusia (bot gagal / menggantung) & belum dibalas manual
      var attn = (c.needs_attention && waState.replyMode !== 'manual') ? ' <span class="tag" style="background:#fee2e2;color:#b91c1c">' + ico('triangle-alert',12) + ' perlu perhatian</span>' : '';
      var _open = String(c.number) === String(waState.current);   // v1.2.136: aktif-fix: nomor bisa angka dari API
      var bg = _open ? 'background:var(--brand-soft);' : '';
      // v1.2.16: waktu aktivitas terakhir + pembeda visual hari ini vs lama
      var t = waConvTimeInfo(c.last_ts);
      var accent = t.today ? 'border-left:3px solid var(--brand);' : 'border-left:3px solid transparent;';
      var timeStyle = t.today
        ? 'font-size:12px;font-weight:600;color:var(--brand);white-space:nowrap'
        : 'font-size:12px;color:var(--muted);white-space:nowrap';
      var timeHtml = t.label
        ? '<span style="' + timeStyle + '">' + esc(t.label) + '</span>'
        : '';
      // v1.2.19: tampilkan nama kalau ada; nomor jadi baris kecil di bawahnya
      var judul = c.name ? esc(c.name) : (c.is_group ? 'Grup WhatsApp' : ('+' + esc(c.number)));
      var subNomor = '<div class="wa-conv-sub">' + (c.is_group ? '<span>' + ico('users', 11) + ' Grup</span>' : (c.name ? '<span>+' + esc(c.number) + '</span>' : ''))   // v1.2.170: grup-wa
         + contactStageBadgeHtml(c.stage, c.vip) + '</div>';   // v1.2.124: Lead Rating di bawah nama/nomor
      // v1.2.39: badge tag kontak (stage + VIP kalau ada)
      var stageBadge = '';   // v1.2.124: Lead Rating pindah ke baris nomor
      if ((waState.schedCounts || {})[c.number]) stageBadge += ' <span class="tag" style="background:#e0f2fe;color:#075985" title="Pesan terjadwal menunggu dikirim">' + ico('alarm-clock', 11) + ' ' + waState.schedCounts[c.number] + ' terjadwal</span>';   // v1.2.153: jadwal-kirim
      if (c.archived) stageBadge += ' <span class="tag" style="background:#e5e7eb;color:#374151" title="Diarsipkan di WhatsApp">' + ico('archive', 11) + ' arsip</span>';   // v1.2.213: wa-arsip
      if (c.has_history) stageBadge += ' <span class="tag" style="background:#fef3c7;color:#92400e" title="Ada riwayat chat dari sebelum terhubung ke dashboard">' + ico('clock-3', 11) + ' riwayat</span>';   // v1.2.105
      if (c.ch_label && (waState.channels || []).length > 1) stageBadge += ' <span class="tag" style="background:#ede9fe;color:#5b21b6" title="Nomor WhatsApp yang dihubungi">' + ico('phone', 11) + ' ' + esc(c.ch_label) + '</span>';   // v1.2.98: multi-nomor
      return '<div class="wa-conv' + (_open ? ' is-open' : '') + '" data-num="' + esc(c.number) + '" style="' + bg + accent + '">' + waAvatarHtml(c.name, c.number, 38) + '<div class="wa-conv-b">' +   // v1.2.134: chat-aktif; v1.2.135: wa-fix
        '<div style="display:flex;justify-content:space-between;align-items:baseline;gap:8px">' +
          '<span style="font-weight:600">' + judul + '</span>' + timeHtml +
        '</div>' + subNomor +
        '<div style="font-size:13px;color:var(--muted);white-space:nowrap;overflow:hidden;text-overflow:ellipsis">' + esc(c.last_q || c.last_text || '') + '</div>' +
        '<div style="margin-top:5px">' + badge + waFlagBadgeHtml(c) + awa + attn + stageBadge + tfBadgeHtml(c.tp) + '</div>' +   // v1.2.138: filter-topik
        (c.flag === 'done' && c.flag_note ? '<div style="font-size:11px;color:var(--muted);margin-top:3px">' + esc(c.flag_note) + '</div>' : '') +
        ((_pin140 && c === _pin140) ? '<div style="font-size:11px;color:var(--muted);margin-top:3px">' + 'Chat terbuka · tidak termasuk filter ini</div>' : '') +   // v1.2.141: filter-chat-terpilih
        '</div></div>';
    }).join('');
    var _shown211 = (waState.convs || []).length - (_pin140 ? 1 : 0);   // v1.2.211: list-db — tombol halaman berikutnya
    if ((waState.listTotal211 || 0) > _shown211) {
      $('#waConvList').insertAdjacentHTML('beforeend', '<div style="padding:10px 12px;text-align:center"><button type="button" class="btn ghost sm" id="waMore211">Tampilkan lebih banyak</button>'
        + '<div style="font-size:11px;color:var(--muted);margin-top:4px">Menampilkan ' + _shown211 + ' dari ' + waState.listTotal211 + ' percakapan</div></div>');
      $('#waMore211').onclick = function () { this.disabled = true; this.textContent = 'Memuat\u2026'; waState.listLim211 = (waState.listLim211 || 500) + 500; fetchWaConvs(); };
    }
    if (_q125) { $('#waConvList').insertAdjacentHTML('beforeend', waGlobHtml164()); waGlobBind164(); }   // v1.2.164: cari-simpan
    $$('#waConvList .wa-conv').forEach(function (el) {
      el.onclick = function () { selectWaConv(el.dataset.num); };
    });
  }

  function statusBadgeHtml(c) {
    var s = c.status || (c.mode === 'human' ? 'human_unclaimed' : 'bot');
    var isMine = c.claim && c.claim.agent_username === waState.me;
    switch (s) {
      case 'bot':
        return '<span class="tag" style="background:#dbeafe;color:#1e40af">' + ico('bot',13) + ' Bot</span>';
      case 'claimed':
        return isMine
          ? '<span class="tag" style="background:#d1fae5;color:#065f46">' + ico('user-round',13) + ' Saya</span>'
          : '<span class="tag" style="background:#fde68a;color:#92400e">' + ico('user-round',13) + ' ' + esc(c.claim.agent_username) + '</span>';
      case 'takeover_requested':
        var req = c.claim && c.claim.takeover_request ? c.claim.takeover_request.requester : '?';
        return '<span class="tag" style="background:#fed7aa;color:#9a3412">' + ico('clock-3',12) + ' Take-over req dari ' + esc(req) + '</span>';
      case 'human_unclaimed':
        if (waState.replyMode === 'manual') return '<span class="tag" style="background:#e5e7eb;color:#374151">' + ico('hand',13) + ' Antrean</span>';   // v1.2.58
        return '<span class="tag" style="background:#e5e7eb;color:#374151">' + ico('user-round',13) + ' Mode manual</span>';
      default:
        return '<span class="tag">' + esc(s) + '</span>';
    }
  }

  function selectWaConv(num) {
    if (waState.findOpen && String(waState.findNum) !== String(num)) waFindClose164(true);   // v1.2.164: cari-simpan
    waState.current = num; renderWaConvs(); fetchWaThread(num);
    // v1.2.7: mobile show thread (hide list)
    var wrap = document.querySelector('.wachat-wrap');
    if (wrap) wrap.classList.add('showing-thread');
  }

  function fetchWaThread(num, silent) {
    var lim163 = (waState.thLim || {})[num] || 60;   // v1.2.163: thread-lengkap
    api('wa_thread', { query: '&number=' + encodeURIComponent(num) + '&limit=' + lim163 + ((waState.wiAll && waState.wiAll[num]) ? '&imp_all=1' : '') /* v1.2.105 */ }).then(function (res) {
      if (!res || !res.ok) return;
      if (waState.current !== num) return;
      renderWaThread(res);
    });
  }

  /* v1.2.123: wa-scroll-stabil — token untuk URL media dibuat tetap (token login berganti di setiap
   * permintaan; bila ikut berganti, semua gambar dimuat ulang tiap polling dan posisi scroll meleset).
   * Token lama tetap sah sampai 8 jam tanpa aktivitas; diperbarui 30 menit sekali. */
  function waMediaTok() {
    if (!waState.mTok || Date.now() - (waState.mTokAt || 0) > 30 * 60000) { waState.mTok = token; waState.mTokAt = Date.now(); }
    return waState.mTok;
  }
  /* v1.2.94: wa-media — gambar/video/audio/dokumen di thread WA */
  function waMediaHtml(md) {
    if (!md || !md.type) return '';
    var lbl = { image: 'Gambar', video: 'Video', audio: 'Pesan suara', document: 'Dokumen', sticker: 'Stiker' }[md.type] || 'Media';
    var note = function (t) { return '<div style="font-size:12px;opacity:.8;margin-bottom:4px">' + ico('triangle-alert', 13) + ' ' + esc(t) + '</div>'; };
    if (!md.file) return note(md.error === 'too_big' ? lbl + ' terlalu besar (> 16 MB) — lihat di HP' : lbl + ' tidak dapat diunduh — lihat di HP');
    var u = API + '?action=wa_media&f=' + encodeURIComponent(md.file) + '&token=' + encodeURIComponent(waMediaTok());   // v1.2.123
    var gone = ' onerror="this.outerHTML=\'<div style=&quot;font-size:12px;opacity:.8&quot;>' + lbl + ' sudah dihapus dari dashboard (lewat masa simpan) — lihat di HP</div>\'"';
    if (md.type === 'image' || md.type === 'sticker') {
      var mx = md.type === 'sticker' ? 'max-width:120px;max-height:120px' : 'max-width:240px;max-height:320px';
      return '<a href="' + u + '" target="_blank" rel="noopener" style="display:block;margin-bottom:4px"><img src="' + u + '" loading="lazy" alt="' + lbl + '" style="' + mx + ';border-radius:8px;display:block"' + gone + '></a>';
    }
    if (md.type === 'video') return '<video controls preload="metadata" src="' + u + '" style="max-width:260px;max-height:320px;border-radius:8px;display:block;margin-bottom:4px"' + gone + '></video>';
    if (md.type === 'audio') return '<audio controls preload="none" src="' + u + '" style="max-width:240px;display:block;margin-bottom:4px"' + gone + '></audio>';
    var kb = md.size ? (md.size > 1048576 ? (md.size / 1048576).toFixed(1) + ' MB' : Math.max(1, Math.round(md.size / 1024)) + ' KB') : '';
    return '<a href="' + u + '&dl=1" style="display:flex;gap:6px;align-items:center;padding:8px 10px;border-radius:8px;background:rgba(0,0,0,.06);color:inherit;text-decoration:none;margin-bottom:4px">' +
      ico('file-text', 16) + '<span style="overflow:hidden;text-overflow:ellipsis">' + esc(md.name || 'Dokumen') + '</span><span style="opacity:.65;font-size:11px">' + kb + '</span></a>';
  }

  /* ---- v1.2.164: cari-simpan — cari pesan (di chat ini & semua chat) + simpan pesan per bubble ---- */
  function waHlSnip164(s, q) {
    s = String(s == null ? '' : s); q = String(q || '').trim();
    if (q.length < 2) return esc(s);
    var lo = s.toLowerCase(), ql = q.toLowerCase(), out = '', i = 0, j;
    if (lo.length !== s.length) return esc(s);   // huruf yang panjangnya berubah saat lowercase: tanpa sorotan
    while ((j = lo.indexOf(ql, i)) > -1) { out += esc(s.slice(i, j)) + '<mark class="wa-hl">' + esc(s.slice(j, j + ql.length)) + '</mark>'; i = j + ql.length; }
    return out + esc(s.slice(i));
  }
  function waHl164(text, on) {
    if (!on || String(waState.findNum) !== String(waState.current)) return esc(text);
    return waHlSnip164(text, waState.findQ);
  }
  function waTsLbl164(ts) {
    ts = String(ts || ''); var dk = waDateKey(ts);
    return (dk ? waDateLabel(dk) : '') + (ts.length >= 16 ? ' ' + ts.slice(11, 16) : '');
  }
  var WA_WHO164 = { 'in': 'Pelanggan', bot: 'Bot', manual: 'Admin' };
  var WA_MT164 = { image: 'Gambar', video: 'Video', audio: 'Pesan suara', document: 'Dokumen', sticker: 'Stiker' };
  // tombol Simpan di baris waktu bubble
  function waSaveBtn164(k, kind, ts, text, media) {
    var num = waState.current; if (!num || !k) return '';
    waState.bIdx = waState.bIdx || {};
    waState.bIdx[k] = { kind: kind === 'in' ? 'in' : (kind === 'manual' ? 'manual' : 'bot'), ts: ts || '', text: String(text || '').slice(0, 2000), mt: (media && media.type) || '', mn: (media && media.name) || '' };
    var on = !!(waState.saved || {})[num + '|' + k];
    return '<a href="#" class="wa-sv' + (on ? ' on' : '') + '" data-sk="' + esc(k) + '" title="' + (on ? 'Hapus dari Pesan tersimpan' : 'Simpan pesan ini') + '">' + ico('bookmark', 12) + (on ? ' Tersimpan' : ' Simpan') + '</a>';
  }
  function waSavedSet164(items) {
    waState.savedList = items || []; waState.saved = {};
    waState.savedList.forEach(function (x) { waState.saved[x.num + '|' + x.k] = x; });
    var b = $('#waSavedBtn'); if (b) b.title = 'Pesan tersimpan (' + waState.savedList.length + ')';
  }
  function waSavedLoad164(then) {
    api('wa_saved_list').then(function (r) { if (r && r.ok) { waSavedSet164(r.items); if (then) then(); } });
  }
  function waSavedToggle164(body) {
    api('wa_saved_toggle', { method: 'POST', body: body }).then(function (r) {
      if (!r || !r.ok) { toast((r && r.error) || 'Gagal menyimpan.', true); return; }
      waSavedSet164(r.items);
      toast(r.saved ? 'Pesan disimpan — buka lewat ikon Tersimpan di atas daftar chat.' : 'Dihapus dari Pesan tersimpan.');
      if (waState.current) fetchWaThread(waState.current);
      if (waState.savedView) renderWaConvs();
    });
  }
  // lompat ke pesan: muat thread sampai entri ke-pos, gulir ke bubble k & beri sorotan
  function waJump164(num, pos, k) {
    num = String(num);
    waState.thLim = waState.thLim || {};
    if (pos >= 0 && (waState.thLim[num] || 60) < pos + 11) waState.thLim[num] = pos + 11;
    waState.jumpK = { num: num, k: k || '' };
    if (String(waState.current) !== num) selectWaConv(num); else fetchWaThread(num);
  }
  function waJumpApply164(num) {
    var j = waState.jumpK; if (!j || String(j.num) !== String(num)) return;
    waState.jumpK = null;
    var el = null;
    $$('#waThreadBody [data-k]').forEach(function (x) { if (!el && x.getAttribute('data-k') === j.k) el = x; });
    if (!el) { toast('Pesan tidak ditemukan di tampilan ini.'); return; }
    waState.waStick = false;
    el.scrollIntoView({ block: 'center' });
    el.style.boxShadow = '0 0 0 3px #fbbf24'; setTimeout(function () { el.style.boxShadow = ''; }, 1800);
  }
  function waJumpTs164(num, ts, k) {   // dari Pesan tersimpan: posisi dicari lewat ts
    api('wa_msg_search', { query: '&number=' + encodeURIComponent(num) + '&ts=' + encodeURIComponent(ts) }).then(function (r) {
      if (!r || !r.ok) { toast((r && r.error) || 'Chat tidak bisa dibuka.', true); return; }
      if (r.pos < 0) { toast('Pesan ini sudah tidak ada di log chat (isinya tetap ada di Pesan tersimpan).'); if (String(waState.current) !== String(num)) selectWaConv(String(num)); return; }
      waJump164(num, r.pos, k);
    });
  }
  // --- cari di dalam chat yang terbuka ---
  function waFindOpen164() {
    var b = $('#waFindBar'); if (!b || !waState.current) return;
    if (!b.innerHTML) {
      b.innerHTML = ico('search', 16, 'style="color:var(--muted);flex:none"') +
        '<input type="search" id="waFindQ" placeholder="Cari di chat ini…" autocomplete="off" enterkeyhint="search">' +
        '<span class="cnt" id="waFindCnt"></span>' +
        '<button type="button" class="wa-ibtn" id="waFindUp" title="Lebih lama (Enter)">' + ico('chevron-down', 16, 'style="transform:rotate(180deg)"') + '</button>' +
        '<button type="button" class="wa-ibtn" id="waFindDn" title="Lebih baru (Shift+Enter)">' + ico('chevron-down', 16) + '</button>' +
        '<button type="button" class="wa-ibtn" id="waFindX" title="Tutup (Esc)">' + ico('x', 16) + '</button>';
      var t = null;
      $('#waFindQ').oninput = function () { var v = this.value; clearTimeout(t); t = setTimeout(function () { waFindRun164(v); }, 300); };
      $('#waFindQ').onkeydown = function (e) {
        if (e.key === 'Enter') { e.preventDefault(); waFindStep164(e.shiftKey ? 1 : -1); }
        else if (e.key === 'Escape') { e.preventDefault(); waFindClose164(); }
      };
      $('#waFindUp').onclick = function () { waFindStep164(-1); };
      $('#waFindDn').onclick = function () { waFindStep164(1); };
      $('#waFindX').onclick = function () { waFindClose164(); };
    }
    b.style.display = 'flex'; waState.findOpen = true; waState.findNum = String(waState.current);
    if ($('#waFindBtn')) $('#waFindBtn').classList.add('on');
    waFindCnt164();
    $('#waFindQ').focus(); $('#waFindQ').select();
  }
  function waFindClose164(noFetch) {
    var b = $('#waFindBar'); if (b) b.style.display = 'none';
    var had = !!waState.findQ;
    waState.findOpen = false; waState.findQ = ''; waState.fHits = []; waState.fIdx = -1; waState.findSeq = (waState.findSeq || 0) + 1;
    if ($('#waFindQ')) $('#waFindQ').value = '';
    if ($('#waFindCnt')) $('#waFindCnt').textContent = '';
    if ($('#waFindBtn')) $('#waFindBtn').classList.remove('on');
    if (had && !noFetch && waState.current) fetchWaThread(waState.current);
  }
  function waFindCnt164(busy) {
    var c = $('#waFindCnt'); if (!c) return;
    var h = waState.fHits || [], q = String(waState.findQ || '');
    if ($('#waFindUp')) $('#waFindUp').disabled = !h.length || waState.fIdx <= 0;
    if ($('#waFindDn')) $('#waFindDn').disabled = !h.length || waState.fIdx >= h.length - 1;
    c.textContent = busy ? 'Mencari…' : (q.length < 2 ? '' : (h.length ? (waState.fIdx + 1) + '/' + h.length + (waState.fMore ? '+' : '') : 'Tidak ada'));
  }
  function waFindRun164(v) {
    var num = String(waState.current || ''), q = String(v || '').trim();
    var seq = waState.findSeq = (waState.findSeq || 0) + 1;
    waState.findNum = num; waState.findQ = q.length >= 2 ? q : '';
    if (q.length < 2) { waState.fHits = []; waState.fIdx = -1; waFindCnt164(); fetchWaThread(num); return; }
    waFindCnt164(true);
    api('wa_msg_search', { query: '&number=' + encodeURIComponent(num) + '&q=' + encodeURIComponent(q) }).then(function (r) {
      if (seq !== waState.findSeq || String(waState.current) !== num) return;
      waState.fHits = (r && r.ok && r.hits) || []; waState.fMore = !!(r && r.more);
      waState.fIdx = waState.fHits.length - 1;   // mulai dari yang terbaru
      waFindCnt164();
      if (waState.fIdx >= 0) { var h = waState.fHits[waState.fIdx]; waJump164(num, h.pos, h.k); }
      else fetchWaThread(num);
    });
  }
  function waFindStep164(d) {
    var h = waState.fHits || []; if (!h.length) return;
    var i = Math.max(0, Math.min(h.length - 1, waState.fIdx + d));
    if (i === waState.fIdx) return;
    waState.fIdx = i; waFindCnt164();
    waJump164(waState.current, h[i].pos, h[i].k);
  }
  // --- cari isi pesan di semua chat (kotak cari daftar chat, >= 3 huruf) ---
  function waGlobFetch164(v) {
    var q = String(v || '').trim();
    clearTimeout(waState.gT);
    if (q.length < 3) { waState.gHits = null; return; }
    waState.gT = setTimeout(function () {
      api('wa_msg_search', { query: '&q=' + encodeURIComponent(q) }).then(function (r) {
        if (String(waState.q || '').trim() !== q) return;
        waState.gHits = { q: q, hits: (r && r.ok && r.hits) || [], more: !!(r && r.more) };
        renderWaConvs();
      });
    }, 350);
  }
  function waGlobHtml164() {
    var q = String(waState.q || '').trim(); if (q.length < 3) return '';
    var g = waState.gHits;
    if (!g || g.q !== q) return '<div class="wa-gh">PESAN</div><div style="padding:12px 14px;color:var(--muted);font-size:13px">Mencari di isi pesan…</div>';
    if (!g.hits.length) return '<div class="wa-gh">PESAN</div><div style="padding:12px 14px;color:var(--muted);font-size:13px">Tidak ada pesan berisi "' + esc(q) + '"</div>';
    return '<div class="wa-gh">PESAN (' + g.hits.length + (g.more ? '+' : '') + ')</div>' + g.hits.map(function (h, i) {
      return '<div class="wa-gmsg" data-gi="' + i + '"><div class="wa-gm-top"><b>' + esc(h.name || ('+' + h.num)) + '</b><span>' + esc(waTsLbl164(h.ts)) + '</span></div>' +
        '<div class="wa-gm-tx"><span style="color:var(--muted)">' + esc(WA_WHO164[h.kind] || '') + ': </span>' + waHlSnip164(h.snip, q) + '</div></div>';
    }).join('');
  }
  function waGlobBind164() {
    $$('#waConvList .wa-gmsg').forEach(function (el) {
      el.onclick = function () {
        var h = ((waState.gHits || {}).hits || [])[+el.getAttribute('data-gi')]; if (!h) return;
        waJump164(h.num, h.pos, h.k);
      };
    });
  }
  // --- daftar Pesan tersimpan (menggantikan daftar chat selama dibuka) ---
  function waSavedRender164() {
    var L = waState.savedList || [], q = String(waState.q || '').trim().toLowerCase();
    if (q) L = L.filter(function (x) { return (String(x.text || '') + ' ' + (x.mn || '') + ' ' + (x.name || '') + ' ' + x.num).toLowerCase().indexOf(q) > -1; });
    var h = '<div class="wa-sv-hd">' + ico('bookmark', 15) + '<b>Pesan tersimpan</b><span style="color:var(--muted);font-size:12px">' + (waState.savedList || []).length + '</span>' +
      '<button type="button" class="wa-svx" id="waSavedClose" title="Kembali ke daftar chat">' + ico('x', 18) + '</button></div>';
    if (!L.length) h += '<div style="padding:16px;color:var(--muted);font-size:13px">' + (q ? 'Tidak ada pesan tersimpan yang cocok.' : 'Belum ada pesan tersimpan. Klik <b>Simpan</b> di bawah bubble chat untuk menyimpannya di sini.') + '</div>';
    h += L.map(function (x) {
      var tx = String(x.text || '');
      if (x.mt) tx = '[' + (WA_MT164[x.mt] || 'Media') + (x.mn ? ': ' + x.mn : '') + ']' + (tx ? '\n' + tx : '');
      return '<div class="wa-svi" data-id="' + esc(x.id) + '"><div class="wa-gm-top"><b>' + esc(x.name || ('+' + x.num)) + '</b><span>' + esc(waTsLbl164(x.ts)) +
        ' <button type="button" class="wa-svx" data-rm="1" title="Hapus dari Pesan tersimpan">' + ico('trash-2', 14) + '</button></span></div>' +
        '<div class="wa-gm-who">' + esc(WA_WHO164[x.kind] || '') + '</div><div class="wa-gm-tx">' + waHlSnip164(tx, q) + '</div></div>';
    }).join('');
    $('#waConvList').innerHTML = h;
    $('#waSavedClose').onclick = function () { waSavedView164(false); };
    $$('#waConvList .wa-svi').forEach(function (el) {
      el.onclick = function (e) {
        var id = el.getAttribute('data-id'), x = (waState.savedList || []).filter(function (y) { return y.id === id; })[0]; if (!x) return;
        if (e.target.closest && e.target.closest('[data-rm]')) { e.stopPropagation(); if (confirm('Hapus pesan ini dari Pesan tersimpan?')) waSavedToggle164({ number: x.num, k: x.k, remove: 1 }); return; }
        waJumpTs164(x.num, x.ts, x.k);
      };
    });
  }
  function waSavedView164(on) {
    waState.savedView = !!on;
    if ($('#waSavedBtn')) $('#waSavedBtn').classList.toggle('on', !!on);
    if (on) waSavedLoad164(renderWaConvs);
    renderWaConvs();
  }
  function waCs164Init() {
    if (waState.cs164) return; waState.cs164 = true;
    waSavedLoad164(function () { if (waState.current) fetchWaThread(waState.current); });
    if ($('#waSavedBtn')) $('#waSavedBtn').onclick = function () { waSavedView164(!waState.savedView); };
    var body = $('#waThreadBody');
    if (body) body.addEventListener('click', function (e) {
      var a = e.target.closest ? e.target.closest('.wa-sv') : null; if (!a) return;
      e.preventDefault();
      var k = a.getAttribute('data-sk'), b = (waState.bIdx || {})[k], num = waState.current; if (!num || !b) return;
      waSavedToggle164({ number: num, k: k, ts: b.ts, kind: b.kind, text: b.text, mt: b.mt, mn: b.mn });
    });
    document.addEventListener('keydown', function (e) {   // Ctrl/Cmd+F di Percakapan WA = cari di chat ini
      if (!(e.ctrlKey || e.metaKey) || String(e.key).toLowerCase() !== 'f' || !waState.current) return;
      var p = $('#panel-wachat'); if (!p || !p.classList.contains('active')) return;
      e.preventDefault(); waFindOpen164();
    });
  }

  function waBubble(text, kind, ts, media, via, rq) {   // v1.2.98: multi-nomor (via = nomor bisnis yang dihubungi); v1.2.121: rq = {id, reply_to}
    var st = kind === 'in' ? 'align-self:flex-start;background:#fff;border:1px solid var(--line);color:var(--ink)'
      : kind === 'manual' ? 'align-self:flex-end;background:#dcfce7;color:#14532d'
      : 'align-self:flex-end;background:var(--brand);color:#fff';
    var who = kind === 'manual' ? ' · admin' : kind === 'bot' ? ' · bot' : '';
    if (media && media.file) text = String(text || '').replace(/^\[[^\]\n]*\]\n?/, '');   // v1.2.94: label diganti media
    // v1.2.121: wa-balas-kutip — kutipan di atas isi + tombol Balas
    var rid = (rq && rq.id) ? String(rq.id) : '', qh = '', rb = '';
    if (rid) {
      var snip = String(text || '').replace(/\s+/g, ' ').trim();
      if (!snip && media && media.type) snip = ({ image: 'Gambar', video: 'Video', audio: 'Pesan suara', document: 'Dokumen', sticker: 'Stiker' }[media.type] || 'Media') + (media.name ? ' ' + media.name : '');
      waState.qIdx = waState.qIdx || {};
      waState.qIdx[rid] = { who: kind === 'in' ? 'in' : 'out', text: snip.length > 160 ? snip.slice(0, 157) + '…' : snip };
      if (waState.canQuote) rb = '<a href="#" class="wa-rep" data-rid="' + esc(rid) + '" title="Balas pesan ini" style="color:inherit;opacity:.8;text-decoration:none;margin-left:8px;display:inline-flex;align-items:center;gap:2px;vertical-align:-2px">' + ico('corner-up-left', 12) + ' Balas</a>';
    }
    if (rq && rq.reply_to) qh = waQuoteHtml(rq.reply_to, kind === 'bot');
    // v1.2.200: edit-hapus-pesan: label diedit / dihapus + tautan Edit & Hapus
    var del200 = rq && rq.del, edt200 = rq && rq.edt, mk200 = '', ma200 = '';
    if (del200) { rb = ''; mk200 = ' · dihapus' + (del200.by ? ' oleh ' + esc(del200.by) : ''); }
    else if (edt200) mk200 = ' · <span title="Diedit' + (edt200.by ? ' oleh ' + esc(edt200.by) : '') + (edt200.at ? ' pukul ' + esc(String(edt200.at).slice(11, 16)) : '') + '">diedit</span>';
    if (!del200 && rid && rq.act && (rq.act.e || rq.act.d)) {
      waState.mIdx = waState.mIdx || {}; waState.mIdx[rid] = { text: String(text || '') };
      if (rq.act.e) ma200 += '<a href="#" class="wa-mact" data-act="edit" data-oid="' + esc(rid) + '" title="Edit pesan ini (maks 15 menit setelah dikirim)">' + ico('pencil', 12) + ' Edit</a>';
      if (rq.act.d) ma200 += '<a href="#" class="wa-mact" data-act="del" data-oid="' + esc(rid) + '" title="Hapus untuk semua orang (maks 48 jam setelah dikirim)">' + ico('trash-2', 12) + ' Hapus</a>';
    }
    var sb164 = (rq && rq.k) ? waSaveBtn164(rq.k, kind, ts, text, media) : '';   // v1.2.164: cari-simpan
    return '<div' + (rid ? ' data-mid="' + esc(rid) + '"' : '') + ((rq && rq.k) ? ' data-k="' + esc(rq.k) + '"' : '') /* v1.2.123 */ + ' style="max-width:78%;' + st + ';padding:8px 12px;border-radius:12px;margin:4px 0;white-space:pre-wrap;font-size:14px;line-height:1.45;transition:box-shadow .3s">' +
      ((rq && rq.gf) ? '<div style="font-size:12px;font-weight:600;color:var(--brand);margin-bottom:2px">' + esc(rq.gf) + '</div>' : '') /* v1.2.170: grup-wa */ + qh + (del200 ? '<div style="font-style:italic;display:flex;align-items:center;gap:5px">' + ico('ban', 13) + ' Pesan ini dihapus</div>' + ((text || (media && media.name)) ? '<div style="opacity:.55;text-decoration:line-through;font-size:12.5px;margin-top:2px" title="Isi sebelum dihapus (hanya terlihat oleh tim)">' + esc(String(text || '') || ('[' + (media.name || 'lampiran') + ']')) + '</div>' : '') : waMediaHtml(media) + waHl164(text, !!(rq && rq.k))) + '<div style="font-size:10px;opacity:.65;margin-top:4px">' + esc((ts || '').slice(11, 16)) + who + (via ? ' · ke ' + esc(via) : '') + mk200 + rb + sb164 + waTaskBtn214(rq) /* v1.2.214: task */ + ma200 + '</div></div>';   // v1.2.200: edit-hapus-pesan   // v1.2.164: cari-simpan
  }
  // v1.2.123: wa-scroll-stabil — penggulir thread: kotak thread (desktop) atau halaman (HP, thread memanjang)
  function waScroller() {
    var b = $('#waThreadBody'); if (!b) return null;
    if (document.body.classList.contains('wa-full')) return b;   // v1.2.124: wa-layout-penuh — thread punya area scroll sendiri (desktop & HP)
    var w = b.closest ? b.closest('.wachat-wrap') : null;
    return (w && getComputedStyle(w).flexDirection === 'column') ? (document.scrollingElement || document.documentElement) : b;
  }
  function waScIsWin(sc) { return sc === document.scrollingElement || sc === document.documentElement; }
  function waScTop(sc) { return waScIsWin(sc) ? 0 : sc.getBoundingClientRect().top; }
  function waScGap(sc) { return sc.scrollHeight - sc.scrollTop - (waScIsWin(sc) ? window.innerHeight : sc.clientHeight); }
  // Saat di posisi paling bawah, tetap di bawah walau gambar/video selesai dimuat belakangan.
  // "Menempel di bawah" hanya lepas bila pengguna menggulir KE ATAS (bukan karena tata letak berubah, mis. kotak balas muncul).
  function waScrollInit() {
    var b = $('#waThreadBody');
    if (!b || waState.scrollBound) return;
    waState.scrollBound = true;
    var onScroll = function (fromWin) {
      var sc = waScroller(); if (!sc || waScIsWin(sc) !== fromWin) return;
      if (!$('#panel-wachat') || !$('#panel-wachat').classList.contains('active')) return;
      var t = sc.scrollTop;
      if (waScGap(sc) < 60) waState.waStick = true;
      else if (t < (waState.waLastTop || 0) - 1) waState.waStick = false;
      waState.waLastTop = t;
    };
    b.addEventListener('scroll', function () { onScroll(false); }, { passive: true });
    window.addEventListener('scroll', function () { onScroll(true); }, { passive: true });
    var tempel = function () { var sc = waScroller(); if (sc && waState.waStick) { sc.scrollTop = sc.scrollHeight; waState.waLastTop = sc.scrollTop; } };
    b.addEventListener('load', tempel, true);             // <img> (event load tidak menggelembung -> capture)
    b.addEventListener('loadedmetadata', tempel, true);   // <video>/<audio>
  }
  function waQuoteWho(r) { return r.who === 'in' ? 'Pelanggan' : (r.who === 'out' ? 'Anda' : 'Pesan sebelumnya'); }
  function waQuoteHtml(r, onBrand) {
    return '<div class="wa-q" data-qid="' + esc(r.id || '') + '" title="Lihat pesan yang dikutip" style="border-left:3px solid ' + (onBrand ? 'rgba(255,255,255,.75)' : (r.who === 'in' ? '#2563eb' : '#16a34a')) +
      ';background:rgba(0,0,0,.07);border-radius:6px;padding:4px 8px;margin-bottom:6px;font-size:12px;cursor:pointer;white-space:normal">' +
      '<div style="font-weight:600;opacity:.9">' + waQuoteWho(r) + '</div>' +
      '<div style="opacity:.85;overflow:hidden;display:-webkit-box;-webkit-line-clamp:2;-webkit-box-orient:vertical">' + esc(r.text || '(pesan)') + '</div></div>';
  }
  function waQuoteClear() {
    waState.replyTo = null;
    if ($('#waQuoteBar')) { $('#waQuoteBar').style.display = 'none'; $('#waQuoteBar').innerHTML = ''; }
  }
  function waQuoteSet(id) {
    var q = (waState.qIdx || {})[id];
    if (!q || !waState.current) return;
    if ($('#waReplyInput').disabled) { toast('Anda tidak bisa membalas chat ini sekarang.', true); return; }
    waState.replyTo = { id: id, num: waState.current, who: q.who, text: q.text };
    var bar = $('#waQuoteBar');
    bar.style.borderLeftColor = q.who === 'in' ? '#2563eb' : '#16a34a';
    bar.innerHTML = '<span style="display:inline-flex;color:var(--muted)">' + ico('corner-up-left', 15) + '</span>' +
      '<span style="flex:1;min-width:0"><strong>Membalas ' + (q.who === 'in' ? 'Pelanggan' : 'Anda') + '</strong>' +
      '<span style="display:block;color:var(--muted);overflow:hidden;text-overflow:ellipsis;white-space:nowrap">' + esc(q.text || '(pesan)') + '</span></span>' +
      '<button type="button" id="waQuoteX" title="Batal membalas" style="border:0;background:transparent;cursor:pointer;color:var(--muted);display:inline-flex">' + ico('x', 16) + '</button>';
    bar.style.display = 'flex';
    $('#waQuoteX').onclick = waQuoteClear;
    $('#waReplyInput').focus();
  }
  function waQuoteInit() {
    var body = $('#waThreadBody');
    if (!body || waState.quoteBound) return;
    waState.quoteBound = true;
    body.addEventListener('click', function (e) {
      var a = e.target.closest ? e.target.closest('.wa-rep') : null;
      if (a) { e.preventDefault(); waQuoteSet(a.getAttribute('data-rid')); return; }
      var ma = e.target.closest ? e.target.closest('.wa-mact') : null;   // v1.2.200: edit-hapus-pesan
      if (ma) { e.preventDefault(); waMsgAct(ma.getAttribute('data-act'), ma.getAttribute('data-oid')); return; }
      var q = e.target.closest ? e.target.closest('.wa-q') : null;
      if (q) {
        var id = q.getAttribute('data-qid'), el = null;
        $$('#waThreadBody [data-mid]').forEach(function (x) { if (!el && x.getAttribute('data-mid') === id) el = x; });
        if (el) { el.scrollIntoView({ behavior: 'smooth', block: 'center' }); el.style.boxShadow = '0 0 0 3px #fbbf24'; setTimeout(function () { el.style.boxShadow = ''; }, 1400); }
        else toast('Pesan yang dikutip sudah tidak ada di tampilan ini.');
      }
    });
    $('#waReplyInput').addEventListener('keydown', function (e) { if (e.key === 'Escape' && waState.replyTo) waQuoteClear(); });
  }

  /* ---- v1.2.200: edit-hapus-pesan — edit & hapus pesan keluar (WAHA) ---- */
  // v1.2.202: id-noweb: id pesan keluar NOWEB kini tersimpan (perubahan di api)
  function waMsgAct(act, oid) {
    var num = waState.current, m = (waState.mIdx || {})[oid];
    if (!num || !m) return;
    if (act === 'del') {
      if (!confirm('Hapus pesan ini untuk semua orang?\n\nPesan ditarik dari WhatsApp pelanggan (di sana tampil "Pesan ini telah dihapus"). Tindakan ini tidak bisa dibatalkan.')) return;
      api('wa_msg_delete', { method: 'POST', body: { number: num, id: oid } }).then(function (r) {
        if (r && r.ok) { toast('Pesan dihapus untuk semua orang.'); fetchWaThread(num); }
        else toast((r && r.error) || 'Gagal menghapus pesan.', true);
      });
      return;
    }
    var ov = document.createElement('div');
    ov.id = 'waMsgEd';
    ov.style.cssText = 'position:fixed;inset:0;background:rgba(15,23,42,.45);z-index:9999;display:flex;align-items:center;justify-content:center;padding:16px';
    ov.innerHTML = '<div class="card" style="width:100%;max-width:540px;margin:0">' +
      '<div style="display:flex;justify-content:space-between;align-items:center;gap:10px;margin-bottom:10px"><h3 style="margin:0">Edit pesan</h3>' +
      '<button type="button" class="btn ghost sm" id="wmeX" title="Tutup">' + ico('x', 16) + '</button></div>' +
      '<textarea id="wmeT" rows="6" maxlength="4000" style="width:100%"></textarea>' +
      '<p class="help" style="margin:6px 0 12px">Pesan di WhatsApp pelanggan ikut berubah dan diberi label <b>Diedit</b>. Hanya bisa sampai 15 menit setelah dikirim. Ctrl/⌘ + Enter untuk menyimpan.</p>' +
      '<div style="display:flex;gap:8px;justify-content:flex-end"><button type="button" class="btn ghost" id="wmeC">Batal</button>' +
      '<button type="button" class="btn" id="wmeS">' + ico('save', 14) + ' Simpan</button></div></div>';
    document.body.appendChild(ov);
    var tutup = function () { ov.remove(); document.removeEventListener('keydown', esck); };
    var esck = function (e) { if (e.key === 'Escape') tutup(); };
    document.addEventListener('keydown', esck);
    ov.onclick = function (e) { if (e.target === ov) tutup(); };
    $('#wmeX').onclick = tutup; $('#wmeC').onclick = tutup;
    var t = $('#wmeT');
    t.value = m.text; t.focus();
    try { t.setSelectionRange(t.value.length, t.value.length); } catch (e) {}
    var simpan = function () {
      var v = t.value.trim(), b = $('#wmeS');
      if (!v) { toast('Isi pesan tidak boleh kosong. Pakai Hapus untuk menarik pesan.', true); return; }
      if (v === String(m.text).trim()) { tutup(); return; }
      b.disabled = true;
      api('wa_msg_edit', { method: 'POST', body: { number: num, id: oid, text: v } }).then(function (r) {
        b.disabled = false;
        if (r && r.ok) { tutup(); toast('Pesan diperbarui.'); fetchWaThread(num); }
        else toast((r && r.error) || 'Gagal mengedit pesan.', true);
      });
    };
    $('#wmeS').onclick = simpan;
    t.addEventListener('keydown', function (e) { if (e.key === 'Enter' && (e.ctrlKey || e.metaKey)) { e.preventDefault(); simpan(); } });
  }

  /* ---- v1.2.15: pemisah tanggal di thread WA ------------------------- */
  // Ambil bagian tanggal dari ts 'Y-m-d H:i:s' -> 'Y-m-d' (kunci pembanding)
  function waDateKey(ts) {
    return String(ts || '').split(' ')[0] || '';
  }
  // Label ramah: Hari ini / Kemarin / 16 Juli 2026
  function waDateLabel(key) {
    if (!key) return '';
    var p = key.split('-');
    if (p.length !== 3) return key;
    var d = new Date(+p[0], +p[1] - 1, +p[2]);
    if (isNaN(d.getTime())) return key;
    var today = new Date();
    today.setHours(0, 0, 0, 0);
    var diffHari = Math.round((today.getTime() - d.getTime()) / 86400000);
    if (diffHari === 0) return 'Hari ini';
    if (diffHari === 1) return 'Kemarin';
    var bulan = ['Januari','Februari','Maret','April','Mei','Juni','Juli','Agustus','September','Oktober','November','Desember'];
    return d.getDate() + ' ' + bulan[d.getMonth()] + ' ' + d.getFullYear();
  }
  function waCallPill(txt, ts, chl) {   // v1.2.108: tolak-telepon
    var t = /\d{2}:\d{2}/.exec(String(ts || '').slice(11)) || [''];
    return '<div style="display:flex;justify-content:center;margin:8px 0">' +
           '<span style="background:#e0f2fe;color:#075985;font-size:12px;padding:5px 12px;border-radius:12px;max-width:85%;text-align:center">' +
           esc(txt) + (t[0] ? ' · ' + esc(t[0]) : '') + (chl ? ' · ' + esc(chl) : '') + '</span></div>';
  }
  function waDateSepHtml(label) {
    return '<div style="display:flex;justify-content:center;margin:14px 0 10px">' +
           '<span style="background:#e5e7eb;color:#374151;font-size:12px;padding:4px 12px;border-radius:12px">' +
           esc(label) + '</span></div>';
  }

  /* v1.2.125: wa-tampilan-sama — avatar inisial & panel info kontak */
  function waAvatarHtml(name, num, sz) {
    var pal = ['#5b3fd1', '#1f7a43', '#c2410c', '#0e7490', '#be185d', '#4338ca', '#b45309', '#7c3aed'];
    var h = 0, s = String(num || ''); for (var i = 0; i < s.length; i++) h = (h * 31 + s.charCodeAt(i)) >>> 0;
    var ch = String(name || '').trim().charAt(0).toUpperCase();
    var inner = (ch && /[A-Z0-9À-ɏ]/.test(ch)) ? esc(ch) : ico('user-round', Math.round(sz * 0.45));
    return '<div class="wa-av" style="width:' + sz + 'px;height:' + sz + 'px;font-size:' + Math.round(sz * 0.38) + 'px;background:' + pal[h % pal.length] + '">' + inner + '</div>';
  }
  // v1.2.151: kontrol-kanan — di layar lebar, kontrol chat pindah dari kepala chat ke panel kanan
  function waCtlWide() { return document.body.classList.contains('wa-full') && window.matchMedia && window.matchMedia('(min-width:1280px)').matches; }
  function waInfoRender(res, k, claim, ctl) {
    var box = $('#waInfo'); if (!box) return;
    if (ctl) {
      var t151 = (k && k.last_ts) ? waConvTimeInfo(k.last_ts) : null;
      var row151 = function (l, v) { return '<div><dt>' + l + '</dt><dd>' + v + '</dd></div>'; };
      box.innerHTML = ctl + '<dl class="wa-ctl-dl">' +
        row151('Ditangani', claim ? esc(claim.agent_username) : '<span style="color:var(--muted);font-weight:400">Belum ada</span>') +
        (t151 && t151.label ? row151('Aktivitas terakhir', esc(t151.label)) : '') +
        (k && k.flag === 'done' && k.flag_note ? row151('Catatan', esc(k.flag_note)) : '') + '</dl>';
      return;
    }
    var nm = (k && k.name) || '';
    var chL = '', curCh = res.ch || 'utama';
    (res.channels || []).forEach(function (c) { if (c.id === curCh) chL = c.label + ((c.number && c.label !== '+' + c.number) ? ' (+' + c.number + ')' : ''); });
    var cs = CONTACT_STAGE[(k && k.stage) || 'new'] || CONTACT_STAGE.new;
    var row = function (l, v) { return '<div><dt>' + l + '</dt><dd>' + v + '</dd></div>'; };
    var t = (k && k.last_ts) ? waConvTimeInfo(k.last_ts) : null;
    box.innerHTML = waAvatarHtml(nm, res.number, 64) +
      '<h3>' + esc(nm || ('+' + res.number)) + '</h3><div class="wa-inf-num">+' + esc(res.number) + '</div><dl>' +
      row('Status', k ? statusBadgeHtml(k) : '—') +
      row('Lead Rating', '<span class="tag" style="background:' + cs.bg + ';color:' + cs.fg + '">' + esc(cs.label) + '</span>' + (k && k.vip ? ' <span class="tag" style="' + CONTACT_VIP_STYLE + '">' + ico('star', 12) + ' VIP</span>' : '')) +
      (chL ? row('Nomor bisnis', esc(chL)) : '') +
      row('Ditangani', claim ? esc(claim.agent_username) : '<span style="color:var(--muted);font-weight:400">Belum ada</span>') +
      (t && t.label ? row('Aktivitas terakhir', esc(t.label)) : '') +
      (k && k.flag === 'done' && k.flag_note ? row('Catatan', esc(k.flag_note)) : '') +
      '</dl>';
  }
  var _ctl151Bound = false;
  function waCtlBind151() {
    if (_ctl151Bound) return; _ctl151Bound = true;
    document.addEventListener('click', function (e) {
      var h = $('#waThreadHead'); if (!h || !h.classList.contains('tools-open')) return;
      if (!window.matchMedia('(max-width:860px)').matches) return;
      if (e.target.closest('.wa-th-tools') || e.target.closest('#waThMore')) return;
      waState.thTools = false; h.classList.remove('tools-open');
    });
    if (window.matchMedia) {
      var mq = window.matchMedia('(min-width:1280px)'), fn = function () {
        if (waState.current && !!waState.ctlWide !== waCtlWide()) fetchWaThread(waState.current, true);
      };
      if (mq.addEventListener) mq.addEventListener('change', fn); else if (mq.addListener) mq.addListener(fn);
    }
  }
  function renderWaThread(res) {
    var num = res.number;
    waState.canQuote = ['meta', 'waha'].indexOf(res.wa_prov || 'meta') > -1;   // v1.2.121: wa-balas-kutip
    waState.qIdx = {}; waState.bIdx = {}; waState.mIdx = {};   // v1.2.164: cari-simpan; v1.2.200: edit-hapus-pesan
    if (res.claim !== undefined) {   // v1.2.141: filter-chat-terpilih — status claim dari server, bukan dari daftar terfilter
      if (res.claim) waState.claimDetails[num] = res.claim; else delete waState.claimDetails[num];
      var _cc140 = (waState.convCache || {})[String(num)];
      if (_cc140) {
        var _was140 = !!_cc140.claim; _cc140.claim = res.claim || null;
        if (res.claim) { _cc140.status = res.claim.takeover_request ? 'takeover_requested' : 'claimed'; _cc140.mode = 'human'; }
        else if (_was140) { _cc140.status = res.mode === 'human' ? 'human_unclaimed' : 'bot'; _cc140.mode = res.mode; }
        if (!waConvInList140(num)) renderWaConvs();
      }
    }
    var claim = waState.claimDetails[num] || null;
    waState.currentThreadClaim = claim;
    var isMine = claim && claim.agent_username === waState.me;
    var hasTakeoverReq = claim && claim.takeover_request;

    // Build action buttons based on claim state + user role
    var actionBtns = '', toolBtns = '';   // v1.2.125: toolBtns = baris alat terpisah
    if (!claim) {
      // Unclaimed → Claim button
      actionBtns = '<button class="btn" id="waClaimBtn" style="padding:7px 14px;font-size:13px">' + ico('hand',14) + ' Claim</button>';
    } else if (isMine) {
      // Mine → Release + (kalau ada takeover req dari orang lain) Approve/Deny
      if (hasTakeoverReq) {
        actionBtns =
          '<div style="display:flex;gap:6px;align-items:center;flex-wrap:wrap">' +
          '<span class="tag" style="background:#fed7aa;color:#9a3412;padding:5px 9px">' + ico('clock-3',12) + ' ' + esc(claim.takeover_request.requester) + ' minta take-over' +
          (claim.takeover_request.reason ? ': "' + esc(claim.takeover_request.reason) + '"' : '') + '</span>' +
          '<button class="btn ghost" id="waTakeoverDenyBtn" style="padding:6px 12px;font-size:12px">Tolak</button>' +
          '<button class="btn" id="waTakeoverApproveBtn" style="padding:6px 12px;font-size:12px">Setujui</button>' +
          '<button class="btn ghost" id="waReleaseBtn" style="padding:6px 12px;font-size:12px">' + ico('corner-up-left',14) + ' Release</button>' +
          '</div>';
      } else {
        actionBtns = '<button class="btn ghost" id="waReleaseBtn" style="padding:7px 14px;font-size:13px" title="' + (waState.replyMode === 'manual' ? 'Lepas chat ke antrean' : 'Release — kembalikan chat ke bot') + '">' + ico('corner-up-left',14) + (waState.replyMode === 'manual' ? ' Lepas ke antrean' : ' Release') + '</button>';   // v1.2.143: kepala-chat-rapi
      }
    } else {
      // Owned by someone else
      var ownerLabel = '<span style="color:var(--muted);font-size:13px">Dikelola oleh <strong>' + esc(claim.agent_username) + '</strong></span>';
      if (waState.isAdmin) {
        actionBtns = ownerLabel +
          ' <button class="btn ghost" id="waAdminTakeoverBtn" style="padding:6px 12px;font-size:12px;margin-left:8px">' + ico('wrench',13) + ' Admin Take-over</button>' +
          ' <button class="btn ghost" id="waReleaseBtn" style="padding:6px 12px;font-size:12px">' + ico('corner-up-left',14) + ' Release</button>';
      } else {
        // wa_agent role → Request Take-over
        if (hasTakeoverReq && claim.takeover_request.requester === waState.me) {
          var secondsLeft = Math.max(0, 300 - Math.floor((Date.now() / 1000) - claim.takeover_request.requested_at));
          actionBtns = ownerLabel +
            ' <span class="tag" style="background:#fed7aa;color:#9a3412;margin-left:8px">' + ico('clock-3',12) + ' Request Anda pending (' + secondsLeft + 's tersisa)</span>';
        } else if (hasTakeoverReq) {
          actionBtns = ownerLabel + ' <span class="tag" style="background:#e5e7eb;color:#374151;margin-left:8px">Ada request take-over pending dari ' + esc(claim.takeover_request.requester) + '</span>';
        } else {
          actionBtns = ownerLabel +
            ' <button class="btn ghost" id="waRequestTakeoverBtn" style="padding:6px 12px;font-size:12px;margin-left:8px">' + ico('hand',13) + ' Minta Take-over</button>';
        }
      }
    }

    // v1.2.101: percakapan — tombol Selesai; v1.2.131: hanya Supervisor / Admin / Super Admin
    var _li129 = waConvOf140(num);   // v1.2.129: wa-selesai-lama; v1.2.130: selesai-fix; v1.2.148: selesai-tanpa-flag — termasuk chat terpilih di luar filter
    var _openConv = res.conv && ['open', 'handover', 'assigned'].indexOf(res.conv.status) > -1;
    if ((_openConv || (_li129 && _li129.flag !== 'done')) && waState.isAdmin) {   // v1.2.148: flag kosong (data lama) = belum selesai   // v1.2.131: selesai-spv — hanya Supervisor/Admin
      actionBtns += ' <button class="btn ghost" id="waResolveBtn" style="padding:7px 14px;font-size:13px;margin-left:6px" title="Tandai percakapan ini selesai. Chat dilepas; pesan berikutnya membuka percakapan baru.">' + ico('check-circle-2',14) + ' Selesai</button>';
    }
    var _ag201 = '', _chO201 = '', _chCur201 = '';   // v1.2.201: transfer-nomor
    // v1.2.58: Supervisor/Admin — serahkan chat ke agent tertentu
    if (waState.isAdmin && (waState.agents || []).length) {
      var _opsi = '<option value="">Transfer ke Agent</option>' +   // v1.2.144: label-alat-chat; v1.2.145: transfer-ke-agent
        waState.agents.map(function (a) {
          if (claim && a.username === claim.agent_username) return '';
          var _rsNo = a.role === 'wa_agent' && !rsAllowed(a.reply_stages, res.stage, res.vip);   // v1.2.119: agent-stage
          return '<option value="' + esc(a.username) + '"' + (_rsNo ? ' disabled' : '') + '>' + esc(a.name || a.username) + ' (' + esc(ROLE_LABEL[a.role] || a.role) + ')' + (_rsNo ? ' — Lead Rating tidak sesuai' : '') + '</option>';
        }).join('');
      _ag201 = _opsi.replace('<option value="">Transfer ke Agent</option>', '');   // v1.2.201: transfer-nomor: dirakit di bawah bersama nomor bisnis
    }
    // v1.2.116: pindah-nomor — Admin/Supervisor memindah nomor bisnis pengirim chat
    var _chs116 = res.channels || [], _cur116 = res.ch || 'utama';
    if (waState.isAdmin && _chs116.length > 1) {
      var _curCh144 = _chs116.filter(function (c) { return c.id === _cur116; })[0];
      var _lbl146 = function (c) {   // v1.2.146: label-nomor-utama — nomor tanpa label: tampilkan nama, bukan nomor WA
        var l = String(c.label || ''), n = String(c.number || '');
        if (!l || l === '+' + n || l.replace(/\D/g, '') === n) return c.primary || c.id === 'utama' ? 'Nomor utama' : (n ? '+' + n : c.id);
        return l;
      };   // v1.2.144: label-alat-chat — tampilkan label nomor yang sedang dipakai
      _chCur201 = _curCh144 ? _lbl146(_curCh144) : 'Nomor bisnis';   // v1.2.201: transfer-nomor
      _chO201 = _chs116.filter(function (c) { return c.id !== _cur116; }).map(function (c) {
        var l = _lbl146(c), n = String(c.number || '');
        return '<option value="ch:' + esc(c.id) + '"' + (n ? ' title="+' + esc(n) + '"' : '') + '>' + esc(l) + (n && l.replace(/\D/g, '') !== n ? ' (+' + esc(n) + ')' : '') + '</option>';
      }).join('');
    }

    // v1.2.201: transfer-nomor: satu menu Transfer ke… = Agent + Nomor WhatsApp bisnis
    if (_ag201 && _chO201) toolBtns += '<span class="wa-assign" title="Serahkan chat ke agent lain, atau pindahkan ke nomor WhatsApp bisnis lain (sekarang: ' + esc(_chCur201) + ')">' + ico('user-round',13) +
      '<select id="waAssignSel"><option value="">Transfer ke…</option><optgroup label="Agent">' + _ag201 + '</optgroup>' +
      '<optgroup label="Nomor WhatsApp bisnis (sekarang: ' + esc(_chCur201) + ')">' + _chO201 + '</optgroup></select></span>';
    else if (_ag201) toolBtns += '<span class="wa-assign">' + ico('user-round',13) + '<select id="waAssignSel"><option value="">Transfer ke Agent</option>' + _ag201 + '</select></span>';
    else if (_chO201) toolBtns += '<span class="wa-assign" title="Pindahkan chat ke nomor WhatsApp bisnis lain (sekarang: ' + esc(_chCur201) + ')">' + ico('phone',13) +
      '<select id="waAssignSel"><option value="">Pindah ke nomor…</option>' + _chO201 + '</select></span>';

    toolBtns += slThreadTools203(res);   // v1.2.203: sales-tag
    // v1.2.19: nama kontak (dari daftar percakapan) + tombol koreksi
    // v1.2.39 fase2e: bandingkan sebagai String -- wa_conversations_v2
    // mengembalikan "number" sebagai JSON Number (tanpa kutip), sementara
    // res.number di sini bisa jadi String. === akan SELALU false kalau
    // tipenya beda walau nilainya sama, bikin _konv selalu undefined dan
    // stage selalu fallback ke 'new'. Ini akar masalah dropdown "balik ke
    // New" -- bukan soal urutan fetch seperti dugaan sebelumnya.
    var _konv = waConvOf140(res.number);   // v1.2.141: filter-chat-terpilih — tetap dapat data walau di luar filter
    var _nama = (_konv && _konv.name) || '';
    if (res.group && !_nama) _nama = res.group.name || 'Grup WhatsApp';   // v1.2.170: grup-wa
    var _judulThread = _nama
      ? '<strong>' + esc(_nama) + '</strong> <span style="color:var(--muted);font-size:12px">+' + esc(res.number) + '</span>'
      : '<strong>+' + esc(res.number) + '</strong>';
    if ((res.channels || []).length > 1 && res.ch) { (res.channels || []).forEach(function (c) { if (c.id === res.ch && _konv) _konv.ch_label = c.label; }); }   // v1.2.116: label dari nomor terkini
    if (_konv && _konv.ch_label && (res.channels || []).length > 1) _judulThread += ' <span class="tag" style="background:#ede9fe;color:#5b21b6;font-size:11px" title="Balasan dikirim dari nomor ini">via ' + esc(_konv.ch_label) + '</span>';   // v1.2.98: multi-nomor
    // v1.2.21: jalan masuk ke Leads dari thread — supaya percakapan lama pun
    // bisa ditarik jadi lead (kartu otomatis hanya terbentuk saat ada pesan baru).
    var _leadLink = '';
    if (_konv && _konv.has_lead) {
      // v1.2.29: agent boleh membuka kartu yang sudah ada
      _leadLink = ' <a href="#" id="waOpenLead" style="font-size:12px">' + ico('clipboard-list',13) + ' Lihat lead</a>';
    } else if (waState.isAdmin !== false) {
      // membuat kartu baru memakai kuota klien -> admin saja
      _leadLink = ' <a href="#" id="waMakeLead" style="font-size:12px">' + ico('clipboard-list',13) + ' Analisa jadi lead</a>';
    }
    // v1.2.39 fase2f: baris kedua kepala thread -- status chat (pakai ulang
    // statusBadgeHtml yang sama dengan daftar percakapan) + kategori kontak
    // (dropdown, diberi label supaya beda jelas dari status chat) + VIP
    // (tombol toggle icon-only, bukan checkbox+emoji lagi).
    if (res.group) _leadLink = '';   // v1.2.170: grup-wa — grup bukan lead
    var _stageNow = (_konv && _konv.stage) || 'new';
    var _vipNow = !!(_konv && _konv.vip);
    var _stageOpts = contactStageOptionsHtml(_stageNow);
    var _statusBadge = _konv ? statusBadgeHtml(_konv) : '';
    var _awaBadge = (_konv && _konv.awaiting && !_konv.flag) ? ' <span class="tag" style="background:#fecaca;color:#991b1b">menunggu</span>' : '';
    var _attnBadge = (_konv && _konv.needs_attention && waState.replyMode !== 'manual') ? ' <span class="tag" style="background:#fee2e2;color:#b91c1c">' + ico('triangle-alert',12) + ' perlu perhatian</span>' : '';
    var _vipBtnStyle = _vipNow
      ? 'background:#fef9c3;color:#92400e;border:1px solid #fbbf24'
      : 'background:transparent;color:var(--muted);border:1px solid var(--line)';
    // v1.2.125: wa-tampilan-sama — kepala chat seperti contoh: avatar | nama, nomor + via, Lead Rating | aksi; baris alat terpisah
    var _metaRow = _statusBadge + (_konv ? waFlagBadgeHtml(_konv) : '') + _awaBadge + _attnBadge +
        ((_konv && _konv.flag === 'done' && _konv.flag_note) ? '<span style="color:var(--muted)">' + esc(_konv.flag_note) + '</span>' : '');
    var _csNow = CONTACT_STAGE[_stageNow] || CONTACT_STAGE.new;   // v1.2.124: wa-layout-penuh — Lead Rating di bawah nama/nomor
    var _vipHtml = '<button type="button" id="waVipToggle" data-vip="' + (_vipNow ? '1' : '0') + '" title="' + (_vipNow ? 'VIP \u2014 klik untuk hapus tanda' : 'Tandai sebagai kontak VIP') + '" style="' + _vipBtnStyle + ';border-radius:6px;padding:3px 7px;display:' + (_stageNow === 'active_customer' ? 'inline-flex' : 'none') + ';align-items:center;gap:3px;cursor:pointer">' + ico('star',13) + ' VIP</button>';
    var _viaTxt = (_konv && _konv.ch_label && (res.channels || []).length > 1) ? (_nama ? ' · ' : '') + '<span class="wa-th-via" title="Balasan dikirim dari nomor ini">via ' + esc(_konv.ch_label) + '</span>' : '';
    var _wide151 = waCtlWide();
    var _fb164 = '<button type="button" class="wa-ibtn' + (waState.findOpen ? ' on' : '') + '" id="waFindBtn" title="Cari di chat ini (Ctrl+F)">' + ico('search', 16) + '</button>';   // v1.2.164: cari-simpan
    var _rate151 = '<div class="wa-rate-row"><label class="wa-rate" title="Lead Rating" style="background:' + _csNow.bg + ';color:' + _csNow.fg + '">' + ico('tag',12) +
            '<select id="waStageSelect">' + _stageOpts + '</select>' + ico('chevron-down',12) + '</label>' +
          tfThreadRowHtml(res) + '</div>';
    if (_wide151) {
      var _mine151 = isMine ? '<span class="tag" style="background:#d1fae5;color:#065f46;flex:none">' + ico('user-round',12) + ' Saya</span>' : '';
      $('#waThreadHead').innerHTML =
        '<div class="wa-th-top wa-th-slim">' + waAvatarHtml(_nama, res.number, 36) +
          '<div class="wa-th-id"><div class="wa-th-name">' + esc(_nama || ('+' + res.number)) + ' <a href="#" id="waEditName" title="Ubah nama" style="text-decoration:none;font-size:12px;font-weight:400">' + ico('pen-tool',12) + '</a></div>' +
          '<div class="wa-th-sub">' + (res.group ? ico('users', 12) + ' Grup WhatsApp' : (_nama ? '+' + esc(res.number) : '')) + _viaTxt + '</div></div>' + _mine151 + _fb164 +
        '</div>';
      waInfoRender(res, _konv, claim,
        '<div class="wa-ctl">' +
          '<div class="wa-ctl-act">' + actionBtns + '</div>' +
          '<div class="wa-ctl-lbl">Lead rating &amp; topik</div>' + _rate151 +
          '<div class="wa-ctl-meta">' + _statusBadge + (_konv ? waFlagBadgeHtml(_konv) : '') + _awaBadge + _attnBadge + '</div>' +
          '<div class="wa-th-tools">' + toolBtns + _vipHtml + _leadLink + '</div>' +
        '</div>');
      waState.ctlWide = true;
    } else {
    waState.ctlWide = false;
    $('#waThreadHead').innerHTML =
      '<div class="wa-th-top">' +
        '<button type="button" class="wa-th-back" id="waThBack" title="Kembali ke daftar">' + ico('arrow-left',18) + '</button>' +
        waAvatarHtml(_nama, res.number, 44) +
        '<div class="wa-th-id">' +
          '<div class="wa-th-name">' + esc(_nama || ('+' + res.number)) + ' <a href="#" id="waEditName" title="Ubah nama" style="text-decoration:none;font-size:12px;font-weight:400">' + ico('pen-tool',12) + '</a></div>' +
          '<div class="wa-th-sub">' + (res.group ? ico('users', 12) + ' Grup WhatsApp' : (_nama ? '+' + esc(res.number) : '')) + _viaTxt + '</div>' +
        '</div>' +
        '<div class="wa-th-act">' + actionBtns + '<button type="button" class="wa-th-more" id="waThMore" title="Serahkan, pindah nomor, VIP, lead">' + ico('more-horizontal',18) + '</button></div>' +
      '</div>' +
      _rate151 +   // v1.2.166: topik-ringkas-hp — Lead Rating + topik baris sendiri (keluar dari kolom nama), tanpa grid display:contents

      '<div class="wa-th-tools"><div class="wa-sheet-hd"><b>Alat chat</b><button type="button" id="waSheetClose" aria-label="Tutup">' + ico('x',18) + '</button></div>' + _metaRow + toolBtns + ' <a href="#" id="waFindBtn" style="font-size:12px">' + ico('search', 13) + ' Cari di chat ini</a>' + _vipHtml + _leadLink + '</div>';   // v1.2.151: lembar bawah di HP
    $('#waThreadHead').classList.toggle('tools-open', !!waState.thTools);
    if ($('#waThBack')) $('#waThBack').onclick = function () { var w = document.querySelector('.wachat-wrap'); if (w) w.classList.remove('showing-thread'); };
    if ($('#waThMore')) $('#waThMore').onclick = function (ev) { ev.stopPropagation(); waState.thTools = !waState.thTools; $('#waThreadHead').classList.toggle('tools-open', waState.thTools); };
    if ($('#waSheetClose')) $('#waSheetClose').onclick = function () { waState.thTools = false; $('#waThreadHead').classList.remove('tools-open'); };
    waInfoRender(res, _konv, claim);
    }
    waCtlBind151();
    if ($('#waFindBtn')) $('#waFindBtn').onclick = function (ev) { if (ev) ev.preventDefault(); waState.thTools = false; if ($('#waThreadHead')) $('#waThreadHead').classList.remove('tools-open'); if (waState.findOpen) waFindClose164(); else waFindOpen164(); };   // v1.2.164: cari-simpan
    tfBindThread(num, res);   // v1.2.138: filter-topik
    slBindThread203(num, res);   // v1.2.203: sales-tag
    // Attach event handlers
    if ($('#waEditName')) $('#waEditName').onclick = function (ev) { ev.preventDefault(); editWaContactName(num); };  // v1.2.19
    // v1.2.39 fase2f: dropdown kategori + tombol toggle VIP
    if ($('#waStageSelect')) {
      $('#waStageSelect').onchange = function () {
        var stage = this.value;
        var vipBtn = $('#waVipToggle');
        var vip = (stage === 'active_customer') ? !!(vipBtn && vipBtn.dataset.vip === '1') : false;
        if (vipBtn) vipBtn.style.display = (stage === 'active_customer') ? 'inline-flex' : 'none';
        saveContactStage(num, stage, vip);
      };
    }
    if ($('#waVipToggle')) {
      $('#waVipToggle').onclick = function () {
        var stage = $('#waStageSelect') ? $('#waStageSelect').value : 'active_customer';
        var newVip = this.dataset.vip !== '1';
        this.dataset.vip = newVip ? '1' : '0';
        this.style.background = newVip ? '#fef9c3' : 'transparent';
        this.style.color = newVip ? '#92400e' : 'var(--muted)';
        this.style.border = newVip ? '1px solid #fbbf24' : '1px solid var(--line)';
        saveContactStage(num, stage, newVip);
      };
    }
    // v1.2.21
    if ($('#waOpenLead')) $('#waOpenLead').onclick = function (ev) { ev.preventDefault(); showTab('leads'); };
    if ($('#waMakeLead')) $('#waMakeLead').onclick = function (ev) {
      ev.preventDefault();
      if (!confirm('Analisa percakapan ini jadi lead?\n\nMemakai 1 jatah kuota chat.')) return;
      toast('Menganalisa...');
      api('analyze_lead', { method: 'POST', body: { number: num } }).then(function (r) {
        if (r && r.ok) {
          toast('Lead dibuat.');
          fetchWaConvs();          // perbarui has_lead
          showTab('leads');
          if (typeof fetchLeads === 'function') fetchLeads();
        } else {
          toast((r && r.error) || 'Analisa gagal.', true);
        }
      });
    };
    if ($('#waClaimBtn')) $('#waClaimBtn').onclick = function () { claimNumber(num); };
    if ($('#waReleaseBtn')) $('#waReleaseBtn').onclick = function () { releaseNumber(num); };
    if ($('#waRequestTakeoverBtn')) $('#waRequestTakeoverBtn').onclick = function () { openRequestTakeoverModal(num); };
    if ($('#waTakeoverApproveBtn')) $('#waTakeoverApproveBtn').onclick = function () { respondTakeover(num, 'approve'); };
    if ($('#waTakeoverDenyBtn')) $('#waTakeoverDenyBtn').onclick = function () { respondTakeover(num, 'deny'); };
    if ($('#waAdminTakeoverBtn')) $('#waAdminTakeoverBtn').onclick = function () { openAdminTakeoverModal(num); };
    if ($('#waAssignSel')) $('#waAssignSel').onchange = function () {   // v1.2.58; v1.2.201: transfer-nomor: nilai 'ch:<id>' = pindah nomor bisnis
      var v = this.value;
      if (v.indexOf('ch:') === 0) { var id = v.slice(3), tc = (res.channels || []).filter(function (c) { return c.id === id; })[0]; moveWaChan(num, id, this, (tc && tc.prov) || res.wa_prov); }
      else assignNumber(num, v, this);
    };
    if ($('#waChMoveSel')) $('#waChMoveSel').onchange = function () { var tc128 = (res.channels || []).filter(function (c) { return c.id === this.value; }, this)[0]; moveWaChan(num, this.value, this, (tc128 && tc128.prov) || res.wa_prov); };   // v1.2.116; v1.2.128: wa-campur
    if ($('#waResolveBtn')) $('#waResolveBtn').onclick = function () { resolveConv(num); };   // v1.2.101

    // v1.2.123: wa-scroll-stabil — catat posisi SEBELUM render: di bawah? atau bubble mana yang sedang terlihat
    var _waBody = $('#waThreadBody');
    var _waSame = waState.bodyNum === num;
    var _sc = waScroller(), _win = _sc && _sc !== _waBody;   // desktop: kotak thread; HP: halaman
    var _waWasBottom = _sc ? (_win ? (_waSame && (waState.waStick || waScGap(_sc) < 60))
                                   : (!_waSame || waState.waStick || waScGap(_sc) < 60)) : true;
    var _waPrevTop = _sc ? _sc.scrollTop : 0;
    var _waAnc = null;
    if (_sc && _waSame && !_waWasBottom) {
      var _bt = waScTop(_sc), _ks = _waBody.querySelectorAll('[data-k]');
      for (var _i = 0; _i < _ks.length; _i++) {
        var _rc = _ks[_i].getBoundingClientRect();
        if (_rc.bottom > _bt + 1) { _waAnc = { k: _ks[_i].getAttribute('data-k'), off: _rc.top - _bt }; break; }
      }
    }

    var _waLastDate = '';   // v1.2.15: reset tiap render -> aman untuk polling
    var _chL = {}; (res.channels || []).forEach(function (c) { _chL[c.id] = c.label; });   // v1.2.98: multi-nomor
    var _chMulti = (res.channels || []).length > 1;
    var _wiH = wiThreadHtml(res);   // v1.2.105: riwayat sebelum terhubung di atas pesan live
    // v1.2.163: thread-lengkap: tombol muat pesan sebelumnya (server mengirim N entri terbaru + total)
    var _more163 = Math.max(0, (+res.total || 0) - (res.messages || []).length);
    var _moreH163 = _more163 > 0 ? '<div style="text-align:center;margin:6px 0 10px"><button type="button" class="btn ghost" id="waMoreBtn" style="padding:6px 14px;font-size:12px;display:inline-flex;align-items:center;gap:4px">' +
      ico('chevron-down', 13, 'style="transform:rotate(180deg)"') + ' Muat pesan sebelumnya (' + _more163 + ' lagi)</button></div>' : '';
    var _waHtml = (res.group ? '<div style="text-align:center;margin:6px 0 10px"><span class="tag" style="background:#e0f2fe;color:#075985">' + ico('users', 12) + ' Chat grup — bot tidak membalas di grup, hanya balasan manual</span></div>' : '') /* v1.2.170: grup-wa */ + _wiH + _moreH163 + (res.messages || []).map(function (m) {   // v1.2.123: dirakit dulu, dipasang hanya bila berubah
      var h = '';
      var _dk = waDateKey(m.ts);
      if (_dk && _dk !== _waLastDate) {   // v1.2.15: tanggal berganti -> sisip pemisah
        h += waDateSepHtml(waDateLabel(_dk));
        _waLastDate = _dk;
      }
      if (m.call_txt) h += waCallPill(m.call_txt, m.ts, (_chMulti && m.ch) ? (_chL[m.ch] || '') : '');   // v1.2.108: tolak-telepon
      if (m.q) h += waBubble(m.q, 'in', m.ts, m.media, (_chMulti && m.ch) ? (_chL[m.ch] || '') : '', { id: m.wamid, reply_to: m.reply_to, k: 'q' + m.ts + (m.wamid || ''), gf: m.g_from /* v1.2.170: grup-wa */ });   // v1.2.121   // v1.2.94: media milik pesan tamu, atau balasan HP bila q kosong
      var _fotoOnly = m.media_out && m.media_out.length && /^\[Foto/.test(m.a || '');   // v1.2.95: kb-foto
      if (m.a && !_fotoOnly) h += waBubble(m.a, m.dir === 'manual' ? 'manual' : 'bot', m.ts, m.q ? null : m.media, '', { id: m.out_id, reply_to: m.q ? null : m.reply_to, k: 'a' + m.ts + (m.out_id || ''), act: m.act, edt: m.edited, del: m.deleted });   // v1.2.121; v1.2.200: edit-hapus-pesan
      if (m.a && !_fotoOnly) h += warNote209(m);   // v1.2.209: autoreply-hp
      (m.media_out || []).forEach(function (md, j) { h += waBubble('', 'bot', m.ts, md, '', { k: 'o' + j + m.ts }); });   // v1.2.123
      return h;
    }).join('') || '<div style="color:var(--muted);margin:auto">Belum ada pesan.</div>';
    waState.sched = res.sched || []; waState.schedWinEnd = res.win_end || 0; waState.schedNum = num;   // v1.2.153: jadwal-kirim
    _waHtml += waSchedHtml(waState.sched);
    // v1.2.123: wa-scroll-stabil — isi sama persis (polling tanpa pesan baru): DOM & gambar dibiarkan, posisi tidak disentuh
    if (_waBody && !(_waSame && waState.bodyHtml === _waHtml)) {
      _waBody.innerHTML = _waHtml;
      waState.bodyNum = num; waState.bodyHtml = _waHtml;
      _sc = waScroller(); _win = _sc && _sc !== _waBody;
      if (!_sc) {}
      else if (_waWasBottom) {
        _sc.scrollTop = _sc.scrollHeight;   // ikuti chat
        waState.waStick = true; waState.waLastTop = _sc.scrollTop;
      } else if (!_waSame && _win) {
        waState.waStick = false; waState.waLastTop = _sc.scrollTop;   // HP: buka chat lain, posisi halaman tidak diubah (seperti sebelumnya)
      } else {
        // sedang membaca pesan lama: kunci ke bubble yang tadi terlihat
        var _el = null;
        if (_waAnc) { var _ks2 = _waBody.querySelectorAll('[data-k]'); for (var _j = 0; _j < _ks2.length; _j++) { if (_ks2[_j].getAttribute('data-k') === _waAnc.k) { _el = _ks2[_j]; break; } } }
        if (_el) _sc.scrollTop += (_el.getBoundingClientRect().top - waScTop(_sc)) - _waAnc.off;
        else _sc.scrollTop = _waPrevTop;
        waState.waStick = false; waState.waLastTop = _sc.scrollTop;
      }
    }

    wiThreadBind(res);   // v1.2.105
    waJumpApply164(num);   // v1.2.164: cari-simpan
    if ($('#waMoreBtn')) $('#waMoreBtn').onclick = function () {   // v1.2.163: thread-lengkap
      this.disabled = true; this.textContent = 'Memuat…';
      waState.thLim = waState.thLim || {}; waState.thLim[num] = ((waState.thLim[num] || 60) + 100);
      waState.waStick = false; fetchWaThread(num);
    };
    $('#waReplyBar').style.display = 'block';
    if (waState.waStick && (_sc = waScroller())) { _sc.scrollTop = _sc.scrollHeight; waState.waLastTop = _sc.scrollTop; }   // v1.2.123: kotak balas memperkecil area chat
    var open = res.window_open;
    // Reply hanya enable kalau isMine ATAU isAdmin (untuk emergency)
    var canReply = open && (isMine || waState.isAdmin);
    var _rsBlock = res.reply_ok === false;   // v1.2.119: agent-stage
    if (_rsBlock) {
      canReply = false;
      ['#waClaimBtn', '#waRequestTakeoverBtn'].forEach(function (id) { if ($(id)) $(id).style.display = 'none'; });
      if ($('#waStageSelect')) $('#waStageSelect').disabled = true;
      if ($('#waVipToggle')) $('#waVipToggle').disabled = true;
    }
    $('#waReplyInput').disabled = !canReply;
    $('#waReplySend').disabled = !canReply;
    if ($('#waAttachBtn')) $('#waAttachBtn').disabled = !canReply || res.wa_prov === 'fonnte';   // v1.2.120: wa-lampiran
    if ($('#waQrBtn')) $('#waQrBtn').disabled = !canReply;   // v1.2.122: template-balasan
    if ($('#waSchedBtn')) $('#waSchedBtn').disabled = !canReply;   // v1.2.153: jadwal-kirim
    if (!canReply || (waState.schedOpen && waState.schedOpen !== num)) waSchedClose();
    if (!canReply) waQrClose();
    if (waState.attach && waState.attachNum !== num) waAttachClear();
    if (waState.replyTo && (waState.replyTo.num !== num || !canReply)) waQuoteClear();   // v1.2.121
    $('#waWindowNote').innerHTML = _rsBlock
      ? '<span style="color:#b45309">' + ico('ban',13) + ' Akun Anda hanya membalas kontak dengan Lead Rating <strong>' + esc((res.reply_stages || []).map(rsLabel).join(', ')) + '</strong>. Chat ini: ' + esc(rsLabel(res.stage || 'new')) + (res.vip ? ' + VIP' : '') + ' — minta Supervisor/Admin menyerahkan ke agent lain.</span>'
      : open
      ? (isMine ? '<span style="color:#065f46">' + ico('check-circle-2',13) + ' Anda mengelola chat ini.</span>'
          : (claim ? '<span style="color:var(--muted)">Chat dikelola oleh <strong>' + esc(claim.agent_username) + '</strong>. Klik "Minta Take-over" untuk request handling.</span>'
              : (waState.replyMode === 'manual'
                  ? '<span style="color:var(--muted)">Klik <strong>Claim</strong> untuk menangani chat ini' + (waState.isAdmin ? ', atau serahkan ke agent' : '') + '.</span>'
                  : '<span style="color:var(--muted)">Tip: klik <strong>Claim</strong> agar bot berhenti dan Anda handle sendiri.</span>')))
      : ico('triangle-alert',13) + ' Jendela 24 jam tertutup' + (res.win_per_ch ? ' untuk nomor ini' : '') + ' — WhatsApp tidak mengizinkan balasan teks bebas sampai pelanggan mengirim pesan lagi' + (res.win_per_ch ? ' ke nomor ini. Kirim template lewat Blast dari nomor ini.' : '.');   // v1.2.116
    // v1.2.125: wa-tampilan-sama — belum di-claim: bar "Claim & Balas" menggantikan kotak ketik
    var _needClaim = open && !claim && !_rsBlock && !!$('#waClaimBtn');
    var _noCl = !!(waState.noClaim && waState.noClaim[num]);
    if (_needClaim) {
      $('#waWindowNote').innerHTML = '<div class="wa-claimbar"><span>' + (waState.replyMode === 'manual'
          ? '<b>Antrean</b> — klik Claim untuk membalas' + (waState.isAdmin ? ', atau serahkan ke agent' : '') + '.'
          : '<b>Dijawab bot</b> — klik Claim agar bot berhenti dan Anda membalas sendiri.') +
        ((canReply && !_noCl) ? ' <a href="#" id="waNoClaimReply" title="Balas tanpa mengambil alih chat">Balas tanpa claim</a>' : '') + '</span>' +
        '<button type="button" class="btn" id="waClaimBar">' + ico('hand',14) + ' Claim &amp; Balas</button></div>';
    }
    if ($('#waComposeRow')) $('#waComposeRow').style.display = (_needClaim && !_noCl) ? 'none' : 'flex';
    if ($('#waClaimBar')) $('#waClaimBar').onclick = function () { waState.focusAfter = num; claimNumber(num); };
    if ($('#waNoClaimReply')) $('#waNoClaimReply').onclick = function (ev) {
      ev.preventDefault(); waState.noClaim = waState.noClaim || {}; waState.noClaim[num] = true; this.style.display = 'none';
      if ($('#waComposeRow')) $('#waComposeRow').style.display = 'flex'; $('#waReplyInput').focus();
    };
    if (waState.focusAfter === num && claim && canReply) { waState.focusAfter = null; setTimeout(function () { if ($('#waReplyInput')) $('#waReplyInput').focus(); }, 60); }
  }

  // === Claim actions ========================================================

  function claimNumber(num) {
    api('wa_claim', { method: 'POST', body: { number: num } }).then(function (res) {
      if (res && res.ok) {
        toast('Anda claim chat ini.');
        var _p125 = fetchWaConvs(); if (_p125 && _p125.then) _p125.then(function () { fetchWaThread(num); }); else fetchWaThread(num);   // v1.2.125
      } else toast((res && res.error) || 'Gagal claim.', true);
    });
  }

  // v1.2.58: serahkan / pindahkan chat ke agent (Supervisor/Admin)
  function assignNumber(num, agent, sel) {
    if (!agent) return;
    var label = sel && sel.options[sel.selectedIndex] ? sel.options[sel.selectedIndex].text : agent;
    if (!confirm('Serahkan chat ini ke ' + label + '?')) { if (sel) sel.value = ''; return; }
    api('wa_assign', { method: 'POST', body: { number: num, agent: agent } }).then(function (res) {
      if (res && res.ok) { toast('Chat diserahkan ke ' + agent + '.'); fetchWaConvs().then(function () { fetchWaThread(num); }); }
      else { toast((res && res.error) || 'Gagal menyerahkan chat.', true); if (sel) sel.value = ''; }
    });
  }

  // v1.2.116: pindah-nomor
  function moveWaChan(num, ch, sel, prov) {
    if (!ch) return;
    var label = sel.options[sel.selectedIndex] ? sel.options[sel.selectedIndex].text : ch;
    label = label.replace(/\s*\(\+\d+\)$/, '');   // v1.2.201: transfer-nomor
    var msg = 'Pindahkan chat ini ke nomor ' + label + '?\n\nBalasan berikutnya (agent & bot) dikirim dari nomor itu. Jika pelanggan masih membalas ke nomor lama, chat otomatis kembali ke nomor lama.';
    if (prov === 'meta') msg += '\n\nWhatsApp API resmi: nomor baru belum punya jendela 24 jam dengan pelanggan ini. Kirim template dulu lewat Blast dari nomor itu; balasan teks bebas aktif setelah pelanggan membalas.';
    if (!confirm(msg)) { sel.value = ''; return; }
    api('wa_set_ch', { method: 'POST', body: { number: num, ch: ch } }).then(function (res) {
      if (res && res.ok) {
        toast(res.note || ('Chat dipindah ke ' + (res.label || label) + (res.agent ? ' · diserahkan ke ' + res.agent : '') + '.'));
        fetchWaConvs().then(function () { fetchWaThread(num); });
      } else { toast((res && res.error) || 'Gagal memindah nomor.', true); sel.value = ''; }
    });
  }

  function releaseNumber(num) {
    var manual = waState.replyMode === 'manual';   // v1.2.58
    if (!confirm(manual ? 'Lepas chat ini ke antrean? Agent lain bisa meng-claim.' : 'Release chat ini? Bot akan resume balas otomatis.')) return;
    api('wa_release', { method: 'POST', body: { number: num } }).then(function (res) {
      if (res && res.ok) {
        toast(manual ? 'Chat dikembalikan ke antrean.' : 'Chat direlease. Bot resume.');
        fetchWaThread(num); fetchWaConvs();
      } else toast((res && res.error) || 'Gagal release.', true);
    });
  }

  function openRequestTakeoverModal(num) {
    var reason = prompt('Alasan request take-over (opsional):', '');
    if (reason === null) return; // cancel
    api('wa_takeover_request', { method: 'POST', body: { number: num, reason: reason } }).then(function (res) {
      if (res && res.ok) {
        toast('Request take-over dikirim. Auto-approve dalam 5 menit kalau tidak ada respond.');
        fetchWaThread(num); fetchWaConvs();
      } else toast((res && res.error) || 'Gagal request.', true);
    });
  }

  function respondTakeover(num, decision) {
    var confirmMsg = decision === 'approve'
      ? 'Setujui take-over? Chat akan pindah ke requester.'
      : 'Tolak take-over?';
    if (!confirm(confirmMsg)) return;
    api('wa_takeover_respond', { method: 'POST', body: { number: num, decision: decision } }).then(function (res) {
      if (res && res.ok) {
        toast(decision === 'approve' ? 'Take-over disetujui.' : 'Take-over ditolak.');
        fetchWaThread(num); fetchWaConvs();
      } else toast((res && res.error) || 'Gagal respond.', true);
    });
  }

  function openAdminTakeoverModal(num) {
    var reason = prompt('Alasan admin take-over (untuk audit log):', 'escalation');
    if (reason === null) return;
    api('wa_admin_takeover', { method: 'POST', body: { number: num, reason: reason } }).then(function (res) {
      if (res && res.ok) {
        toast('Admin take-over sukses. Chat sekarang milik Anda.');
        fetchWaThread(num); fetchWaConvs();
      } else toast((res && res.error) || 'Gagal takeover.', true);
    });
  }

  /* ---- v1.2.120: wa-lampiran — lampirkan file di balasan Percakapan WA ---- */
  var WA_ATT_KIND = { jpg: 'image', jpeg: 'image', png: 'image', mp4: 'video', '3gp': 'video',
    mp3: 'audio', ogg: 'audio', m4a: 'audio', aac: 'audio', amr: 'audio',
    pdf: 'document', doc: 'document', docx: 'document', xls: 'document', xlsx: 'document', ppt: 'document', pptx: 'document', txt: 'document', csv: 'document', zip: 'document' };
  var WA_ATT_MB = { image: 5, video: 16, audio: 16, document: 16 };
  function waFmtSize(n) { return n >= 1048576 ? (n / 1048576).toFixed(1).replace('.', ',') + ' MB' : Math.max(1, Math.round(n / 1024)) + ' KB'; }
  function waAttachClear() {
    if (waState.attachUrl) { try { URL.revokeObjectURL(waState.attachUrl); } catch (e) {} }
    waState.attach = null; waState.attachNum = null; waState.attachUrl = null;
    if ($('#waAttachFile')) $('#waAttachFile').value = '';
    if ($('#waAttachChip')) { $('#waAttachChip').style.display = 'none'; $('#waAttachChip').innerHTML = ''; }
    if ($('#waReplyInput')) $('#waReplyInput').placeholder = 'Tulis balasan manual…';
    if (waState.schedOpen) waSchedMediaRow();   // v1.2.159: jadwal-media
  }
  function waAttachRender(status) {
    var f = waState.attach, chip = $('#waAttachChip');
    if (!f || !chip) return;
    var kind = WA_ATT_KIND[(f.name.split('.').pop() || '').toLowerCase()];
    var thumb = (kind === 'image' && waState.attachUrl)
      ? '<img src="' + waState.attachUrl + '" alt="" style="width:36px;height:36px;object-fit:cover;border-radius:6px">'
      : '<span style="display:inline-flex;color:var(--muted)">' + ico('paperclip', 16) + '</span>';
    chip.innerHTML = thumb + '<span style="flex:1;min-width:0;overflow:hidden;text-overflow:ellipsis;white-space:nowrap"><strong>' + esc(f.name) + '</strong> <span style="color:var(--muted)">' + waFmtSize(f.size) + '</span>' +
      (status ? ' <span style="color:var(--muted)">· ' + esc(status) + '</span>' : '') + '</span>' +
      (status ? '' : '<button type="button" id="waAttachX" title="Batalkan lampiran" style="border:0;background:transparent;cursor:pointer;color:var(--muted);display:inline-flex">' + ico('x', 16) + '</button>');
    chip.style.display = 'flex';
    if ($('#waAttachX')) $('#waAttachX').onclick = waAttachClear;
  }
  function waAttachInit() {
    if (!$('#waAttachBtn') || waState.attachBound) return;
    waState.attachBound = true;
    $('#waAttachBtn').onclick = function () { if (!this.disabled) $('#waAttachFile').click(); };
    $('#waAttachFile').onchange = function () {
      var f = this.files && this.files[0];
      if (!f || !waState.current) return;
      var ext = (f.name.split('.').pop() || '').toLowerCase(), kind = WA_ATT_KIND[ext];
      if (!kind) { toast('Jenis file .' + ext + ' belum didukung. Bisa: JPG/PNG, MP4, MP3/OGG/M4A, PDF, Word, Excel, PowerPoint, TXT, CSV, ZIP.', true); this.value = ''; return; }
      if (f.size > WA_ATT_MB[kind] * 1048576) { toast('Batas WhatsApp untuk file ini: ' + WA_ATT_MB[kind] + ' MB (file Anda ' + waFmtSize(f.size) + ').', true); this.value = ''; return; }
      if (waState.attachUrl) { try { URL.revokeObjectURL(waState.attachUrl); } catch (e) {} waState.attachUrl = null; }
      waState.attach = f; waState.attachNum = waState.current;
      if (kind === 'image') { try { waState.attachUrl = URL.createObjectURL(f); } catch (e) {} }
      $('#waReplyInput').placeholder = kind === 'audio' ? 'Audio dikirim tanpa keterangan' : 'Tulis keterangan (opsional)…';
      waAttachRender('');
      $('#waReplyInput').focus();
      waSchedMediaRow();   // v1.2.159: jadwal-media
    };
  }
  function sendWaMedia(num) {
    var inp = $('#waReplyInput'), f = waState.attach;
    if (!f) return;
    $('#waReplySend').disabled = true; $('#waAttachBtn').disabled = true;
    var kirim = function () {
      var fd = new FormData();
      fd.append('number', num); fd.append('caption', inp.value.trim()); fd.append('file', f, f.name);
      if (waState.replyTo && waState.replyTo.num === num) fd.append('reply_to', waState.replyTo.id);   // v1.2.121
      var xhr = new XMLHttpRequest();
      xhr.open('POST', API + '?action=wa_send_media&_=' + Date.now());
      xhr.setRequestHeader('X-Auth-Token', token);
      xhr.upload.onprogress = function (e) { if (e.lengthComputable) waAttachRender('mengunggah ' + Math.round(e.loaded / e.total * 100) + '%'); };
      xhr.upload.onload = function () { waAttachRender('mengirim ke WhatsApp…'); };
      var selesai = function (res) {
        if (res && res.ok) { inp.value = ''; waAttachClear(); waQuoteClear(); toast('File terkirim.'); fetchWaThread(num); fetchWaConvs(); }
        else { waAttachRender(''); toast((res && res.error) || 'Gagal mengirim file.', true); }
        $('#waReplySend').disabled = false; $('#waAttachBtn').disabled = false;
      };
      xhr.onload = function () {
        var fresh = xhr.getResponseHeader('X-Auth-Refresh');
        if (fresh) { try { token = fresh; localStorage.setItem(TK, fresh); } catch (e) {} }
        if (xhr.status === 401) { logout(); return; }
        var res = null; try { res = JSON.parse(xhr.responseText); } catch (e) {}
        if (!res) res = { ok: false, error: xhr.status === 413 ? 'File terlalu besar untuk server hosting.' : 'Respons tidak valid (HTTP ' + xhr.status + ').' };
        selesai(res);
      };
      xhr.onerror = function () { selesai({ ok: false, error: 'Koneksi terputus saat mengunggah.' }); };
      waAttachRender('mengunggah 0%');
      xhr.send(fd);
    };
    if (!waState.claimDetails[num]) api('wa_claim', { method: 'POST', body: { number: num } }).then(kirim, kirim);   // sama seperti balasan teks
    else kirim();
  }

  /* ---- v1.2.122: template-balasan — template balasan cepat (tombol Template / ketik "/") ---- */
  function waQrIsLead() { return !!user && ['super_admin', 'admin', 'supervisor'].indexOf(user.role) > -1; }
  function waQrLoad(force) {
    if (!force && waState.qrList && Date.now() - (waState.qrAt || 0) < 60000) return Promise.resolve(waState.qrList);
    return api('qr_list').then(function (r) {
      if (r && r.ok) { waState.qrList = r.items || []; waState.qrAt = Date.now(); }
      return waState.qrList || [];
    });
  }
  function waQrFill(t) {
    var nm = '', c = (waState.convs || []).filter(function (x) { return String(x.number) === String(waState.current); })[0];
    if (c && c.name) nm = String(c.name).trim();
    var ag = (user && (user.name || user.username)) || '';
    return String(t || '').replace(/\{nama\}/gi, nm).replace(/\{agen\}/gi, ag)
      .replace(/[ \t]{2,}/g, ' ').replace(/ +([,.!?])/g, '$1').replace(/^[ \t]+|[ \t]+$/gm, '');
  }
  function waQrMatch(q) {
    q = String(q || '').toLowerCase().trim();
    var l = waState.qrList || [];
    if (!q) return l.slice();
    var a = [], b = [];
    l.forEach(function (x) {
      var sc = String(x.shortcut || ''), hay = (x.title + ' ' + sc + ' ' + x.text + ' ' + (x.media ? x.media.name : '')).toLowerCase();   // v1.2.199: template-media
      if (sc && sc.indexOf(q) === 0) a.push(x); else if (hay.indexOf(q) > -1) b.push(x);
    });
    return a.concat(b);
  }
  function waQrAutosize() {
    var el = $('#waReplyInput'); if (!el || el.tagName !== 'TEXTAREA') return;
    el.style.height = 'auto'; el.style.height = Math.min(150, Math.max(38, el.scrollHeight + 2)) + 'px';
  }

  /* ---- v1.2.153: jadwal-kirim — jadwalkan pesan di thread Percakapan WA ---- */
  function waSchedFmt(ts) {
    var d = new Date(ts * 1000), now = new Date();
    var hm = ('0' + d.getHours()).slice(-2) + ':' + ('0' + d.getMinutes()).slice(-2);
    var t0 = new Date(now.getFullYear(), now.getMonth(), now.getDate()).getTime();
    var dd = Math.floor((new Date(d.getFullYear(), d.getMonth(), d.getDate()).getTime() - t0) / 86400000);
    if (dd === 0) return 'hari ini ' + hm;
    if (dd === 1) return 'besok ' + hm;
    var H = ['Min', 'Sen', 'Sel', 'Rab', 'Kam', 'Jum', 'Sab'], B = ['Jan', 'Feb', 'Mar', 'Apr', 'Mei', 'Jun', 'Jul', 'Agu', 'Sep', 'Okt', 'Nov', 'Des'];
    return H[d.getDay()] + ' ' + d.getDate() + ' ' + B[d.getMonth()] + (d.getFullYear() !== now.getFullYear() ? ' ' + d.getFullYear() : '') + ' ' + hm;
  }
  function waSchedHtml(list) {
    var ST = { skipped: 'Tidak dikirim', expired: 'Kedaluwarsa', failed: 'Gagal terkirim' };
    list = (list || []).filter(function (x) { return ['pending', 'sending', 'skipped', 'expired', 'failed'].indexOf(x.status) > -1; });
    var nBad = list.filter(function (x) { return x.can && x.status !== 'pending' && x.status !== 'sending'; }).length;   // v1.2.160: hapus-jadwal
    return list.map(function (x) {
      var live = x.status === 'pending' || x.status === 'sending';
      var meta = live
        ? ico('alarm-clock', 12) + ' <b>Terjadwal ' + esc(waSchedFmt(x.at)) + '</b><span>oleh ' + esc(x.by_name || x.by) + '</span>' +
          (x.cancel_on_reply ? '<span title="Batal otomatis bila pelanggan membalas sebelum jam kirim">· batal bila dibalas</span>' : '') +
          (x.status === 'sending' ? '<span>· sedang dikirim…</span>' : '') +
          (x.last_err ? '<span style="color:#b45309">· dicoba ulang: ' + esc(x.last_err) + '</span>' : '') +
          ((x.can && x.status === 'pending') ? '<a href="#" data-sact="edit" data-sid="' + esc(x.id) + '">Edit</a><a href="#" data-sact="now" data-sid="' + esc(x.id) + '">Kirim sekarang</a><a href="#" data-sact="cancel" data-sid="' + esc(x.id) + '" style="color:#b91c1c">Batal</a>' : '')
        : ico('triangle-alert', 12) + ' <b>' + esc(ST[x.status] || x.status) + '</b><span>(jadwal ' + esc(waSchedFmt(x.at)) + ')</span><span>' + esc(x.reason || '') + '</span>' +
          (x.can ? '<a href="#" data-sact="dismiss" data-sid="' + esc(x.id) + '">Hapus</a>' + (nBad > 1 ? '<a href="#" data-sact="dismissall" data-sid="' + esc(x.id) + '">Hapus semua (' + nBad + ')</a>' : '') : '');
      return '<div class="wa-sbub' + (live ? '' : ' bad') + '" data-k="s' + esc(x.id) + x.status + x.at + esc(x.media ? x.media.name : '') + '">' + waSchedMediaHtml(x, live) + esc(x.text) + '<div class="ws-meta">' + meta + '</div></div>';   // v1.2.159: jadwal-media
    }).join('');
  }
  function waSchedClose() {
    if (waState.schedEdit && $('#waReplyInput')) { $('#waReplyInput').value = ''; waQrAutosize(); }   // isi edit jangan tertinggal di kotak balas
    waState.schedOpen = null; waState.schedEdit = null;
    if ($('#waSchedPop')) { $('#waSchedPop').style.display = 'none'; $('#waSchedPop').innerHTML = ''; }
    if ($('#waSchedBtn')) $('#waSchedBtn').classList.remove('active');
  }
  function waSchedLocal(d) {   // Date -> nilai input datetime-local
    var p = function (n) { return ('0' + n).slice(-2); };
    return d.getFullYear() + '-' + p(d.getMonth() + 1) + '-' + p(d.getDate()) + 'T' + p(d.getHours()) + ':' + p(d.getMinutes());
  }
  function waSchedOpen(edit) {
    var pop = $('#waSchedPop'), num = waState.current; if (!pop || !num) return;
    waQrClose();
    waState.schedOpen = num; waState.schedEdit = edit ? edit.id : null;
    waState.schedEditMedia = (edit && edit.media) || null; waState.schedDrop = false;   // v1.2.159: jadwal-media
    if (edit) { $('#waReplyInput').value = edit.text; waQrAutosize(); }
    var d0 = edit ? new Date(edit.at * 1000) : new Date(Date.now() + 3600000);
    if (!edit) { d0.setMinutes(Math.ceil(d0.getMinutes() / 5) * 5, 0, 0); }
    var mn = new Date(Date.now() + 2 * 60000), mx = new Date(Date.now() + 30 * 86400000);
    pop.innerHTML =
      '<div style="display:flex;align-items:center;gap:6px;margin-bottom:8px"><strong>' + ico('alarm-clock', 14) + ' ' + (edit ? 'Ubah jadwal' : 'Jadwalkan pesan') + '</strong><span style="flex:1"></span>' +
        '<button type="button" id="wsX" title="Tutup" style="border:0;background:transparent;cursor:pointer;color:var(--muted);display:inline-flex">' + ico('x', 16) + '</button></div>' +
      '<div class="ws-row"><input type="datetime-local" id="wsAt" value="' + waSchedLocal(d0) + '" min="' + waSchedLocal(mn) + '" max="' + waSchedLocal(mx) + '"></div>' +
      '<div class="ws-row"><button type="button" class="ws-chip" data-q="1h">+1 jam</button><button type="button" class="ws-chip" data-q="3h">+3 jam</button>' +
        '<button type="button" class="ws-chip" data-q="tom">Besok 09:00</button><button type="button" class="ws-chip" data-q="mon">Senin 09:00</button></div>' +
      '<label class="ws-row" style="cursor:pointer;margin-bottom:8px"><input type="checkbox" id="wsCor"' + ((!edit || edit.cancel_on_reply) ? ' checked' : '') + '> Batalkan otomatis bila pelanggan membalas sebelum jam kirim</label>' +
      '<div id="wsMedia" style="font-size:12px;color:var(--muted);margin-bottom:8px"></div>' +
      '<div class="ws-warn" id="wsWarn" style="display:none"></div>' +
      '<div style="display:flex;gap:8px;align-items:center"><span class="help" style="margin:0;flex:1">Isi pesan &amp; lampiran diambil dari kotak balas.</span>' +
        '<button type="button" class="btn" id="wsGo">' + ico('alarm-clock', 14) + ' ' + (edit ? 'Simpan jadwal' : 'Jadwalkan') + '</button></div>';
    pop.style.display = 'block';
    if ($('#waSchedBtn')) $('#waSchedBtn').classList.add('active');
    waSchedMediaRow();
    var at = function () { var v = $('#wsAt').value; return v ? Math.floor(new Date(v).getTime() / 1000) : 0; };
    var check = function () {
      var t = at(), w = $('#wsWarn'), msg = '', we = waState.schedNum === num ? waState.schedWinEnd : 0;
      if (!t) msg = 'Pilih tanggal & jam kirim.';
      else if (t < Date.now() / 1000 + 120) msg = 'Waktu kirim minimal 2 menit dari sekarang.';
      else if (t > Date.now() / 1000 + 30 * 86400) msg = 'Jadwal paling lama 30 hari ke depan.';
      else if (we && t >= we) msg = 'Jendela 24 jam WhatsApp API resmi berakhir ' + waSchedFmt(we) + ' — pesan teks bebas tidak bisa dikirim setelah itu.';
      w.style.display = msg ? 'block' : 'none'; w.textContent = msg;
      $('#wsGo').disabled = !!msg;
      return !msg;
    };
    $('#wsAt').oninput = check;
    $$('#waSchedPop .ws-chip').forEach(function (b) { b.onclick = function () {
      var d = new Date(), q = b.dataset.q;
      if (q === '1h' || q === '3h') { d = new Date(Date.now() + (q === '1h' ? 1 : 3) * 3600000); d.setSeconds(0, 0); }
      else { d.setHours(9, 0, 0, 0); if (q === 'tom') d.setDate(d.getDate() + 1); else d.setDate(d.getDate() + (((8 - d.getDay()) % 7) || 7)); }
      $('#wsAt').value = waSchedLocal(d); check();
    }; });
    $('#wsX').onclick = waSchedClose;
    $('#wsGo').onclick = function () {
      if (!check()) return;
      var text = $('#waReplyInput').value.trim();
      var f = (waState.attach && waState.attachNum === num) ? waState.attach : null;   // v1.2.159: jadwal-media
      var keep = !f && waState.schedEditMedia && !waState.schedDrop;
      if (!text && !f && !keep) { toast('Tulis isi pesan atau pilih lampiran dulu.', true); $('#waReplyInput').focus(); return; }
      var kind = f ? WA_ATT_KIND[(f.name.split('.').pop() || '').toLowerCase()] : (keep ? waState.schedEditMedia.type : '');
      if (kind === 'audio' && text) { toast('Pesan suara tidak bisa diberi keterangan — kosongkan kotak balas, atau jadwalkan teksnya terpisah.', true); return; }
      if (kind && text.length > 1024) { toast('Keterangan lampiran maksimal 1.024 karakter.', true); return; }
      var btn = this; btn.disabled = true;
      var editing = waState.schedEdit, act = editing ? 'sched_update' : 'sched_create';
      var body = { text: text, at: at(), cancel_on_reply: $('#wsCor').checked ? 1 : 0 };
      if (editing) body.id = editing; else body.number = num;
      if (editing && waState.schedDrop && !f) body.remove_media = 1;
      var selesai = function (r) {
        btn.disabled = false;
        if (r && r.ok) {
          toast((editing ? 'Jadwal diperbarui: ' : 'Pesan dijadwalkan: ') + waSchedFmt(r.item.at) + '.');
          $('#waReplyInput').value = ''; waQuoteClear(); if (f) waAttachClear(); waQrAutosize(); waSchedClose();
          fetchWaThread(num); fetchWaConvs(true);
        } else { if (f) waAttachRender(''); toast((r && r.error) || 'Gagal menjadwalkan.', true); }
      };
      if (!f) { api(act, { method: 'POST', body: body }).then(selesai); return; }
      var fd = new FormData();
      Object.keys(body).forEach(function (k) { fd.append(k, body[k]); });
      fd.append('file', f, f.name);
      waSchedUpload(act, fd, function (p) { waAttachRender(p < 100 ? 'mengunggah ' + p + '%' : 'menyimpan jadwal…'); }, selesai);
    };
    check();
  }
  /* ---- v1.2.159: jadwal-media — lampiran ikut dijadwalkan ---- */
  function waSchedMediaRow() {
    var el = $('#wsMedia'), num = waState.current; if (!el || !waState.schedOpen) return;
    var f = (waState.attach && waState.attachNum === num) ? waState.attach : null, em = waState.schedEditMedia;
    if (f) el.innerHTML = ico('paperclip', 13) + ' Lampiran ikut dijadwalkan: <b>' + esc(f.name) + '</b> (' + waFmtSize(f.size) + ')' + (em && !waState.schedDrop ? ' — menggantikan ' + esc(em.name) : '');
    else if (em && !waState.schedDrop) el.innerHTML = ico('paperclip', 13) + ' Lampiran: <b>' + esc(em.name) + '</b> · <a href="#" id="wsMediaX" style="color:#b91c1c;font-weight:600;text-decoration:none">Hapus lampiran</a> · ganti lewat tombol lampiran';
    else el.innerHTML = ico('paperclip', 13) + ' Bisa menyertakan lampiran: pilih file lewat tombol lampiran.';
    if ($('#wsMediaX')) $('#wsMediaX').onclick = function (e) { e.preventDefault(); waState.schedDrop = true; waSchedMediaRow(); };
  }
  function waSchedMediaHtml(x, live) {
    var m = x.media; if (!m) return '';
    var lbl = { image: 'Gambar', video: 'Video', audio: 'Pesan suara', document: 'Dokumen' }[m.type] || 'Lampiran';
    if (live && m.type === 'image') return '<img src="' + API + '?action=sched_media&id=' + encodeURIComponent(x.id) + '&token=' + encodeURIComponent(waMediaTok()) + '" alt="' + esc(m.name || lbl) + '" loading="lazy" style="max-width:200px;max-height:200px;border-radius:8px;display:block;margin-bottom:6px" onerror="this.style.display=\'none\'">';
    return '<span class="ws-att">' + ico('paperclip', 14) + ' ' + esc(lbl) + ': ' + esc(m.name || '') + (m.size ? ' · ' + waFmtSize(m.size) : '') + '</span>';
  }
  function waSchedUpload(action, fd, onProg, cb) {
    var xhr = new XMLHttpRequest();
    xhr.open('POST', API + '?action=' + action + '&_=' + Date.now());
    xhr.setRequestHeader('X-Auth-Token', token);
    if (onProg) { xhr.upload.onprogress = function (e) { if (e.lengthComputable) onProg(Math.round(e.loaded / e.total * 100)); }; onProg(0); }
    xhr.onload = function () {
      var fresh = xhr.getResponseHeader('X-Auth-Refresh');
      if (fresh) { try { token = fresh; localStorage.setItem(TK, fresh); } catch (e) {} }
      if (xhr.status === 401) { logout(); return; }
      var res = null; try { res = JSON.parse(xhr.responseText); } catch (e) {}
      cb(res || { ok: false, error: xhr.status === 413 ? 'File terlalu besar untuk server hosting.' : 'Respons tidak valid (HTTP ' + xhr.status + ').' });
    };
    xhr.onerror = function () { cb({ ok: false, error: 'Koneksi terputus saat mengunggah.' }); };
    xhr.send(fd);
  }
  function waSchedInit() {
    if (waState.schedBound) return;
    waState.schedBound = true;
    if ($('#waSchedBtn')) $('#waSchedBtn').onclick = function () { if (this.disabled) return; if (waState.schedOpen) waSchedClose(); else waSchedOpen(null); };
    var body = $('#waThreadBody');
    if (body) body.addEventListener('click', function (ev) {
      var a = ev.target.closest ? ev.target.closest('[data-sact]') : null; if (!a) return;
      ev.preventDefault();
      var id = a.getAttribute('data-sid'), act = a.getAttribute('data-sact'), num = waState.current;
      var it = (waState.sched || []).filter(function (x) { return x.id === id; })[0]; if (!it) return;
      var done = function (r, ok) { if (r && r.ok) { toast(ok); fetchWaThread(num); fetchWaConvs(true); } else { toast((r && r.error) || 'Gagal.', true); fetchWaThread(num); } };
      if (act === 'edit') { waSchedOpen(it); $('#waReplyInput').focus(); }
      else if (act === 'cancel') { if (confirm('Batalkan pesan terjadwal ini?')) api('sched_cancel', { method: 'POST', body: { id: id } }).then(function (r) { if (waState.schedEdit === id) { waSchedClose(); $('#waReplyInput').value = ''; } done(r, 'Jadwal dibatalkan.'); }); }
      else if (act === 'dismiss') api('sched_dismiss', { method: 'POST', body: { id: id } }).then(function (r) { done(r, 'Dihapus dari percakapan.'); });   // v1.2.160
      else if (act === 'dismissall') api('sched_dismiss', { method: 'POST', body: { number: num } }).then(function (r) { done(r, (r && r.n) + ' jadwal gagal dihapus.'); });
      else if (act === 'now') { if (confirm('Kirim pesan ini sekarang?')) api('sched_send_now', { method: 'POST', body: { id: id } }).then(function (r) { done(r, 'Pesan terkirim.'); }); }
    });
  }

  function waQrClose() {
    waState.qrOpen = null;
    if ($('#waQrPop')) { $('#waQrPop').style.display = 'none'; $('#waQrPop').innerHTML = ''; }
  }
  // mode: 'btn' (dari tombol, ada kotak cari) | 'slash' (ketik "/" di kotak balas)
  function waQrOpen(mode, q) {
    var pop = $('#waQrPop'); if (!pop) return;
    waState.qrOpen = { mode: mode, q: q || '', sel: 0 };
    if (mode === 'btn') {
      pop.innerHTML = '<div style="padding:8px;border-bottom:1px solid var(--line)"><input type="text" id="waQrSearch" placeholder="Cari template…" autocomplete="off" style="width:100%"></div><div id="waQrList"></div>' + waQrFoot();
      pop.style.display = 'block';
      $('#waQrSearch').value = q || '';
      $('#waQrSearch').oninput = function () { waState.qrOpen.q = this.value; waState.qrOpen.sel = 0; waQrRenderList(); };
      $('#waQrSearch').onkeydown = waQrKey;
      setTimeout(function () { if ($('#waQrSearch')) $('#waQrSearch').focus(); }, 0);
    } else {
      pop.innerHTML = '<div id="waQrList"></div>' + waQrFoot();
      pop.style.display = 'block';
    }
    if ($('#waQrManage')) $('#waQrManage').onclick = function (e) { e.preventDefault(); waQrClose(); showTab('qrtpl'); };   // v1.2.199: template-menu: ke menu kiri
    waQrRenderList();
    waQrLoad(false).then(function () { if (waState.qrOpen) waQrRenderList(); });
  }
  function waQrFoot() {
    return '<div style="display:flex;justify-content:space-between;gap:8px;padding:6px 10px;border-top:1px solid var(--line);font-size:12px;color:var(--muted)">' +
      '<span>Ketik <strong>/</strong> di kotak balas untuk cari cepat · ↑↓ Enter</span>' +
      (waQrIsLead() ? '<a href="#" id="waQrManage">Kelola template</a>' : '') + '</div>';
  }
  function waQrRenderList() {
    var o = waState.qrOpen, box = $('#waQrList'); if (!o || !box) return;
    var l = waQrMatch(o.q);
    o.items = l;
    if (o.sel >= l.length) o.sel = Math.max(0, l.length - 1);
    if (!waState.qrList) { box.innerHTML = '<div style="padding:12px;color:var(--muted);font-size:13px">Memuat…</div>'; return; }
    if (!l.length) {
      box.innerHTML = '<div style="padding:12px;color:var(--muted);font-size:13px">' +
        (waState.qrList.length ? 'Tidak ada template yang cocok.' : 'Belum ada template.' + (waQrIsLead() ? ' Klik <strong>Kelola template</strong> untuk menambah.' : ' Minta Admin/Supervisor menambahkannya.')) + '</div>';
      return;
    }
    box.innerHTML = '<div style="max-height:230px;overflow-y:auto">' + l.map(function (x, i) {
      var prev = String(x.text).replace(/\s+/g, ' ');
      if (x.media) prev = '\uD83D\uDCCE ' + x.media.name + (prev ? ' \u00B7 ' + prev : '');   // v1.2.199: template-media
      return '<div class="wa-qr-it" data-i="' + i + '" style="padding:7px 12px;cursor:pointer;' + (i === o.sel ? 'background:var(--brand-soft)' : '') + '">' +
        '<div style="display:flex;gap:8px;align-items:center;font-size:13px"><strong style="overflow:hidden;text-overflow:ellipsis;white-space:nowrap">' + esc(x.title) + '</strong>' +
        (x.shortcut ? '<span class="tag" style="font-size:11px;padding:1px 6px">/' + esc(x.shortcut) + '</span>' : '') + '</div>' +
        '<div style="font-size:12px;color:var(--muted);overflow:hidden;text-overflow:ellipsis;white-space:nowrap">' + esc(prev) + '</div></div>';
    }).join('') + '</div>';
    $$('#waQrList .wa-qr-it').forEach(function (el) {
      el.onmousedown = function (e) { e.preventDefault(); waQrPick(+el.getAttribute('data-i')); };
    });
    var cur = box.querySelector('.wa-qr-it[data-i="' + o.sel + '"]');
    if (cur && cur.scrollIntoView) cur.scrollIntoView({ block: 'nearest' });
  }
  function waQrPick(i) {
    var o = waState.qrOpen; if (!o || !o.items || !o.items[i]) return;
    var t = waQrFill(o.items[i].text), inp = $('#waReplyInput');
    if (o.items[i].media) waQrAttach(o.items[i]);   // v1.2.199: template-media
    if (o.mode === 'slash' || !inp.value.trim()) inp.value = t;
    else {
      var s = inp.selectionStart != null ? inp.selectionStart : inp.value.length, e = inp.selectionEnd != null ? inp.selectionEnd : s;
      var pre = inp.value.slice(0, s), post = inp.value.slice(e);
      inp.value = pre + (pre && !/\s$/.test(pre) ? ' ' : '') + t + post;
    }
    waQrClose();
    inp.focus();
    try { inp.setSelectionRange(inp.value.length, inp.value.length); } catch (er) {}
    waQrAutosize();
  }
  /* v1.2.199: template-media: lampiran template dipasang ke kotak balas, lalu dikirim/dijadwalkan lewat jalur lampiran biasa */
  function waQrMediaUrl(id) { return API + '?action=qr_media&id=' + encodeURIComponent(id) + '&token=' + encodeURIComponent(waMediaTok()); }
  function waQrAttach(x) {
    var m = x.media, num = waState.current, chip = $('#waAttachChip'), send = $('#waReplySend');
    if (!m || !num) return;
    if (waState.attach && waState.attachNum === num) toast('Lampiran diganti dengan lampiran template.');
    var seq = waState.qrAttSeq = (waState.qrAttSeq || 0) + 1, sendWas = send ? send.disabled : false;
    if (send) send.disabled = true;
    if (chip) { chip.innerHTML = '<span style="display:inline-flex;color:var(--muted)">' + ico('paperclip', 16) + '</span><span style="flex:1;min-width:0;overflow:hidden;text-overflow:ellipsis;white-space:nowrap">Memuat lampiran template: <strong>' + esc(m.name) + '</strong>…</span>'; chip.style.display = 'flex'; }
    var xhr = new XMLHttpRequest();
    xhr.open('GET', API + '?action=qr_media&id=' + encodeURIComponent(x.id) + '&_=' + Date.now());
    xhr.setRequestHeader('X-Auth-Token', token);
    xhr.responseType = 'blob';
    var gagal = function (why) {
      if (seq !== waState.qrAttSeq) return;
      if (send) send.disabled = sendWas;
      if (waState.attach && waState.attachNum === num) waAttachRender(''); else if (chip) { chip.style.display = 'none'; chip.innerHTML = ''; }
      toast('Lampiran template gagal dimuat' + (why ? ' (' + why + ')' : '') + '. Lampirkan manual lewat tombol lampiran.', true);
    };
    xhr.onload = function () {
      if (seq !== waState.qrAttSeq) return;
      if (xhr.status === 401) { logout(); return; }
      if (xhr.status !== 200 || !xhr.response) { gagal(xhr.status === 404 ? 'file tidak ada di server' : 'HTTP ' + xhr.status); return; }
      if (waState.current !== num) { if (send) send.disabled = sendWas; return; }
      var f;
      try { f = new File([xhr.response], m.name, { type: m.mime || xhr.response.type }); } catch (e) { f = xhr.response; try { f.name = m.name; } catch (e2) {} }
      if (waState.attachUrl) { try { URL.revokeObjectURL(waState.attachUrl); } catch (e) {} waState.attachUrl = null; }
      waState.attach = f; waState.attachNum = num;
      if (m.type === 'image') { try { waState.attachUrl = URL.createObjectURL(f); } catch (e) {} }
      if ($('#waReplyInput')) $('#waReplyInput').placeholder = m.type === 'audio' ? 'Audio dikirim tanpa keterangan' : 'Tulis keterangan (opsional)…';
      if (send) send.disabled = sendWas;
      waAttachRender('');
      if (waState.schedOpen) waSchedMediaRow();
    };
    xhr.onerror = function () { gagal('koneksi terputus'); };
    xhr.send();
  }
  function waQrKey(e) {
    var o = waState.qrOpen; if (!o) return false;
    var n = (o.items || []).length;
    if (e.key === 'ArrowDown') { o.sel = n ? (o.sel + 1) % n : 0; waQrRenderList(); }
    else if (e.key === 'ArrowUp') { o.sel = n ? (o.sel - 1 + n) % n : 0; waQrRenderList(); }
    else if (e.key === 'Enter' || e.key === 'Tab') { if (!n) { if (o.mode === 'slash' && e.key === 'Enter') return false; waQrClose(); } else waQrPick(o.sel); }
    else if (e.key === 'Escape') { waQrClose(); if (o.mode === 'btn') $('#waReplyInput').focus(); }
    else return false;
    e.preventDefault(); e.stopImmediatePropagation();
    return true;
  }
  function waQrInit() {
    var inp = $('#waReplyInput');
    if (!inp || waState.qrBound) return;
    waState.qrBound = true;
    $('#waQrBtn').onclick = function () {
      if (this.disabled) return;
      if (waState.qrOpen && waState.qrOpen.mode === 'btn') { waQrClose(); return; }
      waQrOpen('btn', '');
    };
    // capture: berjalan sebelum handler Enter = kirim (bawaan)
    inp.addEventListener('keydown', function (e) {
      if (waState.qrOpen && waState.qrOpen.mode === 'slash' && waQrKey(e)) return;
      if (e.key === 'Enter' && e.shiftKey) { e.stopImmediatePropagation(); return; }   // Shift+Enter = baris baru
      if (e.key === 'Enter' && !e.isComposing) e.preventDefault();                      // Enter = kirim (tanpa baris baru)
    }, true);
    inp.addEventListener('input', function () {
      waQrAutosize();
      var m = /^\/(\S{0,30})$/.exec(inp.value);
      if (m && !inp.disabled) {
        if (!waState.qrOpen || waState.qrOpen.mode !== 'slash') waQrOpen('slash', m[1]);
        else { waState.qrOpen.q = m[1]; waState.qrOpen.sel = 0; waQrRenderList(); }
      } else if (waState.qrOpen && waState.qrOpen.mode === 'slash') waQrClose();
    });
    inp.addEventListener('blur', function () { setTimeout(function () { if (waState.qrOpen && waState.qrOpen.mode === 'slash' && document.activeElement !== inp) waQrClose(); }, 150); });
    document.addEventListener('mousedown', function (e) {
      var o = waState.qrOpen; if (!o || o.mode !== 'btn') return;
      if (!e.target.closest('#waQrPop') && !e.target.closest('#waQrBtn')) waQrClose();
    });
  }
  /* Kelola template (Super Admin/Admin/Supervisor) */
  var qrtplRefresh = null;   // v1.2.199: template-menu
  function waQrManager(host) {   // v1.2.199: template-menu: host = isi halaman menu Template Balasan (tanpa = modal)
    var ov = document.createElement('div');
    ov.id = 'waQrMgr';
    ov.style.cssText = 'position:fixed;inset:0;background:rgba(15,23,42,.45);z-index:9999;display:flex;align-items:center;justify-content:center;padding:16px';
    ov.innerHTML = '<div class="card" style="width:100%;max-width:720px;max-height:92vh;overflow:auto;margin:0">' +
      '<div style="display:flex;justify-content:space-between;align-items:center;gap:10px;margin-bottom:10px"><h3 style="margin:0">Template Balasan WA</h3>' +
      '<button type="button" id="qrmX" class="btn ghost sm" title="Tutup">' + ico('x', 16) + '</button></div>' +
      '<p class="help" style="margin:0 0 12px">Dipakai semua agent dari kotak balas Percakapan WA (tombol ' + ico('file-text', 13) + ' atau ketik <strong>/pintasan</strong>). ' +
      'Variabel: <code>{nama}</code> = nama kontak, <code>{agen}</code> = nama pengirim. Template bisa membawa lampiran (gambar, video, dokumen, audio) yang ikut terpasang saat dipilih.</p>' +
      '<div style="border:1px solid var(--line);border-radius:10px;padding:12px;margin-bottom:12px">' +
        '<div class="grid2"><div class="row"><label class="fl">Judul</label><input type="text" id="qrmTitle" maxlength="80" placeholder="mis. Info harga paket"></div>' +
        '<div class="row"><label class="fl">Pintasan</label><input type="text" id="qrmSc" maxlength="31" placeholder="mis. harga (dipanggil /harga)"></div></div>' +
        '<div class="row"><label class="fl">Isi</label><textarea id="qrmText" rows="5" maxlength="4000" placeholder="Halo Kak {nama}, ..."></textarea></div>' +
        '<div class="row"><label class="fl">Lampiran <span style="font-weight:400;color:var(--muted)">(opsional)</span></label><div id="qrmMedia"></div>' +   // v1.2.199: template-media
          '<input type="file" id="qrmFile" accept=".jpg,.jpeg,.png,.mp4,.3gp,.mp3,.ogg,.m4a,.aac,.amr,.pdf,.doc,.docx,.xls,.xlsx,.ppt,.pptx,.txt,.csv,.zip" style="display:none">' +
          '<p class="help" style="margin:4px 0 0">JPG/PNG maks 5 MB; video, audio, PDF/dokumen maks 16 MB. Dengan lampiran, isi menjadi keterangan (maks 1.024 karakter); pesan suara tanpa keterangan.</p></div>' +
        '<div style="display:flex;gap:8px;flex-wrap:wrap"><button type="button" class="btn" id="qrmSave">Simpan template</button>' +
        '<button type="button" class="btn ghost" id="qrmReset">Baru</button><span id="qrmMode" class="help" style="align-self:center"></span></div>' +
      '</div><div id="qrmList"></div></div>';
    if (host) {   // v1.2.199: template-menu
      ov.id = ''; ov.style.cssText = ''; host.innerHTML = ''; host.appendChild(ov);
      ov.firstChild.style.cssText = 'margin:0;max-width:820px';
      $('#qrmX').parentNode.remove();
    } else document.body.appendChild(ov);
    var editId = '';
    var tutup = function () { ov.remove(); document.removeEventListener('keydown', esck); };
    var esck = function (e) { if (e.key === 'Escape') tutup(); };
    if (!host) { document.addEventListener('keydown', esck); ov.onclick = function (e) { if (e.target === ov) tutup(); }; $('#qrmX').onclick = tutup; }   // v1.2.199: template-menu
    var mEdit = null, mNew = null, mDrop = false;   // v1.2.199: template-media
    var mRender = function () {
      var el = $('#qrmMedia'); if (!el) return;
      var btn = function (id, lbl, red) { return '<a href="#" id="' + id + '" style="font-weight:600;text-decoration:none' + (red ? ';color:#b91c1c' : '') + '">' + lbl + '</a>'; };
      if (mNew) el.innerHTML = ico('paperclip', 14) + ' <b>' + esc(mNew.name) + '</b> <span class="help" style="margin:0">' + waFmtSize(mNew.size) + (mEdit && !mDrop ? ' · menggantikan ' + esc(mEdit.name) : '') + '</span> · ' + btn('qrmMNew', 'Ganti') + ' · ' + btn('qrmMUndo', 'Batal', 1);
      else if (mEdit && !mDrop) el.innerHTML = (mEdit.type === 'image' ? '<img src="' + waQrMediaUrl(editId) + '" alt="" style="width:44px;height:44px;object-fit:cover;border-radius:6px;vertical-align:middle;margin-right:6px" onerror="this.style.display=\'none\'">' : ico('paperclip', 14) + ' ') +
        '<b>' + esc(mEdit.name) + '</b> <span class="help" style="margin:0">' + waFmtSize(mEdit.size || 0) + '</span> · ' + btn('qrmMNew', 'Ganti') + ' · ' + btn('qrmMDel', 'Hapus lampiran', 1);
      else el.innerHTML = '<button type="button" class="btn ghost sm" id="qrmMNew">' + ico('paperclip', 14) + ' Pilih file</button>' + (mEdit && mDrop ? ' <span class="help" style="margin:0">lampiran ' + esc(mEdit.name) + ' akan dihapus · </span>' + btn('qrmMUndo', 'Urungkan') : '');
      if ($('#qrmMNew')) $('#qrmMNew').onclick = function (e) { e.preventDefault(); $('#qrmFile').click(); };
      if ($('#qrmMDel')) $('#qrmMDel').onclick = function (e) { e.preventDefault(); mDrop = true; mRender(); };
      if ($('#qrmMUndo')) $('#qrmMUndo').onclick = function (e) { e.preventDefault(); if (mNew) mNew = null; else mDrop = false; $('#qrmFile').value = ''; mRender(); };
    };
    $('#qrmFile').onchange = function () {
      var f = this.files && this.files[0]; if (!f) return;
      var ext = (f.name.split('.').pop() || '').toLowerCase(), kind = WA_ATT_KIND[ext];
      if (!kind) { toast('Jenis file .' + ext + ' belum didukung. Bisa: JPG/PNG, MP4, MP3/OGG/M4A, PDF, Word, Excel, PowerPoint, TXT, CSV, ZIP.', true); this.value = ''; return; }
      if (f.size > WA_ATT_MB[kind] * 1048576) { toast('Batas WhatsApp untuk file ini: ' + WA_ATT_MB[kind] + ' MB (file Anda ' + waFmtSize(f.size) + ').', true); this.value = ''; return; }
      mNew = f; mRender();
    };
    var reset = function () { editId = ''; $('#qrmTitle').value = ''; $('#qrmSc').value = ''; $('#qrmText').value = ''; $('#qrmMode').textContent = 'Template baru'; mEdit = null; mNew = null; mDrop = false; $('#qrmFile').value = ''; mRender(); };
    var render = function () {
      var l = waState.qrList || [];
      $('#qrmList').innerHTML = l.length ? l.map(function (x) {
        return '<div style="border-top:1px solid var(--line);padding:10px 2px;display:flex;gap:10px;align-items:flex-start">' +
          '<div style="flex:1;min-width:0"><strong>' + esc(x.title) + '</strong>' + (x.shortcut ? ' <span class="tag" style="font-size:11px">/' + esc(x.shortcut) + '</span>' : '') +
          (x.media ? '<div style="font-size:12.5px;margin-top:3px">' + ico('paperclip', 13) + ' ' + esc(x.media.name) + ' <span style="color:var(--muted)">' + waFmtSize(x.media.size || 0) + '</span></div>' : '') +   // v1.2.199: template-media
          '<div style="white-space:pre-wrap;font-size:13px;color:var(--muted);margin-top:3px;max-height:4.2em;overflow:hidden">' + esc(x.text) + '</div></div>' +
          '<div style="white-space:nowrap"><button type="button" class="btn ghost sm qrm-e" data-id="' + esc(x.id) + '">Edit</button> ' +
          '<button type="button" class="btn danger sm qrm-d" data-id="' + esc(x.id) + '">Hapus</button></div></div>';
      }).join('') : '<p class="help" style="margin:0">Belum ada template.</p>';
      $$('#qrmList .qrm-e').forEach(function (b) { b.onclick = function () {
        var x = (waState.qrList || []).filter(function (y) { return y.id === b.dataset.id; })[0]; if (!x) return;
        editId = x.id; $('#qrmTitle').value = x.title || ''; $('#qrmSc').value = x.shortcut || ''; $('#qrmText').value = x.text || '';
        mEdit = x.media || null; mNew = null; mDrop = false; $('#qrmFile').value = ''; mRender();   // v1.2.199: template-media
        $('#qrmMode').textContent = 'Mengedit "' + x.title + '"'; $('#qrmText').focus();
      }; });
      $$('#qrmList .qrm-d').forEach(function (b) { b.onclick = function () {
        if (!confirm('Hapus template ini?')) return;
        api('qr_delete', { method: 'POST', body: { id: b.dataset.id } }).then(function (r) {
          if (r && r.ok) { waState.qrList = r.items || []; waState.qrAt = Date.now(); if (editId === b.dataset.id) reset(); render(); toast('Template dihapus.'); }
          else toast((r && r.error) || 'Gagal menghapus.', true);
        });
      }; });
    };
    $('#qrmReset').onclick = reset;
    $('#qrmSave').onclick = function () {
      var body = { id: editId, title: $('#qrmTitle').value, shortcut: $('#qrmSc').value, text: $('#qrmText').value };
      var hasM = !!mNew || (!!mEdit && !mDrop), mk = mNew ? WA_ATT_KIND[(mNew.name.split('.').pop() || '').toLowerCase()] : (hasM ? mEdit.type : '');   // v1.2.199: template-media
      if (!body.text.trim() && !hasM) { toast('Isi template wajib diisi (atau pilih lampiran).', true); $('#qrmText').focus(); return; }
      if (mk === 'audio' && body.text.trim()) { toast('Pesan suara tidak bisa diberi keterangan — kosongkan isi, atau buat template teks terpisah.', true); return; }
      if (hasM && body.text.trim().length > 1024) { toast('Template berlampiran: isi menjadi keterangan, maksimal 1.024 karakter.', true); return; }
      this.disabled = true; var btn = this;
      var kirim = (mNew || (mEdit && mDrop)) ? function () {
        var fd = new FormData();
        Object.keys(body).forEach(function (k) { fd.append(k, body[k]); });
        if (mNew) fd.append('file', mNew, mNew.name); else fd.append('remove_media', '1');
        return new Promise(function (res) { waSchedUpload('qr_save', fd, mNew ? function (p) { $('#qrmMode').textContent = p < 100 ? 'Mengunggah ' + p + '%…' : 'Menyimpan…'; } : null, res); });
      } : function () { return api('qr_save', { method: 'POST', body: body }); };
      kirim().then(function (r) {
        btn.disabled = false;
        if (r && r.ok) { waState.qrList = r.items || []; waState.qrAt = Date.now(); toast(editId ? 'Template diperbarui.' : 'Template ditambahkan.'); reset(); render(); }
        else toast((r && r.error) || 'Gagal menyimpan.', true);
      });
    };
    reset();
    $('#qrmList').innerHTML = '<p class="help">Memuat…</p>';
    waQrLoad(true).then(render);
    if (host) qrtplRefresh = function () { waQrLoad(true).then(render); };   // v1.2.199: template-menu
  }

  function sendWaManual(num) {
    var inp = $('#waReplyInput'); var t = inp.value.trim();
    if (waState.attach && waState.attachNum === num) { sendWaMedia(num); return; }   // v1.2.120: wa-lampiran
    if (!t) return;
    $('#waReplySend').disabled = true;
    // Auto-claim kalau belum di-claim (backwards compat behavior)
    var claim = waState.claimDetails[num];
    var chainSend = function () {
      var b121 = { number: num, text: t };   // v1.2.121: wa-balas-kutip
      if (waState.replyTo && waState.replyTo.num === num) b121.reply_to = waState.replyTo.id;
      api('wa_send_manual', { method: 'POST', body: b121 }).then(function (res) {
        if (res && res.ok) { inp.value = ''; waQuoteClear(); waQrAutosize(); fetchWaThread(num); fetchWaConvs(); }   // v1.2.122
        else { toast((res && res.error) || 'Gagal mengirim.', true); $('#waReplySend').disabled = false; }
      });
    };
    if (!claim) {
      // Auto-claim dulu supaya konsisten dengan sistem
      api('wa_claim', { method: 'POST', body: { number: num } }).then(function (r) {
        chainSend();
      });
    } else {
      chainSend();
    }
  }

  // === Audit log viewer =====================================================

  // v1.2.131: log-selesai
  function toggleResLog() {
    var box = $('#waResLogBox'); if (!box) return;
    if (box.style.display === 'none') { box.style.display = 'block'; refreshResLog(); } else { box.style.display = 'none'; }
  }
  function refreshResLog() {
    var box = $('#waResLogBox'); if (!box) return;
    if (!box.innerHTML) box.innerHTML = '<div style="padding:8px 0;color:var(--muted);font-size:13px">Memuat…</div>';
    api('wa_resolve_log').then(function (res) {
      if (!res || !res.ok) { box.innerHTML = '<div style="padding:8px 0;color:#b91c1c;font-size:13px">' + esc((res && res.error) || 'Gagal memuat log selesai') + '</div>'; return; }
      var FL = { unreplied: 'Belum dibalas', active: 'Aktif', done: 'Selesai' };
      var h = '<div class="wa-audit-header" style="display:flex;align-items:center;gap:8px;flex-wrap:wrap"><strong>' + ico('check-circle-2',14) + ' Log Selesai Manual</strong>' +
        ' <span style="color:var(--muted);font-size:12px">(' + res.entries.length + ' dari ' + res.total + ')</span><span style="flex:1"></span>' +
        '<button type="button" class="btn ghost" id="waResLogCsv" style="padding:4px 10px;font-size:12px">' + ico('download',12) + ' Unduh CSV</button></div>';
      if (!res.entries.length) h += '<div style="padding:6px 0;color:var(--muted);font-size:13px">Belum ada chat yang ditandai selesai manual.</div>';
      else {
        h += '<div class="wa-audit-list">';
        res.entries.forEach(function (e) {
          h += '<div class="wa-audit-row wa-reslog-row">' +
            '<span class="wa-audit-ts">' + esc(e.ts) + '</span>' +
            '<span class="wa-audit-agent">' + esc(e.by) + '</span>' +
            '<span class="wa-audit-num">+' + esc(e.number) + (e.name ? ' · ' + esc(e.name) : '') + '</span>' +
            '<span>' + esc(FL[e.prev_flag] || '-') + (e.waiting_sec ? ' · ' + waDurasi(e.waiting_sec) : '') + (e.owner ? ' · dipegang ' + esc(e.owner) : '') + (e.ch ? ' · ' + esc(e.ch) : '') + '</span>' +
          '</div>';
        });
        h += '</div>';
      }
      box.innerHTML = h;
      var b = $('#waResLogCsv');
      if (b) b.onclick = function () { window.location.href = API + '?action=wa_resolve_log&format=csv&token=' + encodeURIComponent(token); };
    });
  }

  function toggleAuditLog() {
    var box = $('#waAuditBox');
    if (box.style.display === 'none') {
      box.style.display = 'block';
      refreshAuditLog();
    } else {
      box.style.display = 'none';
    }
  }

  function refreshAuditLog() {
    api('wa_audit_log').then(function (res) {
      if (!res || !res.ok) {
        $('#waAuditBox').innerHTML = '<div style="padding:12px;color:#b91c1c;font-size:13px">Gagal memuat audit log</div>';
        return;
      }
      var entries = res.entries || [];
      if (!entries.length) {
        $('#waAuditBox').innerHTML = '<div style="padding:12px;color:var(--muted);font-size:13px">Belum ada audit entry.</div>';
        return;
      }
      var html = '<div class="wa-audit-header"><strong>' + ico('clipboard-list',14) + ' Audit Log</strong> <span style="color:var(--muted);font-size:12px">(' + res.shown + ' dari ' + res.total + ')</span></div>';
      html += '<div class="wa-audit-list">';
      entries.forEach(function (e) {
        var actionColor = {
          'claim': '#065f46', 'release': '#374151', 'auto_release': '#6b7280',
          'takeover_request': '#9a3412', 'takeover_approve': '#065f46', 'takeover_deny': '#991b1b',
          'takeover_auto_approve': '#a16207', 'admin_takeover': '#7c2d12', 'admin_release': '#374151'
        }[e.action] || '#374151';
        html += '<div class="wa-audit-row">' +
          '<span class="wa-audit-ts">' + esc(e.ts) + '</span>' +
          '<span class="wa-audit-action" style="color:' + actionColor + '">' + esc(e.action) + '</span>' +
          '<span class="wa-audit-agent">' + esc(e.agent) + '</span>' +
          '<span class="wa-audit-num">+' + esc(e.number) + '</span>' +
          (e.extra ? '<span class="wa-audit-extra" title="' + esc(JSON.stringify(e.extra)) + '">' + ico('paperclip',12) + '</span>' : '') +
          '</div>';
      });
      html += '</div>';
      $('#waAuditBox').innerHTML = html;
    });
  }

/* === End v1.2.0 WA Claim Frontend =========================================== */
  function playBeep() {
    try {
      var Ctx = window.AudioContext || window.webkitAudioContext;
      var a = new Ctx(), o = a.createOscillator(), g = a.createGain();
      o.connect(g); g.connect(a.destination);
      o.frequency.value = 880; g.gain.value = 0.05; o.start();
      setTimeout(function () { o.stop(); a.close(); }, 180);
    } catch (e) {}
  }

  /* ====================================================================== *
   *  v1.2.58: WHITE-LABEL WIDGET + TIM & AGENT
   * ====================================================================== */
  function seatText(se) {
    var f = function (used, max, lbl) {
      return '<b>' + used + '</b> / ' + (max > 0 ? max : '∞') + ' ' + lbl +
        (max > 0 && used > max ? ' <span style="color:#b91c1c">(' + (used - max) + ' akun terkunci)</span>' : '');
    };
    return ico('users', 13) + ' Kursi paket: ' + f(se.used_agents, se.max_agents, 'WA Agent') + ' · ' +
      f(se.used_supervisors, se.max_supervisors, 'Supervisor') +
      (se.source === 'pusat' ? '' : ' <span style="color:var(--muted)">(bawaan — belum tersinkron dari server pusat)</span> <a href="#" class="seat-sync">Sinkron ulang</a>');
  }
  function wlPreview() {
    var box = $('#wl_preview'); if (!box) return;
    var sub = $('#wl_subtitle').value.trim() || ($('#wl_hide').checked ? 'Online' : 'Online \u2022 Powered by AI');
    var logo = $('#wl_logo').value.trim();
    var color = (window._deiPrimaryColor || '#140383');
    box.innerHTML = '<div style="display:inline-flex;align-items:center;gap:10px;background:' + esc(color) + ';color:#fff;border-radius:14px;padding:10px 14px;min-width:240px">' +
      '<div style="width:34px;height:34px;border-radius:50%;background:rgba(255,255,255,.18);display:flex;align-items:center;justify-content:center;overflow:hidden">' +
      (logo ? '<img src="' + esc(logo) + '" alt="" style="width:30px;height:30px;border-radius:50%;object-fit:cover;background:#fff">' : ico('message-circle', 18)) + '</div>' +
      '<div><div style="font-weight:600;font-size:14px">' + esc(window._deiBotName || 'Assistant') + '</div><div style="font-size:11px;opacity:.85">' + esc(sub) + '</div></div></div>' +
      '<div class="help" style="margin-top:4px">Pratinjau kepala widget.</div>';
  }
  function loadWhiteLabel(s) {
    if (!$('#wl_subtitle')) return;
    var wl = s.white_label || {};
    window._deiPrimaryColor = (s.appearance || {}).primary_color || '#140383';
    window._deiBotName = (s.bot || {}).bot_name || 'Assistant';
    $('#wl_subtitle').value = wl.subtitle || '';
    $('#wl_logo').value = wl.header_logo || '';
    $('#wl_hide').checked = !!wl.hide_branding;
    ['#wl_subtitle', '#wl_logo'].forEach(function (id) { $(id).oninput = wlPreview; });
    $('#wl_hide').onchange = wlPreview;
    wlPreview();
    api('team_info').then(function (r) {
      if (!r || !r.ok || !$('#wl_status')) return;
      var on = r.features && r.features.white_label;
      $('#wl_status').innerHTML = on
        ? '<span style="color:#065f46">' + ico('check-circle-2', 13) + ' Paket ini mendukung white-label — pengaturan di bawah aktif di widget.</span>'
        : '<span style="color:#92400e">' + ico('triangle-alert', 13) + ' White-label belum aktif untuk paket ini. Pengaturan tersimpan, tetapi widget tetap tampil bawaan sampai diaktifkan oleh ' + BRAND_VENDOR + '.</span>';
    });
  }

  var timTeam = null;
  function loadTim() {
    var today = new Date();
    var pad = function (n) { return String(n).padStart(2, '0'); };
    var ymd = function (d) { return d.getFullYear() + '-' + pad(d.getMonth() + 1) + '-' + pad(d.getDate()); };
    if ($('#btnSaveTim')) $('#btnSaveTim').onclick = saveTim;
    $$('input[name="tim_mode"]').forEach(function (r) { r.onchange = timModeNote; });
    api('team_info').then(function (r) {
      if (!r || !r.ok) { $('#timSeats').textContent = (r && r.error) || 'Gagal memuat.'; return; }
      timTeam = r;
      $$('input[name="tim_mode"]').forEach(function (x) { x.checked = (x.value === r.reply_mode); });
      if ($('#tim_private')) $('#tim_private').checked = !!(r.team && r.team.agent_private);
      rtLoad(r);   // v1.2.100: routing
      timModeNote();
      $('#timSeats').innerHTML = seatText(r.seats) +
        '<div style="margin-top:6px">' + ico('message-circle', 13) + ' Mode balasan WhatsApp saat ini: <b>' + (r.reply_mode === 'manual' ? 'Manual (AI nonaktif)' : 'AI + Agent') + '</b></div>';
    });
    slTimLoad203();   // v1.2.203: sales-tag
  }
  // v1.2.205: laporan-pindah — Laporan per Agent & per Sales di menu Laporan & Log
  function arInit205() {
    var pad = function (n) { return String(n).padStart(2, '0'); };
    var ymd = function (d) { return d.getFullYear() + '-' + pad(d.getMonth() + 1) + '-' + pad(d.getDate()); };
    var t = new Date();
    if (!$('#arFrom').value) $('#arFrom').value = ymd(new Date(t.getFullYear(), t.getMonth(), 1));
    if (!$('#arTo').value) $('#arTo').value = ymd(t);
    $('#btnArLoad').onclick = loadAgentReport;
    loadAgentReport();
  }
  function slRepInit205() {
    if (!$('#slrFrom').value) { var d = new Date(); $('#slrFrom').value = slYmd203(new Date(d.getFullYear(), d.getMonth(), 1)); $('#slrTo').value = slYmd203(d); }
    $('#btnSlrLoad').onclick = slReport203;
    $('#btnSlrCsv').onclick = slReportCsv203;
    slList203(true);
  }
  function timModeNote() {
    var el = $('#timModeNote'); if (!el) return;
    var sel = (document.querySelector('input[name="tim_mode"]:checked') || {}).value;
    var r = timTeam || {};
    var msg = '';
    if (sel === 'manual') {
      msg = ico('triangle-alert', 13) + ' Mode Manual: pesan WhatsApp tidak dibalas otomatis (termasuk auto-closing). Pastikan agent memantau dashboard — aktifkan Eskalasi di menu Respon &amp; Eskalasi agar SPV diberi tahu bila chat terlalu lama tidak dibalas.';
      if (r.wa_provider === 'fonnte' || r.wa_provider === 'waha') msg += '<br>' + ico('triangle-alert', 13) + ' ' + (r.wa_provider === 'waha' ? 'WAHA' : 'Fonnte') + ': jalur tidak resmi — ada risiko nomor diblokir WhatsApp.';
      if (r.wa_enabled === false) msg += '<br>' + ico('octagon-alert', 13) + ' Nomor WhatsApp belum tersambung di menu Widget &amp; API — pesan masuk belum bisa tercatat.';   // v1.2.93: wa-bot-off
    }
    el.innerHTML = msg;
  }

  /* v1.2.100: routing — pengaturan + status agent */
  function rtLoad(r) {
    var c = (r && r.routing) || {};
    if (!$('#rt_enabled')) return;
    $('#rt_enabled').checked = !!c.enabled;
    $('#rt_method').value = c.method === 'rr' ? 'rr' : 'load';
    $('#rt_bynum').checked = !!c.by_number;
    $('#rt_online').checked = c.online_only !== false;
    $('#rt_max').value = c.max_active || 0;
    $('#btnSaveRoute').onclick = function () {
      var b = this; b.disabled = true;
      api('save_settings', { method: 'POST', body: { settings: { routing: {
        enabled: $('#rt_enabled').checked, method: $('#rt_method').value, by_number: $('#rt_bynum').checked,
        online_only: $('#rt_online').checked, max_active: Math.max(0, Math.min(500, Math.round(+$('#rt_max').value || 0)))
      } } } }).then(function (res) {
        b.disabled = false;
        toast(res && res.ok ? 'Routing tersimpan.' : ((res && res.error) || 'Gagal menyimpan.'), !(res && res.ok));
        rtAgents();
      }).catch(function () { b.disabled = false; });
    };
    rtAgents();
  }
  function rtAgents() {
    var box = $('#rtAgents'); if (!box) return;
    api('agent_presence', { method: 'POST', body: { op: 'list' } }).then(function (r) {
      if (!r || !r.ok) { box.textContent = (r && r.error) || 'Gagal memuat.'; return; }
      var a = r.agents || [];
      if (!a.length) { box.textContent = 'Belum ada WA Agent / Supervisor.'; return; }
      box.innerHTML = '<div class="tbl-wrap"><table class="tbl"><thead><tr><th>Agent</th><th>Tim</th><th>Status</th><th style="text-align:right">Dipegang</th></tr></thead><tbody>' +
        a.map(function (x) {
          var st = !x.seat_ok ? '<span class="tag" style="background:#fee2e2;color:#991b1b">Di luar kursi</span>'
            : x.status === 'away' ? '<span class="tag" style="background:#fef3c7;color:#92400e">Istirahat</span>'
            : x.online ? '<span class="tag" style="background:#d1fae5;color:#065f46">Online</span>'
            : '<span class="tag">Offline</span>';
          return '<tr><td>' + esc(x.name || x.username) + ' <span style="color:var(--muted);font-size:11px">' + esc(ROLE_LABEL[x.role] || x.role) + '</span></td><td>' + esc(x.team || '—') + '</td><td>' + st + '</td><td style="text-align:right">' + (x.active || 0) + '</td></tr>';
        }).join('') + '</tbody></table></div>';
    });
  }
  // Tombol status di sidebar + heartbeat (WA Agent & Supervisor)
  var _avail = { status: 'available', t: null };
  function availPaint() {
    var b = $('#btnAvail'); if (!b) return;
    var on = _avail.status !== 'away';
    b.innerHTML = '<span style="display:inline-block;width:8px;height:8px;border-radius:50%;margin-right:6px;background:' + (on ? '#16a34a' : '#d97706') + '"></span>' + (on ? 'Tersedia' : 'Istirahat');
    b.title = on ? 'Anda menerima chat otomatis. Klik untuk Istirahat.' : 'Anda tidak menerima chat otomatis. Klik untuk kembali Tersedia.';
  }
  function availPing(set) {
    var body = set ? { op: 'set', status: set } : { op: 'ping' };
    return api('agent_presence', { method: 'POST', body: body }).then(function (r) {
      if (!r || !r.ok) return;
      _avail.status = r.status || 'available'; availPaint();
      if (r.assigned > 0) { toast(r.assigned + ' chat menunggu dibagikan ke tim.'); if (typeof fetchWaConvs === 'function' && $('#waConvList')) fetchWaConvs(true); }
    }).catch(function () {});
  }
  function availInit() {
    var b = $('#btnAvail');
    if (!b || (role !== 'wa_agent' && role !== 'supervisor')) return;
    b.style.display = '';
    availPaint();
    b.onclick = function () { availPing(_avail.status === 'away' ? 'available' : 'away'); };
    availPing();
    clearInterval(_avail.t);
    _avail.t = setInterval(function () { if (!document.hidden) availPing(); }, 60000);
    document.addEventListener('visibilitychange', function () { if (!document.hidden) availPing(); });
  }
  availInit();

  function saveTim() {
    var sel = (document.querySelector('input[name="tim_mode"]:checked') || {}).value || 'ai';
    var prev = timTeam ? timTeam.reply_mode : 'ai';
    if (sel !== prev && !confirm(sel === 'manual'
        ? 'Matikan AI untuk WhatsApp? Semua pesan masuk harus dibalas agent.'
        : 'Aktifkan kembali AI? Chat yang tidak dipegang agent akan dijawab bot.')) return;
    api('save_settings', { method: 'POST', body: { settings: {
      reply: { mode: sel },
      team: { agent_private: $('#tim_private').checked }
    } } }).then(function (res) {
      if (res && res.ok) { toast('Pengaturan tim tersimpan.'); loaded.wachat = false; loadTim(); }
      else toast((res && res.error) || 'Gagal menyimpan.', true);
    });
  }
  function fmtDur(sec) {
    if (sec === null || sec === undefined) return '–';
    if (sec < 60) return sec + ' dtk';
    if (sec < 3600) return Math.floor(sec / 60) + ' mnt ' + (sec % 60 ? (sec % 60) + ' dtk' : '');
    var h = Math.floor(sec / 3600), m = Math.floor((sec % 3600) / 60);
    return h + ' jam' + (m ? ' ' + m + ' mnt' : '');
  }
  function loadAgentReport() {
    var q = '&from=' + encodeURIComponent($('#arFrom').value) + '&to=' + encodeURIComponent($('#arTo').value);
    $('#tblAr').innerHTML = '<tr><td colspan="7" style="color:var(--muted)">Memuat…</td></tr>';
    api('agent_report', { query: q }).then(function (r) {
      if (!r || !r.ok) { $('#tblAr').innerHTML = '<tr><td colspan="7" style="color:#b91c1c">' + esc((r && r.error) || 'Gagal memuat.') + '</td></tr>'; return; }
      var t = r.totals || {};
      var kpi = function (n, l) { return '<div class="tim-kpi"><div class="n">' + n + '</div><div class="l">' + l + '</div></div>'; };
      $('#arKpis').innerHTML =
        kpi(t.chats_handled || 0, 'Chat ditangani agent') +
        kpi(fmtDur(t.frt_avg_sec), 'Respon pertama rata²') +
        kpi(fmtDur(t.resp_avg_sec), 'Waktu respon rata²') +
        kpi((t.unreplied_now || 0) + (r.self_only ? '' : ' <span style="font-size:12px;color:var(--muted);font-weight:400">(' + (t.unreplied_unassigned || 0) + ' belum diklaim)</span>'), 'Belum dibalas saat ini');
      var rows = r.agents || [];
      if (!rows.length) { $('#tblAr').innerHTML = '<tr><td colspan="7" style="color:var(--muted)">Belum ada agent / aktivitas di rentang ini.</td></tr>'; return; }
      $('#tblAr').innerHTML = rows.map(function (a) {
        var lbl = a.agent === '(HP)' ? 'Dari HP (tanpa claim)' : (a.name || a.agent);
        return '<tr><td>' + esc(lbl) + (a.agent !== '(HP)' ? ' <span class="tag">' + esc(ROLE_LABEL[a.role] || a.role || '-') + '</span>' : '') + '</td>' +
          '<td style="text-align:right">' + a.chats + '</td>' +
          '<td style="text-align:right">' + a.replies + '</td>' +
          '<td style="text-align:right">' + fmtDur(a.frt_avg_sec) + '</td>' +
          '<td style="text-align:right">' + fmtDur(a.resp_avg_sec) + '</td>' +
          '<td style="text-align:right">' + a.holding_now + '</td>' +
          '<td style="text-align:right;' + (a.unreplied_now ? 'color:#b91c1c;font-weight:600' : '') + '">' + a.unreplied_now + '</td></tr>';
      }).join('');
    });
  }

  /* ---- loader registry + first tab ------------------------------------ */
  /* ====================================================================== *
   *  CENTRAL SERVER — auto-update + report-back (super_admin only)
   * ====================================================================== */
  function loadCentral() {
    if (role !== 'super_admin') return;
    var card = document.querySelector('[data-role-card="super_admin"] #cs_url');
    if (!card) return;   // card not rendered (role hidden)
    api('update_status').then(function (res) {
      if (!res.ok) return;
      var c = res.central || {};
      $('#cs_url').value     = c.url || '';
      $('#cs_tenant').value  = c.tenant_id || '';
      $('#cs_license').value = c.license_set ? c.license_key : '';
      $('#cs_auto').checked  = !!c.auto_update;
      $('#csVersion').textContent    = res.installed_version || 'v1.1.0';
      $('#csLastCheck').textContent  = c.last_check  || '–';
      $('#csLastResult').textContent = c.last_result || '–';
    });
  }

  function saveCentral() {
    var body = {
      url:         $('#cs_url').value.trim(),
      tenant_id:   $('#cs_tenant').value.trim(),
      license_key: $('#cs_license').value.trim(),
      auto_update: $('#cs_auto').checked
    };
    if (!body.url || !body.tenant_id) { toast('URL & Tenant ID wajib.', true); return; }
    api('save_central', { method: 'POST', body: body }).then(function (res) {
      if (res.ok) { toast('Setting pusat tersimpan.'); loadCentral(); }
      else toast(res.error || 'Gagal simpan.', true);
    });
  }

  function checkUpdate(silent) {
    return api('update_check', { method: 'POST' }).then(function (res) {
      if (!res.ok) {
        if (!silent) toast(res.error || 'Gagal cek update.', true);
        loadCentral();
        return res;
      }
      if (res.update_available) {
        if (!silent) toast('Update tersedia: ' + res.latest + '. Memasang…');
        return applyUpdate(res, silent);
      }
      if (!silent) toast('Sudah versi terkini (' + res.current + ').');
      loadCentral();
      return res;
    });
  }

  function applyUpdate(info, silent) {
    return api('update_apply', { method: 'POST', body: {
      zip_url: info.zip_url, manifest_url: info.manifest_url, target: info.latest
    }}).then(function (res) {
      if (!res.ok) {
        toast(res.error || 'Gagal pasang update.', true);
        return res;
      }
      toast('Versi baru dipasang: ' + res.version + ' ✓');
      // v1.1.2: trigger one more check so central immediately learns the new version
      // (the in-page report_back fired BEFORE replacement still has the old version).
      api('update_check', { method: 'POST' }).catch(function(){});
      // Brief reload so the new code is loaded
      // v1.2.2: cache-buster reload — bypass browser cache after update
      setTimeout(function () {
        var url = new URL(location.href);
        url.searchParams.set('_cb', Date.now());
        location.href = url.toString();
      }, 1500);
      return res;
    });
  }

  // Wire buttons (only attach once when DOM has the card)
  function wireCentralButtons() {
    if ($('#btnSaveCentral') && !$('#btnSaveCentral').dataset.wired) {
      $('#btnSaveCentral').onclick = saveCentral;
      $('#btnSaveCentral').dataset.wired = '1';
    }
    if ($('#btnCheckUpdate') && !$('#btnCheckUpdate').dataset.wired) {
      $('#btnCheckUpdate').onclick = function () { checkUpdate(false); };
      $('#btnCheckUpdate').dataset.wired = '1';
    }
  }

  // Auto-check on dashboard bootstrap (silent — only acts if auto_update is enabled)
  function maybeAutoCheck() {
    if (role !== 'super_admin' && role !== 'admin') return;
    // small delay so it doesn't block initial UI
    setTimeout(function () {
      api('update_status').then(function (res) {
        if (!res.ok || !res.central) return;
        if (!res.central.auto_update) return;
        if (!res.central.url || !res.central.tenant_id || !res.central.license_set) return;
        // super_admin runs the check directly. Admins also check, but the call requires super_admin role —
        // so we only fire if role allows.
        if (role !== 'super_admin') return;
        checkUpdate(true);
      });
    }, 1200);
  }

  /* ====================================================================== *
   *  LICENSE BANNER (v1.1.3) — super_admin/admin only
   * ====================================================================== */
  function licPayLink(lic, txt) {   // v1.2.173: bayar-mandiri
    return lic && lic.pay_url ? ' <a href="' + esc(lic.pay_url) + '" target="_blank" rel="noopener" style="color:inherit;font-weight:700;white-space:nowrap">' + (txt || 'Perpanjang online') + ' &rarr;</a>' : '';
  }
  function renderLicenseBanner() {
    if (role !== 'super_admin' && role !== 'admin') return;
    var el = document.getElementById('licenseBanner');
    if (!el) return;
    api('license_status').then(function (res) {
      if (!res.ok || !res.license) { el.style.display = 'none'; return; }
      var lic = res.license;
      if (lic.status === 'active') {
        // Show banner only if expires_at is within 14 days
        if (lic.days_left !== null && lic.days_left >= 0 && lic.days_left <= 14) {
          el.style.display = 'block';
          el.style.background = '#fef3c7';
          el.style.borderColor = '#fde68a';
          el.style.color = '#854d0e';
          el.innerHTML = '<div style="display:flex;gap:10px;align-items:flex-start">'
                       + '<span style="flex-shrink:0;margin-top:1px">' + ico('clock-3', 18) + '</span>'
                       + '<div><b>Lisensi akan berakhir dalam ' + lic.days_left + ' hari.</b> ' + (lic.pay_url ? 'Perpanjang sekarang supaya bot tetap aktif.' + licPayLink(lic, 'Perpanjang online') : 'Silakan hubungi vendor untuk perpanjangan.') + '</div>'
                       + '</div>';
        } else {
          el.style.display = 'none';
        }
      } else if (lic.status === 'expired') {
        el.style.display = 'block';
        el.style.background = '#fef3c7';
        el.style.borderColor = '#d97706';
        el.style.color = '#854d0e';
        var msg = '<b>Lisensi sudah expired</b> (sejak ' + (lic.expires_at || '?') + ').';
        if (lic.days_left !== null && lic.days_left < 0) {
          var daysOver = Math.abs(lic.days_left);
          var daysLeftBeforeSuspend = 7 - daysOver;
          if (daysLeftBeforeSuspend > 0) {
            msg += ' Layanan akan otomatis di-suspend dalam <b>' + daysLeftBeforeSuspend + ' hari</b> jika tidak diperpanjang.';
          } else {
            msg += ' Suspend otomatis akan segera dilakukan.';
          }
        }
        msg += lic.pay_url ? licPayLink(lic, 'Perpanjang online sekarang') : ' Hubungi vendor untuk perpanjangan.';   // v1.2.173: bayar-mandiri
        el.innerHTML = '<div style="display:flex;gap:10px;align-items:flex-start">'
                     + '<span style="flex-shrink:0;margin-top:1px">' + ico('triangle-alert', 18) + '</span>'
                     + '<div>' + msg + '</div></div>';
      } else if (lic.status === 'suspended') {
        el.style.display = 'block';
        el.style.background = '#fee2e2';
        el.style.borderColor = '#c4302b';
        el.style.color = '#991b1b';
        el.innerHTML = '<div style="display:flex;gap:10px;align-items:flex-start">'
                     + '<span style="flex-shrink:0;margin-top:1px">' + ico('ban', 18) + '</span>'
                     + '<div><b>Layanan SUSPENDED.</b> Chatbot tidak melayani pengunjung. Token API Anda telah dikosongkan. Setelah perpanjangan, isi ulang token Claude/WhatsApp/Telegram di menu Widget &amp; API.' + licPayLink(lic, 'Perpanjang online') + '</div>'
                     + '</div>';
      } else {
        el.style.display = 'none';
      }
    }).catch(function(){ el.style.display = 'none'; });
  }

  /* ====================================================================== *
   *  CAP BANNER (v1.1.4) — all roles see this
   * ====================================================================== */

  /* ====================================================================== *
   *  v1.2.172: trial-paket — beda paket Starter vs Growth dibuat jelas
   *  (label "Growth" di menu, kartu perbandingan, tombol bandingkan di fitur terkunci)
   * ====================================================================== */
  var PLAN = null, planCbs = null;
  function planGet(cb) {
    if (PLAN) { cb(PLAN); return; }
    if (planCbs) { planCbs.push(cb); return; }
    planCbs = [cb];
    api('plan_info').then(function (r) {
      PLAN = (r && r.ok) ? r : { ok: false, tier: 'custom', growth: true, trial: false };
      var l = planCbs; planCbs = null; l.forEach(function (f) { try { f(PLAN); } catch (e) {} });
    });
  }
  var PLAN_ROWS = [
    ['Balasan AI per bulan', '1.000', '2.000'],
    ['Chatbot WhatsApp + widget web', true, true],
    ['Knowledge Base, Produk & Leads', true, true],
    ['Tim & agent, Kontak, Blast WA', true, true],
    ['Nomor WhatsApp tambahan', false, '+2 nomor'],
    ['Unit Bisnis (cabang / brand / divisi)', false, '3 unit'],
    ['Filter Topik & Divisi — chat WA dipilah AI otomatis', false, '5.000 chat/bulan'],
    ['Customer Feedback — survei kepuasan WA & web', false, true]
  ];
  (function () {
    var st = document.createElement('style');
    st.textContent =
      '.plan-tag{margin-left:auto;font-size:9.5px;font-weight:700;text-transform:uppercase;letter-spacing:.4px;padding:2px 7px;border-radius:9px;background:#fef3c7;color:#92400e;line-height:1.4;flex-shrink:0}' +
      '.plan-tag.on{background:#cffafe;color:#0e7490}' +
      '.pc-tbl{width:100%;border-collapse:separate;border-spacing:0;font-size:13px;margin-top:14px}' +
      '.pc-tbl th,.pc-tbl td{padding:9px 10px;border-bottom:1px solid var(--line);text-align:center;vertical-align:middle}' +
      '.pc-tbl td:first-child,.pc-tbl th:first-child{text-align:left}' +
      '.pc-tbl th{font-size:13.5px}.pc-tbl th small{display:block;font-weight:500;font-size:10.5px;opacity:.8;margin-top:2px}' +
      '.pc-tbl .pc-g{background:#ecfeff;width:30%}.pc-tbl th.pc-g{background:linear-gradient(135deg,#0891b2,#0e7490);color:#fff;border-radius:10px 10px 0 0}' +
      '.pc-tbl td.pc-s,.pc-tbl th.pc-s{width:24%;color:var(--muted)}' +
      '.pc-tbl tr.pc-x td{font-weight:600}.pc-tbl tr.pc-x td.pc-g{color:#0e7490}' +
      '.pc-y{color:#16a34a;display:inline-flex}.pc-n{color:#cbd5e1;font-weight:700}' +
      '.pc-head{display:flex;gap:12px;align-items:flex-start}.pc-head>svg{flex-shrink:0;color:#0e7490;margin-top:2px}' +
      '.pc-head p{margin:4px 0 0;color:var(--muted);font-size:13px;line-height:1.5}' +
      '.pc-foot{margin-top:14px;display:flex;justify-content:flex-end;align-items:center;gap:10px;flex-wrap:wrap}' +
      '.pc-cta{background:linear-gradient(135deg,#0891b2,#0e7490)!important;color:#fff!important;text-decoration:none;display:inline-flex;gap:6px;align-items:center;border:0}' +
      '.pc-ctx{font-size:13px;color:#0e7490;font-weight:600}' +
      '.pc-more{font-size:12px;color:var(--muted);margin-top:8px}' +
      '.pc-ov{position:fixed;inset:0;background:rgba(15,23,42,.55);z-index:9999;display:flex;align-items:center;justify-content:center;padding:16px}' +
      '.pc-box{background:#fff;color:var(--ink);border-radius:14px;max-width:640px;width:100%;max-height:90vh;overflow:auto;padding:22px;position:relative;box-shadow:0 20px 50px rgba(0,0,0,.25)}' +
      '.pc-box h3{margin:0;display:flex;gap:8px;align-items:center;color:#0e7490}' +
      '.pc-close{position:absolute;right:12px;top:8px;border:0;background:none;font-size:24px;cursor:pointer;color:var(--muted)}' +
      '@media(max-width:600px){.pc-tbl{font-size:12px}.pc-tbl th,.pc-tbl td{padding:7px 6px}}';
    document.head.appendChild(st);
  })();
  function planCell(v) {
    if (v === true) return '<span class="pc-y">' + ico('check-circle-2', 16) + '</span>';
    if (v === false) return '<span class="pc-n">&ndash;</span>';
    return esc(v);
  }
  function planCta(p) {
    var u = p && p.upgrade_url;
    return u ? '<a class="btn pc-cta" href="' + esc(u) + '" target="_blank" rel="noopener">' + ico('crown', 15) + ' ' + (p.trial ? 'Berlangganan Growth' : 'Naik ke Growth') + '</a>'
             : '<span class="pc-ctx">' + ico('crown', 14, 'style="vertical-align:-2px"') + ' Hubungi ' + esc(BRAND_VENDOR) + ' untuk upgrade ke Growth.</span>';
  }
  function planCompareHtml(p) {
    var g = !!(p && p.growth);
    var h = '<table class="pc-tbl"><thead><tr><th>Fitur</th>' +
      '<th class="pc-s">Starter' + (!g ? '<small>' + (p && p.trial ? 'Trial Anda' : 'Paket Anda') + '</small>' : '') + '</th>' +
      '<th class="pc-g">' + ico('crown', 14, 'style="vertical-align:-2px"') + ' Growth<small>' + (g ? (p.trial ? 'Sedang Anda coba' : 'Paket Anda') : 'Direkomendasikan') + '</small></th></tr></thead><tbody>';
    PLAN_ROWS.forEach(function (r) {
      h += '<tr' + (r[1] === false ? ' class="pc-x"' : '') + '><td>' + esc(r[0]) + '</td><td class="pc-s">' + planCell(r[1]) + '</td><td class="pc-g">' + planCell(r[2]) + '</td></tr>';
    });
    return h + '</tbody></table><div class="pc-more">Butuh lebih besar? <b>Business</b> (5.000 balasan, +4 nomor, 5 unit) dan <b>Pro</b> (15.000 balasan, +9 nomor, 10 unit).</div>';
  }
  window.showPlanCompare = function () {
    planGet(function (p) {
      var ov = document.createElement('div'); ov.className = 'pc-ov';
      ov.innerHTML = '<div class="pc-box"><button type="button" class="pc-close" aria-label="Tutup">&times;</button>' +
        '<h3>' + ico('crown', 20) + ' Beda paket Starter &amp; Growth</h3>' + planCompareHtml(p) +
        '<div class="pc-foot">' + (p.growth && !p.trial ? '' : planCta(p)) + '</div></div>';
      ov.onclick = function (e) { if (e.target === ov || (e.target.closest && e.target.closest('.pc-close'))) ov.remove(); };
      document.body.appendChild(ov);
    });
  };
  function planBtn() {
    return '<div style="margin-top:10px"><button type="button" class="btn sm pc-cta" onclick="showPlanCompare()">' + ico('crown', 14) + ' Lihat beda Starter &amp; Growth</button></div>';
  }
  function renderPlanCard() {
    var uc = document.getElementById('usageCard'); if (!uc) return;
    planGet(function (p) {
      var el = document.getElementById('planCard');
      if (!p.ok || (p.growth && !p.trial)) { if (el) el.style.display = 'none'; return; }
      if (!el) { el = document.createElement('div'); el.id = 'planCard'; el.className = 'card'; uc.parentNode.insertBefore(el, uc.nextSibling); }
      el.style.display = '';
      var head = p.growth
        ? '<div class="pc-head">' + ico('crown', 22) + '<div><b>Anda sedang mencoba paket Growth</b><p>Semua fitur Growth aktif selama trial' + (p.days_left != null ? ' (' + p.days_left + ' hari lagi)' : '') +
          ': Filter Topik &amp; Divisi, Customer Feedback, nomor WA tambahan, dan Unit Bisnis. Berlangganan Growth supaya fitur ini tetap jalan setelah trial berakhir.</p></div></div>'
        : '<div class="pc-head">' + ico('rocket', 22) + '<div><b>Naik ke Growth, layani pelanggan lebih rapi</b><p>Paket Anda ' + (p.trial ? 'trial Starter' : 'Starter') +
          '. Dengan Growth, chat WA otomatis dipilah per topik/divisi, kepuasan pelanggan terukur lewat survei, bisa pakai nomor WA tambahan dan beberapa unit bisnis, dengan kuota balasan AI dua kali lipat.</p></div></div>';
      el.innerHTML = head + planCompareHtml(p) + '<div class="pc-foot">' + planCta(p) + '</div>';
    });
  }
  function planNav() {
    planGet(function (p) {
      if (!p.ok || (p.growth && !p.trial)) return;
      ['topik', 'gc'].forEach(function (k) {
        var b = document.querySelector('#nav button[data-tab="' + k + '"]');
        if (!b || b.querySelector('.plan-tag')) return;
        b.insertAdjacentHTML('beforeend', '<span class="plan-tag' + (p.growth ? ' on' : '') + '" title="' + (p.growth ? 'Fitur paket Growth — aktif selama trial' : 'Fitur paket Growth — klik untuk melihat') + '">Growth</span>');
      });
    });
  }

  function renderCapBanner() {
    var el = document.getElementById('capBanner');
    if (!el) return;
    api('cap_status').then(function (res) {
      if (!res.ok || !res.cap) { el.style.display = 'none'; return; }
      var c = res.cap;
      if (c.trial) {   // v1.2.90: masa trial
        var t = c.trial, up = t.upgrade_url ? ' <a href="' + esc(t.upgrade_url) + '" target="_blank" rel="noopener" style="color:inherit;font-weight:700">Berlangganan sekarang &rarr;</a>' : ' Hubungi ' + esc(BRAND_VENDOR) + ' untuk berlangganan.';
        el.style.display = 'block';
        if (t.expired || t.quota_out) {
          el.style.background = '#fee2e2'; el.style.borderColor = '#c4302b'; el.style.color = '#991b1b';
          el.innerHTML = '<div style="display:flex;gap:10px;align-items:flex-start"><span style="flex-shrink:0;margin-top:1px">' + ico('octagon-alert', 18) + '</span><div><b>'
                       + (t.expired ? 'Masa trial sudah berakhir.' : 'Kuota trial ' + t.cap + ' balasan AI sudah habis.')
                       + '</b> Bot tidak lagi membalas otomatis; percakapan tetap bisa dibalas manual dari dashboard.' + up + '</div></div>';
        } else {
          var warn = t.days_left <= 5 || (t.cap && t.used >= t.cap * 0.8);
          el.style.background = warn ? '#fef3c7' : '#eef4ff'; el.style.borderColor = warn ? '#d97706' : '#c7d7fe'; el.style.color = warn ? '#854d0e' : '#1e3a8a';
          el.innerHTML = '<div style="display:flex;gap:10px;align-items:flex-start;flex-wrap:wrap"><span style="flex-shrink:0;margin-top:1px">' + ico('sparkles', 18) + '</span><div><b>Masa trial' + (t.tier === 'growth' ? ' paket Growth' : '') + ': ' + t.days_left + ' hari lagi</b> &middot; '
                       + t.used + ' / ' + t.cap + ' balasan AI terpakai.' + up + '</div></div>';
        }
        return;
      }
      if (c.reached) {
        // 100%+
        el.style.display = 'block';
        el.style.background = '#fee2e2';
        el.style.borderColor = '#c4302b';
        el.style.color = '#991b1b';
        el.innerHTML = '<div style="display:flex;gap:10px;align-items:flex-start">'
                     + '<span style="flex-shrink:0;margin-top:1px">' + ico('octagon-alert', 18) + '</span>'
                     + '<div><b>Layanan mencapai batas kuota bulan ini.</b> Chatbot tidak memanggil AI sampai reset tanggal 1 atau kuota dinaikkan. Pengunjung dapat pesan pengganti.</div>'
                     + '</div>';
      } else if (c.warning) {
        // 90-99%
        el.style.display = 'block';
        el.style.background = '#fef3c7';
        el.style.borderColor = '#d97706';
        el.style.color = '#854d0e';
        el.innerHTML = '<div style="display:flex;gap:10px;align-items:flex-start">'
                     + '<span style="flex-shrink:0;margin-top:1px">' + ico('triangle-alert', 18) + '</span>'
                     + '<div><b>Layanan mendekati batas kuota bulan ini.</b> Chatbot sudah berhenti memanggil AI untuk menghemat kuota. Pengunjung dapat pesan pengganti.</div>'
                     + '</div>';
      } else {
        el.style.display = 'none';
      }
    }).catch(function(){ el.style.display = 'none'; });
  }

  /* ====================================================================== *
   *  v1.2.90: MULAI CEPAT — tenant hasil pendaftaran mandiri
   * ====================================================================== */
  function renderOnboarding() {
    var el = document.getElementById('onboardCard');
    if (!el || (role !== 'super_admin' && role !== 'admin')) return;
    api('onboarding_status').then(function (r) {
      if (!r || !r.ok || !r.enabled || r.dismissed) { el.style.display = 'none'; return; }
      var st = r.steps || {};
      var steps = [
        { k: 'bot',  tab: 'content', t: 'Atur nama & gaya bot',       d: 'Nama bot, sapaan, dan cara bot menjawab pelanggan.' },
        { k: 'kb',   tab: 'kb',      t: 'Isi Knowledge Base',          d: 'Unggah PDF atau tulis info produk, harga, jam buka.' },
        { k: 'test', tab: 'test',    t: 'Coba tanya ke bot',           d: 'Pastikan jawabannya sudah sesuai sebelum tersambung ke WhatsApp.' },
        { k: 'wa',   tab: 'widget',  t: 'Hubungkan WhatsApp',          d: 'Scan QR dari HP, atau minta bantuan tim kami untuk WhatsApp API resmi.' }
      ];
      var done = steps.filter(function (x) { return st[x.k]; }).length;
      var all = done === steps.length;
      el.style.display = '';
      el.innerHTML = '<div style="display:flex;justify-content:space-between;align-items:flex-start;gap:12px;flex-wrap:wrap">'
        + '<div><h3 style="margin:0 0 4px">' + (all ? 'Chatbot siap dipakai' : 'Mulai Cepat') + (r.business ? ' &mdash; ' + esc(r.business) : '') + '</h3>'
        + '<p style="margin:0;color:var(--muted);font-size:13.5px">' + (all ? 'Semua langkah selesai. Pesan WhatsApp yang masuk kini dijawab bot.' : done + ' dari ' + steps.length + ' langkah selesai.') + '</p></div>'
        + '<button type="button" class="btn ghost" id="obHide" style="font-size:13px">' + (all ? 'Tutup' : 'Sembunyikan') + '</button></div>'
        + '<div style="height:6px;background:var(--line);border-radius:6px;margin:12px 0 14px;overflow:hidden"><div style="height:100%;width:' + Math.round(done / steps.length * 100) + '%;background:var(--brand)"></div></div>'
        + '<div style="display:grid;grid-template-columns:repeat(auto-fit,minmax(210px,1fr));gap:10px">'
        + steps.map(function (x, i) {
            var ok = !!st[x.k];
            return '<button type="button" class="ob-step" data-tab="' + x.tab + '" data-k="' + x.k + '" style="text-align:left;border:1px solid ' + (ok ? '#bbf7d0' : 'var(--line)') + ';background:' + (ok ? '#f0fdf4' : '#fff') + ';border-radius:10px;padding:12px;cursor:pointer;font:inherit;color:inherit">'
              + '<div style="display:flex;gap:8px;align-items:center;font-weight:600"><span style="display:inline-flex;color:' + (ok ? '#16a34a' : 'var(--muted)') + '">' + ico(ok ? 'check-circle-2' : 'circle', 18) + '</span>' + (i + 1) + '. ' + esc(x.t) + '</div>'
              + '<div style="font-size:12.5px;color:var(--muted);margin-top:4px">' + esc(x.d) + '</div></button>';
          }).join('')
        + '</div>';
      $$('#onboardCard .ob-step').forEach(function (b) {
        b.onclick = function () {
          showTab(b.dataset.tab);
          if (b.dataset.k === 'wa') setTimeout(function () { var c = document.getElementById('fonConnCard'); if (c && c.scrollIntoView) c.scrollIntoView({ behavior: 'smooth', block: 'start' }); }, 400);
        };
      });
      $('#obHide').onclick = function () {
        api('onboarding_dismiss', { method: 'POST', body: { dismiss: true } }).then(function () { el.style.display = 'none'; });
      };
    }).catch(function () { el.style.display = 'none'; });
  }
  setInterval(function () { if (!document.hidden) renderOnboarding(); }, 60000);

  /* ====================================================================== *
   *  USAGE CARD (v1.1.5) — renders in Reports tab, all roles
   * ====================================================================== */
  function loadUsageCard() {
    var card = document.getElementById('usageCard');
    if (!card) return;
    api('usage_dashboard').then(function (res) {
      if (!res.ok) { card.style.display = 'none'; return; }
      card.style.display = '';

      // v1.1.9: inject Lucide icon ke header
      var headIcon = document.getElementById('ucHeadIcon');
      if (headIcon && !headIcon.firstChild) headIcon.innerHTML = ico('activity', 20);

      // Tier badge — pill dengan label kecil + dot + nama tier
      var tierLabels  = { starter:'Starter', growth:'Growth', business:'Business', pro:'Pro', custom:'Custom' };
      // Gradient backgrounds for tiers — give a premium feel
      var tierStyles  = {
        starter:  'linear-gradient(135deg,#64748b,#475569)',
        growth:   'linear-gradient(135deg,#0891b2,#0e7490)',
        business: 'linear-gradient(135deg,#140383,#3730a3)',
        pro:      'linear-gradient(135deg,#16a34a,#15803d)',
        custom:   'linear-gradient(135deg,#d97706,#b45309)',
      };
      tierLabels.trial = 'Trial'; tierStyles.trial = 'linear-gradient(135deg,#4f46e5,#3730a3)';   // v1.2.90
      var tier  = (res.tier || 'starter').toLowerCase();
      var tBadge = document.getElementById('ucTier');
      tBadge.innerHTML = '<span class="uc-dot"></span>'
                       + '<span class="uc-label">Paket</span>'
                       + (tierLabels[tier] || tier) + (res.trial && res.trial.tier === 'growth' ? ' · Growth' : '');   // v1.2.172: trial-paket
      tBadge.style.background = tierStyles[tier] || tierStyles.starter;
      tBadge.className = 'uc-pill uc-tier-' + tier;

      // License status badge — pill dengan ikon emoji + label + status
      var statusLabels = { active:'Aktif', expired:'Expired', suspended:'Suspended' };
      var statusIcons  = { active: ico('check-circle-2',13), expired: ico('clock-3',13), suspended: ico('ban',13) };
      var statusStyles = {
        active:    'linear-gradient(135deg,#16a34a,#15803d)',
        expired:   'linear-gradient(135deg,#d97706,#b45309)',
        suspended: 'linear-gradient(135deg,#c4302b,#991b1b)',
      };
      var st = res.license_status || 'active';
      var sBadge = document.getElementById('ucStatus');
      sBadge.innerHTML = '<span class="uc-dot"></span>'
                       + '<span class="uc-label">Lisensi</span>'
                       + (statusLabels[st] || st);
      sBadge.style.background = statusStyles[st] || statusStyles.active;
      sBadge.className = 'uc-pill uc-status-' + st;

      renderPlanCard();   // v1.2.172: trial-paket
      if (res.trial) {   // v1.2.90: kartu pemakaian untuk masa trial
        res.chats_used = res.trial.used; res.chat_cap = res.trial.cap;
        res.chat_pct = res.trial.cap > 0 ? Math.round(res.trial.used / res.trial.cap * 100) : 0;
      }
      // Chat used / cap
      var used = res.chats_used || 0;
      var cap = res.chat_cap || 0;
      var pct = res.usage_pct || 0;
      // v1.2.9: chat-based — bar & display pakai chat count, bukan usage_pct (cost)
      var chatPct = (typeof res.chat_pct === 'number') ? res.chat_pct : (res.chat_cap > 0 ? Math.round((res.chats_used||0) / res.chat_cap * 100) : 0);
      document.getElementById('ucUsedRaw').textContent = cap > 0 ? used + ' / ' + cap : used + ' (unlimited)';
      var bar = document.getElementById('ucBar');
      bar.style.width = Math.min(chatPct, 100) + '%';
      bar.style.background = chatPct >= 100 ? '#c4302b' : (chatPct >= 90 ? '#d97706' : '#16a34a');
      var pctEl = document.getElementById('ucPct');
      pctEl.textContent = res.chat_cap > 0 ? (res.chats_used||0) + ' / ' + res.chat_cap + ' balasan AI' : (res.chats_used||0) + ' balasan AI'; // v1.2.9: chat-based; v1.2.212: label-ai
      pctEl.style.color = res.cap_reached ? '#c4302b' : (res.cap_warning ? '#d97706' : 'var(--muted)');

      // Days left
      document.getElementById('ucDaysLeft').textContent = (res.days_left_month || 0) + ' hari';
      if (res.trial) {   // v1.2.90
        var dl = document.getElementById('ucDaysLeft'), ur = document.getElementById('ucUsedRaw'), hh = card.querySelector('h3');
        dl.textContent = res.trial.days_left + ' hari';
        if (dl.previousElementSibling) dl.previousElementSibling.textContent = 'Sisa Masa Trial';
        if (dl.nextElementSibling) dl.nextElementSibling.textContent = 'Berakhir ' + new Date(res.trial.ends * 1000).toLocaleDateString('id-ID', { day: 'numeric', month: 'long', year: 'numeric' });
        if (ur.previousElementSibling) ur.previousElementSibling.textContent = 'Balasan AI Terpakai (total trial)';
        if (hh && hh.lastChild && hh.lastChild.nodeType === 3) hh.lastChild.textContent = ' Penggunaan Masa Trial';
      }

      // v1.2.57: pesan WA keluar (Cloud API Meta) vs 1.000 service message gratis
      var wo = res.wa_out || null, waBox = document.getElementById('ucWaBox');
      if (waBox) {
        if (wo && wo.enabled && (wo.provider || 'meta') === 'meta') {   // v1.2.76: hanya Meta
          var q = wo.free_quota || 1000, sv = wo.service || 0, tp = wo.template || 0;
          var paid = Math.max(0, sv - q);
          var wPct = Math.round(sv / q * 100);
          waBox.style.display = '';
          document.getElementById('ucWaUsed').textContent = sv + ' / ' + q;
          var wb = document.getElementById('ucWaBar');
          wb.style.width = Math.min(wPct, 100) + '%';
          wb.style.background = wPct >= 100 ? '#c4302b' : (wPct >= 80 ? '#d97706' : '#16a34a');
          var note = paid > 0 ? (paid + ' service berbayar') : ('Gratis, sisa ' + (q - sv));
          if (tp > 0) note += ' · ' + tp + ' template (berbayar)';
          if (wo.saved > 0) note += ' · ' + wo.saved + ' dihemat';   // v1.2.89
          if ((wo.by_ch || []).length > 1) note += ' · ' + wo.by_ch.map(function (c) { return c.label + ': ' + c.service + (c.template ? ' + ' + c.template + ' tpl' : ''); }).join(', ');   // v1.2.98: multi-nomor
          var nEl = document.getElementById('ucWaNote');
          nEl.textContent = note;
          nEl.style.color = paid > 0 ? '#c4302b' : (wPct >= 80 ? '#d97706' : 'var(--muted)');
        } else {
          waBox.style.display = 'none';
        }
      }

      // Chart 30 hari — inline SVG bar chart
      drawDailyChart(res.daily_30d || [], res.today_wib);
    }).catch(function () { card.style.display = 'none'; });
  }

  function drawDailyChart(daily, todayWib) {
    var container = document.getElementById('ucChart');
    if (!container) return;

    // Build full 30-day array (fill missing days with 0)
    var days = [];
    var todayMs = Date.parse((todayWib || new Date().toISOString().slice(0,10)) + 'T00:00:00Z');
    for (var i = 29; i >= 0; i--) {
      var d = new Date(todayMs - i * 86400000);
      var ds = d.toISOString().slice(0,10);
      var hit = daily.find(function(x){ return x.date === ds; });
      days.push({ date: ds, calls: hit ? hit.calls : 0 });
    }
    var max = Math.max.apply(null, days.map(function(d){return d.calls;}).concat([1]));
    var w = container.clientWidth - 24 || 400;
    var h = 130;
    var pad = { top: 8, right: 8, bottom: 22, left: 28 };
    var chartW = w - pad.left - pad.right;
    var chartH = h - pad.top - pad.bottom;
    var barW = chartW / days.length;

    // Y axis ticks: 0, 50%, 100% of max
    var yMax = Math.max(max, 1);
    var ticks = [0, Math.ceil(yMax/2), yMax];

    var bars = days.map(function (d, i) {
      var bh = d.calls > 0 ? Math.max(2, (d.calls / yMax) * chartH) : 0;
      var x = pad.left + i * barW + 1;
      var y = pad.top + chartH - bh;
      var color = d.calls > 0 ? BRAND_C1 : '#e2e5ee';   // v1.2.169: tema-warna
      return '<rect x="'+x.toFixed(1)+'" y="'+y.toFixed(1)+'" width="'+(barW-2).toFixed(1)+'" height="'+bh.toFixed(1)+'" fill="'+color+'" rx="1"><title>'+d.date+': '+d.calls+' chat</title></rect>';
    }).join('');

    var yAxis = ticks.map(function (t) {
      var y = pad.top + chartH - (t / yMax) * chartH;
      return '<text x="'+(pad.left-4)+'" y="'+(y+3)+'" text-anchor="end" font-size="9" fill="#5d6479">'+t+'</text>'
           + '<line x1="'+pad.left+'" x2="'+(w-pad.right)+'" y1="'+y+'" y2="'+y+'" stroke="#eef0fb" stroke-width="1"/>';
    }).join('');

    // X axis: label every ~5th day
    var xLabels = days.map(function (d, i) {
      if (i % 5 !== 0 && i !== days.length-1) return '';
      var x = pad.left + i * barW + barW/2;
      var label = d.date.slice(5);   // MM-DD
      return '<text x="'+x.toFixed(1)+'" y="'+(h-6)+'" text-anchor="middle" font-size="9" fill="#5d6479">'+label+'</text>';
    }).join('');

    container.innerHTML = '<svg viewBox="0 0 '+w+' '+h+'" width="100%" height="'+h+'" xmlns="http://www.w3.org/2000/svg">'+yAxis+bars+xLabels+'</svg>';
  }

  /* ====================================================================== *
   *  LEADS (v1.2.20) — AI menyiapkan bahan, agent yang memutuskan
   * ====================================================================== */
  var leadData = [];
  var leadFilter = 'all';
  // v1.2.27: mengingat kartu mana yang terbuka. Tanpa ini, mengubah status akan
  // memuat ulang daftar dan menutup semuanya — Anda kehilangan tempat.
  var leadOpenState = {};
  var LEAD_STATUS = {
    baru:      { label: 'Baru',      bg: '#e5e7eb', fg: '#374151' },
    qualified: { label: 'Qualified', bg: '#d1fae5', fg: '#065f46' },
    follow_up: { label: 'Follow-up', bg: '#fed7aa', fg: '#9a3412' },
    proposal:  { label: 'Penawaran', bg: '#ede9fe', fg: '#6d28d9' },   // v1.2.216: pipeline-sales
    negosiasi: { label: 'Negosiasi', bg: '#fef9c3', fg: '#a16207' },
    // v1.2.118: close-deal-lose — Closed dipecah dua; 'closed' = data lama
    closed_deal: { label: 'Close Deal', bg: '#bbf7d0', fg: '#166534', grp: 'Close' },
    closed_lost: { label: 'Close Lose', bg: '#fecaca', fg: '#991b1b', grp: 'Close' },
    closed:      { label: 'Closed (lama)', bg: '#e0e7ff', fg: '#3730a3', legacy: true }
  };
  function leadStatusOptionsHtml(cur) {
    var h = '', grp = '';
    Object.keys(LEAD_STATUS).forEach(function (k) {
      var d = LEAD_STATUS[k];
      if ((d.legacy || d.off) && cur !== k) return;   // v1.2.216: pipeline-sales   // pilihan lama hanya tampil bila masih dipakai
      var g = d.grp || '';
      if (g !== grp) { if (grp) h += '</optgroup>'; if (g) h += '<optgroup label="' + g + '">'; grp = g; }
      h += '<option value="' + k + '"' + (cur === k ? ' selected' : '') + '>' + d.label + (d.legacy ? ' \u2014 pilih Deal/Lose' : '') + '</option>';
    });
    if (grp) h += '</optgroup>';
    return h;
  }
  function leadFilterLegacyBtn() {
    var ada = leadData.some(function (l) { return l.status === 'closed'; });
    var b = $('#leadFltLegacy');
    if (b) b.style.display = ada ? '' : 'none';
    if (!ada && leadFilter === 'closed') {
      leadFilter = 'all';
      $$('.lead-filter').forEach(function (x) { x.classList.toggle('active', x.dataset.leadStatus === 'all'); });
    }
  }
  // v1.2.39: tag pipeline kontak (stage) — terpisah dari status lead di atas.
  var CONTACT_STAGE = {
    new:             { label: 'Unrated',         bg: '#e5e7eb', fg: '#374151' },
    cold:            { label: 'Cold',            bg: '#dbeafe', fg: '#1e40af' },
    warm:            { label: 'Warm',            bg: '#fef3c7', fg: '#92400e' },
    hot_prospect:    { label: 'Hot Prospect',    bg: '#fee2e2', fg: '#991b1b' },
    lost:            { label: 'Unqualified',     bg: '#f3f4f6', fg: '#6b7280' },
    active_customer: { label: 'Active Customer', bg: '#d1fae5', fg: '#065f46' },
    churned:         { label: 'Churned',         bg: '#fde68a', fg: '#78350f' }
  };
  // v1.2.39 fase2g: urutan tampil di dropdown, dikelompokkan dengan garis
  // pemisah -- '__sep__' bukan value asli, cuma penanda render pemisah.
  var CONTACT_STAGE_ORDER = ['new', '__sep__', 'cold', 'warm', 'hot_prospect', '__sep__', 'lost', '__sep__', 'active_customer', 'churned'];
  function contactStageOptionsHtml(selected) {
    return CONTACT_STAGE_ORDER.map(function (k) {
      if (k === '__sep__') return '<option disabled>\u2500\u2500\u2500\u2500\u2500</option>';
      return '<option value="' + k + '"' + (selected === k ? ' selected' : '') + '>' + CONTACT_STAGE[k].label + '</option>';
    }).join('');
  }
  var CONTACT_VIP_STYLE = 'background:#fef9c3;color:#92400e';
  // v1.2.117: filter-lead-rating — pilihan filter Lead Rating (Percakapan WA & Web)
  var STAGE_FLT_EXTRA = { vip: 'VIP', nonum: 'Tanpa nomor HP' };
  function stageFltLabel(k) {
    if (!k) return 'Semua Lead Rating';
    return CONTACT_STAGE[k] ? CONTACT_STAGE[k].label : (STAGE_FLT_EXTRA[k] || k);
  }
  function stageFltKeys(withNonum) {
    var ks = [''];
    CONTACT_STAGE_ORDER.forEach(function (k) { if (k !== '__sep__') ks.push(k); });
    ks.push('vip');
    if (withNonum) ks.push('nonum');
    return ks;
  }
  function stageFltOptionsHtml(sel, counts) {
    return stageFltKeys(false).map(function (k) {
      var n = counts ? counts[k || 'all'] : null;
      return '<option value="' + k + '"' + (sel === k ? ' selected' : '') + '>' + esc(stageFltLabel(k)) +
        (n != null ? ' (' + Number(n).toLocaleString('id-ID') + ')' : '') + '</option>';
    }).join('');
  }
  function contactStageBadgeHtml(stage, vip, extraStyle) {
    var cs = CONTACT_STAGE[stage || 'new'] || CONTACT_STAGE.new;
    var html = '<span class="tag" style="background:' + cs.bg + ';color:' + cs.fg + (extraStyle || '') + '">' + esc(cs.label) + '</span>';
    if (vip) html += ' <span class="tag" style="' + CONTACT_VIP_STYLE + '">' + ico('star', 12) + ' VIP</span>';
    return html;
  }
  // Simpan stage/vip lalu segarkan daftar percakapan. Dipakai dari daftar
  // percakapan maupun kepala thread.
  function saveContactStage(num, stage, vip) {
    api('save_contact_stage', { method: 'POST', body: { number: num, stage: stage, vip: vip } }).then(function (r) {
      // v1.2.39 fase2b: refresh thread yang SEDANG DIBUKA juga (bukan cuma
      // daftar percakapan) — kalau tidak, dropdown kelihatan balik ke nilai
      // lama karena kepala thread tidak ikut digambar ulang dengan data baru.
      if (r && r.ok) {
        toast('Tag disimpan.');
        // v1.2.106: kontak-sinkron — sinkronkan cache menu Kontak (sebelumnya perubahan dari
        // Percakapan WA tidak pernah sampai ke contactData karena tab dimuat sekali).
        for (var _ci = 0; _ci < contactData.length; _ci++) {
          if (String(contactData[_ci].number) === String(num)) {
            contactData[_ci].stage = r.stage || stage;
            contactData[_ci].vip = (r.vip !== undefined) ? !!r.vip : !!vip;
            break;
          }
        }
        if ($('#contactList') && $('#panel-kontak') && $('#panel-kontak').classList.contains('active')) renderContacts();
        // v1.2.39 fase2c: tunggu fetchWaConvs SELESAI (waState.convs terisi
        // data baru) baru gambar ulang thread -- kalau paralel, thread bisa
        // selesai duluan dan baca data lama (dropdown keliatan balik lagi).
        fetchWaConvs().then(function () { if (waState.current === num) fetchWaThread(num); });
        if ($('#panel-webchat') && $('#panel-webchat').classList.contains('active')) {   // v1.2.117: filter-lead-rating
          fetchWebConvs(true).then(function () { if (webState.current) fetchWebThread(webState.current, true); });
        }
      } else toast((r && r.error) || 'Gagal menyimpan tag.', true);
    });
  }
  // v1.2.39 fase4: simpan nama/tanggal lahir pelanggan (partial update --
  // cuma kirim field yang diisi). Update data lokal supaya tidak perlu
  // refetch penuh, cukup renderContacts() ulang.
  function saveContactInfo(num, fields) {
    var body = { number: num };
    if (fields.cust_name !== undefined) body.cust_name = fields.cust_name;
    if (fields.cust_dob !== undefined) body.cust_dob = fields.cust_dob;
    api('save_contact_info', { method: 'POST', body: body }).then(function (r) {
      if (r && r.ok) {
        toast('Data pelanggan disimpan.');
        var idx = -1;
        for (var i = 0; i < contactData.length; i++) { if (contactData[i].number === num) { idx = i; break; } }
        if (idx > -1) {
          if (fields.cust_name !== undefined) contactData[idx].cust_name = r.cust_name;
          if (fields.cust_dob !== undefined) contactData[idx].cust_dob = r.cust_dob;
        }
      } else toast((r && r.error) || 'Gagal menyimpan data pelanggan.', true);
    });
  }


  /* ====================================================================== *
   *  v1.2.214: task — to-do dari bubble chat, menu Task (kanban) + catatan
   * ====================================================================== */
  var TK_ST = {
    'new':    { label: 'New',         bg: '#e0e7ff', fg: '#3730a3' },
    progress: { label: 'On Progress', bg: '#dbeafe', fg: '#1d4ed8' },
    pending:  { label: 'Pending',     bg: '#fef3c7', fg: '#92400e' },
    done:     { label: 'Done',        bg: '#dcfce7', fg: '#166534' },
    closed:   { label: 'Closed',      bg: '#e5e7eb', fg: '#374151' }
  };
  var tkS = { list: [], users: [], me: '', idx: {}, filter: 'all', q: '', loaded: false, wired: false };
  try { var _tkf = localStorage.getItem('dei_task_flt'); if (['all', 'mine', 'byme'].indexOf(_tkf) !== -1) tkS.filter = _tkf; } catch (e) {}
  function tkIndex214() {
    tkS.idx = {};
    tkS.list.forEach(function (t) { if (t.src && t.src.num && t.src.k) tkS.idx[t.src.num + '|' + t.src.k] = t; });
    tkBadge214();
  }
  function tkSet214(r) {
    tkS.list = r.tasks || []; tkS.users = r.users || tkS.users; tkS.me = r.me || tkS.me; tkS.loaded = true;
    tkIndex214();
  }
  function tkFetch214(then) {
    api('tasks_list').then(function (r) {
      if (!r || !r.ok) { if (then) toast((r && r.error) || 'Gagal memuat task.', true); return; }
      tkSet214(r);
      if (typeof then === 'function') then();
    });
  }
  function tkUpsert214(t) {
    var i = -1;
    tkS.list.forEach(function (x, j) { if (x.id === t.id) i = j; });
    if (i >= 0) tkS.list[i] = t; else tkS.list.unshift(t);
    tkIndex214(); tkAfter214(t);
  }
  function tkRemove214(id) {
    var t = tkS.list.filter(function (x) { return x.id === id; })[0];
    tkS.list = tkS.list.filter(function (x) { return x.id !== id; });
    tkIndex214(); tkAfter214(t);
  }
  function tkAfter214(t) {   // segarkan tampilan yang memakai task
    var p = $('#panel-tasks'); if (p && p.classList.contains('active')) tkRender214();
    if (t && t.src && waState.current && String(waState.current) === String(t.src.num)) { try { fetchWaThread(waState.current); } catch (e) {} }
  }
  function tkBadge214() {
    var b = document.querySelector('#nav button[data-tab="tasks"]'); if (!b) return;
    var n = tkS.list.filter(function (t) { return t.assignee === tkS.me && ['new', 'progress', 'pending'].indexOf(t.status) !== -1; }).length;
    var s = b.querySelector('.tk-nb');
    if (!s) { s = document.createElement('span'); s.className = 'tk-nb'; b.appendChild(s); }
    s.textContent = n; s.style.display = n ? '' : 'none'; s.title = n + ' task terbuka untuk Anda';
  }
  function tkUserName214(un) {
    if (!un) return '';
    var u = tkS.users.filter(function (x) { return x.username === un; })[0];
    return u ? (u.name || u.username) : un;
  }
  function tkUserOpts214(sel) {
    var has = !sel;
    var h = '<option value="">— Belum ditentukan —</option>' + tkS.users.map(function (u) {
      if (u.username === sel) has = true;
      return '<option value="' + esc(u.username) + '"' + (u.username === sel ? ' selected' : '') + '>' + esc(u.name || u.username) + (u.username === tkS.me ? ' (saya)' : '') + '</option>';
    }).join('');
    if (!has) h += '<option value="' + esc(sel) + '" selected>' + esc(sel) + '</option>';
    return h;
  }
  function tkStatusOpts214(sel) {
    return Object.keys(TK_ST).map(function (k) { return '<option value="' + k + '"' + (k === sel ? ' selected' : '') + '>' + TK_ST[k].label + '</option>'; }).join('');
  }
  function tkSrcName214(src) {
    if (!src || !src.num) return '';
    return src.name ? src.name + ' (+' + src.num + ')' : '+' + src.num;
  }
  function tkSnip214(src) {
    var s = String((src && src.text) || '').replace(/\s+/g, ' ').trim();
    if (!s && src && src.mt) s = '[' + ({ image: 'Gambar', video: 'Video', audio: 'Pesan suara', document: 'Dokumen', sticker: 'Stiker' }[src.mt] || 'Media') + (src.mn ? ' ' + src.mn : '') + ']';
    return s;
  }
  function tkToday214() { var d = new Date(); return d.getFullYear() + '-' + String(d.getMonth() + 1).padStart(2, '0') + '-' + String(d.getDate()).padStart(2, '0'); }
  function tkDueHtml214(t) {
    if (!t.due) return '';
    var late = t.due < tkToday214() && t.status !== 'done' && t.status !== 'closed';
    return '<span class="tk-due' + (late ? ' late' : '') + '" title="Tenggat' + (late ? ' — terlewat' : '') + '">' + ico('calendar', 12) + ' ' + esc(t.due.split('-').reverse().join('/')) + '</span>';
  }

  // ---- tautan di bubble Percakapan WA ----
  function waTaskBtn214(rq) {
    var num = waState.current; if (!num || !rq || !rq.k) return '';
    var t = tkS.idx[num + '|' + rq.k];
    if (t) { var d = TK_ST[t.status] || TK_ST['new']; return '<a href="#" class="wa-tk on" data-tk="' + esc(t.id) + '" title="Buka task: ' + esc(t.title) + '">' + ico('list-todo', 12) + ' Task · ' + esc(d.label) + '</a>'; }
    return '<a href="#" class="wa-tk" data-tk-k="' + esc(rq.k) + '" title="Jadikan to-do (menu Task)">' + ico('list-todo', 12) + ' To-do</a>';
  }
  function tk214WaInit() {
    if (waState.tk214) return; waState.tk214 = true;
    tkFetch214(function () { if (waState.current && tkS.list.length) fetchWaThread(waState.current); });
    var body = $('#waThreadBody');
    if (body) body.addEventListener('click', function (e) {
      var a = e.target.closest ? e.target.closest('.wa-tk') : null; if (!a) return;
      e.preventDefault();
      var id = a.getAttribute('data-tk');
      if (id) { tkOpen214(id); return; }
      var k = a.getAttribute('data-tk-k'), b = (waState.bIdx || {})[k], num = waState.current;
      if (!num || !b) return;
      var cv = (waState.convCache || {})[String(num)] || {};
      tkNew214({ number: String(num), k: k, ts: b.ts, kind: b.kind, text: b.text, mt: b.mt, mn: b.mn, name: cv.name || '' });
    });
  }

  // ---- modal ----
  function tkModal214(title, inner, wire) {
    var ov = document.createElement('div'); ov.className = 'thm-ov tk-ov';
    ov.innerHTML = '<div class="thm-box tk-box"><div class="thm-hd"><h3>' + title + '</h3><button type="button" class="thm-x tk-x" aria-label="Tutup">' + ico('x', 18) + '</button></div>' + inner + '</div>';
    document.body.appendChild(ov);
    var onKey = function (e) { if (e.key === 'Escape') close(); };
    function close() { if (ov.parentNode) ov.parentNode.removeChild(ov); document.removeEventListener('keydown', onKey); }
    document.addEventListener('keydown', onKey);
    ov.addEventListener('mousedown', function (e) { if (e.target === ov) close(); });
    Array.prototype.forEach.call(ov.querySelectorAll('.tk-x'), function (b) { b.onclick = close; });
    wire(ov, close);
    return ov;
  }
  function tkSrcBox214(src, withBtn) {
    if (!src || !src.num) return '';
    var who = src.kind === 'in' ? 'Pelanggan' : (src.kind === 'manual' ? 'Admin' : 'Bot');
    return '<div class="tk-src"><div class="tk-src-h">' + ico('message-circle', 13) + ' <b>' + esc(tkSrcName214(src)) + '</b>' +
      '<span>' + who + (src.ts ? ' · ' + esc(String(src.ts).slice(0, 16)) : '') + '</span>' +
      (withBtn ? '<button type="button" class="btn ghost sm tk-go">Buka di chat</button>' : '') + '</div>' +
      '<div class="tk-src-t">' + esc(tkSnip214(src) || '(pesan)') + '</div></div>';
  }
  function tkNew214(src) {
    if (src) {
      var ada = tkS.idx[src.number + '|' + src.k];
      if (ada) { tkOpen214(ada.id); return; }
    }
    var srcView = src ? { num: src.number, k: src.k, ts: src.ts, kind: src.kind, text: src.text, mt: src.mt, mn: src.mn, name: src.name } : null;
    var snip = srcView ? tkSnip214(srcView) : '';
    var judul = snip.length > 120 ? snip.slice(0, 117) + '…' : snip;
    tkModal214('Task baru',
      tkSrcBox214(srcView, false) +
      '<div class="row"><label class="fl">Judul to-do</label><input type="text" class="tk-title" maxlength="300" placeholder="Mis. Kirim penawaran harga ke pelanggan" value="' + esc(judul) + '"></div>' +
      '<div class="tk-grid">' +
        '<div class="row"><label class="fl">Status</label><select class="tk-st">' + tkStatusOpts214('new') + '</select></div>' +
        '<div class="row"><label class="fl">Ditugaskan ke</label><select class="tk-as">' + tkUserOpts214(tkS.me) + '</select></div>' +
        '<div class="row"><label class="fl">Tenggat (opsional)</label><input type="date" class="tk-due-in"></div>' +
      '</div>' +
      '<div class="row"><label class="fl">Catatan (opsional)</label><textarea class="tk-note-in" rows="3" maxlength="2000" placeholder="Detail yang perlu dikerjakan…"></textarea></div>' +
      '<div class="tk-foot"><button type="button" class="btn ghost tk-x">Batal</button><button type="button" class="btn tk-save">' + ico('list-todo', 15) + ' Simpan task</button></div>',
      function (ov, close) {
        var ti = ov.querySelector('.tk-title'); setTimeout(function () { ti.focus(); ti.select(); }, 30);
        var go = function () {
          var title = ti.value.trim();
          if (!title) { toast('Judul to-do wajib diisi.', true); ti.focus(); return; }
          var bt = ov.querySelector('.tk-save'); bt.disabled = true;
          var body = { title: title, status: ov.querySelector('.tk-st').value, assignee: ov.querySelector('.tk-as').value,
                       due: ov.querySelector('.tk-due-in').value, note: ov.querySelector('.tk-note-in').value };
          if (src) body.src = src;
          api('task_save', { method: 'POST', body: body }).then(function (r) {
            bt.disabled = false;
            if (!r || !r.ok) { toast((r && r.error) || 'Gagal menyimpan task.', true); return; }
            close(); tkUpsert214(r.task);
            toast(r.dup ? 'Pesan ini sudah punya task — dibuka.' : 'Task dibuat — lihat di menu Task.');
            if (r.dup) tkOpen214(r.task.id);
          });
        };
        ov.querySelector('.tk-save').onclick = go;
        ti.onkeydown = function (e) { if (e.key === 'Enter') { e.preventDefault(); go(); } };
      });
  }
  function tkNotesHtml214(t) {
    var n = t.notes || [];
    if (!n.length) return '<div class="tk-empty-n">Belum ada catatan.</div>';
    return n.map(function (x) {
      return '<div class="tk-n"><div class="tk-n-h"><b>' + esc(x.by_name || x.by || '') + '</b><span>' + esc(String(x.at || '').slice(0, 16)) + '</span>' +
        (x.can_del ? '<button type="button" class="tk-n-del" data-nid="' + esc(x.id) + '" title="Hapus catatan">' + ico('trash-2', 12) + '</button>' : '') + '</div>' +
        '<div class="tk-n-t">' + esc(x.text || '') + '</div></div>';
    }).join('');
  }
  function tkLogHtml214(t) {
    var l = (t.log || []).slice(-8).reverse();
    if (!l.length) return '';
    return '<details class="tk-log"><summary>Riwayat status (' + (t.log || []).length + ')</summary>' + l.map(function (x) {
      var d = TK_ST[x.s] || { label: x.s };
      return '<div>' + esc(String(x.at || '').slice(0, 16)) + ' — <b>' + esc(d.label) + '</b> oleh ' + esc(x.by_name || x.by || '') + '</div>';
    }).join('') + '</details>';
  }
  function tkOpen214(id) {
    var t = tkS.list.filter(function (x) { return x.id === id; })[0];
    if (!t) { tkFetch214(function () { if (tkS.list.some(function (x) { return x.id === id; })) tkOpen214(id); else toast('Task tidak ditemukan.', true); }); return; }
    tkModal214('Detail task',
      '<div class="row"><label class="fl">Judul to-do</label><input type="text" class="tk-title" maxlength="300" value="' + esc(t.title) + '"></div>' +
      '<div class="tk-grid">' +
        '<div class="row"><label class="fl">Status</label><select class="tk-st">' + tkStatusOpts214(t.status) + '</select></div>' +
        '<div class="row"><label class="fl">Ditugaskan ke</label><select class="tk-as">' + tkUserOpts214(t.assignee) + '</select></div>' +
        '<div class="row"><label class="fl">Tenggat</label><input type="date" class="tk-due-in" value="' + esc(t.due || '') + '"></div>' +
      '</div>' +
      tkSrcBox214(t.src, true) + crmLeadBox215(t) + /* v1.2.215: crm-aktivitas */
      '<div class="tk-sec">' + ico('sticky-note', 14) + ' Catatan <span class="tk-nc">' + (t.notes || []).length + '</span></div>' +
      '<div class="tk-notes">' + tkNotesHtml214(t) + '</div>' +
      '<div class="tk-add"><textarea class="tk-note-in" rows="2" maxlength="2000" placeholder="Tulis catatan… (Ctrl+Enter untuk kirim)"></textarea><button type="button" class="btn ghost sm tk-note-add">' + ico('plus', 14) + ' Tambah</button></div>' +
      tkLogHtml214(t) +
      '<div class="tk-meta">Dibuat ' + esc(String(t.created_at || '').slice(0, 16)) + ' oleh ' + esc(t.by_name || t.by || '') +
        (t.updated_at && t.updated_at !== t.created_at ? ' · diubah ' + esc(String(t.updated_at).slice(0, 16)) + (t.updated_by_name ? ' oleh ' + esc(t.updated_by_name) : '') : '') + '</div>' +
      '<div class="tk-foot">' + (t.can_del ? '<button type="button" class="btn danger sm tk-del" style="margin-right:auto">' + ico('trash-2', 14) + ' Hapus task</button>' : '') +
        '<button type="button" class="btn ghost tk-x">Tutup</button><button type="button" class="btn tk-save">Simpan</button></div>',
      function (ov, close) {
        var cur = t;
        var go = ov.querySelector('.tk-go');
        if (go) go.onclick = function () { close(); tkGoChat214(cur); };
        ov.querySelector('.tk-save').onclick = function () {
          var title = ov.querySelector('.tk-title').value.trim();
          if (!title) { toast('Judul to-do wajib diisi.', true); return; }
          var bt = this; bt.disabled = true;
          api('task_save', { method: 'POST', body: { id: cur.id, title: title, status: ov.querySelector('.tk-st').value,
            assignee: ov.querySelector('.tk-as').value, due: ov.querySelector('.tk-due-in').value } }).then(function (r) {
            bt.disabled = false;
            if (!r || !r.ok) { toast((r && r.error) || 'Gagal menyimpan.', true); return; }
            tkUpsert214(r.task); close(); toast('Task disimpan.');
          });
        };
        var ta = ov.querySelector('.tk-note-in');
        function paintNotes() {
          ov.querySelector('.tk-notes').innerHTML = tkNotesHtml214(cur);
          ov.querySelector('.tk-nc').textContent = (cur.notes || []).length;
        }
        var addNote = function () {
          var v = ta.value.trim(); if (!v) { ta.focus(); return; }
          var bt = ov.querySelector('.tk-note-add'); bt.disabled = true;
          api('task_note', { method: 'POST', body: { id: cur.id, text: v } }).then(function (r) {
            bt.disabled = false;
            if (!r || !r.ok) { toast((r && r.error) || 'Gagal menambah catatan.', true); return; }
            ta.value = ''; cur = r.task; tkUpsert214(cur); paintNotes();
          });
        };
        ov.querySelector('.tk-note-add').onclick = addNote;
        ta.onkeydown = function (e) { if (e.key === 'Enter' && (e.ctrlKey || e.metaKey)) { e.preventDefault(); addNote(); } };
        ov.querySelector('.tk-notes').addEventListener('click', function (e) {
          var b = e.target.closest ? e.target.closest('.tk-n-del') : null; if (!b) return;
          if (!confirm('Hapus catatan ini?')) return;
          api('task_note', { method: 'POST', body: { id: cur.id, note_id: b.getAttribute('data-nid'), remove: 1 } }).then(function (r) {
            if (!r || !r.ok) { toast((r && r.error) || 'Gagal menghapus catatan.', true); return; }
            cur = r.task; tkUpsert214(cur); paintNotes();
          });
        });
        var del = ov.querySelector('.tk-del');
        if (del) del.onclick = function () {
          if (!confirm('Hapus task "' + cur.title + '"?\n\nTask beserta catatannya hilang permanen. Pesan chat-nya tidak terhapus.')) return;
          api('task_delete', { method: 'POST', body: { id: cur.id } }).then(function (r) {
            if (!r || !r.ok) { toast((r && r.error) || 'Gagal menghapus task.', true); return; }
            close(); tkRemove214(cur.id); toast('Task dihapus.');
          });
        };
      });
  }
  function tkGoChat214(t) {
    if (!t || !t.src || !t.src.num) return;
    var wasLoaded = !!loaded.wachat;
    showTab('wachat');
    setTimeout(function () {
      try { if (t.src.ts) waJumpTs164(String(t.src.num), t.src.ts, t.src.k); else selectWaConv(String(t.src.num)); } catch (e) {}
    }, wasLoaded ? 0 : 700);
  }
  function tkSaveQuick214(id, body) {
    body.id = id;
    api('task_save', { method: 'POST', body: body }).then(function (r) {
      if (!r || !r.ok) { toast((r && r.error) || 'Gagal menyimpan.', true); tkFetch214(tkRender214); return; }
      tkUpsert214(r.task);
    });
  }

  // ---- menu Task (kanban) ----
  function loadTasks214() {
    if (!tkS.wired) {
      tkS.wired = true;
      $$('[data-tk-f]').forEach(function (b) {
        b.onclick = function () {
          tkS.filter = b.dataset.tkF;
          try { localStorage.setItem('dei_task_flt', tkS.filter); } catch (e) {}
          tkRender214();
        };
      });
      var qt = null;
      if ($('#tkQ')) $('#tkQ').oninput = function () { var v = this.value; clearTimeout(qt); qt = setTimeout(function () { tkS.q = v.trim().toLowerCase(); tkRender214(); }, 200); };
      if ($('#tkNewBtn')) $('#tkNewBtn').onclick = function () { tkNew214(null); };
      if ($('#tkReload')) $('#tkReload').onclick = function () { tkFetch214(tkRender214); };
    }
    if (!tkS.loaded && $('#taskBoard')) $('#taskBoard').innerHTML = '<div class="card" style="text-align:center;color:var(--muted)">Memuat task…</div>';
    tkFetch214(tkRender214);
  }
  function tkMatch214(t) {
    if (tkS.filter === 'mine' && t.assignee !== tkS.me) return false;
    if (tkS.filter === 'byme' && t.by !== tkS.me) return false;
    if (!tkS.q) return true;
    var hay = [t.title, t.src && t.src.name, t.src && t.src.num, t.src && t.src.text, tkUserName214(t.assignee), t.lead_name, t.lead]
      .concat((t.notes || []).map(function (n) { return n.text; })).join(' ').toLowerCase();
    return hay.indexOf(tkS.q) !== -1;
  }
  function tkRender214() {
    var box = $('#taskBoard'); if (!box) return;
    $$('[data-tk-f]').forEach(function (b) { b.classList.toggle('active', b.dataset.tkF === tkS.filter); });
    var list = tkS.list.filter(tkMatch214);
    if (!tkS.list.length) {
      box.innerHTML = '<div class="card" style="text-align:center;color:var(--muted);line-height:1.6">Belum ada task.<br>Buka <b>Percakapan WA</b>, lalu klik <b>' + ico('list-todo', 13) + ' To-do</b> di bawah bubble pesan untuk menjadikannya task — atau klik <b>+ Task baru</b>.</div>';
      return;
    }
    var cols = Object.keys(TK_ST), by = {};
    cols.forEach(function (k) { by[k] = []; });
    list.forEach(function (t) { (by[t.status] || by['new']).push(t); });
    cols.forEach(function (k) { by[k].sort(function (a, b) { return String(b.updated_at || '').localeCompare(String(a.updated_at || '')); }); });
    box.innerHTML = (list.length ? '' : '<div class="card" style="text-align:center;color:var(--muted)">Tidak ada task pada filter / pencarian ini.</div>') +
    '<div class="lk-board tk-board">' + cols.map(function (k) {
      var d = TK_ST[k];
      return '<div class="lk-col" data-col="' + k + '">' +
        '<div class="lk-col-h"><span class="tag" style="background:' + d.bg + ';color:' + d.fg + '">' + d.label + '</span><span class="lk-n">' + by[k].length + '</span></div>' +
        '<div class="lk-list">' + (by[k].length ? by[k].map(function (t) {
          var nn = (t.notes || []).length, last = nn ? t.notes[nn - 1] : null;
          return '<div class="lk-card tk-card" draggable="true" data-tk="' + esc(t.id) + '" title="Klik untuk detail · seret ke kolom lain untuk ganti status">' +
            '<div class="lk-t">' + esc(t.title) + '</div>' +
            (t.src && t.src.num ? '<div class="lk-s tk-from">' + ico('message-circle', 12) + ' ' + esc(tkSrcName214(t.src)) + '</div>' : '') +
            (t.lead ? '<div class="lk-s tk-from">' + ico('briefcase-business', 12) + ' Lead: ' + esc(t.lead_name || ('+' + t.lead)) + '</div>' : '') +   // v1.2.215: crm-aktivitas
            '<div class="tk-chips">' +
              '<span class="tk-as-c' + (t.assignee ? '' : ' none') + '">' + ico('user', 12) + ' ' + esc(t.assignee ? tkUserName214(t.assignee) : 'Belum ditentukan') + '</span>' +
              tkDueHtml214(t) +
              (nn ? '<span class="tk-nn" title="' + nn + ' catatan">' + ico('sticky-note', 12) + ' ' + nn + '</span>' : '') +
            '</div>' +
            (last ? '<div class="lk-note">' + esc((last.by_name || last.by || '') + ': ' + last.text) + '</div>' : '') +
            '<div class="lk-f"><select class="lk-st" aria-label="Status">' + tkStatusOpts214(t.status) + '</select>' +
              (t.src && t.src.num ? '<button type="button" class="lk-chat" title="Buka di chat">' + ico('message-circle', 14) + '</button>' : '') + '</div>' +
          '</div>';
        }).join('') : '<div class="lk-empty">Seret kartu ke sini</div>') + '</div></div>';
    }).join('') + '</div>';

    var dragId = null;
    function pindah(id, st) {
      var t = tkS.list.filter(function (x) { return x.id === id; })[0];
      if (!t || t.status === st) return;
      t.status = st; tkRender214(); tkBadge214();   // langsung pindah, server menyusul
      tkSaveQuick214(id, { status: st });
    }
    $$('#taskBoard .tk-card').forEach(function (c) {
      var id = c.dataset.tk;
      c.ondragstart = function (e) { dragId = id; c.classList.add('lk-drag'); try { e.dataTransfer.setData('text/plain', id); e.dataTransfer.effectAllowed = 'move'; } catch (er) {} };
      c.ondragend = function () { c.classList.remove('lk-drag'); $$('#taskBoard .lk-col').forEach(function (x) { x.classList.remove('lk-over'); }); };
      var sel = c.querySelector('.lk-st');
      sel.onchange = function (e) { pindah(id, e.target.value); };
      sel.onmousedown = function (e) { e.stopPropagation(); };
      sel.onclick = function (e) { e.stopPropagation(); };
      var ch = c.querySelector('.lk-chat');
      if (ch) ch.onclick = function (e) { e.stopPropagation(); tkGoChat214(tkS.list.filter(function (x) { return x.id === id; })[0]); };
      c.onclick = function () { tkOpen214(id); };
    });
    $$('#taskBoard .lk-col').forEach(function (col) {
      col.ondragover = function (e) { e.preventDefault(); col.classList.add('lk-over'); };
      col.ondragleave = function (e) { if (!col.contains(e.relatedTarget)) col.classList.remove('lk-over'); };
      col.ondrop = function (e) {
        e.preventDefault(); col.classList.remove('lk-over');
        var id = dragId; try { id = e.dataTransfer.getData('text/plain') || dragId; } catch (er) {}
        dragId = null; if (id) pindah(id, col.dataset.col);
      };
    });
  }
  // badge "task terbuka untuk saya" di menu, dimuat sekali saat dashboard dibuka
  setTimeout(function () { if (!tkS.loaded) tkFetch214(); }, 1500);


  /* ====================================================================== *
   *  v1.2.215: crm-aktivitas — lead manual, aktivitas sales & activity record,
   *  task per lead, follow-up + pengingat jatuh tempo (Growth+)
   * ====================================================================== */
  var CRM_TYPES = { call: 'Telepon', wa: 'Chat WA', meeting: 'Meeting', visit: 'Kunjungan', email: 'Email', presentasi: 'Presentasi / Demo', penawaran: 'Kirim penawaran', other: 'Lainnya' };
  var CRM_TICO = { call: 'phone', wa: 'message-circle', meeting: 'users', visit: 'target', email: 'mail', presentasi: 'monitor-smartphone', penawaran: 'file-text', other: 'activity', sys: 'clipboard-list' };
  var CRM_SRC = { manual: 'Input manual', referensi: 'Referensi', telepon: 'Telepon masuk', walkin: 'Walk-in / datang langsung', event: 'Event / pameran', website: 'Website', sosmed: 'Media sosial', iklan: 'Iklan', lainnya: 'Lainnya' };
  var leadCrm215 = false, crmSales215 = null;
  function crmFmtD215(d) { return d ? String(d).slice(0, 10).split('-').reverse().join('/') : ''; }
  function crmNow215() { var d = new Date(); return tkToday214() + 'T' + String(d.getHours()).padStart(2, '0') + ':' + String(d.getMinutes()).padStart(2, '0'); }
  function crmFuChip215(l) {
    var f = l && l.fu; if (!f || !f.due) return '';
    var t = tkToday214(), late = f.due < t, today = f.due === t;
    return ' <span class="tag crm-fu' + (late ? ' late' : (today ? ' today' : '')) + '" title="Follow-up berikutnya' + (f.text ? ': ' + esc(f.text) : '') + (f.by_name ? ' (' + esc(f.by_name) + ')' : '') + '">' +
      ico('alarm-clock', 11) + ' ' + (late ? 'Terlambat ' : (today ? 'Hari ini ' : 'FU ')) + esc(crmFmtD215(f.due)) + (f.time ? ' ' + esc(f.time) : '') + '</span>';
  }
  function crmInfoLine215(l) {
    var p = [];
    if (l.company) p.push(ico('briefcase-business', 11) + ' ' + esc(l.company));
    if (l.email) p.push(ico('mail', 11) + ' ' + esc(l.email));
    if (l.src === 'manual') p.push('Sumber: ' + esc(CRM_SRC[l.source] || 'Input manual'));
    if (l.act_n) p.push(ico('activity', 11) + ' ' + l.act_n + ' aktivitas' + (l.last_act ? ', terakhir ' + esc(crmFmtD215(l.last_act)) : ''));
    return p.length ? '<div class="crm-inf">' + p.join(' &middot; ') + '</div>' : '';
  }
  function crmToolbar215() {
    var a = $('#crmNewLead'), b = $('#crmRemBtn');
    if (a) a.style.display = leadCrm215 ? '' : 'none';
    if (b) b.style.display = leadCrm215 && (user.role === 'super_admin' || user.role === 'admin') ? '' : 'none';
    var c216 = $('#crmPipeBtn'); if (c216) c216.style.display = leadCrm215 && (user.role === 'super_admin' || user.role === 'admin') ? '' : 'none';   // v1.2.216: pipeline-sales
  }
  function crmLoadSales215(then) {
    if (crmSales215) { then(crmSales215); return; }
    api('sales_list').then(function (r) { crmSales215 = (r && r.ok && !r.locked) ? (r.items || []).filter(function (x) { return x.active; }) : []; then(crmSales215); });
  }
  function crmBadge215() {
    api('crm_badge').then(function (r) {
      var b = document.querySelector('#nav button[data-tab="leads"]'); if (!b || !r || !r.ok) return;
      var n = r.fu_due || 0, s = b.querySelector('.crm-nb');
      if (!s) { s = document.createElement('span'); s.className = 'tk-nb crm-nb'; b.appendChild(s); }
      s.textContent = n; s.style.display = n ? '' : 'none'; s.title = n + ' follow-up lead Anda jatuh tempo';
    });
  }
  setTimeout(crmBadge215, 2200);

  // ---- input lead manual ----
  function crmNewLead215() {
    crmLoadSales215(function (sales) {
      tkModal214(ico('user-plus', 17) + ' Input lead manual',
        '<div class="tk-grid">' +
          '<div class="row"><label class="fl">Nama *</label><input type="text" class="crm-nm" maxlength="120" placeholder="Nama orang / PIC"></div>' +
          '<div class="row"><label class="fl">No. HP / WA *</label><input type="tel" class="crm-num" maxlength="20" placeholder="0812xxxx"></div>' +
          '<div class="row"><label class="fl">Perusahaan</label><input type="text" class="crm-co" maxlength="120" placeholder="Opsional"></div>' +
          '<div class="row"><label class="fl">Email</label><input type="email" class="crm-em" maxlength="150" placeholder="Opsional"></div>' +
          '<div class="row"><label class="fl">Sumber lead</label><select class="crm-src">' + Object.keys(CRM_SRC).map(function (k) { return '<option value="' + k + '">' + esc(CRM_SRC[k]) + '</option>'; }).join('') + '</select></div>' +
          '<div class="row"><label class="fl">Status</label><select class="crm-st">' + crmOpenKeys216().filter(function (k) { return !LEAD_STATUS[k].off; }).map(function (k) { return '<option value="' + k + '">' + esc(LEAD_STATUS[k].label) + '</option>'; }).join('') + '</select></div>' +
          (sales.length && user.role !== 'sales' ? '<div class="row"><label class="fl">Sales</label><select class="crm-sl"><option value="">— Tanpa sales —</option>' + sales.map(function (x) { return '<option value="' + esc(x.id) + '">' + esc(x.name) + '</option>'; }).join('') + '</select></div>' : '') +
        '</div>' +
        '<div class="tk-grid"><div class="row"><label class="fl">Nilai deal (Rp)</label><input type="text" inputmode="numeric" class="crm-val" placeholder="Opsional"></div>' +
        '<div class="row"><label class="fl">Perkiraan closing</label><input type="date" class="crm-ce"></div></div>' +   // v1.2.216: pipeline-sales
        '<div class="row"><label class="fl">Catatan</label><textarea class="crm-nt" rows="3" maxlength="1000" placeholder="Kebutuhan, anggaran, konteks…"></textarea></div>' +
        '<div class="tk-foot"><button type="button" class="btn ghost tk-x">Batal</button><button type="button" class="btn crm-save">' + ico('user-plus', 15) + ' Simpan lead</button></div>',
        function (ov, close) {
          var nm = ov.querySelector('.crm-nm'); setTimeout(function () { nm.focus(); }, 30);
          crmNumIn216(ov.querySelector('.crm-val'));   // v1.2.216: pipeline-sales
          ov.querySelector('.crm-save').onclick = function () {
            var bt = this, sl = ov.querySelector('.crm-sl');
            var body = { name: nm.value.trim(), number: ov.querySelector('.crm-num').value.trim(), company: ov.querySelector('.crm-co').value.trim(),
                         email: ov.querySelector('.crm-em').value.trim(), source: ov.querySelector('.crm-src').value, status: ov.querySelector('.crm-st').value,
                         note: ov.querySelector('.crm-nt').value.trim(), sales: sl ? sl.value : '',
                         value: ov.querySelector('.crm-val').value, close_est: ov.querySelector('.crm-ce').value };
            if (!body.name) { toast('Nama wajib diisi.', true); nm.focus(); return; }
            if (!body.number) { toast('No. HP / WA wajib diisi.', true); ov.querySelector('.crm-num').focus(); return; }
            bt.disabled = true;
            api('lead_create', { method: 'POST', body: body }).then(function (r) {
              bt.disabled = false;
              if (!r || !r.ok) {
                if (r && r.exists) { if (confirm((r.error || 'Lead sudah ada.') + '\n\nBuka lead tersebut?')) { close(); crmOpen215(r.number); } return; }
                toast((r && r.error) || 'Gagal menyimpan lead.', true); return;
              }
              close(); toast('Lead ditambahkan.'); fetchLeads(); crmOpen215(r.number);
            });
          };
        });
    });
  }

  // ---- modal Aktivitas & Task per lead ----
  function crmTlHtml215(acts) {
    if (!acts.length) return '<div class="tk-empty-n">Belum ada aktivitas. Catat telepon, meeting, kunjungan, dll. lewat formulir di atas.</div>';
    var t = tkToday214();
    return acts.map(function (a) {
      var sys = a.type === 'sys', fu = '';
      if (a.next_due) {
        var late = !a.next_done && a.next_due < t;
        fu = '<div class="crm-fu-row' + (a.next_done ? ' done' : (late ? ' late' : '')) + '"><label><input type="checkbox" class="crm-fu-ck" data-aid="' + esc(a.id) + '"' + (a.next_done ? ' checked' : '') + '> ' +
          ico('alarm-clock', 12) + ' Follow-up ' + esc(crmFmtD215(a.next_due)) + (a.next_time ? ' ' + esc(a.next_time) : '') + (a.next_text ? ' — ' + esc(a.next_text) : '') + '</label>' +
          (a.next_done ? '<span>Selesai' + (a.next_done_by_name ? ' · ' + esc(a.next_done_by_name) : '') + '</span>' : (late ? '<span>Terlambat</span>' : '')) + '</div>';
      }
      return '<div class="crm-it' + (sys ? ' sys' : '') + '"><span class="crm-ic">' + ico(CRM_TICO[a.type] || 'activity', 13) + '</span><div class="crm-bd">' +
        '<div class="crm-ih"><b>' + esc(sys ? 'Catatan sistem' : (CRM_TYPES[a.type] || a.type)) + '</b><span>' + esc(String(a.at || '').slice(0, 16)) + (a.by_name ? ' · ' + esc(a.by_name) : '') + '</span>' +
        (a.can_del ? '<button type="button" class="tk-n-del crm-del" data-aid="' + esc(a.id) + '" title="Hapus aktivitas">' + ico('trash-2', 12) + '</button>' : '') + '</div>' +
        (a.text ? '<div class="crm-tx2">' + esc(a.text) + '</div>' : '') + fu + '</div></div>';
    }).join('');
  }
  function crmTasksHtml215(ts) {
    if (!ts.length) return '<div class="tk-empty-n">Belum ada task untuk lead ini.</div>';
    return ts.map(function (t) {
      var d = TK_ST[t.status] || TK_ST['new'];
      return '<div class="crm-tk" data-tk="' + esc(t.id) + '"><span class="tag" style="background:' + d.bg + ';color:' + d.fg + '">' + esc(d.label) + '</span> <b>' + esc(t.title) + '</b>' +
        '<span class="crm-tk-m">' + (t.assignee ? ico('user', 11) + ' ' + esc(tkUserName214(t.assignee)) : '') + ' ' + tkDueHtml214(t) + '</span></div>';
    }).join('');
  }
  function crmOpen215(num) {
    num = String(num);
    api('lead_acts', { query: '&number=' + encodeURIComponent(num) }).then(function (r) {
      if (!r || !r.ok) { toast((r && r.error) || 'Gagal memuat aktivitas.', true); return; }
      if (!r.lead) { toast('Lead tidak ditemukan.', true); return; }
      var l = leadAll203.filter(function (x) { return x.number === num; })[0] || {};
      var info = r.lead, acts = r.acts || [], tasks = r.tasks || [];
      var nm = info.name || l.name || ('+' + num);
      var st = LEAD_STATUS[info.status] || LEAD_STATUS.baru;
      var ov = tkModal214(ico('activity', 17) + ' ' + esc(nm),
        '<div class="crm-hd">+' + esc(num) + ' <span class="tag" style="background:' + st.bg + ';color:' + st.fg + '">' + esc(st.label) + '</span>' + (crmSalesSel218(l) ? ' ' + ico('briefcase-business', 12) + crmSalesSel218(l, 'crm-hd-sl') : slLeadBadge203(l)) + crmFuChip215(l) + '</div>' +   /* v1.2.218: sales-di-lead */
        crmDealForm216(info) + '<details class="crm-info"><summary>Info lead' + (info.company ? ' — ' + esc(info.company) : '') + '</summary><div class="crm-ib">' +
          '<div class="tk-grid">' +
            '<div class="row"><label class="fl">Nama</label><input type="text" class="ci-nm" maxlength="120" value="' + esc(info.name || '') + '"></div>' +
            '<div class="row"><label class="fl">Perusahaan</label><input type="text" class="ci-co" maxlength="120" value="' + esc(info.company || '') + '"></div>' +
            '<div class="row"><label class="fl">Email</label><input type="email" class="ci-em" maxlength="150" value="' + esc(info.email || '') + '"></div>' +
            '<div class="row"><label class="fl">Sumber lead</label><select class="ci-src"><option value="">' + (info.src === 'manual' ? '—' : 'Chat / otomatis') + '</option>' +
              Object.keys(CRM_SRC).map(function (k) { return '<option value="' + k + '"' + (info.source === k ? ' selected' : '') + '>' + esc(CRM_SRC[k]) + '</option>'; }).join('') + '</select></div>' +
          '</div>' +
          '<div class="crm-fbtn"><span class="crm-inf" style="margin-right:auto">' + (info.created_at ? 'Dibuat ' + esc(info.created_at.slice(0, 16)) + (info.created_by ? ' oleh ' + esc(tkUserName214(info.created_by)) : '') : '') + '</span><button type="button" class="btn ghost sm ci-save">Simpan info</button></div>' +
        '</div></details>' +
        '<div class="crm-tabs"><button type="button" class="active" data-ct="act">' + ico('activity', 14) + ' Aktivitas</button><button type="button" data-ct="task">' + ico('list-todo', 14) + ' Task <span class="crm-tn">' + tasks.length + '</span></button></div>' +
        '<div class="crm-pane" data-cp="act">' +
          '<div class="crm-form">' +
            '<div class="tk-grid">' +
              '<div class="row"><label class="fl">Jenis aktivitas</label><select class="crm-ty">' + Object.keys(CRM_TYPES).map(function (k) { return '<option value="' + k + '">' + esc(CRM_TYPES[k]) + '</option>'; }).join('') + '</select></div>' +
              '<div class="row"><label class="fl">Waktu</label><input type="datetime-local" class="crm-at" value="' + crmNow215() + '"></div>' +
            '</div>' +
            '<div class="row"><label class="fl">Hasil / catatan</label><textarea class="crm-tx" rows="2" maxlength="2000" placeholder="Mis. Sudah telepon, tertarik paket B, minta penawaran tertulis"></textarea></div>' +
            '<div class="row"><label class="fl">Follow-up berikutnya (opsional — dapat pengingat email)</label><div class="crm-next-r"><input type="date" class="crm-nd"><input type="time" class="crm-ntm"><input type="text" class="crm-nx" maxlength="200" placeholder="Rencana: telepon ulang, kirim penawaran…"></div></div>' +
            '<div class="crm-fbtn"><button type="button" class="btn sm crm-add">' + ico('plus', 14) + ' Catat aktivitas</button></div>' +
          '</div>' +
          '<div class="crm-tl">' + crmTlHtml215(acts) + '</div>' +
        '</div>' +
        '<div class="crm-pane" data-cp="task" style="display:none"><div class="crm-tasks">' + crmTasksHtml215(tasks) + '</div>' +
          '<button type="button" class="btn ghost sm crm-tnew">' + ico('plus', 14) + ' Task untuk lead ini</button></div>' +
        '<div class="tk-foot"><button type="button" class="btn ghost sm crm-chat" style="margin-right:auto">' + ico('message-circle', 14) + ' Lihat percakapan</button><button type="button" class="btn ghost tk-x">Tutup</button></div>',
        function (ov, close) {
          ov.querySelector('.tk-box').classList.add('crm-box');
          crmDealWire216(ov, num, function (x) { if (x.acts) { acts = x.acts; paintTl(); } changed(); });   // v1.2.216: pipeline-sales
          if (r.ro) {   // v1.2.219: divisi-sales: lead sales lain — lihat saja
            ov.querySelector('.tk-box').classList.add('crm-ro');
            Array.prototype.forEach.call(ov.querySelectorAll('.crm-deal input, .crm-info input, .crm-info select'), function (x) { x.disabled = true; });
            ov.querySelector('.crm-hd').insertAdjacentHTML('afterend', '<div class="crm-ro-n">' + ico('eye', 13) + ' Lihat saja — lead ini dipegang ' + esc(l.sales_name || 'sales lain') + '. Hanya lead milik Anda yang bisa diubah.</div>');
          }
          function paintTl() { ov.querySelector('.crm-tl').innerHTML = crmTlHtml215(acts); }
          function paintTasks() { ov.querySelector('.crm-tasks').innerHTML = crmTasksHtml215(tasks); ov.querySelector('.crm-tn').textContent = tasks.length; }
          function changed() { fetchLeads(); crmBadge215(); }
          Array.prototype.forEach.call(ov.querySelectorAll('[data-ct]'), function (b) {
            b.onclick = function () {
              Array.prototype.forEach.call(ov.querySelectorAll('[data-ct]'), function (x) { x.classList.toggle('active', x === b); });
              Array.prototype.forEach.call(ov.querySelectorAll('[data-cp]'), function (p) { p.style.display = p.getAttribute('data-cp') === b.getAttribute('data-ct') ? '' : 'none'; });
            };
          });
          ov.querySelector('.ci-save').onclick = function () {
            var bt = this; bt.disabled = true;
            api('lead_info_save', { method: 'POST', body: { number: num, name: ov.querySelector('.ci-nm').value.trim(), company: ov.querySelector('.ci-co').value.trim(),
              email: ov.querySelector('.ci-em').value.trim(), source: ov.querySelector('.ci-src').value } }).then(function (x) {
              bt.disabled = false;
              if (!x || !x.ok) { toast((x && x.error) || 'Gagal menyimpan info.', true); return; }
              toast('Info lead disimpan.'); fetchLeads();
            });
          };
          ov.querySelector('.crm-add').onclick = function () {
            var bt = this, tx = ov.querySelector('.crm-tx'), nd = ov.querySelector('.crm-nd');
            var body = { number: num, type: ov.querySelector('.crm-ty').value, at: ov.querySelector('.crm-at').value, text: tx.value.trim(),
                         next_due: nd.value, next_time: ov.querySelector('.crm-ntm').value, next_text: ov.querySelector('.crm-nx').value.trim() };
            if (!body.text && !body.next_due) { toast('Isi hasil aktivitas atau jadwal follow-up.', true); tx.focus(); return; }
            bt.disabled = true;
            api('lead_act_add', { method: 'POST', body: body }).then(function (x) {
              bt.disabled = false;
              if (!x || !x.ok) { toast((x && x.error) || 'Gagal mencatat aktivitas.', true); return; }
              acts = x.acts || []; paintTl();
              tx.value = ''; nd.value = ''; ov.querySelector('.crm-ntm').value = ''; ov.querySelector('.crm-nx').value = ''; ov.querySelector('.crm-at').value = crmNow215();
              toast('Aktivitas dicatat.'); changed();
            });
          };
          ov.querySelector('.crm-tl').addEventListener('click', function (e) {
            var b = e.target.closest ? e.target.closest('.crm-del') : null; if (!b) return;
            if (!confirm('Hapus aktivitas ini?')) return;
            api('lead_act_update', { method: 'POST', body: { number: num, id: b.getAttribute('data-aid'), remove: 1 } }).then(function (x) {
              if (!x || !x.ok) { toast((x && x.error) || 'Gagal menghapus.', true); return; }
              acts = x.acts || []; paintTl(); changed();
            });
          });
          ov.querySelector('.crm-tl').addEventListener('change', function (e) {
            var c = e.target; if (!c.classList || !c.classList.contains('crm-fu-ck')) return;
            api('lead_act_update', { method: 'POST', body: { number: num, id: c.getAttribute('data-aid'), done: c.checked ? 1 : 0 } }).then(function (x) {
              if (!x || !x.ok) { toast((x && x.error) || 'Gagal menyimpan.', true); c.checked = !c.checked; return; }
              acts = x.acts || []; paintTl(); changed();
              if (c.checked) toast('Follow-up ditandai selesai.');
            });
          });
          ov.querySelector('.crm-tasks').addEventListener('click', function (e) {
            var b = e.target.closest ? e.target.closest('.crm-tk') : null; if (!b) return;
            var id = b.getAttribute('data-tk');
            tasks.forEach(function (t) { if (t.id === id && !tkS.list.some(function (x) { return x.id === id; })) tkS.list.unshift(t); });
            tkOpen214(id);
          });
          ov.querySelector('.crm-tnew').onclick = function () { crmTaskNew215(num, nm, function (t) { tasks.unshift(t); paintTasks(); }); };
          ov.querySelector('.crm-chat').onclick = function () { close(); openLeadConv(num); };
        });
      return ov;
    });
  }
  function crmTaskNew215(num, nm, after) {
    tkModal214('Task untuk ' + esc(nm),
      '<div class="row"><label class="fl">Judul to-do</label><input type="text" class="tk-title" maxlength="300" placeholder="Mis. Kirim penawaran ke ' + esc(nm) + '"></div>' +
      '<div class="tk-grid">' +
        '<div class="row"><label class="fl">Status</label><select class="tk-st">' + tkStatusOpts214('new') + '</select></div>' +
        '<div class="row"><label class="fl">Ditugaskan ke</label><select class="tk-as">' + tkUserOpts214(tkS.me) + '</select></div>' +
        '<div class="row"><label class="fl">Tenggat (dapat pengingat email)</label><input type="date" class="tk-due-in"></div>' +
      '</div>' +
      '<div class="row"><label class="fl">Catatan (opsional)</label><textarea class="tk-note-in" rows="3" maxlength="2000"></textarea></div>' +
      '<div class="tk-foot"><button type="button" class="btn ghost tk-x">Batal</button><button type="button" class="btn tk-save">' + ico('list-todo', 15) + ' Simpan task</button></div>',
      function (ov, close) {
        var ti = ov.querySelector('.tk-title'); setTimeout(function () { ti.focus(); }, 30);
        var go = function () {
          var title = ti.value.trim();
          if (!title) { toast('Judul to-do wajib diisi.', true); ti.focus(); return; }
          var bt = ov.querySelector('.tk-save'); bt.disabled = true;
          api('task_save', { method: 'POST', body: { title: title, status: ov.querySelector('.tk-st').value, assignee: ov.querySelector('.tk-as').value,
            due: ov.querySelector('.tk-due-in').value, note: ov.querySelector('.tk-note-in').value, lead: num } }).then(function (r) {
            bt.disabled = false;
            if (!r || !r.ok) { toast((r && r.error) || 'Gagal menyimpan task.', true); return; }
            close(); tkUpsert214(r.task); toast('Task dibuat — juga tampil di menu Task.');
            if (after) after(r.task);
          });
        };
        ov.querySelector('.tk-save').onclick = go;
        ti.onkeydown = function (e) { if (e.key === 'Enter') { e.preventDefault(); go(); } };
      });
  }
  function crmLeadBox215(t) {
    if (!t || !t.lead) return '';
    return '<div class="crm-lead">' + ico('briefcase-business', 13) + ' Lead: <b>' + esc(t.lead_name || ('+' + t.lead)) + '</b><button type="button" class="btn ghost sm crm-golead" data-num="' + esc(t.lead) + '">Buka lead</button></div>';
  }
  document.addEventListener('click', function (e) {
    var b = e.target.closest && e.target.closest('.crm-golead'); if (!b) return;
    var ov = b.closest('.tk-ov'); if (ov && ov.parentNode) ov.parentNode.removeChild(ov);
    crmOpen215(b.getAttribute('data-num'));
  });

  // ---- pengaturan pengingat (Admin) ----
  function crmRemind215() {
    api('crm_remind_get').then(function (r) {
      if (!r || !r.ok) { toast((r && r.error) || 'Gagal memuat pengaturan.', true); return; }
      var hrs = ''; for (var h = 5; h <= 20; h++) hrs += '<option value="' + h + '"' + (h === r.hour ? ' selected' : '') + '>' + String(h).padStart(2, '0') + ':00 WIB</option>';
      tkModal214(ico('bell', 17) + ' Pengingat jatuh tempo',
        '<p class="crm-p">Sekali sehari, tiap pengguna menerima <b>email</b> (dan notifikasi push bila diaktifkan) berisi task yang ditugaskan kepadanya dan follow-up lead yang ia jadwalkan — yang jatuh tempo hari ini, besok, atau sudah terlambat.</p>' +
        '<label class="crm-ck"><input type="checkbox" class="cr-on"' + (r.on ? ' checked' : '') + '> Kirim pengingat harian</label>' +
        '<div class="row" style="margin-top:10px"><label class="fl">Jam kirim</label><select class="cr-h" style="width:auto">' + hrs + '</select></div>' +
        (r.no_email && r.no_email.length ? '<p class="crm-p crm-warn">Belum punya email (tidak menerima email, hanya push): ' + r.no_email.map(esc).join(', ') + '. Isi email di menu Pengguna.</p>' : '') +
        '<div class="tk-foot"><button type="button" class="btn ghost sm cr-test" style="margin-right:auto">' + ico('send', 14) + ' Kirim uji ke email saya</button><button type="button" class="btn ghost tk-x">Batal</button><button type="button" class="btn cr-save">Simpan</button></div>',
        function (ov, close) {
          ov.querySelector('.cr-save').onclick = function () {
            api('crm_remind_save', { method: 'POST', body: { on: ov.querySelector('.cr-on').checked ? 1 : 0, hour: +ov.querySelector('.cr-h').value } }).then(function (x) {
              if (!x || !x.ok) { toast((x && x.error) || 'Gagal menyimpan.', true); return; }
              close(); toast('Pengaturan pengingat disimpan.');
            });
          };
          ov.querySelector('.cr-test').onclick = function () {
            var bt = this; bt.disabled = true;
            api('crm_remind_test', { method: 'POST', body: {} }).then(function (x) {
              bt.disabled = false;
              if (!x || !x.ok) { toast((x && x.error) || 'Gagal mengirim email uji.', true); return; }
              toast('Email uji terkirim ke ' + x.to + ' (' + x.total + ' item).');
            });
          };
        });
    });
  }


  /* ====================================================================== *
   *  v1.2.216: pipeline-sales — tahap pipeline, nilai deal, perkiraan closing,
   *  ringkasan pipeline, role Sales
   * ====================================================================== */
  var crmPipe216 = null;
  function crmRpFmt216(n) { n = Math.round(+n || 0); return 'Rp ' + String(n).replace(/\B(?=(\d{3})+(?!\d))/g, '.'); }
  function crmRpShort216(n) {
    n = +n || 0;
    if (n >= 1e9) return 'Rp ' + (n / 1e9).toFixed(n >= 1e10 ? 0 : 1).replace('.', ',') + ' M';
    if (n >= 1e6) return 'Rp ' + (n / 1e6).toFixed(n >= 1e7 ? 0 : 1).replace('.', ',') + ' jt';
    if (n >= 1e3) return 'Rp ' + Math.round(n / 1e3) + ' rb';
    return 'Rp ' + n;
  }
  function crmNumIn216(el) {   // input Rupiah: titik ribuan saat mengetik
    if (!el) return;
    el.addEventListener('input', function () {
      var d = el.value.replace(/\D/g, '').replace(/^0+(?=\d)/, '');
      el.value = d ? d.replace(/\B(?=(\d{3})+(?!\d))/g, '.') : '';
    });
  }
  function crmOpenKeys216() { return ['baru', 'qualified', 'follow_up', 'proposal', 'negosiasi']; }
  function crmPipeApply216(pc) {
    crmPipe216 = pc;
    Object.keys(pc).forEach(function (k) {
      var d = LEAD_STATUS[k]; if (!d) return;
      d.label = pc[k].label; d.off = !pc[k].on; d.prob = pc[k].prob;
      $$('.lead-filter[data-lead-status="' + k + '"]').forEach(function (b) { b.textContent = pc[k].label; b.style.display = (d.off && !leadAll203.some(function (l) { return l.status === k; })) ? 'none' : ''; });
    });
  }
  function crmProb216(st) { var d = LEAD_STATUS[st]; return d && typeof d.prob === 'number' ? d.prob : 0; }
  function crmDealChip216(l) {
    var h = '';
    if (l.value) h += ' <span class="tag crm-val" title="Nilai deal">' + esc(crmRpShort216(l.value)) + '</span>';
    if (l.close_est && crmOpenKeys216().indexOf(l.status || 'baru') !== -1) {
      var late = l.close_est < tkToday214();
      h += ' <span class="tag crm-ce' + (late ? ' late' : '') + '" title="Perkiraan closing' + (late ? ' — sudah lewat' : '') + '">' + ico('calendar', 11) + ' ' + esc(crmFmtD215(l.close_est)) + '</span>';
    }
    return h;
  }
  function crmColSum216(list) {
    var t = 0; list.forEach(function (l) { t += +l.value || 0; });
    return t ? '<span class="crm-colsum" title="Total nilai deal">' + esc(crmRpShort216(t)) + '</span>' : '';
  }
  function crmPipeRender216() {
    var box = $('#crmPipe'); if (!box) return;
    if (!leadCrm215 || !leadData.length) { box.innerHTML = ''; return; }
    var today = tkToday214(), ym = today.slice(0, 7), open = crmOpenKeys216();
    var o = { n: 0, v: 0, w: 0, mN: 0, mV: 0, wonN: 0, wonV: 0, lost: 0, late: 0, noVal: 0 }, by = {};
    open.forEach(function (k) { by[k] = { n: 0, v: 0 }; });
    leadData.forEach(function (l) {
      var st = l.status || 'baru', v = +l.value || 0;
      if (open.indexOf(st) !== -1) {
        o.n++; o.v += v; o.w += v * crmProb216(st) / 100; by[st].n++; by[st].v += v;
        if (!v) o.noVal++;
        if (l.close_est && l.close_est.slice(0, 7) === ym) { o.mN++; o.mV += v; }
        if (l.close_est && l.close_est < today) o.late++;
      } else if ((l.closed_at || '').slice(0, 7) === ym) {
        if (st === 'closed_deal') { o.wonN++; o.wonV += v; } else if (st === 'closed_lost') o.lost++;
      }
    });
    var wr = (o.wonN + o.lost) ? Math.round(o.wonN * 100 / (o.wonN + o.lost)) + '%' : '—';
    var tile = function (lbl, big, sub, cls) { return '<div class="crm-pt' + (cls ? ' ' + cls : '') + '"><div class="crm-pt-l">' + lbl + '</div><div class="crm-pt-b">' + big + '</div><div class="crm-pt-s">' + sub + '</div></div>'; };
    var max = 0; open.forEach(function (k) { if (by[k].v > max) max = by[k].v; });
    box.innerHTML = '<div class="card crm-pipe"><div class="crm-pipe-h"><b>' + ico('bar-chart-3', 15) + ' Pipeline</b><span>' + (leadSales203 ? 'filter sales aktif · ' : '') + 'bulan ini = ' + esc(ym.split('-').reverse().join('/')) + '</span></div>' +
      '<div class="crm-pts">' +
        tile('Pipeline terbuka', esc(crmRpShort216(o.v)), o.n + ' lead' + (o.noVal ? ' · ' + o.noVal + ' belum ada nilai' : '')) +
        tile('Nilai tertimbang', esc(crmRpShort216(o.w)), 'nilai × peluang tahap') +
        tile('Perkiraan closing bulan ini', esc(crmRpShort216(o.mV)), o.mN + ' lead') +
        tile('Close Deal bulan ini', esc(crmRpShort216(o.wonV)), o.wonN + ' deal · ' + o.lost + ' lose', 'good') +
        tile('Win rate bulan ini', wr, 'deal ÷ (deal + lose)') +
        tile('Lewat perkiraan closing', String(o.late), 'lead terbuka', o.late ? 'bad' : '') +
      '</div>' +
      '<div class="crm-stg">' + open.filter(function (k) { return !(LEAD_STATUS[k] || {}).off || by[k].n; }).map(function (k) {
        var d = LEAD_STATUS[k];
        return '<div class="crm-stg-r"><span class="crm-stg-l">' + esc(d.label) + ' <i>' + crmProb216(k) + '%</i></span><span class="crm-stg-bar"><span style="width:' + (max ? Math.max(2, Math.round(by[k].v * 100 / max)) : 0) + '%;background:' + d.fg + '"></span></span><span class="crm-stg-n">' + by[k].n + ' · ' + esc(crmRpShort216(by[k].v)) + '</span></div>';
      }).join('') + '</div></div>';
  }
  function crmDealForm216(info) {
    return '<div class="crm-deal"><div class="row"><label class="fl">Nilai deal (Rp)</label><input type="text" inputmode="numeric" class="cd-val" placeholder="0" value="' + (info.value ? esc(String(info.value).replace(/\B(?=(\d{3})+(?!\d))/g, '.')) : '') + '"></div>' +
      '<div class="row"><label class="fl">Perkiraan closing</label><input type="date" class="cd-ce" value="' + esc(info.close_est || '') + '"></div>' +
      '<button type="button" class="btn ghost sm cd-save">Simpan</button></div>';
  }
  function crmDealWire216(ov, num, done) {
    var v = ov.querySelector('.cd-val'); if (!v) return;
    crmNumIn216(v);
    ov.querySelector('.cd-save').onclick = function () {
      var bt = this; bt.disabled = true;
      api('lead_deal_save', { method: 'POST', body: { number: num, value: v.value, close_est: ov.querySelector('.cd-ce').value } }).then(function (x) {
        bt.disabled = false;
        if (!x || !x.ok) { toast((x && x.error) || 'Gagal menyimpan nilai deal.', true); return; }
        toast('Nilai deal disimpan.'); if (done) done(x);
      });
    };
  }
  // Pindah ke Close Deal tanpa nilai -> minta nilai deal
  function crmAskValue216(num, then) {
    var l = leadAll203.filter(function (x) { return x.number === num; })[0];
    if (!leadCrm215 || !l || +l.value) { then(); return; }
    var v = prompt('Close Deal — berapa nilai deal-nya (Rp)?\nKosongkan bila belum tahu.', '');
    var d = String(v || '').replace(/\D/g, '');
    if (!d) { then(); return; }
    api('lead_deal_save', { method: 'POST', body: { number: num, value: d, close_est: l.close_est || '' } }).then(function () { then(); });
  }
  // Pengaturan tahap pipeline (Admin)
  function crmPipeEdit216() {
    api('crm_pipeline_get').then(function (r) {
      if (!r || !r.ok) { toast((r && r.error) || 'Gagal memuat tahap.', true); return; }
      var st = r.stages, cnt = r.counts || {};
      tkModal214(ico('layers', 17) + ' Tahap pipeline',
        '<p class="crm-p">Ubah nama tahap dan peluang menang (%) yang dipakai untuk <b>nilai tertimbang</b>. Tahap Penawaran &amp; Negosiasi bisa dimatikan; lead yang sudah ada di tahap itu tetap tampil.</p>' +
        '<table class="tbl crm-pe"><thead><tr><th>Tahap</th><th>Nama tampilan</th><th>Peluang</th><th>Aktif</th></tr></thead><tbody>' +
        Object.keys(st).map(function (k) {
          var x = st[k];
          return '<tr data-k="' + k + '"><td class="mono" style="font-size:12px">' + esc(k) + (cnt[k] ? ' <span class="help">(' + cnt[k] + ')</span>' : '') + '</td>' +
            '<td><input type="text" class="pe-l" maxlength="30" value="' + esc(x.label) + '"></td>' +
            '<td>' + (x.fix ? x.prob + '%' : '<input type="number" class="pe-p" min="0" max="100" value="' + x.prob + '" style="width:76px"> %') + '</td>' +
            '<td>' + (x.opt ? '<input type="checkbox" class="pe-o"' + (x.on ? ' checked' : '') + '>' : '<span class="help">selalu</span>') + '</td></tr>';
        }).join('') + '</tbody></table>' +
        '<div class="tk-foot"><button type="button" class="btn ghost tk-x">Batal</button><button type="button" class="btn pe-save">Simpan</button></div>',
        function (ov, close) {
          ov.querySelector('.tk-box').classList.add('crm-box');
          ov.querySelector('.pe-save').onclick = function () {
            var out = {};
            Array.prototype.forEach.call(ov.querySelectorAll('tr[data-k]'), function (tr) {
              var p = tr.querySelector('.pe-p'), o = tr.querySelector('.pe-o');
              out[tr.dataset.k] = { label: tr.querySelector('.pe-l').value.trim(), prob: p ? +p.value : undefined, on: o ? o.checked : undefined };
            });
            api('crm_pipeline_save', { method: 'POST', body: { stages: out } }).then(function (x) {
              if (!x || !x.ok) { toast((x && x.error) || 'Gagal menyimpan.', true); return; }
              close(); toast('Tahap pipeline disimpan.'); fetchLeads();
            });
          };
        });
    });
  }
  // Pengguna: akun Sales terhubung ke data Sales
  var uSales216 = [];
  function uSalesLoad216() {
    api('sales_list').then(function (r) {
      uSales216 = (r && r.ok && !r.locked) ? (r.items || []) : [];
      var sel = document.getElementById('u_sales_id'); if (!sel) return;
      var cur = sel.value;
      uDiv220 = (r && r.divisions) || []; uDivFill220(); uOrphan220();   // v1.2.220: sales-di-pengguna
      sel.innerHTML = (r && r.locked) ? '<option value="">Butuh paket Growth</option>' : '<option value="">＋ Data sales baru (otomatis dari Nama)</option>' + uSales216.map(function (x) {
        return '<option value="' + esc(x.id) + '" data-div="' + esc(x.div || '') + '">Pakai data lama: ' + esc(x.name) + (x.div ? ' — ' + esc(x.div) : '') + (x.user ? ' (akun ' + esc(x.user) + ')' : '') + (x.active ? '' : ' (nonaktif)') + '</option>';
      }).join('');
      sel.onchange = function () { var o = sel.options[sel.selectedIndex]; if (sel.value && o) uDivSet220(o.getAttribute('data-div') || ''); };
      sel.value = cur;
    });
  }
  function uSalesName216(id) { var x = uSales216.filter(function (s) { return s.id === id; })[0]; return x ? x.name : id; }


  /* ====================================================================== *
   *  v1.2.217: laporan-crm — Leads > Performa + laporan mingguan via email
   * ====================================================================== */
  var crmPerfS217 = { preset: 'lastweek', from: '', to: '', data: null, busy: false };
  try { var _pp = localStorage.getItem('dei_perf_preset'); if (_pp) crmPerfS217.preset = _pp; } catch (e) {}
  function crmYmd217(d) { return d.getFullYear() + '-' + String(d.getMonth() + 1).padStart(2, '0') + '-' + String(d.getDate()).padStart(2, '0'); }
  function crmRange217(p) {
    var t = new Date(); t.setHours(12, 0, 0, 0);
    var dow = (t.getDay() + 6) % 7;   // 0 = Senin
    var a = new Date(t), b = new Date(t);
    if (p === 'thisweek') { a.setDate(t.getDate() - dow); }
    else if (p === 'lastweek') { a.setDate(t.getDate() - dow - 7); b.setDate(t.getDate() - dow - 1); }
    else if (p === 'thismonth') { a.setDate(1); }
    else if (p === 'lastmonth') { a = new Date(t.getFullYear(), t.getMonth() - 1, 1, 12); b = new Date(t.getFullYear(), t.getMonth(), 0, 12); }
    else if (p === 'last7') { a.setDate(t.getDate() - 6); }
    else { a.setDate(t.getDate() - 29); }   // last30
    return [crmYmd217(a), crmYmd217(b)];
  }
  var CRM_PRESETS = { lastweek: 'Minggu lalu', thisweek: 'Minggu ini', last7: '7 hari terakhir', thismonth: 'Bulan ini', lastmonth: 'Bulan lalu', last30: '30 hari terakhir', custom: 'Pilih tanggal' };
  function crmPerfRender217() {
    var box = $('#leadList'); if (!box) return;
    if (!leadCrm215) { box.innerHTML = '<div class="card" style="text-align:center;color:var(--muted)">Laporan performa tersedia mulai paket Growth.</div>'; return; }
    var S = crmPerfS217;
    if (S.preset !== 'custom' || !S.from) { var r = crmRange217(S.preset); S.from = S.from && S.preset === 'custom' ? S.from : r[0]; S.to = S.preset === 'custom' && S.to ? S.to : r[1]; }
    var adm = user.role === 'super_admin' || user.role === 'admin';
    if (!box.querySelector('#crmPerfBar')) {
      box.innerHTML = '<div class="card crm-perf"><div class="crm-perf-bar" id="crmPerfBar">' +
        '<select id="crmPerfPre" style="width:auto">' + Object.keys(CRM_PRESETS).map(function (k) { return '<option value="' + k + '"' + (k === S.preset ? ' selected' : '') + '>' + CRM_PRESETS[k] + '</option>'; }).join('') + '</select>' +
        '<input type="date" id="crmPerfFrom"><span class="help">s/d</span><input type="date" id="crmPerfTo">' +
        '<button type="button" class="btn ghost sm" id="crmPerfGo">Tampilkan</button>' +
        '<button type="button" class="btn ghost sm" id="crmPerfCsv">' + ico('download', 14) + ' CSV</button>' +
        (adm ? '<button type="button" class="btn ghost sm" id="crmWeekBtn" style="margin-left:auto">' + ico('mail', 14) + ' Laporan mingguan</button>' : '') +
        '</div><div id="crmPerfBody"><div class="help">Memuat…</div></div></div>';
      var pre = $('#crmPerfPre'), f = $('#crmPerfFrom'), t = $('#crmPerfTo');
      pre.onchange = function () {
        S.preset = pre.value; try { localStorage.setItem('dei_perf_preset', S.preset); } catch (e) {}
        if (S.preset !== 'custom') { var r = crmRange217(S.preset); S.from = r[0]; S.to = r[1]; f.value = S.from; t.value = S.to; crmPerfLoad217(); }
      };
      var cust = function () { S.preset = 'custom'; pre.value = 'custom'; };
      f.onchange = cust; t.onchange = cust;
      $('#crmPerfGo').onclick = function () { S.from = f.value; S.to = t.value; crmPerfLoad217(); };
      $('#crmPerfCsv').onclick = crmPerfCsv217;
      if ($('#crmWeekBtn')) $('#crmWeekBtn').onclick = crmWeekly217;
    }
    $('#crmPerfFrom').value = S.from; $('#crmPerfTo').value = S.to;
    crmPerfLoad217();
  }
  function crmPerfLoad217() {
    var S = crmPerfS217, body = $('#crmPerfBody'); if (!body) return;
    if (!S.from || !S.to) { toast('Isi tanggal awal & akhir.', true); return; }
    body.style.opacity = '.5';
    api('crm_sales_perf', { query: '&from=' + encodeURIComponent(S.from) + '&to=' + encodeURIComponent(S.to) }).then(function (r) {
      body.style.opacity = '';
      if (!r || !r.ok) { body.innerHTML = '<div class="help">' + esc((r && r.error) || 'Gagal memuat laporan.') + '</div>'; return; }
      S.data = r; crmPerfPaint217();
    });
  }
  function crmPerfRows217() {
    var r = crmPerfS217.data; if (!r) return [];
    if (!leadSales203 || r.own) return r.rows;
    var want = leadSales203 === '_none' ? '' : leadSales203;
    return r.rows.filter(function (x) { return x.id === want; });
  }
  function crmPerfPaint217() {
    var r = crmPerfS217.data, body = $('#crmPerfBody'); if (!r || !body) return;
    var rows = crmPerfRows217(), T = (leadSales203 && !r.own) ? (rows[0] || r.total) : r.total;
    var per = crmFmtD215(r.from) + ' – ' + crmFmtD215(r.to);
    var tile = function (l, b, s, c) { return '<div class="crm-pt' + (c ? ' ' + c : '') + '"><div class="crm-pt-l">' + l + '</div><div class="crm-pt-b">' + b + '</div><div class="crm-pt-s">' + s + '</div></div>'; };
    var types = r.types || {};
    var bt = Object.keys(T.by_type || {}).sort(function (a, b) { return T.by_type[b] - T.by_type[a]; }).map(function (k) { return esc(types[k] || k) + ' ' + T.by_type[k]; }).join(' · ');
    var h = '<div class="crm-perf-per">' + (r.own ? 'Kinerja Anda' : 'Semua sales' + (leadSales203 ? ' (filter sales aktif)' : '')) + ' · ' + esc(per) + '</div>' +
      '<div class="crm-pts">' +
        tile('Lead baru', T.new, 'dibuat dalam periode') +
        tile('Aktivitas', T.acts, bt || 'belum ada') +
        tile('Close Deal', esc(crmRpShort216(T.deal_v)), T.deal + ' deal · rata-rata ' + esc(crmRpShort216(T.avg_deal)), 'good') +
        tile('Win rate', T.win === null ? '—' : T.win + '%', T.deal + ' deal · ' + T.lost + ' lose' + (T.cycle !== null ? ' · ±' + String(T.cycle).replace('.', ',') + ' hari closing' : '')) +
        tile('Pipeline terbuka (saat ini)', esc(crmRpShort216(T.open_v)), T.open + ' lead · tertimbang ' + esc(crmRpShort216(T.weighted))) +
        tile('Follow-up', T.fu_done + ' selesai', T.fu_late + ' terlambat saat ini · PO ' + T.po, T.fu_late ? 'bad' : '') +
      '</div>';
    if (!r.own) {
      h += '<div class="scroll" style="margin-top:12px"><table class="tbl crm-perf-t"><thead><tr><th>Sales</th><th>Lead baru</th><th>Aktivitas</th><th>FU selesai</th><th>FU telat</th><th>PO</th><th>Deal</th><th>Nilai deal</th><th>Lose</th><th>Win</th><th>Lama closing</th><th>Pipeline</th><th>Tertimbang</th><th>Closing 30 hr</th></tr></thead><tbody>' +
        (rows.length ? rows.map(function (x) {
          return '<tr><td><b>' + esc(x.name) + '</b>' + (x.active || !x.id ? '' : ' <span class="help">(nonaktif)</span>') + '</td><td>' + x.new + '</td><td title="' + esc(Object.keys(x.by_type || {}).map(function (k) { return (types[k] || k) + ': ' + x.by_type[k]; }).join(', ')) + '">' + x.acts + '</td>' +
            '<td>' + x.fu_done + '</td><td' + (x.fu_late ? ' style="color:#b91c1c;font-weight:600"' : '') + '>' + x.fu_late + '</td><td>' + x.po + '</td><td>' + x.deal + '</td><td>' + esc(crmRpFmt216(x.deal_v)) + '</td><td>' + x.lost + '</td>' +
            '<td>' + (x.win === null ? '—' : x.win + '%') + '</td><td>' + (x.cycle === null ? '—' : String(x.cycle).replace('.', ',') + ' hr') + '</td><td>' + esc(crmRpShort216(x.open_v)) + ' <span class="help">(' + x.open + ')</span></td><td>' + esc(crmRpShort216(x.weighted)) + '</td><td>' + esc(crmRpShort216(x.fc_v)) + ' <span class="help">(' + x.fc_n + ')</span></td></tr>';
        }).join('') : '<tr><td colspan="14" class="help">Belum ada sales. Buat akun peran Sales di Pengguna.</td></tr>') +
        '</tbody></table></div>';
      if ((r.by_user || []).length) h += '<div class="crm-perf-u"><b>Aktivitas per pencatat:</b> ' + r.by_user.map(function (x) { return esc(x.name) + ' ' + x.acts; }).join(' · ') + '</div>';
    }
    h += '<p class="help" style="margin-top:10px">Lead baru, aktivitas, follow-up selesai, PO dan Close Deal/Lose dihitung dalam periode. Pipeline, nilai tertimbang, follow-up terlambat dan closing 30 hari = kondisi saat ini. Aktivitas dihitung ke sales pemilik lead.</p>';
    body.innerHTML = h;
  }
  function crmPerfCsv217() {
    var r = crmPerfS217.data; if (!r) return;
    var rows = crmPerfRows217(), q = function (v) { v = String(v === null || v === undefined ? '' : v); return /[",\n;]/.test(v) ? '"' + v.replace(/"/g, '""') + '"' : v; };
    var L = [['Sales', 'Lead baru', 'Aktivitas', 'Follow-up selesai', 'Follow-up terlambat', 'PO', 'Close Deal', 'Nilai deal (Rp)', 'Close Lose', 'Win rate (%)', 'Rata-rata nilai deal', 'Lama closing (hari)', 'Pipeline terbuka', 'Nilai pipeline (Rp)', 'Nilai tertimbang (Rp)', 'Closing 30 hari', 'Nilai closing 30 hari (Rp)'].join(',')];
    rows.concat(rows.length > 1 ? [Object.assign({ name: 'TOTAL' }, r.total)] : []).forEach(function (x) {
      L.push([x.name, x.new, x.acts, x.fu_done, x.fu_late, x.po, x.deal, x.deal_v, x.lost, x.win, x.avg_deal, x.cycle, x.open, x.open_v, x.weighted, x.fc_n, x.fc_v].map(q).join(','));
    });
    var a = document.createElement('a');
    a.href = URL.createObjectURL(new Blob(['﻿' + L.join('\n')], { type: 'text/csv;charset=utf-8' }));
    a.download = 'performa-sales-' + r.from + '_' + r.to + '.csv';
    document.body.appendChild(a); a.click(); setTimeout(function () { URL.revokeObjectURL(a.href); a.remove(); }, 500);
  }
  function crmWeekly217() {
    api('crm_weekly_get').then(function (r) {
      if (!r || !r.ok) { toast((r && r.error) || 'Gagal memuat pengaturan.', true); return; }
      var days = ['', 'Senin', 'Selasa', 'Rabu', 'Kamis', 'Jumat', 'Sabtu', 'Minggu'], hrs = '';
      for (var h = 5; h <= 20; h++) hrs += '<option value="' + h + '"' + (h === r.hour ? ' selected' : '') + '>' + String(h).padStart(2, '0') + ':00 WIB</option>';
      tkModal214(ico('mail', 17) + ' Laporan mingguan',
        '<p class="crm-p">Setiap minggu, ringkasan <b>7 hari terakhir</b> dikirim lewat email: lead baru, aktivitas, PO, Close Deal (Rp), win rate, pipeline, dan follow-up terlambat. Admin menerima laporan seluruh sales; akun Sales menerima laporannya sendiri.</p>' +
        '<label class="crm-ck"><input type="checkbox" class="cw-on"' + (r.on ? ' checked' : '') + '> Kirim laporan mingguan</label>' +
        '<div class="tk-grid" style="margin-top:10px"><div class="row"><label class="fl">Hari kirim</label><select class="cw-dow">' + days.slice(1).map(function (d, i) { return '<option value="' + (i + 1) + '"' + (i + 1 === r.dow ? ' selected' : '') + '>' + d + '</option>'; }).join('') + '</select></div>' +
        '<div class="row"><label class="fl">Jam kirim</label><select class="cw-h">' + hrs + '</select></div></div>' +
        '<label class="crm-ck" style="font-weight:400"><input type="checkbox" class="cw-adm"' + (r.admins ? ' checked' : '') + '> Super Admin &amp; Admin (laporan lengkap)</label>' +
        '<label class="crm-ck" style="font-weight:400;margin-top:6px"><input type="checkbox" class="cw-sales"' + (r.sales ? ' checked' : '') + '> Akun Sales (laporan masing-masing)</label>' +
        '<div class="row" style="margin-top:10px"><label class="fl">Email tambahan (laporan lengkap, maks. 10, pisahkan koma)</label><input type="text" class="cw-ex" value="' + esc((r.extra || []).join(', ')) + '" placeholder="owner@perusahaan.com"></div>' +
        '<p class="crm-p">' + r.recipients + ' penerima dengan pengaturan saat ini' + (r.last_week ? ' · terakhir terkirim minggu ' + esc(r.last_week) : '') + '.</p>' +
        (r.no_email && r.no_email.length ? '<p class="crm-p crm-warn">Belum punya email (tidak menerima): ' + r.no_email.map(esc).join(', ') + '. Isi email di menu Pengguna.</p>' : '') +
        '<div class="tk-foot"><button type="button" class="btn ghost sm cw-test" style="margin-right:auto">' + ico('send', 14) + ' Kirim uji ke email saya</button><button type="button" class="btn ghost tk-x">Batal</button><button type="button" class="btn cw-save">Simpan</button></div>',
        function (ov, close) {
          ov.querySelector('.cw-save').onclick = function () {
            api('crm_weekly_save', { method: 'POST', body: { on: ov.querySelector('.cw-on').checked ? 1 : 0, dow: +ov.querySelector('.cw-dow').value, hour: +ov.querySelector('.cw-h').value,
              admins: ov.querySelector('.cw-adm').checked ? 1 : 0, sales: ov.querySelector('.cw-sales').checked ? 1 : 0, extra: ov.querySelector('.cw-ex').value } }).then(function (x) {
              if (!x || !x.ok) { toast((x && x.error) || 'Gagal menyimpan.', true); return; }
              close(); toast('Pengaturan laporan mingguan disimpan.');
            });
          };
          ov.querySelector('.cw-test').onclick = function () {
            var bt = this; bt.disabled = true;
            api('crm_weekly_test', { method: 'POST', body: {} }).then(function (x) {
              bt.disabled = false;
              if (!x || !x.ok) { toast((x && x.error) || 'Gagal mengirim email uji.', true); return; }
              toast('Laporan uji terkirim ke ' + x.to + '.');
            });
          };
        });
    });
  }




  /* ====================================================================== *
   *  v1.2.223: laporan-pdf — Laporan & Log > Laporan Berkala (PDF mingguan & bulanan → email & WhatsApp)
   * ====================================================================== */
  var rpS223 = { d: null };
  if (!ICONS['file-text']) ICONS['file-text'] = '<path d="M15 2H6a2 2 0 0 0-2 2v16a2 2 0 0 0 2 2h12a2 2 0 0 0 2-2V7Z"/><path d="M14 2v4a2 2 0 0 0 2 2h4"/><path d="M10 9H8"/><path d="M16 13H8"/><path d="M16 17H8"/>';
  if (!ICONS['calendar-days']) ICONS['calendar-days'] = '<path d="M8 2v4"/><path d="M16 2v4"/><rect width="18" height="18" x="3" y="4" rx="2"/><path d="M3 10h18"/><path d="M8 14h.01"/><path d="M12 14h.01"/><path d="M16 14h.01"/><path d="M8 18h.01"/><path d="M12 18h.01"/><path d="M16 18h.01"/>';
  if (!ICONS.cpu) ICONS.cpu = '<rect width="16" height="16" x="4" y="4" rx="2"/><rect width="6" height="6" x="9" y="9" rx="1"/><path d="M15 2v2"/><path d="M15 20v2"/><path d="M2 15h2"/><path d="M2 9h2"/><path d="M20 15h2"/><path d="M20 9h2"/><path d="M9 2v2"/><path d="M9 20v2"/>';
  if (!ICONS['file-down']) ICONS['file-down'] = '<path d="M15 2H6a2 2 0 0 0-2 2v16a2 2 0 0 0 2 2h12a2 2 0 0 0 2-2V7Z"/><path d="M14 2v4a2 2 0 0 0 2 2h4"/><path d="M12 18v-6"/><path d="m9 15 3 3 3-3"/>';
  function rpCss223() {
    if (document.getElementById('rpCss223')) return;
    var st = document.createElement('style'); st.id = 'rpCss223';
    st.textContent = '.rp-g{display:grid;grid-template-columns:1fr 1fr;gap:14px}@media(max-width:820px){.rp-g{grid-template-columns:1fr}}' +
      '.rp-box{border:1px solid var(--line,#e6e6ef);border-radius:12px;padding:14px}.rp-box h4{margin:0 0 10px;font-size:14px;display:flex;align-items:center;gap:8px}' +
      '.rp-row{display:flex;gap:10px;flex-wrap:wrap;align-items:flex-end;margin-bottom:10px}.rp-row>div{min-width:120px}' +
      '.rp-secs{display:grid;grid-template-columns:1fr 1fr;gap:4px 10px;margin:6px 0 4px}.rp-secs label{font-size:13px;display:flex;gap:6px;align-items:flex-start;cursor:pointer}.rp-secs label.off{opacity:.5}' +
      '.rp-st{font-size:12.5px;color:var(--muted);margin-top:8px;line-height:1.5}.rp-ok{color:#15803d;font-weight:600}.rp-bad{color:#b91c1c;font-weight:600}' +
      '.rp-pill{display:inline-block;font-size:11px;padding:2px 8px;border-radius:99px;background:#eef0fb;color:#33334d;margin:0 4px 4px 0}' +
      '.rp-act{display:flex;gap:8px;flex-wrap:wrap;align-items:center;margin-top:14px}';
    document.head.appendChild(st);
  }
  function rpInit223() {
    rpCss223();
    if (!can('super_admin,admin')) { repView('summary'); return; }
    var box = $('#rpCard'); if (!box) return;
    box.innerHTML = '<div class="help">Memuat…</div>';
    api('rpt_get').then(function (r) {
      if (!r || !r.ok) { box.innerHTML = '<h3>Laporan Berkala (PDF)</h3><div class="crm-p ' + (r && r.locked ? 'crm-warn' : '') + '">' + esc((r && r.error) || 'Gagal memuat.') + '</div>'; return; }
      rpS223.d = r; rpRender223();
    });
  }
  function rpSecBox223(r, kind) {
    var on = r.conf[kind].sections || [];
    return '<div class="rp-secs">' + r.sections.map(function (x) {
      return '<label class="' + (x.avail ? '' : 'off') + '" title="' + (x.avail ? '' : 'Butuh fitur CRM (paket Growth+)') + '"><input type="checkbox" class="rp-sec" data-k="' + kind + '" value="' + x.key + '"' + (on.indexOf(x.key) > -1 ? ' checked' : '') + (x.avail ? '' : ' disabled') + '> ' + esc(x.label) + (x.sales ? '' : '') + '</label>';
    }).join('') + '</div>';
  }
  function rpHours223(sel) { var h = ''; for (var i = 5; i <= 21; i++) h += '<option value="' + i + '"' + (i === sel ? ' selected' : '') + '>' + String(i).padStart(2, '0') + ':00 WIB</option>'; return h; }
  function rpPer223(p) {
    if (!p) return '';
    return (p.skipped ? 'Jadwal aktif mulai periode berikutnya (periode <b>' + esc(p.label) + '</b> dilewati karena jadwalnya sudah lewat saat diaktifkan).' : 'Periode laporan berikutnya/terakhir: <b>' + esc(p.label) + '</b> — ' + (p.done ? '<span class="rp-ok">terkirim' + (p.done_at ? ' ' + esc(p.done_at) : '') + '</span>' : 'belum dikirim')) +
      (p.err ? '<br><span class="rp-bad">Gagal: ' + esc(p.err) + '</span>' : '');
  }
  function rpRender223() {
    var r = rpS223.d, c = r.conf, E = r.engine, box = $('#rpCard'), sa = role === 'super_admin';
    var days = ['Senin', 'Selasa', 'Rabu', 'Kamis', 'Jumat', 'Sabtu', 'Minggu'], dom = '';
    for (var i = 1; i <= 28; i++) dom += '<option value="' + i + '"' + (i === c.monthly.dom ? ' selected' : '') + '>Tanggal ' + i + '</option>';
    var rc = r.recipients || [];
    var eng = E.active === 'chrome' ? 'Chromium (' + esc(E.chrome_bin) + ')' : (E.dompdf ? 'dompdf ' + esc(E.dompdf_ver) + (E.dompdf_via === 'vendor' ? ' (composer)' : '') : '<span class="rp-bad">dompdf belum terpasang</span> — dipasang otomatis saat PDF pertama dibuat');
    var h = '<h3 style="display:flex;align-items:center;gap:8px">' + ico('file-text', 17) + ' Laporan Berkala (PDF)</h3>' +
      '<p class="crm-p">Laporan PDF dibuat dan dikirim otomatis setiap minggu dan/atau setiap bulan ke email (lampiran PDF) dan WhatsApp (dokumen PDF). Admin menerima laporan lengkap; akun Sales hanya menerima performa, pipeline, dan task miliknya.</p>' +
      '<div class="rp-g">' +
        '<div class="rp-box"><h4>' + ico('calendar', 15) + ' Mingguan</h4>' +
          '<label class="crm-ck"><input type="checkbox" class="rp-on" data-k="weekly"' + (c.weekly.on ? ' checked' : '') + '> Kirim laporan mingguan</label>' +
          '<div class="rp-row" style="margin-top:10px"><div><label class="fl">Hari kirim</label><select class="rp-dow">' + days.map(function (d, i) { return '<option value="' + (i + 1) + '"' + (i + 1 === c.weekly.dow ? ' selected' : '') + '>' + d + '</option>'; }).join('') + '</select></div>' +
          '<div><label class="fl">Jam</label><select class="rp-h" data-k="weekly">' + rpHours223(c.weekly.hour) + '</select></div></div>' +
          '<div class="fl">Isi laporan (7 hari sebelum hari kirim)</div>' + rpSecBox223(r, 'weekly') +
          '<div class="rp-st">' + rpPer223(r.period.weekly) + '</div></div>' +
        '<div class="rp-box"><h4>' + ico('calendar-days', 15) + ' Bulanan</h4>' +
          '<label class="crm-ck"><input type="checkbox" class="rp-on" data-k="monthly"' + (c.monthly.on ? ' checked' : '') + '> Kirim laporan bulanan</label>' +
          '<div class="rp-row" style="margin-top:10px"><div><label class="fl">Tanggal kirim</label><select class="rp-dom">' + dom + '</select></div>' +
          '<div><label class="fl">Jam</label><select class="rp-h" data-k="monthly">' + rpHours223(c.monthly.hour) + '</select></div></div>' +
          '<div class="fl">Isi laporan (bulan sebelumnya, dibandingkan bulan sebelumnya lagi)</div>' + rpSecBox223(r, 'monthly') +
          '<div class="rp-st">' + rpPer223(r.period.monthly) + '</div></div>' +
        '<div class="rp-box"><h4>' + ico('users', 15) + ' Penerima & saluran</h4>' +
          '<label class="crm-ck" style="font-weight:400"><input type="checkbox" class="rp-adm"' + (c.to_admins ? ' checked' : '') + '> Super Admin &amp; Admin (laporan lengkap)</label>' +
          '<label class="crm-ck" style="font-weight:400;margin-top:6px"><input type="checkbox" class="rp-spv"' + (c.to_spv ? ' checked' : '') + '> Supervisor (laporan lengkap)</label>' +
          '<label class="crm-ck" style="font-weight:400;margin-top:6px"><input type="checkbox" class="rp-sales"' + (c.to_sales ? ' checked' : '') + '> Akun Sales (laporan miliknya)</label>' +
          '<div class="row" style="margin-top:10px"><label class="fl">Email tambahan (laporan lengkap, maks. 10)</label><input type="text" class="rp-em" value="' + esc((c.extra_email || []).join(', ')) + '" placeholder="owner@perusahaan.com, direksi@perusahaan.com"></div>' +
          '<div class="row"><label class="fl">Nomor WhatsApp tambahan (laporan lengkap, maks. 10)</label><input type="text" class="rp-wa" value="' + esc((c.extra_wa || []).join(', ')) + '" placeholder="62812xxxx, 62813xxxx"></div>' +
          '<div class="row"><label class="fl">Kirim lewat</label><select class="rp-via"><option value="email"' + (c.via === 'email' ? ' selected' : '') + '>Email saja</option><option value="wa"' + (c.via === 'wa' ? ' selected' : '') + '>WhatsApp saja</option><option value="both"' + (c.via === 'both' ? ' selected' : '') + '>Email &amp; WhatsApp</option></select></div>' +
          (!r.wa_ready ? '<p class="crm-p crm-warn">WhatsApp belum bisa dipakai: ' + esc(r.wa_why) + ' Penerima tetap dikirimi lewat email.</p>' : '') +
          '<div class="rp-st"><b>' + rc.length + ' penerima</b> dengan pengaturan tersimpan:<br>' + (rc.length ? rc.map(function (x) {
            return '<span class="rp-pill">' + esc(x.name) + (x.own ? ' · milik sendiri' : '') + ' · ' + [x.via_email ? 'email' : '', x.via_wa ? 'WA' : ''].filter(Boolean).join(' + ') + (!x.via_email && !x.via_wa ? '<span class="rp-bad">tanpa email/WA</span>' : '') + '</span>';
          }).join('') : 'belum ada') + '</div>' +
          '<p class="help" style="margin-top:6px">Email & nomor WhatsApp anggota tim diisi di menu Pengguna / Profil Saya. WhatsApp dikirim dari nomor pengirim Notifikasi Tim (Widget &amp; API).</p></div>' +
        '<div class="rp-box"><h4>' + ico('cpu', 15) + ' Mesin PDF</h4>' +
          '<div class="rp-st" style="margin-top:0">Dipakai sekarang: <b>' + eng + '</b>' + (E.chrome && E.active !== 'chrome' ? '<br>Chromium terdeteksi: ' + esc(E.chrome_bin) : '') +
          (E.php_missing && E.php_missing.length ? '<br><span class="rp-bad">Ekstensi PHP belum aktif: ' + esc(E.php_missing.join(', ')) + '</span>' : '') + '</div>' +
          '<div class="row" style="margin-top:10px"><label class="fl">Mesin</label><select class="rp-eng"><option value="auto"' + (c.engine === 'auto' ? ' selected' : '') + '>Otomatis (Chromium bila ada di server, selain itu dompdf)</option><option value="dompdf"' + (c.engine === 'dompdf' ? ' selected' : '') + '>dompdf saja</option><option value="chrome"' + (c.engine === 'chrome' ? ' selected' : '') + '>Chromium (cadangan dompdf)</option></select></div>' +
          (sa ? '<div class="row"><label class="fl">Lokasi Chromium/Chrome (opsional, untuk VPS)</label><input type="text" class="rp-cb" value="' + esc(c.chrome_bin || '') + '" placeholder="/usr/bin/chromium"></div>' : '') +
          '<p class="help">dompdf jalan di cPanel maupun VPS (butuh ekstensi PHP dom, mbstring, gd). Di VPS Ubuntu: <code>sudo apt install php-xml php-mbstring php-gd</code>; opsional Chromium: <code>sudo apt install chromium-browser</code>.</p>' +
          (!E.dompdf ? '<button type="button" class="btn ghost sm rp-lib">' + ico('download', 14) + ' Pasang mesin PDF sekarang</button>' : '') + '</div>' +
      '</div>' +
      '<div class="rp-act"><button type="button" class="btn rp-save">' + ico('save', 15) + ' Simpan</button>' +
        '<span style="flex:1"></span>' +
        '<select class="rp-mk" style="width:auto"><option value="weekly">Mingguan terakhir</option><option value="monthly">Bulan lalu</option><option value="custom">Pilih tanggal…</option></select>' +
        '<input type="date" class="rp-f" style="width:auto;display:none"><input type="date" class="rp-t" style="width:auto;display:none">' +
        '<button type="button" class="btn ghost rp-make">' + ico('file-down', 15) + ' Buat &amp; unduh PDF</button>' +
        '<button type="button" class="btn ghost rp-test">' + ico('send', 15) + ' Kirim uji ke saya</button></div>' +
      '<h4 style="margin:22px 0 8px;font-size:14px">Arsip PDF</h4>' +
      '<div class="scroll"><table class="tbl"><thead><tr><th>Dibuat</th><th>Jenis</th><th>Periode</th><th>Untuk</th><th>Mesin</th><th style="text-align:right">Ukuran</th><th></th></tr></thead><tbody>' +
        ((r.archive || []).length ? r.archive.map(function (a) {
          var k = { weekly: 'Mingguan', monthly: 'Bulanan', custom: 'Pilih tanggal' }[a.kind] || a.kind;
          return '<tr><td>' + esc(String(a.at || '').slice(0, 16)) + '</td><td>' + esc(k) + (a.test ? ' <span class="help">(uji)</span>' : '') + '</td><td>' + esc(a.from) + ' – ' + esc(a.to) + '</td><td>' + esc(a.own ? a.for : 'Lengkap') + '</td><td>' + esc(a.engine || '') + '</td>' +
            '<td style="text-align:right">' + Math.max(1, Math.round((a.size || 0) / 1024)) + ' KB</td><td><button type="button" class="btn ghost sm rp-dl" data-id="' + esc(a.id) + '">' + ico('download', 13) + ' Unduh</button></td></tr>';
        }).join('') : '<tr><td colspan="7" class="help">Belum ada laporan PDF.</td></tr>') + '</tbody></table></div>' +
      rpLog223(r);
    box.innerHTML = h;
    var mk = box.querySelector('.rp-mk');
    mk.onchange = function () { var cu = mk.value === 'custom'; box.querySelector('.rp-f').style.display = cu ? '' : 'none'; box.querySelector('.rp-t').style.display = cu ? '' : 'none'; };
    box.querySelector('.rp-save').onclick = rpSave223;
    box.querySelector('.rp-make').onclick = function () { rpMake223(this); };
    box.querySelector('.rp-test').onclick = function () { rpTest223(this); };
    if (box.querySelector('.rp-lib')) box.querySelector('.rp-lib').onclick = function () {
      var bt = this; bt.disabled = true; bt.textContent = 'Memasang…';
      api('rpt_lib', { method: 'POST', body: {} }).then(function (x) {
        if (!x || !x.ok) { bt.disabled = false; bt.textContent = 'Coba lagi'; toast((x && x.error) || 'Gagal memasang mesin PDF.', true); return; }
        toast('Mesin PDF terpasang.'); rpS223.d = x; rpRender223();
      });
    };
    Array.prototype.forEach.call(box.querySelectorAll('.rp-dl'), function (b) { b.onclick = function () { rpDownload223(b.dataset.id, b); }; });
  }
  function rpLog223(r) {
    var L = [];
    ['monthly', 'weekly'].forEach(function (k) { (r.period[k].log || []).forEach(function (x) { L.push([k, x]); }); });
    if (!L.length) return '';
    return '<h4 style="margin:18px 0 8px;font-size:14px">Riwayat kirim periode terakhir</h4><div class="scroll"><table class="tbl"><thead><tr><th>Waktu</th><th>Jenis</th><th>Penerima</th><th>Lewat</th><th>Status</th></tr></thead><tbody>' +
      L.slice(0, 30).map(function (p) { var x = p[1];
        return '<tr><td>' + esc(x.at) + '</td><td>' + (p[0] === 'monthly' ? 'Bulanan' : 'Mingguan') + '</td><td>' + esc(x.name) + ' <span class="help">' + esc(x.to) + '</span></td><td>' + (x.ch === 'wa' ? 'WhatsApp' : 'Email') + '</td><td>' + (x.ok ? '<span class="rp-ok">terkirim</span>' : '<span class="rp-bad">gagal</span> <span class="help">' + esc(x.err || '') + '</span>') + '</td></tr>';
      }).join('') + '</tbody></table></div>';
  }
  function rpCollect223() {
    var box = $('#rpCard'), q = function (s) { return box.querySelector(s); };
    var secs = function (k) { return Array.prototype.filter.call(box.querySelectorAll('.rp-sec[data-k="' + k + '"]'), function (x) { return x.checked; }).map(function (x) { return x.value; }); };
    var b = {
      weekly: { on: q('.rp-on[data-k="weekly"]').checked ? 1 : 0, dow: +q('.rp-dow').value, hour: +q('.rp-h[data-k="weekly"]').value, sections: secs('weekly') },
      monthly: { on: q('.rp-on[data-k="monthly"]').checked ? 1 : 0, dom: +q('.rp-dom').value, hour: +q('.rp-h[data-k="monthly"]').value, sections: secs('monthly') },
      to_admins: q('.rp-adm').checked ? 1 : 0, to_spv: q('.rp-spv').checked ? 1 : 0, to_sales: q('.rp-sales').checked ? 1 : 0,
      extra_email: q('.rp-em').value, extra_wa: q('.rp-wa').value, via: q('.rp-via').value, engine: q('.rp-eng').value
    };
    if (q('.rp-cb')) b.chrome_bin = q('.rp-cb').value;
    return b;
  }
  function rpSave223() {
    var bt = $('#rpCard .rp-save'); bt.disabled = true;
    return api('rpt_save', { method: 'POST', body: rpCollect223() }).then(function (x) {
      bt.disabled = false;
      if (!x || !x.ok) { toast((x && x.error) || 'Gagal menyimpan.', true); return false; }
      toast('Pengaturan Laporan Berkala disimpan.'); rpS223.d = x; rpRender223(); return true;
    });
  }
  function rpDownload223(id, bt) {
    if (bt) bt.disabled = true;
    fetch(API + '?action=rpt_file&id=' + encodeURIComponent(id) + '&_=' + Date.now(), { headers: { 'X-Auth-Token': token }, cache: 'no-store' }).then(function (res) {
      if (!res.ok) return res.json().then(function (j) { throw new Error((j && j.error) || ('HTTP ' + res.status)); }, function () { throw new Error('HTTP ' + res.status); });
      var cd = res.headers.get('Content-Disposition') || '', m = /filename="([^"]+)"/.exec(cd);
      return res.blob().then(function (b) {
        var a = document.createElement('a'); a.href = URL.createObjectURL(b); a.download = m ? m[1] : 'laporan.pdf';
        document.body.appendChild(a); a.click(); setTimeout(function () { URL.revokeObjectURL(a.href); a.remove(); }, 1500);
      });
    }).catch(function (e) { toast(e.message || 'Gagal mengunduh.', true); }).then(function () { if (bt) bt.disabled = false; });
  }
  function rpMake223(bt) {
    var box = $('#rpCard'), k = box.querySelector('.rp-mk').value, body = { kind: k };
    if (k === 'custom') {
      body.from = box.querySelector('.rp-f').value; body.to = box.querySelector('.rp-t').value;
      if (!body.from || !body.to) { toast('Isi tanggal dari & sampai.', true); return; }
    } else body.sections = Array.prototype.filter.call(box.querySelectorAll('.rp-sec[data-k="' + k + '"]'), function (x) { return x.checked; }).map(function (x) { return x.value; });
    var t0 = bt.innerHTML; bt.disabled = true; bt.innerHTML = 'Membuat PDF…';
    api('rpt_make', { method: 'POST', body: body }).then(function (x) {
      bt.disabled = false; bt.innerHTML = t0;
      if (!x || !x.ok) { toast((x && x.error) || 'Gagal membuat PDF.', true); return; }
      if (x.warn) toast(x.warn, true);
      rpDownload223(x.id); api('rpt_get').then(function (r) { if (r && r.ok) { rpS223.d = r; rpRender223(); } });
    });
  }
  function rpTest223(bt) {
    var k = $('#rpCard .rp-mk').value === 'monthly' ? 'monthly' : 'weekly';
    var t0 = bt.innerHTML; bt.disabled = true; bt.innerHTML = 'Mengirim…';
    api('rpt_test', { method: 'POST', body: { kind: k } }).then(function (x) {
      bt.disabled = false; bt.innerHTML = t0;
      if (!x || (!x.ok && !x.email && !x.wa)) { toast((x && x.error) || 'Gagal mengirim laporan uji.', true); return; }
      var m = [];
      if (x.email) m.push(x.email.ok ? 'email ke ' + x.email.to + (x.email.attached ? ' (lampiran PDF)' : ' (tautan unduh)') : 'email gagal: ' + x.email.error);
      if (x.wa) m.push(x.wa.ok ? 'WhatsApp ke ' + x.wa.to + (x.wa.via === 'link' ? ' (tautan unduh)' : ' (dokumen PDF)') : 'WhatsApp gagal: ' + x.wa.error);
      toast('Laporan ' + (k === 'monthly' ? 'bulanan' : 'mingguan') + ' uji: ' + m.join(' · '), !x.ok);
      api('rpt_get').then(function (r) { if (r && r.ok) { rpS223.d = r; rpRender223(); } });
    });
  }

  /* v1.2.221: laporan-sales */
  /* ====================================================================== *
   *  v1.2.221: laporan-sales — menu Laporan Sales (Growth+)
   *  Performa & Target · Aktivitas · Produktivitas · Forecast · Funnel & Win/Loss · Umur Lead
   * ====================================================================== */
  var SR_PRESETS221 = { thismonth: 'Bulan ini', lastmonth: 'Bulan lalu', thisweek: 'Minggu ini', lastweek: 'Minggu lalu', last7: '7 hari terakhir', last30: '30 hari terakhir',
                        thisquarter: 'Kuartal ini', lastquarter: 'Kuartal lalu', thisyear: 'Tahun ini', custom: 'Pilih tanggal' };
  function srRange221(p) {
    var t = new Date(); t.setHours(12, 0, 0, 0);
    var q = Math.floor(t.getMonth() / 3);
    if (p === 'thisquarter') return [crmYmd217(new Date(t.getFullYear(), q * 3, 1, 12)), crmYmd217(t)];
    if (p === 'lastquarter') return [crmYmd217(new Date(t.getFullYear(), q * 3 - 3, 1, 12)), crmYmd217(new Date(t.getFullYear(), q * 3, 0, 12))];
    if (p === 'thisyear') return [crmYmd217(new Date(t.getFullYear(), 0, 1, 12)), crmYmd217(t)];
    return crmRange217(p);
  }
  var srS221 = { preset: 'thismonth', from: '', to: '', sales: '', div: '', view: 'perf', data: null, actType: '', actQ: '' };
  try { var _sr = JSON.parse(localStorage.getItem('dei_sr221') || '{}'); if (_sr.preset && SR_PRESETS221[_sr.preset] && _sr.preset !== 'custom') srS221.preset = _sr.preset; if (_sr.view) srS221.view = _sr.view; } catch (e) {}
  var SR_VIEWS221 = [['perf', 'target', 'Performa &amp; Target'], ['act', 'activity', 'Aktivitas'], ['prod', 'clock-3', 'Produktivitas'],
                     ['fc', 'wallet', 'Forecast'], ['fun', 'layers', 'Funnel &amp; Win/Loss'], ['age', 'alarm-clock', 'Umur Lead']];
  var SR_COL221 = { call: '#4f46e5', wa: '#16a34a', meeting: '#ea580c', visit: '#0891b2', email: '#9333ea', presentasi: '#db2777', penawaran: '#ca8a04', other: '#64748b' };
  var SR_MON221 = ['Jan', 'Feb', 'Mar', 'Apr', 'Mei', 'Jun', 'Jul', 'Agu', 'Sep', 'Okt', 'Nov', 'Des'];
  function srSave221() { try { localStorage.setItem('dei_sr221', JSON.stringify({ preset: srS221.preset, view: srS221.view })); } catch (e) {} }
  function srMon221(ym) { var p = String(ym).split('-'); return p.length === 2 ? SR_MON221[(+p[1]) - 1] + ' ' + p[0] : ym; }
  function srPct221(v) { return v === null || v === undefined ? '—' : v + '%'; }
  function srNum221(v) { return v === null || v === undefined ? '—' : String(v).replace('.', ','); }
  function srDays221(v) { return v === null || v === undefined ? '—' : (+v < 1 ? '&lt; 1' : srNum221(v)); }
  function srBar221(pct, cls) { pct = Math.max(0, Math.min(100, +pct || 0)); return '<span class="sr-bar' + (cls ? ' ' + cls : '') + '"><i style="width:' + pct + '%"></i></span>'; }
  function srAttCls221(p) { return p === null || p === undefined ? '' : (p >= 100 ? 'good' : (p >= 70 ? '' : 'bad')); }
  function srTile221(l, b, s, c) { return '<div class="crm-pt' + (c ? ' ' + c : '') + '"><div class="crm-pt-l">' + l + '</div><div class="crm-pt-b">' + b + '</div><div class="crm-pt-s">' + (s || '') + '</div></div>'; }
  function srTbl221(head, rows, cls) {
    return '<div class="scroll"><table class="tbl sr-t' + (cls ? ' ' + cls : '') + '"><thead><tr>' + head.map(function (h) { return '<th>' + h + '</th>'; }).join('') + '</tr></thead><tbody>' +
      (rows.length ? rows.join('') : '<tr><td colspan="' + head.length + '" class="help">Belum ada data untuk periode / filter ini.</td></tr>') + '</tbody></table></div>';
  }
  function srSec221(title, sub, inner) { return '<div class="card sr-card"><div class="sr-h"><b>' + title + '</b>' + (sub ? '<span class="help">' + sub + '</span>' : '') + '</div>' + inner + '</div>'; }

  function srLoad221() {
    var root = $('#srRoot'); if (!root) return;
    var S = srS221;
    if (!S.from) { var r0 = srRange221(S.preset); S.from = r0[0]; S.to = r0[1]; }
    root.innerHTML =
      '<div class="rep-seg" id="srSeg">' + SR_VIEWS221.map(function (v) { return '<button type="button" data-v="' + v[0] + '"' + (v[0] === S.view ? ' class="on"' : '') + '>' + ico(v[1], 15, 'style="vertical-align:-3px"') + ' ' + v[2] + '</button>'; }).join('') + '</div>' +
      '<div class="card sr-bar-card"><div class="crm-perf-bar" style="margin:0">' +
        '<select id="srPre" style="width:auto">' + Object.keys(SR_PRESETS221).map(function (k) { return '<option value="' + k + '"' + (k === S.preset ? ' selected' : '') + '>' + SR_PRESETS221[k] + '</option>'; }).join('') + '</select>' +
        '<input type="date" id="srFrom"><span class="help">s/d</span><input type="date" id="srTo">' +
        '<select id="srSales" style="width:auto;display:none" title="Filter sales"></select>' +
        '<select id="srDiv" style="width:auto;display:none" title="Filter divisi"></select>' +
        '<button type="button" class="btn ghost sm" id="srGo">Tampilkan</button>' +
        '<button type="button" class="btn ghost sm" id="srCsv">' + ico('download', 14) + ' CSV</button>' +
        '<button type="button" class="btn ghost sm" id="srTgt" style="display:none;margin-left:auto">' + ico('target', 14) + ' Target sales</button>' +
      '</div></div>' +
      '<div id="srBody"><div class="card help">Memuat…</div></div>';
    $('#srFrom').value = S.from; $('#srTo').value = S.to;
    $$('#srSeg button').forEach(function (b) { b.onclick = function () { S.view = b.dataset.v; srSave221(); $$('#srSeg button').forEach(function (x) { x.classList.toggle('on', x === b); }); srPaint221(); }; });
    $('#srPre').onchange = function () {
      S.preset = this.value; srSave221();
      if (S.preset !== 'custom') { var r = srRange221(S.preset); S.from = r[0]; S.to = r[1]; $('#srFrom').value = S.from; $('#srTo').value = S.to; srFetch221(); }
    };
    var cust = function () { S.preset = 'custom'; $('#srPre').value = 'custom'; };
    $('#srFrom').onchange = cust; $('#srTo').onchange = cust;
    $('#srGo').onclick = function () { S.from = $('#srFrom').value; S.to = $('#srTo').value; srFetch221(); };
    $('#srSales').onchange = function () { S.sales = this.value; srFetch221(); };
    $('#srDiv').onchange = function () { S.div = this.value; srFetch221(); };
    $('#srCsv').onclick = srCsv221;
    $('#srTgt').onclick = srTargets221;
    srFetch221();
  }
  function srFetch221() {
    var S = srS221, body = $('#srBody'); if (!body) return;
    if (!S.from || !S.to) { toast('Isi tanggal awal & akhir.', true); return; }
    body.style.opacity = '.5';
    api('sales_rep', { query: '&from=' + encodeURIComponent(S.from) + '&to=' + encodeURIComponent(S.to) + '&sales=' + encodeURIComponent(S.sales) + '&div=' + encodeURIComponent(S.div) }).then(function (r) {
      body.style.opacity = '';
      if (!r || !r.ok) {
        body.innerHTML = '<div class="card" style="text-align:center;color:var(--muted)">' + esc((r && r.error) || 'Gagal memuat laporan.') + '</div>';
        return;
      }
      S.data = r; srFilters221(); srPaint221();
    });
  }
  function srFilters221() {
    var r = srS221.data, sel = $('#srSales'), dv = $('#srDiv');
    if (!r || r.own) { sel.style.display = 'none'; dv.style.display = 'none'; }
    else {
      sel.innerHTML = '<option value="">Semua sales</option>' + (r.sales || []).map(function (x) { return '<option value="' + esc(x.id) + '"' + (x.id === srS221.sales ? ' selected' : '') + '>' + esc(x.name) + (x.active ? '' : ' (nonaktif)') + '</option>'; }).join('') +
        '<option value="_none"' + (srS221.sales === '_none' ? ' selected' : '') + '>Tanpa sales</option>';
      sel.style.display = '';
      if ((r.divs || []).length) {
        dv.innerHTML = '<option value="">Semua divisi</option>' + r.divs.map(function (d) { return '<option value="' + esc(d) + '"' + (d === srS221.div ? ' selected' : '') + '>' + esc(d) + '</option>'; }).join('');
        dv.style.display = '';
      } else dv.style.display = 'none';
    }
    $('#srTgt').style.display = r && r.can_target ? '' : 'none';
  }
  function srPaint221() {
    var r = srS221.data, body = $('#srBody'); if (!r || !body) return;
    var per = crmFmtD215(r.from) + ' – ' + crmFmtD215(r.to);
    var who = r.own ? 'Kinerja Anda' : (srS221.sales ? ((r.sales || []).filter(function (x) { return x.id === srS221.sales; })[0] || { name: 'Tanpa sales' }).name : (srS221.div ? 'Divisi ' + srS221.div : 'Semua sales'));
    var head = '<div class="sr-per">' + esc(who) + ' · ' + esc(per) + ' <span class="help">· dibuat ' + esc(r.generated) + ' WIB</span></div>';
    var v = srS221.view, h = '';
    if (v === 'act') h = srAct221(r); else if (v === 'prod') h = srProd221(r); else if (v === 'fc') h = srFc221(r);
    else if (v === 'fun') h = srFun221(r); else if (v === 'age') h = srAge221(r); else h = srPerf221(r);
    body.innerHTML = head + h;
    var q = $('#srActQ'), ty = $('#srActTy');
    if (q) q.oninput = function () { srS221.actQ = q.value; srActList221(); };
    if (ty) ty.onchange = function () { srS221.actType = ty.value; srActList221(); };
    if (q) srActList221();
  }

  /* ---- Performa & Target ---- */
  function srPerf221(r) {
    var P = r.perf, T = P.total, tg = T.target;
    var tiles = '<div class="crm-pts">' +
      srTile221('Nilai Close Deal', esc(crmRpShort216(T.deal_v)), tg && tg.rev ? srBar221(T.att_rev, srAttCls221(T.att_rev)) + ' ' + srPct221(T.att_rev) + ' dari target ' + esc(crmRpShort216(tg.rev)) : T.deal + ' deal · target belum diatur', 'good') +
      srTile221('Jumlah deal', T.deal, tg && tg.deals ? srPct221(T.att_deals) + ' dari target ' + tg.deals : 'PO ' + T.po + ' · lose ' + T.lost) +
      srTile221('Win rate', srPct221(T.win), T.deal + ' deal · ' + T.lost + ' lose') +
      srTile221('Rata-rata deal', esc(crmRpShort216(T.avg_deal)), T.cycle === null ? 'lama closing —' : '±' + srDays221(T.cycle) + ' hari dari lead ke closing') +
      srTile221('Lead baru', T.new, 'masuk dalam periode') +
      srTile221('Aktivitas', T.acts, tg && tg.acts ? srPct221(Math.round(T.acts * 100 / tg.acts)) + ' dari target ' + tg.acts : 'follow-up selesai ' + T.fu_done) +
      srTile221('Pipeline terbuka', esc(crmRpShort216(T.open_v)), T.open + ' lead · tertimbang ' + esc(crmRpShort216(T.weighted))) +
    '</div>';
    var rows = P.rows.map(function (x) {
      var t = x.target;
      return '<tr><td><b>' + esc(x.name) + '</b>' + (x.active || !x.id ? '' : ' <span class="help">(nonaktif)</span>') + (x.div ? '<div class="help">' + esc(x.div) + '</div>' : '') + '</td>' +
        '<td class="num">' + esc(crmRpFmt216(x.deal_v)) + '</td><td class="num">' + (t && t.rev ? esc(crmRpShort216(t.rev)) : '—') + '</td>' +
        '<td style="min-width:120px">' + (x.att_rev === null ? '<span class="help">—</span>' : srBar221(x.att_rev, srAttCls221(x.att_rev)) + ' <b>' + x.att_rev + '%</b>') + '</td>' +
        '<td class="num">' + x.deal + (t && t.deals ? ' <span class="help">/ ' + t.deals + '</span>' : '') + '</td>' +
        '<td class="num">' + x.acts + (t && t.acts ? ' <span class="help">/ ' + t.acts + '</span>' : '') + '</td>' +
        '<td class="num">' + srPct221(x.win) + '</td><td class="num">' + esc(crmRpShort216(x.avg_deal)) + '</td><td class="num">' + (x.cycle === null ? '—' : srDays221(x.cycle) + ' hr') + '</td>' +
        '<td class="num">' + x.new + '</td><td class="num">' + x.po + '</td><td class="num">' + x.lost + '</td>' +
        '<td class="num">' + esc(crmRpShort216(x.open_v)) + ' <span class="help">(' + x.open + ')</span></td></tr>';
    });
    var rank = P.rows.filter(function (x) { return x.id; }).slice().sort(function (a, b) { return b.deal_v - a.deal_v; }).slice(0, 5);
    var mx = rank.length ? Math.max(1, rank[0].deal_v) : 1;
    return tiles +
      srSec221('Pencapaian per sales', 'Target bulanan dihitung pro-rata sesuai panjang periode (' + srNum221(P.month_frac) + ' bulan).',
        srTbl221(['Sales', 'Nilai deal', 'Target', 'Pencapaian', 'Deal', 'Aktivitas', 'Win', 'Rata-rata', 'Lama closing', 'Lead baru', 'PO', 'Lose', 'Pipeline'], rows)) +
      (rank.length > 1 ? srSec221('Peringkat nilai deal', '', rank.map(function (x, i) { return '<div class="sr-rank"><span>' + (i + 1) + '. ' + esc(x.name) + '</span>' + srBar221(x.deal_v * 100 / mx) + '<b>' + esc(crmRpShort216(x.deal_v)) + '</b></div>'; }).join('')) : '') +
      (r.can_target && !T.target ? '<p class="help" style="margin:8px 2px">Belum ada target. Klik <b>Target sales</b> untuk mengisi target bulanan (nilai deal, jumlah deal, aktivitas) per sales.</p>' : '');
  }

  /* ---- Aktivitas ---- */
  function srAct221(r) {
    var A = r.activity, types = r.types || {};
    var chips = Object.keys(A.by_type || {}).map(function (k) { return '<span class="sr-chip"><i style="background:' + (SR_COL221[k] || '#64748b') + '"></i>' + esc(types[k] || k) + ' <b>' + A.by_type[k] + '</b></span>'; }).join('');
    var mx = 1; A.days.forEach(function (d) { if (d.n > mx) mx = d.n; });
    var tkeys = Object.keys(A.by_type || {});
    var chart = '<div class="sr-chart">' + A.days.map(function (d) {
      var seg = tkeys.map(function (k) { var n = (d.t || {})[k] || 0; return n ? '<i style="height:' + (n * 100 / mx) + '%;background:' + (SR_COL221[k] || '#64748b') + '"></i>' : ''; }).join('');
      var dt = new Date(d.d + 'T12:00:00'), sun = dt.getDay() === 0;
      return '<div class="sr-col' + (sun ? ' sun' : '') + '" title="' + esc(crmFmtD215(d.d)) + ': ' + d.n + ' aktivitas"><div class="sr-stack">' + seg + '</div><span>' + (A.days.length <= 31 ? dt.getDate() : '') + '</span></div>';
    }).join('') + '</div>';
    var mrows = (A.by_sales || []).map(function (x) {
      return '<tr><td><b>' + esc(x.name) + '</b></td><td class="num"><b>' + x.n + '</b></td>' + tkeys.map(function (k) { return '<td class="num">' + ((x.t || {})[k] || '<span class="help">0</span>') + '</td>'; }).join('') + '</tr>';
    });
    var tyOpt = '<option value="">Semua jenis</option>' + tkeys.map(function (k) { return '<option value="' + esc(k) + '"' + (k === srS221.actType ? ' selected' : '') + '>' + esc(types[k] || k) + '</option>'; }).join('');
    return '<div class="crm-pts">' + srTile221('Total aktivitas', A.total, 'dicatat sales di lead (tanpa catatan sistem)') +
        srTile221('Rata-rata per hari', srNum221(Math.round(A.total * 10 / Math.max(1, A.days.length)) / 10), A.days.length + ' hari dalam periode') +
        srTile221('Jenis terbanyak', tkeys.length ? esc(types[tkeys[0]] || tkeys[0]) : '—', tkeys.length ? A.by_type[tkeys[0]] + ' kali' : '') + '</div>' +
      srSec221('Aktivitas per hari', '', (chips ? '<div class="sr-chips">' + chips + '</div>' : '') + chart) +
      srSec221('Per sales &amp; jenis', 'Dihitung ke sales pemilik lead.', srTbl221(['Sales', 'Total'].concat(tkeys.map(function (k) { return esc(types[k] || k); })), mrows)) +
      srSec221('Daftar aktivitas', A.list_more ? 'Menampilkan 500 terbaru dari ' + A.total + '.' : '',
        '<div class="crm-perf-bar" style="margin:0 0 8px"><select id="srActTy" style="width:auto">' + tyOpt + '</select><input type="search" id="srActQ" placeholder="Cari lead, catatan, pencatat…" value="' + esc(srS221.actQ) + '" style="flex:1;min-width:160px;max-width:320px"></div><div id="srActList"></div>');
  }
  function srActList221() {
    var r = srS221.data, box = $('#srActList'); if (!r || !box) return;
    var types = r.types || {}, q = (srS221.actQ || '').toLowerCase(), ty = srS221.actType;
    var L = (r.activity.list || []).filter(function (a) { return (!ty || a.type === ty) && (!q || (a.lead + ' ' + a.text + ' ' + a.by + ' ' + a.sales).toLowerCase().indexOf(q) !== -1); });
    box.innerHTML = srTbl221(['Waktu', 'Jenis', 'Lead', 'Catatan', 'Sales', 'Dicatat oleh', 'Follow-up'], L.slice(0, 300).map(function (a) {
      return '<tr><td style="white-space:nowrap">' + esc(crmFmtD215(a.at) + ' ' + String(a.at).slice(11, 16)) + '</td><td><span class="sr-chip"><i style="background:' + (SR_COL221[a.type] || '#64748b') + '"></i>' + esc(types[a.type] || a.type) + '</span></td>' +
        '<td><b>' + esc(a.lead) + '</b></td><td class="sr-txt">' + esc(a.text) + '</td><td>' + esc(a.sales) + '</td><td>' + esc(a.by) + '</td><td>' + (a.next ? esc(crmFmtD215(a.next)) : '') + '</td></tr>';
    })) + (L.length > 300 ? '<p class="help">' + (L.length - 300) + ' lagi — persempit dengan pencarian atau unduh CSV.</p>' : '');
  }

  /* ---- Produktivitas ---- */
  function srProd221(r) {
    var P = r.productivity, T = P.total;
    var rows = P.rows.map(function (x) {
      return '<tr><td><b>' + esc(x.name) + '</b>' + (x.active || !x.id ? '' : ' <span class="help">(nonaktif)</span>') + '</td><td class="num">' + x.acts + '</td><td class="num">' + srNum221(x.per_day) + '</td>' +
        '<td class="num">' + x.active_days + '<span class="help"> / ' + x.workdays + '</span></td><td class="num">' + x.touched + '</td><td class="num">' + srNum221(x.per_lead) + '</td>' +
        '<td class="num">' + x.fu_due + '</td><td class="num">' + x.fu_ontime + '</td><td class="num">' + x.fu_late_done + '</td><td class="num"' + (x.fu_missed ? ' style="color:#b91c1c;font-weight:600"' : '') + '>' + x.fu_missed + '</td>' +
        '<td style="min-width:110px">' + (x.compliance === null ? '<span class="help">—</span>' : srBar221(x.compliance, srAttCls221(x.compliance >= 90 ? 100 : x.compliance)) + ' <b>' + x.compliance + '%</b>') + '</td>' +
        '<td class="num">' + (x.resp_med_h === null ? '—' : srNum221(x.resp_med_h) + ' jam') + (x.resp_none ? '<div class="help">' + x.resp_none + ' belum disentuh</div>' : '') + '</td>' +
        '<td class="num">' + x.open + '</td><td class="num"' + (x.idle ? ' style="color:#b45309;font-weight:600"' : '') + '>' + x.idle + '</td></tr>';
    });
    return '<div class="crm-pts">' +
        srTile221('Aktivitas per hari kerja', srNum221(T.per_day), T.acts + ' aktivitas · ' + P.workdays + ' hari kerja (Sen–Sab)') +
        srTile221('Lead disentuh', T.touched, srNum221(T.per_lead) + ' aktivitas per lead') +
        srTile221('Kepatuhan follow-up', srPct221(T.compliance), T.fu_ontime + ' tepat waktu · ' + T.fu_late_done + ' telat · ' + T.fu_missed + ' terlewat', T.compliance !== null && T.compliance < 70 ? 'bad' : (T.compliance >= 90 ? 'good' : '')) +
        srTile221('Respons lead baru', T.resp_med_h === null ? '—' : srNum221(T.resp_med_h) + ' jam', 'median lead masuk → aktivitas pertama' + (T.resp_none ? ' · ' + T.resp_none + ' belum disentuh' : '')) +
        srTile221('Lead diam &gt; 7 hari', T.idle, 'termasuk belum disentuh · dari ' + T.open + ' lead terbuka (saat ini)', T.idle ? 'bad' : '') +
      '</div>' +
      srSec221('Produktivitas per sales', 'Follow-up = jadwal follow-up yang jatuh tempo dalam periode. Tepat waktu = ditandai selesai paling lambat di tanggal jatuh temponya.',
        srTbl221(['Sales', 'Aktivitas', 'Per hari', 'Hari aktif', 'Lead disentuh', 'Akt./lead', 'FU jatuh tempo', 'Tepat waktu', 'Selesai telat', 'Terlewat', 'Kepatuhan', 'Respons lead baru', 'Lead terbuka', 'Diam &gt;7 hr'], rows));
  }

  /* ---- Forecast ---- */
  function srFc221(r) {
    var F = r.forecast, m0 = F.months[0], m1 = F.months[1];
    var b0 = F.buckets.filter(function (b) { return b.key === m0; })[0] || {}, bo = F.buckets.filter(function (b) { return b.key === 'overdue'; })[0] || {};
    var won0 = 0, tg0 = 0, wt0 = 0;
    F.by_sales.forEach(function (x) { var m = x.months[m0] || {}; won0 += m.won || 0; tg0 += m.target || 0; wt0 += m.weighted || 0; });
    var proj = won0 + wt0, att = tg0 ? Math.round(proj * 100 / tg0) : null;
    var mxp = 1; F.buckets.forEach(function (b) { if (b.pipe > mxp) mxp = b.pipe; });
    var bRows = F.buckets.map(function (b) {
      var lab = b.key === 'overdue' ? '<span style="color:#b91c1c">Lewat perkiraan closing</span>' : (b.key === 'later' ? 'Sesudahnya' : (b.key === 'none' ? 'Tanpa perkiraan closing' : srMon221(b.key)));
      return '<tr><td><b>' + lab + '</b></td><td class="num">' + b.n + '</td><td style="min-width:140px">' + srBar221(b.pipe * 100 / mxp) + ' ' + esc(crmRpShort216(b.pipe)) + '</td><td class="num">' + esc(crmRpShort216(b.best)) + '</td><td class="num">' + esc(crmRpShort216(b.commit)) + '</td><td class="num"><b>' + esc(crmRpShort216(b.weighted)) + '</b></td></tr>';
    });
    var sRows = F.by_sales.map(function (x) {
      var cell = function (mm) { var m = x.months[mm] || {}; return '<td class="num">' + (m.target ? esc(crmRpShort216(m.target)) : '—') + '</td><td class="num">' + esc(crmRpShort216(m.won || 0)) + '</td><td class="num">' + esc(crmRpShort216(m.commit || 0)) + '</td><td class="num">' + esc(crmRpShort216(m.weighted || 0)) + '</td><td style="min-width:110px">' + (m.att === null || m.att === undefined ? '<b>' + esc(crmRpShort216(m.projected || 0)) + '</b>' : srBar221(m.att, srAttCls221(m.att)) + ' <b>' + m.att + '%</b>') + '</td>'; };
      return '<tr><td><b>' + esc(x.name) + '</b></td>' + cell(m0) + cell(m1) + '</tr>';
    });
    var dRows = F.deals.map(function (d) {
      return '<tr' + (d.overdue ? ' class="sr-late"' : '') + '><td style="white-space:nowrap">' + esc(crmFmtD215(d.ce)) + (d.overdue ? ' <span class="sr-tag bad">lewat</span>' : '') + '</td><td><b>' + esc(d.lead) + '</b>' + (d.company ? '<div class="help">' + esc(d.company) + '</div>' : '') + '</td><td>' + esc(d.sales) + '</td>' +
        '<td>' + esc(d.st_label) + ' <span class="help">' + d.prob + '%</span></td><td class="num">' + esc(crmRpFmt216(d.v)) + '</td><td class="num">' + esc(crmRpShort216(d.weighted)) + '</td><td>' + (d.last ? esc(crmFmtD215(d.last)) : '<span class="help">belum ada</span>') + '</td></tr>';
    });
    var stg = (F.stages || []).map(function (s) { return esc(s.label) + ' ' + s.prob + '%'; }).join(' · ');
    return '<div class="crm-pts">' +
        srTile221('Proyeksi ' + srMon221(m0), esc(crmRpShort216(proj)), (att === null ? 'sudah closing ' + esc(crmRpShort216(won0)) + ' + tertimbang ' + esc(crmRpShort216(wt0)) : srBar221(att, srAttCls221(att)) + ' ' + att + '% dari target ' + esc(crmRpShort216(tg0))), 'good') +
        srTile221('Commit ' + srMon221(m0), esc(crmRpShort216((b0.commit || 0) + (bo.commit || 0))), 'tahap peluang ≥ 70%, closing bulan ini / lewat') +
        srTile221('Best case ' + srMon221(m0), esc(crmRpShort216((b0.best || 0) + (bo.best || 0))), 'tahap peluang ≥ 40%') +
        srTile221('Lewat perkiraan closing', bo.n || 0, esc(crmRpShort216(bo.pipe || 0)) + ' — perbarui tanggal atau status', bo.n ? 'bad' : '') +
      '</div>' +
      srSec221('Forecast per bulan perkiraan closing', 'Kondisi pipeline saat ini (tidak terpengaruh periode). Tertimbang = nilai × peluang tahap (' + stg + ').',
        srTbl221(['Bulan closing', 'Lead', 'Pipeline', 'Best case', 'Commit', 'Tertimbang'], bRows)) +
      srSec221('Forecast per sales', 'Proyeksi = sudah Close Deal di bulan itu + nilai tertimbang. Bulan ini termasuk lead yang lewat perkiraan closing.',
        srTbl221(['Sales', 'Target ' + srMon221(m0), 'Closing', 'Commit', 'Tertimbang', 'Proyeksi', 'Target ' + srMon221(m1), 'Closing', 'Commit', 'Tertimbang', 'Proyeksi'], sRows)) +
      srSec221('Deal yang diperkirakan closing', 'Lead terbuka dengan perkiraan closing sampai ' + srMon221(F.months[3]) + ', urut tanggal.',
        srTbl221(['Perkiraan closing', 'Lead', 'Sales', 'Tahap', 'Nilai', 'Tertimbang', 'Aktivitas terakhir'], dRows));
  }

  /* ---- Funnel & Win/Loss ---- */
  function srFun221(r) {
    var F = r.funnel;
    var fun = F.stages.map(function (s, i) {
      return '<div class="sr-fun"><span class="sr-fun-l">' + esc(s.label) + '</span><span class="sr-fun-b"><i style="width:' + (s.pct || 0) + '%"></i><b>' + s.n + '</b></span>' +
        '<span class="sr-fun-p">' + srPct221(s.pct) + (i && s.step !== null ? '<span class="help"> · ' + s.step + '% dari tahap sebelumnya</span>' : '') + '</span></div>';
    }).join('');
    var src = F.by_source.map(function (x) {
      return '<tr><td><b>' + esc(x.label) + '</b></td><td class="num">' + x.leads + '</td><td class="num">' + x.deal + '</td><td class="num">' + x.lost + '</td><td class="num">' + x.open + '</td><td class="num">' + srPct221(x.conv) + '</td><td class="num">' + srPct221(x.win) + '</td><td class="num">' + esc(crmRpShort216(x.deal_v)) + '</td><td class="num">' + esc(crmRpShort216(x.pipe)) + '</td></tr>';
    });
    var dur = F.stage_days.map(function (x) { return '<tr><td>' + esc(x.label) + '</td><td class="num">' + (x.avg_d === null ? '—' : srNum221(x.avg_d) + ' hari') + '</td><td class="num help">' + x.n + '</td></tr>'; });
    var lost = F.lost_list.map(function (x) { return '<tr><td>' + esc(crmFmtD215(x.at)) + '</td><td><b>' + esc(x.lead) + '</b></td><td>' + esc(x.sales) + '</td><td>' + esc(x.stage) + '</td><td class="num">' + esc(crmRpFmt216(x.v)) + '</td><td class="sr-txt">' + (x.reason ? esc(x.reason) : '<span class="help">tanpa catatan</span>') + '</td></tr>'; });
    return '<div class="crm-pts">' +
        srTile221('Lead baru (kohort)', F.cohort, 'dibuat dalam periode; funnel di bawah mengikuti lead ini') +
        srTile221('Win rate', srPct221(F.win), F.won + ' deal · ' + F.lost + ' lose (ditutup dalam periode)', 'good') +
        srTile221('Nilai menang', esc(crmRpShort216(F.won_v)), 'kalah ' + esc(crmRpShort216(F.lost_v))) +
        srTile221('Lama closing', F.cycle === null ? '—' : srDays221(F.cycle) + ' hari', 'rata-rata lead dibuat → Close Deal') +
      '</div>' +
      srSec221('Funnel konversi', 'Tahap tertinggi yang pernah dicapai tiap lead (dari riwayat status). Tahap opsional yang dilewati tidak dihitung.', '<div class="sr-funnel">' + fun + '</div>') +
      srSec221('Per sumber lead', 'Konversi = Close Deal ÷ lead. Win = deal ÷ (deal + lose).', srTbl221(['Sumber', 'Lead', 'Deal', 'Lose', 'Masih jalan', 'Konversi', 'Win', 'Nilai deal', 'Pipeline'], src)) +
      '<div class="sr-2">' +
        srSec221('Rata-rata lama di tiap tahap', 'Semua lead yang pindah tahap.', srTbl221(['Tahap', 'Rata-rata', 'Data'], dur)) +
        srSec221('Kalah di tahap', '', F.lost_at.length ? F.lost_at.map(function (x) { return '<div class="sr-rank"><span>' + esc(x.label) + '</span>' + srBar221(x.n * 100 / Math.max(1, F.lost), 'bad') + '<b>' + x.n + '</b></div>'; }).join('') : '<p class="help">Belum ada Close Lose dalam periode.</p>') +
      '</div>' +
      srSec221('Close Lose &amp; alasannya', 'Alasan diambil dari catatan lead. Isi catatan saat menandai Close Lose supaya analisa kekalahan lebih tajam.', srTbl221(['Tanggal', 'Lead', 'Sales', 'Tahap terakhir', 'Nilai', 'Alasan / catatan'], lost));
  }

  /* ---- Umur Lead ---- */
  function srAge221(r) {
    var A = r.aging, ks = ['0-3', '4-7', '8-14', '15-30', '>30'];
    var mxI = 1, mxA = 1; ks.concat(['never']).forEach(function (k) { if (A.idle[k] && A.idle[k].n > mxI) mxI = A.idle[k].n; }); ks.forEach(function (k) { if (A.age[k].n > mxA) mxA = A.age[k].n; });
    var row = function (lab, x, mx, cls) { return '<div class="sr-rank"><span>' + lab + '</span>' + srBar221(x.n * 100 / mx, cls) + '<b>' + x.n + '</b><span class="help" style="min-width:70px;text-align:right">' + esc(crmRpShort216(x.v)) + '</span></div>'; };
    var idle7 = A.idle['8-14'].n + A.idle['15-30'].n + A.idle['>30'].n;
    var list = A.list.map(function (x) {
      return '<tr><td><b>' + esc(x.lead) + '</b></td><td>' + esc(x.sales) + '</td><td>' + esc(x.st_label) + '</td><td class="num">' + esc(crmRpShort216(x.v)) + '</td><td class="num">' + (x.age === null ? '—' : x.age + ' hr') + '</td>' +
        '<td class="num"' + (x.idle === null || x.idle > 7 ? ' style="color:#b91c1c;font-weight:600"' : '') + '>' + (x.idle === null ? 'belum pernah' : x.idle + ' hr') + '</td><td>' + (x.fu ? esc(crmFmtD215(x.fu)) : '<span class="help">tidak ada</span>') + '</td></tr>';
    });
    var bs = A.by_stage.map(function (x) { return '<tr><td><b>' + esc(x.label) + '</b></td><td class="num">' + x.n + '</td><td class="num">' + srNum221(x.avg_age) + ' hari</td><td class="num">' + (x.avg_idle === null ? '—' : srNum221(x.avg_idle) + ' hari') + '</td></tr>'; });
    return '<div class="crm-pts">' +
        srTile221('Lead terbuka', A.open, 'kondisi saat ini (tidak terpengaruh periode)') +
        srTile221('Diam &gt; 7 hari', idle7, 'tanpa aktivitas sales lebih dari seminggu', idle7 ? 'bad' : 'good') +
        srTile221('Belum pernah disentuh', A.idle.never.n, 'belum ada aktivitas sama sekali', A.idle.never.n ? 'bad' : '') +
      '</div>' +
      '<div class="sr-2">' +
        srSec221('Hari sejak aktivitas terakhir', '', ks.map(function (k) { return row(k + ' hari', A.idle[k], mxI, k === '0-3' || k === '4-7' ? '' : 'bad'); }).join('') + row('belum pernah', A.idle.never, mxI, 'bad')) +
        srSec221('Umur lead (sejak dibuat)', '', ks.map(function (k) { return row(k + ' hari', A.age[k], mxA); }).join('')) +
      '</div>' +
      srSec221('Per tahap', '', srTbl221(['Tahap', 'Lead', 'Rata-rata umur', 'Rata-rata diam'], bs)) +
      srSec221('Lead perlu perhatian', 'Urut dari yang paling lama tidak disentuh.', srTbl221(['Lead', 'Sales', 'Tahap', 'Nilai', 'Umur', 'Diam', 'Follow-up berikut'], list));
  }

  /* ---- CSV per tampilan ---- */
  function srCsv221() {
    var r = srS221.data; if (!r) return;
    var q = function (v) { v = String(v === null || v === undefined ? '' : v); return /[",\n;]/.test(v) ? '"' + v.replace(/"/g, '""') + '"' : v; };
    var L = [], v = srS221.view, types = r.types || {}, name = 'laporan-sales';
    var add = function (a) { L.push(a.map(q).join(',')); };
    if (v === 'perf') {
      name = 'performa-target'; add(['Sales', 'Divisi', 'Nilai deal (Rp)', 'Target nilai (Rp)', 'Pencapaian nilai (%)', 'Deal', 'Target deal', 'Aktivitas', 'Target aktivitas', 'Win rate (%)', 'Rata-rata deal', 'Lama closing (hari)', 'Lead baru', 'PO', 'Close Lose', 'Pipeline (Rp)', 'Lead terbuka']);
      r.perf.rows.forEach(function (x) { var t = x.target || {}; add([x.name, x.div, x.deal_v, t.rev, x.att_rev, x.deal, t.deals, x.acts, t.acts, x.win, x.avg_deal, x.cycle, x.new, x.po, x.lost, x.open_v, x.open]); });
    } else if (v === 'act') {
      name = 'aktivitas'; add(['Waktu', 'Jenis', 'Lead', 'Nomor', 'Catatan', 'Sales', 'Dicatat oleh', 'Follow-up']);
      r.activity.list.forEach(function (a) { add([a.at, types[a.type] || a.type, a.lead, a.num, a.text, a.sales, a.by, a.next]); });
    } else if (v === 'prod') {
      name = 'produktivitas'; add(['Sales', 'Aktivitas', 'Per hari kerja', 'Hari aktif', 'Hari kerja', 'Lead disentuh', 'Aktivitas per lead', 'FU jatuh tempo', 'Tepat waktu', 'Selesai telat', 'Terlewat', 'Kepatuhan (%)', 'Lead baru', 'Respons median (jam)', 'Belum disentuh', 'Lead terbuka', 'Diam >7 hari']);
      r.productivity.rows.forEach(function (x) { add([x.name, x.acts, x.per_day, x.active_days, x.workdays, x.touched, x.per_lead, x.fu_due, x.fu_ontime, x.fu_late_done, x.fu_missed, x.compliance, x.new, x.resp_med_h, x.resp_none, x.open, x.idle]); });
    } else if (v === 'fc') {
      name = 'forecast'; add(['Perkiraan closing', 'Lead', 'Nomor', 'Perusahaan', 'Sales', 'Tahap', 'Peluang (%)', 'Nilai (Rp)', 'Tertimbang (Rp)', 'Lewat perkiraan', 'Aktivitas terakhir']);
      r.forecast.deals.forEach(function (d) { add([d.ce, d.lead, d.num, d.company, d.sales, d.st_label, d.prob, d.v, d.weighted, d.overdue ? 'ya' : '', d.last]); });
    } else if (v === 'fun') {
      name = 'funnel-winloss'; add(['Tahap', 'Lead mencapai', '% kohort', '% dari tahap sebelumnya']);
      r.funnel.stages.forEach(function (s) { add([s.label, s.n, s.pct, s.step]); });
      add([]); add(['Sumber', 'Lead', 'Deal', 'Lose', 'Masih jalan', 'Konversi (%)', 'Win (%)', 'Nilai deal (Rp)', 'Pipeline (Rp)']);
      r.funnel.by_source.forEach(function (x) { add([x.label, x.leads, x.deal, x.lost, x.open, x.conv, x.win, x.deal_v, x.pipe]); });
      add([]); add(['Tanggal lose', 'Lead', 'Nomor', 'Sales', 'Tahap terakhir', 'Nilai (Rp)', 'Alasan']);
      r.funnel.lost_list.forEach(function (x) { add([x.at, x.lead, x.num, x.sales, x.stage, x.v, x.reason]); });
    } else {
      name = 'umur-lead'; add(['Lead', 'Nomor', 'Sales', 'Tahap', 'Nilai (Rp)', 'Umur (hari)', 'Diam (hari)', 'Aktivitas terakhir', 'Follow-up berikut']);
      r.aging.list.forEach(function (x) { add([x.lead, x.num, x.sales, x.st_label, x.v, x.age, x.idle === null ? 'belum pernah' : x.idle, x.last, x.fu]); });
    }
    var a = document.createElement('a');
    a.href = URL.createObjectURL(new Blob(['﻿' + L.join('\n')], { type: 'text/csv;charset=utf-8' }));
    a.download = 'laporan-sales-' + name + '-' + r.from + '_' + r.to + '.csv';
    document.body.appendChild(a); a.click(); setTimeout(function () { URL.revokeObjectURL(a.href); a.remove(); }, 500);
  }

  /* ---- Target sales (Super Admin / Admin) ---- */
  function srTargets221() {
    var r = srS221.data; if (!r || !r.can_target) return;
    var tg = r.targets || {}, act = (r.sales || []).filter(function (x) { return x.active; });
    if (!act.length) { toast('Belum ada sales aktif. Buat akun peran Sales di Pengguna.', true); return; }
    var rows = act.map(function (x) {
      var t = tg[x.id] || {};
      return '<tr data-sid="' + esc(x.id) + '"><td><b>' + esc(x.name) + '</b>' + (x.div ? '<div class="help">' + esc(x.div) + '</div>' : '') + '</td>' +
        '<td><input type="text" inputmode="numeric" class="st-rev" value="' + (t.rev ? esc(crmRpFmt216(t.rev).replace('Rp ', '')) : '') + '" placeholder="0" style="width:140px"></td>' +
        '<td><input type="number" min="0" class="st-deals" value="' + (t.deals || '') + '" placeholder="0" style="width:80px"></td>' +
        '<td><input type="number" min="0" class="st-acts" value="' + (t.acts || '') + '" placeholder="0" style="width:90px"></td></tr>';
    }).join('');
    tkModal214(ico('target', 17) + ' Target sales per bulan',
      '<p class="crm-p">Target dipakai di <b>Performa &amp; Target</b> (dihitung pro-rata sesuai panjang periode) dan <b>Forecast</b> (proyeksi bulan ini &amp; bulan depan). Kosongkan bila tidak ada target.</p>' +
      '<div class="scroll"><table class="tbl sr-t"><thead><tr><th>Sales</th><th>Nilai deal (Rp)</th><th>Jumlah deal</th><th>Aktivitas</th></tr></thead><tbody>' + rows + '</tbody></table></div>' +
      '<div class="tk-foot"><button type="button" class="btn ghost tk-x">Batal</button><button type="button" class="btn st-save">Simpan target</button></div>',
      function (ov, close) {
        Array.prototype.slice.call(ov.querySelectorAll('.st-rev')).forEach(function (inp) { inp.oninput = function () { var d = inp.value.replace(/\D/g, ''); inp.value = d ? d.replace(/\B(?=(\d{3})+(?!\d))/g, '.') : ''; }; });
        ov.querySelector('.st-save').onclick = function () {
          var out = {};
          Array.prototype.slice.call(ov.querySelectorAll('tr[data-sid]')).forEach(function (tr) {
            out[tr.getAttribute('data-sid')] = { rev: tr.querySelector('.st-rev').value.replace(/\D/g, ''), deals: +tr.querySelector('.st-deals').value || 0, acts: +tr.querySelector('.st-acts').value || 0 };
          });
          api('sales_target_save', { method: 'POST', body: { targets: out } }).then(function (x) {
            if (!x || !x.ok) { toast((x && x.error) || 'Gagal menyimpan target.', true); return; }
            close(); toast('Target sales disimpan.'); srFetch221();
          });
        };
      });
  }




  /* v1.2.222: notif-wa */
  /* ====================================================================== *
   *  v1.2.222: notif-wa — notifikasi tim via WhatsApp (Widget & API + Profil Saya)
   * ====================================================================== */
  var NTF_MODE222 = { email: 'Email saja', wa: 'WhatsApp saja', both: 'Email + WhatsApp', off: 'Mati' };
  var NTF_ROLE222 = { super_admin: 'Super Admin', admin: 'Admin', supervisor: 'Supervisor', wa_agent: 'Agent', sales: 'Sales' };
  var ntfData222 = null;
  function ntfLoad222() {
    var card = $('#ntfCard'); if (!card) return;
    if (!(user.role === 'super_admin' || user.role === 'admin')) { card.style.display = 'none'; return; }
    api('ntf_get').then(function (r) {
      var box = $('#ntfBody'); if (!box) return;
      if (!r || !r.ok) { box.innerHTML = '<div class="help">' + esc((r && r.error) || 'Gagal memuat.') + '</div>'; return; }
      ntfData222 = r; ntfPaint222();
    });
  }
  function ntfPaint222() {
    var r = ntfData222, box = $('#ntfBody'); if (!r || !box) return;
    var chs = r.channels || [];
    var chOpt = chs.length ? chs.map(function (c) {
      return '<option value="' + esc(c.id) + '"' + (c.id === r.ch ? ' selected' : '') + (c.ok ? '' : ' disabled') + '>' + esc(c.label) + (c.number && String(c.label).indexOf(c.number) === -1 ? ' — +' + esc(c.number) : '') + (c.ok ? '' : ' (tidak bisa dipakai)') + '</option>';
    }).join('') : '<option value="">Belum ada nomor WhatsApp</option>';
    var why = chs.filter(function (c) { return !c.ok; }).map(function (c) { return '<li><b>' + esc(c.label) + '</b>: ' + esc(c.why) + '</li>'; }).join('');
    var kinds = (r.kinds || []).map(function (k) {
      return '<tr><td>' + esc(k.label) + '</td><td><select class="ntf-k" data-k="' + esc(k.id) + '" style="width:auto">' + k.opts.map(function (o) { return '<option value="' + o + '"' + (o === k.val ? ' selected' : '') + '>' + NTF_MODE222[o] + '</option>'; }).join('') + '</select></td></tr>';
    }).join('');
    var us = (r.users || []).map(function (u) {
      var lock = user.role === 'admin' && u.role === 'super_admin' && u.username !== user.username;
      return '<tr><td><b>' + esc(u.name) + '</b><div class="help">' + esc(NTF_ROLE222[u.role] || u.role) + (u.email ? '' : ' · tanpa email') + '</div></td>' +
        '<td><input type="text" inputmode="tel" class="ntf-u" data-u="' + esc(u.username) + '" value="' + esc(u.wa ? '0' + u.wa.slice(2) : '') + '" placeholder="08xxxxxxxxxx" style="width:170px"' + (lock ? ' disabled' : '') + '></td>' +
        '<td>' + (u.wa ? '<button type="button" class="btn ghost sm ntf-t" data-u="' + esc(u.username) + '">' + ico('send', 13) + ' Uji</button>' : '') + '</td></tr>';
    }).join('');
    var log = (r.log || []).slice(0, 15).map(function (x) {
      var kl = ((r.kinds || []).filter(function (k) { return k.id === x.kind; })[0] || {}).label || (x.kind === 'test' ? 'Uji' : x.kind);
      return '<tr><td style="white-space:nowrap">' + esc(crmFmtD215(x.at) + ' ' + String(x.at).slice(11, 16)) + '</td><td>' + esc(kl) + '</td><td>' + esc(x.name || '') + ' <span class="help">+' + esc(x.to) + '</span></td><td>' +
        (x.ok ? '<span style="color:#166534">terkirim</span>' : '<span style="color:#b91c1c" title="' + esc(x.err || '') + '">gagal</span>' + (x.err ? '<div class="help">' + esc(x.err) + '</div>' : '')) + '</td></tr>';
    }).join('');
    box.innerHTML =
      '<div class="toggle-row"><div><div class="tt">Kirim notifikasi tim lewat WhatsApp</div><div class="td">Pengingat jatuh tempo, laporan mingguan, task baru, lead untuk Sales, dan chat yang diserahkan dikirim ke nomor WhatsApp anggota tim, dari salah satu nomor bisnis di atas.</div></div>' +
        '<label class="switch"><input type="checkbox" id="ntfOn"' + (r.on ? ' checked' : '') + '><span class="sl"></span></label></div>' +
      '<div class="row" style="margin-top:10px"><label class="fl">Nomor pengirim</label><select id="ntfCh">' + chOpt + '</select>' +
        (why ? '<ul class="help" style="margin:6px 0 0 16px;padding:0">' + why + '</ul>' : '') + '</div>' +
      (r.on && !r.sender_ok ? '<p class="crm-p crm-warn" style="margin-top:8px">' + esc(r.sender_err) + '</p>' : '') +
      '<h4 class="ntf-h">Jenis notifikasi</h4><div class="scroll"><table class="tbl ntf-t"><tbody>' + kinds + '</tbody></table></div>' +
      '<p class="help">WhatsApp saja: anggota tim tanpa nomor WhatsApp tetap menerima email. Email lupa password &amp; keamanan akun tetap lewat email.</p>' +
      '<h4 class="ntf-h">Nomor WhatsApp tim</h4><p class="help" style="margin-top:0">Nomor penerima notifikasi. Setiap anggota juga bisa mengisi sendiri di <b>Profil Saya</b>. Pesan dari nomor ini ke nomor bisnis tidak dijawab bot.</p>' +
      '<div class="scroll"><table class="tbl ntf-t"><tbody>' + (us || '<tr><td class="help">Belum ada pengguna.</td></tr>') + '</tbody></table></div>' +
      '<div style="display:flex;gap:8px;margin-top:12px;flex-wrap:wrap"><button type="button" class="btn" id="ntfSave">Simpan</button><button type="button" class="btn ghost" id="ntfReload">Muat ulang</button></div>' +
      (log ? '<h4 class="ntf-h">Riwayat terakhir</h4><div class="scroll"><table class="tbl ntf-t"><tbody>' + log + '</tbody></table></div>' : '') +
      (r.updated_at ? '<p class="help" style="margin-top:8px">Diubah ' + esc(r.updated_at) + (r.updated_by ? ' oleh ' + esc(r.updated_by) : '') + '.</p>' : '');
    $('#ntfReload').onclick = ntfLoad222;
    $('#ntfSave').onclick = function () {
      var b = this, kinds = {}, users = {};
      Array.prototype.slice.call(box.querySelectorAll('.ntf-k')).forEach(function (s) { kinds[s.getAttribute('data-k')] = s.value; });
      Array.prototype.slice.call(box.querySelectorAll('.ntf-u')).forEach(function (i) { if (!i.disabled) users[i.getAttribute('data-u')] = i.value.trim(); });
      b.disabled = true;
      api('ntf_save', { method: 'POST', body: { on: $('#ntfOn').checked ? 1 : 0, ch: $('#ntfCh').value, kinds: kinds, users: users } }).then(function (x) {
        b.disabled = false;
        if (!x || !x.ok) { toast((x && x.error) || 'Gagal menyimpan.', true); return; }
        ntfData222 = x; ntfPaint222(); toast('Notifikasi WhatsApp disimpan.');
      });
    };
    Array.prototype.slice.call(box.querySelectorAll('.ntf-t')).forEach(function (bt) {
      bt.onclick = function () {
        bt.disabled = true;
        api('ntf_test', { method: 'POST', body: { username: bt.getAttribute('data-u') } }).then(function (x) {
          bt.disabled = false;
          if (!x || !x.ok) { toast((x && x.error) || 'Gagal mengirim uji.', true); return; }
          toast('Pesan uji terkirim ke +' + x.to + '.'); ntfLoad222();
        });
      };
    });
  }
  function ntfProfile222() {
    var card = $('#ntfMeCard'); if (!card) return;
    api('ntf_me').then(function (r) {
      if (!r || !r.ok) { card.style.display = 'none'; return; }
      card.style.display = '';
      $('#ntfMeWa').value = r.wa ? '0' + r.wa.slice(2) : '';
      $('#ntfMeNote').innerHTML = r.active
        ? 'Notifikasi aktif dari ' + esc(r.sender) + (r.kinds && r.kinds.length ? ': ' + r.kinds.map(esc).join(', ') + '.' : '.')
        : 'Notifikasi WhatsApp belum diaktifkan Admin. Nomor Anda tetap disimpan.';
      $('#ntfMeSave').onclick = function () {
        var b = this; b.disabled = true;
        api('update_own_wa', { method: 'POST', body: { wa: $('#ntfMeWa').value.trim() } }).then(function (x) {
          b.disabled = false;
          if (!x || !x.ok) { toast((x && x.error) || 'Gagal menyimpan.', true); return; }
          $('#ntfMeWa').value = x.wa ? '0' + x.wa.slice(2) : ''; toast(x.wa ? 'Nomor WhatsApp disimpan.' : 'Nomor WhatsApp dihapus.');
        });
      };
      $('#ntfMeTest').onclick = function () {
        var b = this; b.disabled = true;
        api('ntf_test', { method: 'POST', body: {} }).then(function (x) {
          b.disabled = false;
          if (!x || !x.ok) { toast((x && x.error) || 'Gagal mengirim uji.', true); return; }
          toast('Pesan uji terkirim ke +' + x.to + '.');
        });
      };
    });
  }


  /* ---- v1.2.218: sales-di-lead — assign Sales dari kartu Leads ---- */
  function crmSalesSel218(l, cls) {
    if (!leadCrm215 || user.role === 'sales' || !crmSales215) return '';
    var cur = l.sales_id || '', has = !cur;
    if (!crmSales215.length && !cur) return '';
    var o = '<option value="">— Tanpa sales —</option>' + crmSales215.map(function (x) {
      if (x.id === cur) has = true;
      return '<option value="' + esc(x.id) + '"' + (x.id === cur ? ' selected' : '') + '>' + esc(x.name) + '</option>';
    }).join('');
    if (!has) o += '<option value="' + esc(cur) + '" selected>' + esc(l.sales_name || cur) + '</option>';
    return '<select class="crm-sl218 ' + (cls || '') + '" data-num="' + esc(l.number) + '" data-prev="' + esc(cur) + '" title="Sales yang memegang lead ini" aria-label="Sales">' + o + '</select>';
  }
  function crmSalesSet218(sel) {
    var num = sel.getAttribute('data-num'), prev = sel.getAttribute('data-prev') || '', v = sel.value;
    if (v === prev) return;
    var l = leadAll203.filter(function (x) { return x.number === num; })[0] || {};
    if (!v && l.src === 'sales' && (l.status || 'baru') === 'baru' &&
        !confirm('Lepas sales dari lead ini?\n\nLead ini dibuat otomatis saat chat di-tag sales dan statusnya masih Baru, jadi kartunya akan hilang dari Leads. Kontak & percakapan tetap ada.')) { sel.value = prev; return; }
    sel.disabled = true;
    api('sales_tag', { method: 'POST', body: { number: num, sales: v } }).then(function (r) {
      sel.disabled = false;
      if (!r || !r.ok) { sel.value = prev; toast((r && r.error) || 'Gagal mengatur sales.', true); return; }
      sel.setAttribute('data-prev', v);
      var nm = v ? ((crmSales215 || []).filter(function (x) { return x.id === v; })[0] || {}).name || v : '';
      toast(v ? 'Lead dipegang ' + nm + '.' : (r.lead_removed ? 'Tag sales dilepas — lead Baru ini dihapus dari Leads.' : 'Tag sales dilepas.'));
      fetchLeads();
    });
  }
  document.addEventListener('change', function (e) { var s = e.target; if (s && s.classList && s.classList.contains('crm-sl218')) crmSalesSet218(s); });
  document.addEventListener('mousedown', function (e) { var s = e.target; if (s && s.classList && s.classList.contains('crm-sl218')) e.stopPropagation(); }, true);


  /* ---- v1.2.220: sales-di-pengguna — divisi & data sales di form Pengguna ---- */
  var uDiv220 = [];
  function uDivFill220() {
    var sel = document.getElementById('u_sales_div'); if (!sel) return;
    var cur = sel.dataset.want !== undefined ? sel.dataset.want : sel.value;
    sel.innerHTML = '<option value="">— Tanpa divisi —</option>' + uDiv220.map(function (d) { return '<option value="' + esc(d.name) + '">' + esc(d.name) + ' (' + d.n + ' sales)</option>'; }).join('') +
      '<option value="__new">＋ Divisi baru…</option>';
    uDivSet220(cur || '');
    sel.onchange = function () { var n = document.getElementById('u_sales_div_new'); if (n) { n.style.display = sel.value === '__new' ? '' : 'none'; if (sel.value === '__new') n.focus(); } };
  }
  function uDivSet220(v) {
    var sel = document.getElementById('u_sales_div'), n = document.getElementById('u_sales_div_new'); if (!sel) return;
    sel.dataset.want = v || '';
    var hit = uDiv220.filter(function (d) { return d.name.toLowerCase() === String(v || '').toLowerCase(); })[0];
    sel.value = hit ? hit.name : '';
    if (n) { n.value = ''; n.style.display = 'none'; }
  }
  function uDivGet220() {   // null = divisi baru belum diisi
    var sel = document.getElementById('u_sales_div'); if (!sel) return '';
    if (sel.value !== '__new') return sel.value;
    var v = ((document.getElementById('u_sales_div_new') || {}).value || '').replace(/\s+/g, ' ').trim();
    if (!v) return null;
    var hit = uDiv220.filter(function (d) { return d.name.toLowerCase() === v.toLowerCase(); })[0];
    return hit ? hit.name : v;   // sama dengan divisi yang ada -> pakai yang ada (tidak dobel)
  }
  function uOrphan220() {
    var box = document.getElementById('uSalesOrphan'); if (!box) return;
    var adm = user.role === 'super_admin' || user.role === 'admin';
    var list = uSales216.filter(function (x) { return x.active && !x.user; });
    if (!adm || !list.length) { box.style.display = 'none'; box.innerHTML = ''; return; }
    box.style.display = '';
    box.innerHTML = '<h3 style="margin-top:0">Sales tanpa akun login</h3><div class="desc">Data sales lama yang belum punya akun. Masih bisa ditandai di chat &amp; lead. Buatkan akun peran Sales, atau nonaktifkan bila sudah tidak dipakai (riwayat &amp; laporan tetap).</div>' +
      '<div class="scroll"><table class="tbl"><thead><tr><th>Nama</th><th>Divisi</th><th></th></tr></thead><tbody>' + list.map(function (x) {
        return '<tr data-id="' + esc(x.id) + '"><td>' + esc(x.name) + '</td><td>' + (x.div ? esc(x.div) : '<span class="help">—</span>') + '</td>' +
          '<td style="text-align:right;white-space:nowrap"><button type="button" class="btn ghost sm uo-acc">Buat akun</button> <button type="button" class="btn ghost sm uo-off">Nonaktifkan</button></td></tr>';
      }).join('') + '</tbody></table></div>';
    Array.prototype.forEach.call(box.querySelectorAll('tr[data-id]'), function (tr) {
      var x = list.filter(function (s) { return s.id === tr.dataset.id; })[0];
      tr.querySelector('.uo-acc').onclick = function () {
        resetUserForm();
        $('#u_role').value = 'sales'; $('#u_name').value = x.name;
        if ($('#u_sales_id')) $('#u_sales_id').value = x.id;
        uDivSet220(x.div || ''); toggleSpvRow(); updateSeatWarn();
        window.scrollTo({ top: 0, behavior: 'smooth' }); setTimeout(function () { $('#u_username').focus(); }, 300);
        toast('Isi username, email & password untuk ' + x.name + ', lalu Simpan Pengguna.');
      };
      tr.querySelector('.uo-off').onclick = function () {
        if (!confirm('Nonaktifkan sales "' + x.name + '"?\n\nTidak muncul lagi di pilihan sales chat & lead. Riwayat & laporan tetap.')) return;
        api('sales_save', { method: 'POST', body: { id: x.id, name: x.name, phone: x.phone || '', active: false } }).then(function (r) {
          if (r && r.ok) { toast('Sales dinonaktifkan.'); uSalesLoad216(); } else toast((r && r.error) || 'Gagal.', true);
        });
      };
    });
  }

  // v1.2.147: leads-kanban — pilihan tampilan diingat per browser
  var leadView = 'list';
  try { var _lv217 = localStorage.getItem('dei_lead_view'); leadView = (_lv217 === 'kanban' || _lv217 === 'perf') ? _lv217 : 'list'; } catch (e) {}   // v1.2.217: laporan-crm
  function leadViewApply() {
    var p = $('#panel-leads'); if (p) p.classList.toggle('lk-on', leadView !== 'list');   /* v1.2.217: laporan-crm */
    $$('[data-lead-view]').forEach(function (b) { b.classList.toggle('on', b.dataset.leadView === leadView); });
  }
  function loadLeads() {
    fetchLeads();
    $('#btnReloadLeads').onclick = fetchLeads;
    if ($('#crmNewLead')) $('#crmNewLead').onclick = crmNewLead215;   // v1.2.215: crm-aktivitas
    if ($('#crmRemBtn')) $('#crmRemBtn').onclick = crmRemind215;
    if ($('#crmPipeBtn')) $('#crmPipeBtn').onclick = crmPipeEdit216;   // v1.2.216: pipeline-sales
    $$('[data-lead-view]').forEach(function (b) {   // v1.2.147: leads-kanban
      b.onclick = function () {
        leadView = b.dataset.leadView;
        try { localStorage.setItem('dei_lead_view', leadView); } catch (e) {}
        leadViewApply(); renderLeads();
      };
    });
    leadViewApply();
    $$('.lead-filter').forEach(function (b) {
      b.onclick = function () {
        leadFilter = b.dataset.leadStatus;
        $$('.lead-filter').forEach(function (x) { x.classList.remove('active'); });
        b.classList.add('active');
        renderLeads();
      };
    });
  }

  function fetchLeads() {
    api('get_leads').then(function (res) {
      if (!res || !res.ok) { toast((res && res.error) || 'Gagal memuat leads.', true); return; }
      leadCrm215 = !!res.crm; crmToolbar215();   // v1.2.215: crm-aktivitas
      document.body.classList.toggle('sales-wide', !!res.sales_scope && res.sales_scope !== 'own');   // v1.2.219: divisi-sales
      if (leadCrm215 && crmSales215 === null && user.role !== 'sales') crmLoadSales215(function () { renderLeads(); });   // v1.2.218: sales-di-lead
      leadAll203 = res.leads || []; if (res.pipeline) crmPipeApply216(res.pipeline); /* v1.2.216: pipeline-sales */ slLeadSel203(); leadData = slLeadFilt203(leadAll203);   // v1.2.203: sales-tag
      renderLeads();
    });
  }

  // Kolom kosong ditampilkan sebagai "—": customer tidak menyebutkannya,
  // dan itu sendiri informasi berguna bagi agent.
  function leadField(label, val) {
    var isi = (val && String(val).trim()) ? esc(val) : '<span style="color:var(--muted)">&mdash;</span>';
    return '<div style="margin-bottom:6px"><span style="color:var(--muted);font-size:12px">' + label + '</span><br>' + isi + '</div>';
  }

  function renderLeads() {
    leadFilterLegacyBtn();   // v1.2.118
    crmPipeRender216();   // v1.2.216: pipeline-sales
    if (leadView === 'perf') { crmPerfRender217(); return; }   // v1.2.217: laporan-crm
    if (leadView === 'kanban') { renderLeadsKanban(); return; }   // v1.2.147: leads-kanban
    var list = leadData.filter(function (l) {
      return leadFilter === 'all' || (l.status || 'baru') === leadFilter;
    });
    if (!list.length) {
      $('#leadList').innerHTML = '<div class="card" style="text-align:center;color:var(--muted)">' +
        (leadData.length ? 'Tidak ada lead pada filter ini.' : 'Belum ada lead. Kartu dibuat otomatis saat percakapan WhatsApp mencapai 8 pesan.') +
        '</div>';
      return;
    }
    $('#leadList').innerHTML = list.map(function (l) {
      var ex = l.extracted || {};
      var st = LEAD_STATUS[l.status || 'baru'] || LEAD_STATUS.baru;
      var judul = l.name ? esc(l.name) : ('+' + esc(l.number));
      var opsi = leadStatusOptionsHtml(l.status || 'baru');   // v1.2.118

      // v1.2.27: kepala selalu tampil, rincian menyusul saat diklik
      var terbuka = !!leadOpenState[l.number];
      var putar = terbuka ? 'transform:rotate(180deg);' : '';
      return '<div class="card" data-lead="' + esc(l.number) + '">' +
        '<div class="lead-head" style="display:flex;justify-content:space-between;align-items:center;gap:10px;flex-wrap:wrap;cursor:pointer;user-select:none">' +
          '<div style="display:flex;align-items:center;gap:8px">' +
            '<span class="lead-chev" style="display:inline-flex;color:var(--muted);transition:transform .15s;' + putar + '">' +
              ico('chevron-down', 16) + '</span>' +
            '<div><strong style="font-size:15px">' + judul + '</strong>' +
              (l.name ? ' <span style="color:var(--muted);font-size:12px">+' + esc(l.number) + '</span>' : '') +
              '<div style="color:var(--muted);font-size:12px">' + (l.analyzed_at ? 'Dianalisa ' + esc(l.analyzed_at.slice(0, 16)) : (l.src === 'manual' ? 'Input manual ' : l.src === 'sales' ? 'Dibuat saat tag sales ' : 'Dibuat dari PO ') + esc((l.created_at || l.updated_at || '').slice(0, 16))) + '</div>' +   // v1.2.203: sales-tag
            '</div>' +
          '</div>' +
          '<span class="tag" style="background:' + st.bg + ';color:' + st.fg + '">' + st.label + '</span>' +
          ' ' + contactStageBadgeHtml(l.contact_stage, l.contact_vip, ';margin-left:2px') + slLeadBadge203(l) + crmDealChip216(l) + crmFuChip215(l) + (l.ro ? ' <span class="tag crm-ro-t" title="Lead sales lain — hanya bisa dilihat">Lihat saja</span>' : '') + /* v1.2.215: crm-aktivitas; v1.2.216: pipeline-sales; v1.2.219: divisi-sales */
        '</div>' +
        '<div class="lead-body" style="margin-top:12px;' + (terbuka ? '' : 'display:none') + '">' + crmInfoLine215(l) + /* v1.2.215: crm-aktivitas */
        '<div style="background:var(--brand-soft);padding:10px 12px;border-radius:8px;margin-bottom:10px;font-size:14px">' +
          (ex.ringkasan ? esc(ex.ringkasan) : '<span style="color:var(--muted)">Tidak ada ringkasan.</span>') +
        '</div>' +
        '<div class="grid2">' +
          leadField('Nama disebut', ex.nama) +
          leadField('Kebutuhan', ex.kebutuhan) +
          leadField('Waktu', ex.waktu) +
          leadField('Anggaran', ex.anggaran) +
        '</div>' +
        (crmSalesSel218(l) ? '<div class="row" style="margin-top:8px"><label class="fl">Sales</label>' + crmSalesSel218(l) + '</div>' : '') +   // v1.2.218: sales-di-lead
        '<div class="row" style="margin-top:8px"><label class="fl">Status</label>' +
          '<select class="lead-status"' + (l.ro ? ' disabled' : '') + '>' + opsi + '</select></div>' +
        '<div class="row"><label class="fl">Catatan</label>' +
          '<textarea class="lead-note" rows="2" placeholder="Catatan agent..."' + (l.ro ? ' readonly' : '') + '>' + esc(l.note || '') + '</textarea></div>' +
        '<div style="display:flex;gap:8px;flex-wrap:wrap;margin-top:8px">' +
          (leadCrm215 ? '<button class="btn sm lead-crm">' + ico('activity', 14) + ' Aktivitas &amp; Task</button>' : '') +   // v1.2.215: crm-aktivitas
          '<button class="btn ghost sm lead-open">Lihat percakapan</button>' +
          // v1.2.29: analisa memakai kuota klien -> hanya admin
          (user.role === 'wa_agent' || user.role === 'sales' ? '' : '<button class="btn ghost sm lead-reanalyze">Analisa ulang</button>') +
          (user.role === 'wa_agent' || user.role === 'sales' ? '' : '<button class="btn danger sm lead-del" style="margin-left:auto">' + ico('trash-2', 14) + ' Hapus lead</button>') +   // v1.2.207: hapus-lead
        '</div>' +
        '</div>' +   /* v1.2.27: tutup lead-body */
      '</div>';
    }).join('');

    $$('#leadList .card[data-lead]').forEach(function (card) {
      var num = card.dataset.lead;
      // v1.2.27: buka/tutup. Klik hanya ditangkap di kepala, jadi menekan
      // dropdown/catatan/tombol di dalam rincian tidak menutup kartunya.
      var kepala = card.querySelector('.lead-head');
      var badan  = card.querySelector('.lead-body');
      var chev   = card.querySelector('.lead-chev');
      if (kepala) kepala.onclick = function () {
        var kini = badan.style.display !== 'none';
        badan.style.display = kini ? 'none' : '';
        leadOpenState[num] = !kini;
        if (chev) chev.style.transform = kini ? '' : 'rotate(180deg)';
      };
      card.querySelector('.lead-status').onchange = function (e) {
        saveLead(num, { status: e.target.value });
      };
      // simpan saat kursor meninggalkan kotak catatan
      card.querySelector('.lead-note').onblur = function (e) {
        var lama = (leadData.filter(function (x) { return x.number === num; })[0] || {}).note || '';
        if (e.target.value === lama) return;
        saveLead(num, { note: e.target.value });
      };
      card.querySelector('.lead-open').onclick = function () { openLeadConv(num); };
      var bc215 = card.querySelector('.lead-crm'); if (bc215) bc215.onclick = function () { crmOpen215(num); };   // v1.2.215: crm-aktivitas
      var btnUlang = card.querySelector('.lead-reanalyze');
      if (btnUlang) btnUlang.onclick = function () {
        if (!confirm('Analisa ulang percakapan ini? Memakai 1 jatah kuota chat.')) return;
        api('analyze_lead', { method: 'POST', body: { number: num } }).then(function (r) {
          if (r && r.ok) { toast('Analisa diperbarui.'); fetchLeads(); }
          else toast((r && r.error) || 'Analisa gagal.', true);
        });
      };
      var btnDel = card.querySelector('.lead-del');   // v1.2.207: hapus-lead
      if (btnDel) btnDel.onclick = function () { deleteLead207(num); };
    });
  }

  // v1.2.147: leads-kanban — satu kolom per status; seret kartu (desktop) atau ganti dropdown (HP)
  function renderLeadsKanban() {
    var box = $('#leadList');
    if (!leadData.length) {
      box.innerHTML = '<div class="card" style="text-align:center;color:var(--muted)">Belum ada lead. Kartu dibuat otomatis saat percakapan WhatsApp mencapai 8 pesan.</div>';
      return;
    }
    var cols = Object.keys(LEAD_STATUS).filter(function (k) {
      return !(LEAD_STATUS[k].legacy || LEAD_STATUS[k].off) || leadData.some(function (l) { return l.status === k; });   // v1.2.216: pipeline-sales
    });
    var byCol = {}; cols.forEach(function (k) { byCol[k] = []; });
    leadData.forEach(function (l) { var k = l.status || 'baru'; (byCol[k] || byCol.baru).push(l); });
    cols.forEach(function (k) {   // terbaru di atas
      byCol[k].sort(function (a, b) { return String(b.updated_at || b.analyzed_at || '').localeCompare(String(a.updated_at || a.analyzed_at || '')); });
    });
    box.innerHTML = '<div class="lk-board">' + cols.map(function (k) {
      var d = LEAD_STATUS[k];
      return '<div class="lk-col" data-col="' + k + '">' +
        '<div class="lk-col-h"><span class="tag" style="background:' + d.bg + ';color:' + d.fg + '">' + esc(d.label) + '</span>' +
          '<span class="lk-n">' + byCol[k].length + '</span>' + crmColSum216(byCol[k]) + '</div>' +
        '<div class="lk-list">' + (byCol[k].length ? byCol[k].map(function (l) {
          var ex = l.extracted || {};
          var judul = l.name ? esc(l.name) : ('+' + esc(l.number));
          return '<div class="lk-card' + (l.ro ? ' lk-ro' : '') + '" draggable="' + (l.ro ? 'false' : 'true') + '" data-lead="' + esc(l.number) + '" title="Seret ke kolom lain untuk mengganti status">' +
            '<div class="lk-t">' + judul + '</div>' +
            '<div class="lk-s">' + (l.name ? '+' + esc(l.number) + ' &middot; ' : '') + esc((l.analyzed_at || '').slice(0, 16)) + '</div>' +
            '<div style="margin-top:6px">' + contactStageBadgeHtml(l.contact_stage, l.contact_vip) + slLeadBadge203(l) + '</div>' +
            crmInfoLine215(l) + ((l.fu || l.value || l.close_est) ? '<div style="margin-top:5px">' + crmDealChip216(l) + crmFuChip215(l) + '</div>' : '') +   // v1.2.215: crm-aktivitas
            (ex.ringkasan ? '<div class="lk-r">' + esc(ex.ringkasan) + '</div>' : '') +
            (ex.kebutuhan ? '<div class="lk-s" style="margin-top:5px"><strong>Kebutuhan:</strong> ' + esc(ex.kebutuhan) + '</div>' : '') +
            (l.note ? '<div class="lk-note">' + esc(l.note) + '</div>' : '') +
            (crmSalesSel218(l) ? '<div class="lk-slw">' + ico('briefcase-business', 12) + crmSalesSel218(l, 'lk-sl') + '</div>' : '') +   // v1.2.218: sales-di-lead
            (l.ro ? '<div class="lk-s"><span class="tag crm-ro-t">Lihat saja</span></div>' : '') + '<div class="lk-f"><select class="lk-st" aria-label="Status"' + (l.ro ? ' disabled' : '') + '>' + leadStatusOptionsHtml(l.status || 'baru') + '</select>' +
              (leadCrm215 ? '<button type="button" class="lk-crm" title="Aktivitas & Task">' + ico('activity', 14) + '</button>' : '') +   // v1.2.215: crm-aktivitas
              '<button type="button" class="lk-chat" title="Lihat percakapan">' + ico('message-circle', 14) + '</button>' +
              (user.role === 'wa_agent' || user.role === 'sales' ? '' : '<button type="button" class="lk-del" title="Hapus lead">' + ico('trash-2', 14) + '</button>') + '</div>' +   // v1.2.207: hapus-lead
          '</div>';
        }).join('') : '<div class="lk-empty">Seret kartu ke sini</div>') + '</div>' +
      '</div>';
    }).join('') + '</div>';

    var dragNum = null;
    function pindah(num, st) {
      var l = leadData.filter(function (x) { return x.number === num; })[0];
      if (!l || (l.status || 'baru') === st) return;
      l.status = st; renderLeadsKanban();   // langsung pindah, server menyusul
      saveLead(num, { status: st });
    }
    $$('#leadList .lk-card').forEach(function (c) {
      var num = c.dataset.lead;
      c.ondragstart = function (e) { dragNum = num; c.classList.add('lk-drag'); try { e.dataTransfer.setData('text/plain', num); e.dataTransfer.effectAllowed = 'move'; } catch (er) {} };
      c.ondragend = function () { c.classList.remove('lk-drag'); $$('#leadList .lk-col').forEach(function (x) { x.classList.remove('lk-over'); }); };
      c.querySelector('.lk-st').onchange = function (e) { pindah(num, e.target.value); };
      c.querySelector('.lk-st').onmousedown = function (e) { e.stopPropagation(); };
      c.querySelector('.lk-chat').onclick = function () { openLeadConv(num); };
      var kc215 = c.querySelector('.lk-crm'); if (kc215) kc215.onclick = function () { crmOpen215(num); };   // v1.2.215: crm-aktivitas
      var kd = c.querySelector('.lk-del'); if (kd) kd.onclick = function () { deleteLead207(num); };   // v1.2.207: hapus-lead
    });
    $$('#leadList .lk-col').forEach(function (col) {
      col.ondragover = function (e) { e.preventDefault(); col.classList.add('lk-over'); };
      col.ondragleave = function (e) { if (!col.contains(e.relatedTarget)) col.classList.remove('lk-over'); };
      col.ondrop = function (e) {
        e.preventDefault(); col.classList.remove('lk-over');
        var num = dragNum; try { num = e.dataTransfer.getData('text/plain') || dragNum; } catch (er) {}
        dragNum = null; if (num) pindah(num, col.dataset.col);
      };
    });
  }

  // v1.2.207: hapus-lead — hapus kartu lead saja; kontak, percakapan, tag sales tetap
  function deleteLead207(num) {
    var l = leadData.filter(function (x) { return x.number === num; })[0] || {};
    var nm = l.name ? l.name + ' (+' + num + ')' : '+' + num;
    if (!confirm('Hapus lead ' + nm + '?\n\nKartu lead dan hasil analisanya hilang. Kontak, percakapan, dan tag sales tidak ikut terhapus.\nLead ini tidak dibuat ulang otomatis; bisa dianalisa lagi manual dari chat.')) return;
    api('delete_lead', { method: 'POST', body: { number: num } }).then(function (r) {
      if (r && r.ok) {
        toast('Lead dihapus.');
        delete leadOpenState[num];
        fetchLeads();
        if (typeof fetchWaConvs === 'function') { try { fetchWaConvs(); } catch (e) {} }
      } else toast((r && r.error) || 'Gagal menghapus lead.', true);
    });
  }

  function saveLead(num, body) {
    if (body.status === 'closed_deal' && !body._v216) { body._v216 = 1; crmAskValue216(num, function () { saveLead(num, body); }); return; }   // v1.2.216: pipeline-sales
    delete body._v216;
    body.number = num;
    api('save_lead', { method: 'POST', body: body }).then(function (r) {
      if (r && r.ok) { toast('Tersimpan.'); fetchLeads(); }
      else toast((r && r.error) || 'Gagal menyimpan.', true);
    });
  }

  function openLeadConv(num) {
    showTab('wachat');
    // beri jeda supaya daftar percakapan sempat dimuat sebelum dipilih
    setTimeout(function () {
      try { selectWaConv(num); } catch (e) {}
    }, 700);
  }

  /* ====================================================================== *
   *  KONTAK (v1.2.39) — semua kontak WA + tag pipeline
   * ====================================================================== */
  // v1.2.39 fase6: VIP yang ulang tahun (bulan+hari) hari ini -- dipakai
  // filter Fase 5 maupun tombol "Kirim Ucapan" di kartu.
  function contactBirthdayToday(c) {
    if (!c || !c.vip || !c.cust_dob) return false;
    var d = new Date();
    var mmdd = String(d.getMonth() + 1).padStart(2, '0') + '-' + String(d.getDate()).padStart(2, '0');
    return c.cust_dob.slice(5) === mmdd;
  }
  // Ambil template dari pengaturan (fallback teks default kalau kosong),
  // ganti {nama}, lalu ISI OTOMATIS kotak balas WA -- TIDAK langsung
  // kirim, admin yang review & kirim manual (sesuai jendela 24 jam WA).
  // v1.2.39 fase8: template diambil dari contactWaConfig (hasil action
  // get_birthday_config), BUKAN get_settings -- get_settings dibatasi
  // super_admin/admin sehingga wa_agent dulu gagal tanpa penjelasan.
  function sendBirthdayGreeting(num, custName) {
    var tmpl = (contactWaConfig && contactWaConfig.birthday_greeting) || '';
    if (!tmpl.trim()) {
      tmpl = 'Selamat ulang tahun, {nama}! \uD83C\uDF89 Semoga sehat selalu dan sukses terus. Terima kasih sudah menjadi pelanggan setia kami.';
    }
    var teks = tmpl.split('{nama}').join(custName || '');
    showTab('wachat');
    setTimeout(function () {
      try {
        selectWaConv(num);
        setTimeout(function () {
          var input = $('#waReplyInput');
          if (input) { input.value = teks; input.focus(); }
        }, 700);
      } catch (e) {}
    }, 300);
  }
  // v1.2.39 fase8: status WA Bot + template ucapan (diisi loadKontak)
  var contactWaConfig = { wa_enabled: false, birthday_greeting: '' };
  var contactData = [];
  var contactFilter = 'all';
  var contactOpenState = {};
  function loadKontak() {
    // v1.2.39 fase8: status WhatsApp Bot + template ucapan. Semua elemen
    // fitur ulang tahun bergantung pada ini.
    api('get_birthday_config').then(function (r) {
      if (r && r.ok) {
        contactWaConfig.wa_enabled = !!r.wa_enabled && (r.provider === 'fonnte' || r.provider === 'waha');   // v1.2.39 fase8b, v1.2.76
        contactWaConfig.birthday_greeting = r.birthday_greeting || '';
      }
      var fb = document.querySelector('.contact-filter[data-contact-stage="vip_birthday_today"]');
      if (fb) fb.style.display = contactWaConfig.wa_enabled ? '' : 'none';
      renderContacts();
    });
    fetchContacts();
    $('#btnReloadKontak').onclick = fetchContacts;
    // v1.2.70: ekspor CSV -- data pribadi keluar sistem, WA Agent tidak boleh
    var _bCsv = $('#btnExportKontakCsv');
    if (_bCsv) {
      if (user && user.role === 'wa_agent') _bCsv.style.display = 'none';
      _bCsv.onclick = exportContactsCsv;
    }
    // v1.2.113: import-kontak (Super Admin & Admin)
    var _bImp = $('#btnImportKontak'), _fImp = $('#kontakImportFile');
    if (_bImp && _fImp) {
      if (!user || (user.role !== 'super_admin' && user.role !== 'admin')) _bImp.style.display = 'none';
      _bImp.onclick = function () { _fImp.value = ''; _fImp.click(); };
      _fImp.onchange = function () { contactImpStart(_fImp.files && _fImp.files[0]); };
    }
    var _bAdd = $('#btnAddKontak'); if (_bAdd) _bAdd.onclick = contactAddOpen;   // v1.2.224: kontak-manual
    $$('.contact-filter').forEach(function (b) {
      b.onclick = function () {
        contactFilter = b.dataset.contactStage;
        $$('.contact-filter').forEach(function (x) { x.classList.remove('active'); });
        b.classList.add('active');
        renderContacts();
      };
    });
  }
  /* ---- v1.2.224: kontak-manual -- tambah satu kontak dari menu Kontak ---- */
  function contactAddOpen() {
    var card = $('#kontakAddCard'); if (!card) return;
    if (card.style.display !== 'none') { card.style.display = 'none'; return; }
    var imp = $('#kontakImportCard'); if (imp) imp.style.display = 'none';
    card.innerHTML =
      '<div style="display:flex;justify-content:space-between;align-items:center;gap:8px">' +
        '<h3 style="margin:0">Tambah Kontak</h3>' +
        '<button type="button" class="btn ghost sm" id="caClose" title="Tutup">' + ico('x', 14) + '</button></div>' +
      '<p style="color:var(--muted);font-size:13px;margin:6px 0 10px;line-height:1.5">Nomor otomatis dirapikan ke format WhatsApp (mis. <span class="mono">0812…</span> → <span class="mono">62812…</span>). Saat nomor ini chat nanti, kontaknya langsung menyatu.</p>' +
      '<div class="grid2">' +
        '<div class="row"><label class="fl">Nomor WhatsApp *</label><input type="text" inputmode="tel" id="caNum" placeholder="0812xxxxxxx" autocomplete="off"></div>' +
        '<div class="row"><label class="fl">Nama *</label><input type="text" id="caName" maxlength="100" placeholder="Nama kontak"></div>' +
      '</div>' +
      '<div class="grid2" style="margin-top:8px">' +
        '<div class="row"><label class="fl">Lead Rating</label><select id="caStage">' + contactStageOptionsHtml('new') + '</select></div>' +
        '<div class="row" id="caDobRow" style="display:none"><label class="fl">Tanggal Lahir</label><input type="date" id="caDob"></div>' +
      '</div>' +
      '<label id="caVipRow" style="display:none;gap:6px;align-items:center;font-size:13px;margin-top:8px"><input type="checkbox" id="caVip"> Tandai sebagai VIP</label>' +
      '<div style="display:flex;gap:8px;align-items:center;margin-top:12px;flex-wrap:wrap">' +
        '<button class="btn" id="caSave">Simpan Kontak</button>' +
        '<label style="display:flex;gap:6px;align-items:center;font-size:13px"><input type="checkbox" id="caMore"> Tambah lagi setelah simpan</label>' +
        '<span id="caMsg" style="font-size:13px"></span></div>';
    card.style.display = '';
    var st = $('#caStage');
    function syncStage() {
      var ac = st.value === 'active_customer';
      $('#caVipRow').style.display = ac ? 'flex' : 'none';
      $('#caDobRow').style.display = ac ? '' : 'none';
    }
    st.onchange = syncStage;
    $('#caClose').onclick = function () { card.style.display = 'none'; };
    $('#caNum').focus();
    ['#caNum', '#caName'].forEach(function (s) { $(s).onkeydown = function (e) { if (e.key === 'Enter') { e.preventDefault(); contactAddSave(); } }; });
    $('#caSave').onclick = contactAddSave;
  }
  function contactAddFocus(num) {
    contactOpenState[num] = true;
    if (contactFilter !== 'all') {
      contactFilter = 'all';
      $$('.contact-filter').forEach(function (x) { x.classList.toggle('active', x.dataset.contactStage === 'all'); });
    }
    api('get_contacts').then(function (res) {
      if (res && res.ok) { contactData = res.contacts || []; renderContacts(); }
      var el = document.querySelector('#contactList .card[data-contact="' + num + '"]');
      if (el) { el.scrollIntoView({ behavior: 'smooth', block: 'center' }); el.style.outline = '2px solid var(--accent, #2563eb)'; setTimeout(function () { el.style.outline = ''; }, 2500); }
    });
  }
  function contactAddSave() {
    var btn = $('#caSave'), msg = $('#caMsg');
    var body = { number: $('#caNum').value.trim(), name: $('#caName').value.trim(), stage: $('#caStage').value,
                 vip: $('#caVip').checked, cust_dob: $('#caDob').value };
    if (!body.number) { msg.innerHTML = '<span style="color:#b91c1c">Isi nomor WhatsApp.</span>'; $('#caNum').focus(); return; }
    if (!body.name) { msg.innerHTML = '<span style="color:#b91c1c">Isi nama kontak.</span>'; $('#caName').focus(); return; }
    btn.disabled = true; msg.textContent = 'Menyimpan…';
    api('add_contact', { method: 'POST', body: body }).then(function (r) {
      btn.disabled = false;
      if (r && r.ok) {
        toast('Kontak ' + (r.name || ('+' + r.number)) + ' ditambahkan.');
        if ($('#caMore').checked) {
          $('#caNum').value = ''; $('#caName').value = ''; $('#caDob').value = ''; $('#caVip').checked = false;
          msg.innerHTML = '<span style="color:#065f46">' + esc(r.name) + ' (+' + esc(r.number) + ') tersimpan.</span>';
          $('#caNum').focus(); fetchContacts();
        } else {
          $('#kontakAddCard').style.display = 'none';
          contactAddFocus(r.number);
        }
        return;
      }
      msg.innerHTML = '<span style="color:#b91c1c">' + esc((r && r.error) || 'Gagal menyimpan.') + '</span>' +
        (r && r.exists ? ' <button type="button" class="btn ghost sm" id="caGo">Buka kontak</button>' : '');
      var g = $('#caGo'); if (g) g.onclick = function () { $('#kontakAddCard').style.display = 'none'; contactAddFocus(r.number); };
    }).catch(function (e) { btn.disabled = false; msg.innerHTML = '<span style="color:#b91c1c">' + esc(e.message || String(e)) + '</span>'; });
  }
  /* ---- v1.2.113: import-kontak -- impor kontak dari XLS/XLSX/CSV ---------- */
  var XLSX_VER = '0.18.5';
  var contactImp = null;   // { file, header, rows, col:{num,name,status,refund}, map:{status->stage}, refundLost, overwrite, defStage }
  function _loadXlsx() {
    if (window.XLSX) return Promise.resolve(window.XLSX);
    return new Promise(function (res, rej) {
      var sc = document.createElement('script');
      sc.src = 'https://cdnjs.cloudflare.com/ajax/libs/xlsx/' + XLSX_VER + '/xlsx.full.min.js';
      sc.onload = function () { window.XLSX ? res(window.XLSX) : rej(new Error('XLSX')); };
      sc.onerror = function () { rej(new Error('Gagal memuat pembaca Excel. Periksa koneksi internet.')); };
      document.head.appendChild(sc);
    });
  }
  // Sama dengan contactImportNormNum() di server.
  function contactImpNorm(raw) {
    var d = String(raw == null ? '' : raw).replace(/\D/g, '');
    if (!d) return '';
    if (d.indexOf('00') === 0) d = d.slice(2);
    if (d.indexOf('620') === 0) d = '62' + d.slice(3);
    else if (d.charAt(0) === '0') d = '62' + d.slice(1);
    else if (d.charAt(0) === '8' && d.length >= 9 && d.length <= 13) d = '62' + d;
    if (d.length < 10 || d.length > 15) return '';
    if (d.indexOf('62') === 0 && d.charAt(2) !== '8') return '';
    return d;
  }
  var CONTACT_IMP_RANK = { active_customer: 6, hot_prospect: 5, warm: 4, cold: 3, churned: 2, lost: 1, 'new': 0 };
  function contactImpSuggest(v) {
    v = String(v || '').toLowerCase();
    if (/batal|cancel|gagal|fail|expire|kadaluarsa|ditolak|reject|ditutup|closed|refund|void/.test(v)) return 'lost';
    if (/menunggu|pending|booking|proses|process|\bdp\b|uang muka|belum|waiting|unpaid/.test(v)) return 'hot_prospect';
    if (/selesai|siap|lunas|complete|done|deliver|terkirim|diterima|sukses|success|paid|dibayar|aktif|active/.test(v)) return 'active_customer';
    return 'new';
  }
  function _impPickCol(header, good, bad) {
    for (var g = 0; g < good.length; g++) {
      for (var i = 0; i < header.length; i++) {
        var h = String(header[i] || '').toLowerCase().trim();
        if (h && good[g].test(h) && !(bad && bad.test(h))) return i;
      }
    }
    return -1;
  }
  function contactImpStart(file) {
    if (!file) return;
    if (file.size > 15 * 1024 * 1024) { toast('File terlalu besar (maks 15 MB).', true); return; }
    var card = $('#kontakImportCard');
    card.style.display = '';
    card.innerHTML = '<div style="color:var(--muted)">Membaca ' + esc(file.name) + '…</div>';
    _loadXlsx().then(function (X) {
      return file.arrayBuffer().then(function (buf) {
        var wb = X.read(new Uint8Array(buf), { type: 'array', raw: false });
        var ws = wb.Sheets[wb.SheetNames[0]];
        var aoa = X.utils.sheet_to_json(ws, { header: 1, raw: true, defval: '' });
        var hi = 0;   // baris header = baris pertama yang punya >= 2 sel terisi
        for (; hi < Math.min(aoa.length, 20); hi++) {
          if (aoa[hi].filter(function (x) { return String(x).trim() !== ''; }).length >= 2) break;
        }
        var header = (aoa[hi] || []).map(function (h) { return String(h).trim(); });
        var rows = aoa.slice(hi + 1).filter(function (r) { return r.some(function (x) { return String(x).trim() !== ''; }); });
        if (!header.length || !rows.length) throw new Error('File kosong atau tidak punya baris data.');
        var col = {
          num: _impPickCol(header, [/^(nomor|no\.?)\s*(wa|whatsapp|hp|handphone|telepon|telp)/, /whatsapp|\bwa\b|\bhp\b|handphone|ponsel|telepon|telp|phone|mobile/], /pesanan|order|transaksi|kontrak|pembayaran|dealer|\bid\b/),
          name: _impPickCol(header, [/nama (penerima|pelanggan|customer|konsumen|pembeli|lengkap)/, /^nama$|^name$|customer name|full ?name/, /nama|name/], /benefit|voucher|toko|store|promotor|sales|dealer|produk|barang|product|item|file/),
          status: _impPickCol(header, [/status (pesanan|order|transaksi|pelanggan|customer)/, /status/], /refund|pengembalian|pembayaran|payment/),
          refund: _impPickCol(header, [/status refund|refund|pengembalian dana/])
        };
        if (col.num < 0) {   // tebak: kolom dengan nomor valid terbanyak
          var best = -1, bestN = 0;
          header.forEach(function (_, i) {
            var n = 0; rows.slice(0, 200).forEach(function (r) { if (contactImpNorm(r[i])) n++; });
            if (n > bestN) { bestN = n; best = i; }
          });
          col.num = best;
        }
        contactImp = { file: file.name, header: header, rows: rows, col: col, map: {}, refundLost: col.refund > -1, overwrite: false, defStage: 'new' };
        contactImpRender();
      });
    }).catch(function (e) {
      card.innerHTML = '<div style="color:#b91c1c">Gagal membaca file: ' + esc(e && e.message ? e.message : String(e)) + '</div>';
    });
  }
  function contactImpCompute() {
    var s = contactImp, out = {}, invalid = 0, skipped = 0;
    s.rows.forEach(function (r) {
      var num = contactImpNorm(s.col.num > -1 ? r[s.col.num] : '');
      if (!num) { invalid++; return; }
      var st = s.col.status > -1 ? String(r[s.col.status] || '').trim() : '';
      var stage = s.col.status > -1 ? (s.map[st] != null ? s.map[st] : contactImpSuggest(st)) : s.defStage;
      if (stage === 'skip') { skipped++; return; }
      if (s.refundLost && s.col.refund > -1 && String(r[s.col.refund] || '').trim() !== '') stage = 'lost';
      var nm = s.col.name > -1 ? String(r[s.col.name] || '').trim() : '';
      var o = out[num];
      if (!o) { out[num] = { n: num, name: nm, stage: stage, st: st, cnt: 1 }; return; }
      o.cnt++;
      if (!o.name && nm) o.name = nm;
      if ((CONTACT_IMP_RANK[stage] || 0) > (CONTACT_IMP_RANK[o.stage] || 0)) { o.stage = stage; o.st = st; }
    });
    var list = Object.keys(out).map(function (k) { return out[k]; });
    var by = {}; list.forEach(function (o) { by[o.stage] = (by[o.stage] || 0) + 1; });
    return { list: list, invalid: invalid, skipped: skipped, by: by };
  }
  function _impStageOpts(sel, withSkip) {
    var h = withSkip ? '<option value="skip"' + (sel === 'skip' ? ' selected' : '') + '>Lewati (tidak diimpor)</option>' : '';
    return h + ['new', 'cold', 'warm', 'hot_prospect', 'lost', 'active_customer', 'churned'].map(function (k) {
      return '<option value="' + k + '"' + (sel === k ? ' selected' : '') + '>' + CONTACT_STAGE[k].label + '</option>';
    }).join('');
  }
  function contactImpRender() {
    var s = contactImp, card = $('#kontakImportCard');
    function colSel(key, optional) {
      return '<select data-impcol="' + key + '">' + (optional ? '<option value="-1">— tidak dipakai —</option>' : '') +
        s.header.map(function (h, i) { return '<option value="' + i + '"' + (s.col[key] === i ? ' selected' : '') + '>' + esc(h || ('Kolom ' + (i + 1))) + '</option>'; }).join('') + '</select>';
    }
    var stCount = {};
    if (s.col.status > -1) s.rows.forEach(function (r) { var v = String(r[s.col.status] || '').trim(); stCount[v] = (stCount[v] || 0) + 1; });
    var stKeys = Object.keys(stCount).sort(function (a, b) { return stCount[b] - stCount[a]; });
    var mapHtml = s.col.status > -1
      ? '<div style="overflow-x:auto"><table class="tbl" style="margin-top:6px"><thead><tr><th>Nilai status di file</th><th style="text-align:right">Baris</th><th>Jadi Lead Rating</th></tr></thead><tbody>' +
        stKeys.map(function (v) {
          var cur = s.map[v] != null ? s.map[v] : contactImpSuggest(v);
          return '<tr><td>' + (v ? esc(v) : '<em style="color:var(--muted)">(kosong)</em>') + '</td><td style="text-align:right">' + stCount[v] +
            '</td><td><select data-impmap="' + esc(v) + '">' + _impStageOpts(cur, true) + '</select></td></tr>';
        }).join('') + '</tbody></table></div>'
      : '<div class="row" style="margin-top:6px"><label class="fl">Lead Rating semua kontak</label><select id="impDefStage">' + _impStageOpts(s.defStage, false) + '</select></div>';
    var c = contactImpCompute();
    var sum = Object.keys(c.by).sort(function (a, b) { return (CONTACT_IMP_RANK[b] || 0) - (CONTACT_IMP_RANK[a] || 0); })
      .map(function (k) { return contactStageBadgeHtml(k, false, '') + ' <strong>' + c.by[k] + '</strong>'; }).join(' &nbsp; ');
    var contoh = c.list.slice(0, 5).map(function (o) {
      return '<tr><td class="mono">+' + esc(o.n) + '</td><td>' + esc(o.name) + '</td><td>' + esc(o.st) + (o.cnt > 1 ? ' <span style="color:var(--muted)">(' + o.cnt + ' baris)</span>' : '') + '</td><td>' + contactStageBadgeHtml(o.stage, false, '') + '</td></tr>';
    }).join('');
    card.innerHTML =
      '<div style="display:flex;justify-content:space-between;align-items:center;gap:8px;flex-wrap:wrap">' +
        '<h3 style="margin:0">Impor Kontak — ' + esc(s.file) + '</h3>' +
        '<button class="btn ghost sm" id="impClose">Tutup</button></div>' +
      '<p style="color:var(--muted);font-size:13px;margin:6px 0 10px;line-height:1.5">' + s.rows.length + ' baris dibaca. Nomor otomatis dirapikan ke format WhatsApp (mis. <span class="mono">+62 0812…</span> → <span class="mono">62812…</span>), jadi saat nomor itu chat nanti, kontaknya langsung menyatu. Nomor yang muncul di beberapa baris digabung dan memakai Lead Rating tertinggi.</p>' +
      '<div class="grid2">' +
        '<div class="row"><label class="fl">Kolom nomor WA</label>' + colSel('num', false) + '</div>' +
        '<div class="row"><label class="fl">Kolom nama</label>' + colSel('name', true) + '</div>' +
        '<div class="row"><label class="fl">Kolom status</label>' + colSel('status', true) + '</div>' +
        '<div class="row"><label class="fl">Kolom refund/batal</label>' + colSel('refund', true) + '</div>' +
      '</div>' +
      (s.col.refund > -1 ? '<label style="display:flex;gap:6px;align-items:flex-start;font-size:13px;margin-top:8px"><input type="checkbox" id="impRefund"' + (s.refundLost ? ' checked' : '') + ' style="margin-top:3px"> <span>Baris yang kolom <strong>' + esc(s.header[s.col.refund]) + '</strong>-nya terisi dijadikan Unqualified</span></label>' : '') +
      mapHtml +
      '<div style="margin-top:12px;padding:10px;border-radius:8px;background:var(--bg)">' +
        '<div style="margin-bottom:6px"><strong>' + c.list.length + '</strong> nomor unik akan diimpor' +
          (c.invalid ? ' · <span style="color:#b45309">' + c.invalid + ' baris nomor tidak valid dilewati</span>' : '') +
          (c.skipped ? ' · ' + c.skipped + ' baris dilewati sesuai pemetaan' : '') + '</div>' +
        '<div style="display:flex;flex-wrap:wrap;gap:6px;align-items:center">' + (sum || '—') + '</div>' +
        (contoh ? '<div style="overflow-x:auto"><table class="tbl" style="margin-top:8px;font-size:12px"><thead><tr><th>Nomor</th><th>Nama</th><th>Status asli</th><th>Lead Rating</th></tr></thead><tbody>' + contoh + '</tbody></table></div>' : '') +
      '</div>' +
      '<label style="display:flex;gap:6px;align-items:flex-start;font-size:13px;margin-top:10px"><input type="checkbox" id="impOverwrite"' + (s.overwrite ? ' checked' : '') + ' style="margin-top:3px"> <span>Timpa Lead Rating kontak yang sudah diatur. Bila tidak dicentang, kontak yang sudah ada hanya diubah kalau masih Unrated. Nama yang sudah ada tidak pernah ditimpa.</span></label>' +
      '<div style="display:flex;gap:8px;align-items:center;margin-top:12px;flex-wrap:wrap">' +
        '<button class="btn" id="impGo"' + (c.list.length ? '' : ' disabled') + '>Impor ' + c.list.length + ' kontak</button>' +
        '<span id="impProg" style="color:var(--muted);font-size:13px"></span></div>';

    $('#impClose').onclick = function () { contactImp = null; card.style.display = 'none'; card.innerHTML = ''; };
    $$('#kontakImportCard [data-impcol]').forEach(function (el) {
      el.onchange = function () { s.col[el.dataset.impcol] = parseInt(el.value, 10); if (el.dataset.impcol === 'refund') s.refundLost = s.col.refund > -1; contactImpRender(); };
    });
    $$('#kontakImportCard [data-impmap]').forEach(function (el) {
      el.onchange = function () { s.map[el.dataset.impmap] = el.value; contactImpRender(); };
    });
    var r = $('#impRefund'); if (r) r.onchange = function () { s.refundLost = r.checked; contactImpRender(); };
    var d = $('#impDefStage'); if (d) d.onchange = function () { s.defStage = d.value; contactImpRender(); };
    $('#impOverwrite').onchange = function () { s.overwrite = this.checked; };
    $('#impGo').onclick = function () { contactImpSend(c.list); };
  }
  function contactImpSend(list) {
    var s = contactImp, btn = $('#impGo'), prog = $('#impProg');
    if (!list.length) return;
    if (!confirm('Impor ' + list.length + ' kontak ke menu Kontak?')) return;
    btn.disabled = true;
    var CH = 500, i = 0, tot = { created: 0, updated: 0, kept: 0, invalid: 0 };
    function next() {
      if (i >= list.length) {
        prog.innerHTML = '<span style="color:#065f46">Selesai: ' + tot.created + ' kontak baru, ' + tot.updated + ' diperbarui' +
          (tot.kept ? ', ' + tot.kept + ' Lead Rating lama dipertahankan' : '') + (tot.invalid ? ', ' + tot.invalid + ' tidak valid' : '') + '.</span>';
        toast(list.length + ' kontak diimpor.');
        fetchContacts();
        return;
      }
      var part = list.slice(i, i + CH);
      prog.textContent = 'Mengimpor ' + Math.min(i + CH, list.length) + ' / ' + list.length + '…';
      api('import_contacts', { method: 'POST', body: { rows: part, overwrite: s.overwrite, file: s.file } }).then(function (res) {
        if (!res || !res.ok) throw new Error((res && res.error) || 'Gagal mengimpor.');
        tot.created += res.created || 0; tot.updated += res.updated || 0; tot.kept += res.kept || 0; tot.invalid += res.invalid || 0;
        i += CH; next();
      }).catch(function (e) {
        btn.disabled = false;
        prog.innerHTML = '<span style="color:#b91c1c">' + esc(e.message || String(e)) + ' (' + i + ' kontak pertama sudah tersimpan; impor ulang aman)</span>';
      });
    }
    next();
  }
  function fetchContacts() {
    api('get_contacts').then(function (res) {
      if (res && res.ok) { contactData = res.contacts || []; renderContacts(); }
    });
  }
  function contactFilteredList() {
    return contactData.filter(function (c) {
      // v1.2.39 fase5: filter khusus -- VIP yang tanggal lahirnya (bulan+hari)
      // sama dengan hari ini (tanggal perangkat yang membuka dashboard).
      if (contactFilter === 'vip_birthday_today') {
        if (!c.vip || !c.cust_dob) return false;
        var _d = new Date();
        var _mmdd = String(_d.getMonth() + 1).padStart(2, '0') + '-' + String(_d.getDate()).padStart(2, '0');
        return c.cust_dob.slice(5) === _mmdd;   // cust_dob format YYYY-MM-DD
      }
      return contactFilter === 'all' || (c.stage || 'new') === contactFilter;
    });
  }
  /* ---- v1.2.70: ekspor CSV & simpan satu kontak ke HP (.vcf) ---------- */
  function _contactDl(content, filename, mime) {
    var blob = new Blob([content], { type: mime });
    var url = URL.createObjectURL(blob);
    var a = document.createElement('a');
    a.href = url; a.download = filename;
    document.body.appendChild(a); a.click(); document.body.removeChild(a);
    setTimeout(function () { URL.revokeObjectURL(url); }, 1500);
  }
  function _contactDisplayName(c) {
    return (c.stage === 'active_customer' && c.cust_name) ? c.cust_name : (c.name || c.cust_name || '');
  }
  function exportContactsCsv() {
    var list = contactFilteredList();
    if (!list.length) { toast('Tidak ada kontak untuk diekspor.', true); return; }
    function cell(v) {
      v = String(v == null ? '' : v);
      if (/^[=\-@]/.test(v)) v = "'" + v;            // cegah formula injection di Excel
      return '"' + v.replace(/"/g, '""') + '"';
    }
    var head = ['Nama', 'Nomor WhatsApp', 'Nama Profil WA', 'Nama Koreksi', 'Lead Rating', 'VIP', 'Nama Pelanggan', 'Tanggal Lahir', 'Pertama Dilihat', 'Terakhir Aktif'];
    var rows = list.map(function (c) {
      var st = CONTACT_STAGE[c.stage || 'new'] || CONTACT_STAGE.new;
      return [
        _contactDisplayName(c), '+' + c.number, c.name_wa || '', c.name_manual || '',
        st.label, c.vip ? 'Ya' : '', c.cust_name || '', c.cust_dob || '',
        (c.first_seen || '').slice(0, 16), (c.last_seen || '').slice(0, 16)
      ].map(cell).join(',');
    });
    var d = new Date();
    var stamp = d.getFullYear() + String(d.getMonth() + 1).padStart(2, '0') + String(d.getDate()).padStart(2, '0');
    var suffix = contactFilter === 'all' ? '' : '-' + contactFilter;
    try {
      // BOM supaya Excel membaca UTF-8 (nama dengan emoji/aksen) dengan benar
      _contactDl('\uFEFF' + [head.map(cell).join(',')].concat(rows).join('\r\n'), 'kontak' + suffix + '-' + stamp + '.csv', 'text/csv;charset=utf-8');
      toast(list.length + ' kontak diekspor ke CSV.');
    } catch (e) { toast('Gagal membuat file CSV.', true); }
  }
  // Satu kontak -> file .vcf. Di HP, membuka file ini langsung menawarkan
  // "Tambah ke Kontak" (Android: app Kontak, iPhone: kartu kontak Safari).
  function saveContactToPhone(c) {
    var nama = _contactDisplayName(c) || ('+' + c.number);
    function v(str) {
      return String(str).replace(/\\/g, '\\\\').replace(/;/g, '\\;').replace(/,/g, '\\,').replace(/[\r\n]+/g, ' ');
    }
    var vcf = 'BEGIN:VCARD\r\nVERSION:3.0\r\n' +
      'FN:' + v(nama) + '\r\n' +
      'N:' + v(nama) + ';;;;\r\n' +
      'TEL;TYPE=CELL:+' + c.number + '\r\n' +
      (c.cust_dob ? 'BDAY:' + c.cust_dob + '\r\n' : '') +
      'NOTE:' + v('Kontak WhatsApp chatbot - ' + ((CONTACT_STAGE[c.stage || 'new'] || CONTACT_STAGE.new).label)) + '\r\n' +
      'END:VCARD\r\n';
    var fname = (nama.replace(/[^\w\- ]+/g, '').trim().replace(/\s+/g, '-') || c.number) + '.vcf';
    try {
      _contactDl(vcf, fname, 'text/vcard;charset=utf-8');
      toast('Kontak ' + nama + ' diunduh. Buka file .vcf di HP untuk menyimpan.');
    } catch (e) { toast('Gagal membuat file kontak.', true); }
  }
  /* v1.2.114: kontak-jumlah -- angka total per Lead Rating di tombol filter */
  function contactUpdateCounts() {
    var n = { all: contactData.length, vip_birthday_today: 0 };
    var _d = new Date();
    var _mmdd = String(_d.getMonth() + 1).padStart(2, '0') + '-' + String(_d.getDate()).padStart(2, '0');
    contactData.forEach(function (c) {
      var st = c.stage || 'new';
      n[st] = (n[st] || 0) + 1;
      if (c.vip && c.cust_dob && c.cust_dob.slice(5) === _mmdd) n.vip_birthday_today++;
    });
    $$('.contact-filter').forEach(function (b) {
      var sp = b.querySelector('.cf-n');
      if (!sp) {
        sp = document.createElement('span');
        sp.className = 'cf-n';
        sp.style.cssText = 'margin-left:6px;padding:0 6px;border-radius:999px;background:rgba(0,0,0,.07);font-size:11px;font-weight:700;line-height:18px;display:inline-block';
        b.appendChild(sp);
      }
      sp.textContent = (n[b.dataset.contactStage] || 0).toLocaleString('id-ID');
    });
  }
  function renderContacts() {
    contactUpdateCounts();   // v1.2.114
    var list = contactFilteredList();
    if (!list.length) {
      $('#contactList').innerHTML = '<div class="card" style="text-align:center;color:var(--muted)">' +
        (contactData.length ? 'Tidak ada kontak pada filter ini.' : 'Belum ada kontak.') +
        '</div>';
      return;
    }
    $('#contactList').innerHTML = list.map(function (c) {
      var judul = c.name ? esc(c.name) : ('+' + esc(c.number));
      var opsi = contactStageOptionsHtml(c.stage || 'new');
      var terbuka = !!contactOpenState[c.number];
      var putar = terbuka ? 'transform:rotate(180deg);' : '';
      return '<div class="card" data-contact="' + esc(c.number) + '">' +
        '<div class="contact-head" style="display:flex;justify-content:space-between;align-items:center;gap:10px;flex-wrap:wrap;cursor:pointer;user-select:none">' +
          '<div style="display:flex;align-items:center;gap:8px">' +
            '<span class="contact-chev" style="display:inline-flex;color:var(--muted);transition:transform .15s;' + putar + '">' +
              ico('chevron-down', 16) + '</span>' +
            '<div><strong style="font-size:15px">' + judul + '</strong>' +
              (c.name ? ' <span style="color:var(--muted);font-size:12px">+' + esc(c.number) + '</span>' : '') +
              '<div style="color:var(--muted);font-size:12px">' + (c.last_seen ? 'Terakhir aktif ' + esc(c.last_seen.slice(0, 16)) : 'Belum pernah chat') +
                (c.imp ? ' · <span title="' + esc('Diimpor ' + (c.imp.at || '') + (c.imp.src ? ' dari ' + c.imp.src : '')) + '">diimpor</span>' : '') +   // v1.2.113
                (c.man ? ' · <span title="' + esc('Ditambah manual ' + (c.man.at || '').slice(0, 16) + (c.man.by ? ' oleh ' + c.man.by : '')) + '">ditambah manual</span>' : '') + '</div>' +   // v1.2.224: kontak-manual
            '</div>' +
          '</div>' +
          '<div style="display:flex;align-items:center;gap:8px">' +
            contactStageBadgeHtml(c.stage, c.vip, '') +
            '<button type="button" class="btn ghost sm contact-save-phone" title="Simpan nomor ini ke kontak HP (.vcf)" style="display:inline-flex;align-items:center;gap:4px">' + ico('user-plus', 14) + ' Simpan ke HP</button>' +
          '</div>' +
        '</div>' +
        '<div class="contact-body" style="margin-top:12px;' + (terbuka ? '' : 'display:none') + '">' +
        '<div class="row" style="margin-top:8px"><label class="fl">Lead Rating</label>' +
          '<select class="contact-stage-select">' + opsi + '</select></div>' +
        '<div class="row contact-vip-row" style="align-items:center;gap:8px;display:' + ((c.stage || 'new') === 'active_customer' ? 'flex' : 'none') + '">' +
          '<label class="fl">VIP</label><input type="checkbox" class="contact-vip-check" style="margin-left:4px"' + (c.vip ? ' checked' : '') + '></div>' +
        // v1.2.39 fase4: data pelanggan, cuma tampil saat Active Customer
        '<div class="contact-customer-fields" style="display:' + ((c.stage || 'new') === 'active_customer' ? 'block' : 'none') + '">' +
          '<div class="row" style="margin-top:8px"><label class="fl">Nama</label>' +
            '<input type="text" class="contact-cust-name" placeholder="Nama pelanggan" value="' + esc(c.cust_name || '') + '"></div>' +
          (contactWaConfig.wa_enabled
            ? '<div class="row" style="margin-top:8px"><label class="fl">Tanggal Lahir</label>' +
                '<input type="date" class="contact-cust-dob" value="' + esc(c.cust_dob || '') + '"></div>'
            : '') +
        '</div>' +
        '<div class="grid2" style="margin-top:8px">' +
          leadField('Pertama dilihat', (c.first_seen || '').slice(0, 16)) +
          leadField('Terakhir aktif', (c.last_seen || '').slice(0, 16)) +
        '</div>' +
        (c.imp ? '<div class="grid2" style="margin-top:8px">' + leadField('Diimpor', (c.imp.at || '').slice(0, 16) + (c.imp.src ? ' · ' + c.imp.src : '')) +
          leadField('Status di file', (c.imp.st || '-') + (c.imp.n > 1 ? ' (' + c.imp.n + ' baris)' : '')) + '</div>' : '') +   // v1.2.113
        '<div style="display:flex;gap:8px;flex-wrap:wrap;margin-top:8px">' +
          '<button class="btn ghost sm contact-open-thread">Lihat percakapan</button>' +
          ((contactWaConfig.wa_enabled && contactBirthdayToday(c)) ? '<button class="btn sm contact-birthday-btn" style="background:#fef3c7;color:#92400e;border:1px solid #fbbf24">' + ico('cake', 14) + ' Kirim Ucapan</button>' : '') +
        '</div>' +
        '</div>' +
      '</div>';
    }).join('');

    $$('#contactList .card[data-contact]').forEach(function (card) {
      var num = card.dataset.contact;
      var kepala = card.querySelector('.contact-head');
      var badan  = card.querySelector('.contact-body');
      var chev   = card.querySelector('.contact-chev');
      kepala.onclick = function () {
        var buka = badan.style.display === 'none';
        badan.style.display = buka ? '' : 'none';
        chev.style.transform = buka ? 'rotate(180deg)' : '';
        contactOpenState[num] = buka;
      };
      var sel    = card.querySelector('.contact-stage-select');
      var vipRow = card.querySelector('.contact-vip-row');
      var vipChk = card.querySelector('.contact-vip-check');
      function _syncLocal(stage, vip) {
        var idx = -1;
        for (var i = 0; i < contactData.length; i++) { if (contactData[i].number === num) { idx = i; break; } }
        if (idx > -1) { contactData[idx].stage = stage; contactData[idx].vip = vip; }
      }
      if (sel) {
        sel.onclick = function (ev) { ev.stopPropagation(); };
        sel.onchange = function (ev) {
          ev.stopPropagation();
          var stage = this.value;
          var vip = (stage === 'active_customer') ? (vipChk ? vipChk.checked : false) : false;
          _syncLocal(stage, vip);
          saveContactStage(num, stage, vip);
          renderContacts();   // optimistic: badge & filter langsung ikut berubah
        };
      }
      if (vipChk) {
        vipChk.onclick = function (ev) { ev.stopPropagation(); };
        vipChk.onchange = function (ev) {
          var stage = sel ? sel.value : 'active_customer';
          _syncLocal(stage, this.checked);
          saveContactStage(num, stage, this.checked);
          renderContacts();
        };
      }
      // v1.2.39 fase4: field Nama (simpan saat kursor pindah) & Tanggal
      // Lahir (simpan saat dipilih) -- sama pola dengan catatan di Leads.
      var custNameInput = card.querySelector('.contact-cust-name');
      var custDobInput  = card.querySelector('.contact-cust-dob');
      if (custNameInput) {
        custNameInput.onclick = function (ev) { ev.stopPropagation(); };
        custNameInput.onblur = function (e) {
          var lama = (contactData.filter(function (x) { return x.number === num; })[0] || {}).cust_name || '';
          if (e.target.value === lama) return;
          saveContactInfo(num, { cust_name: e.target.value });
        };
      }
      if (custDobInput) {
        custDobInput.onclick = function (ev) { ev.stopPropagation(); };
        custDobInput.onchange = function (e) {
          saveContactInfo(num, { cust_dob: e.target.value });
        };
      }
      var btnSave = card.querySelector('.contact-save-phone');
      if (btnSave) {
        btnSave.onclick = function (ev) {
          ev.stopPropagation();
          var cd = contactData.filter(function (x) { return x.number === num; })[0];
          if (cd) saveContactToPhone(cd);
        };
      }
      var btnOpen = card.querySelector('.contact-open-thread');
      if (btnOpen) {
        btnOpen.onclick = function (ev) {
          ev.stopPropagation();
          showTab('wachat');
          setTimeout(function () { try { selectWaConv(num); } catch (e) {} }, 700);
        };
      }
      // v1.2.39 fase6: tombol Kirim Ucapan (kalau tampil di kartu ini)
      var btnBday = card.querySelector('.contact-birthday-btn');
      if (btnBday) {
        btnBday.onclick = function (ev) {
          ev.stopPropagation();
          var cd = contactData.filter(function (x) { return x.number === num; })[0] || {};
          sendBirthdayGreeting(num, cd.cust_name || cd.name || '');
        };
      }
    });
  }
  /* ====================================================================== *
   *  v1.2.56: RESPON & ESKALASI
   * ====================================================================== */
  var escContacts = { l1: [], l2: [] };
  function escRenderList(lv) {
    var box = $('#esc_' + lv + '_list');
    if (!box) return;
    box.innerHTML = '';
    if (!escContacts[lv].length) box.innerHTML = '<div class="help">Belum ada kontak.</div>';
    escContacts[lv].forEach(function (c, i) {
      var row = document.createElement('div');
      row.style.cssText = 'display:grid;grid-template-columns:1.1fr 1fr 1fr 1fr auto;gap:6px;margin-bottom:6px';
      row.innerHTML =
        '<input placeholder="Nama" data-f="name" value="' + esc(c.name || '') + '">' +
        '<input placeholder="No. WA 0812…" data-f="wa" value="' + esc(c.wa || '') + '">' +
        '<input placeholder="Pushover user key" class="mono" data-f="pushover" value="' + esc(c.pushover || '') + '">' +
        '<input placeholder="Topik ntfy" class="mono" data-f="ntfy" value="' + esc(c.ntfy || '') + '">' +
        '<button class="btn ghost" type="button" title="Hapus">&times;</button>';
      row.querySelectorAll('input').forEach(function (inp) {
        inp.oninput = function () { escContacts[lv][i][inp.dataset.f] = inp.value; };
      });
      row.querySelector('button').onclick = function () { escContacts[lv].splice(i, 1); escRenderList(lv); };
      box.appendChild(row);
    });
  }
  function escFmtDur(sec) {
    if (sec == null) return '–';
    if (sec < 60) return sec + ' dtk';
    var m = Math.floor(sec / 60), d = sec % 60;
    return m + ' mnt' + (d ? ' ' + d + ' dtk' : '');
  }
  function escFmtTs(ts) {
    if (!ts) return '–';
    var d = new Date(ts * 1000);
    return d.toLocaleString('id-ID', { timeZone: 'Asia/Jakarta', day: '2-digit', month: 'short', hour: '2-digit', minute: '2-digit' });
  }
  /* v1.2.96: jeda-balasan — pola jeda balasan AI per jumlah karakter */
  var rdRules = [];
  function rdRender() {
    var box = $('#rd_rules');
    if (!box) return;
    box.innerHTML = '';
    if (!rdRules.length) box.innerHTML = '<div class="help">Belum ada pola — semua balasan memakai jeda "lebih panjang".</div>';
    var prev = 0;
    rdRules.forEach(function (r, i) {
      var row = document.createElement('div');
      row.style.cssText = 'display:flex;align-items:center;gap:6px;margin-bottom:6px;flex-wrap:wrap';
      row.innerHTML =
        '<span class="rd-from" style="min-width:52px">' + (prev + 1) + ' –</span>' +
        '<input type="number" min="1" data-f="max" style="width:90px" value="' + (r.max || '') + '"> karakter →' +
        '<input type="number" min="0" max="20" data-f="sec" style="width:70px" value="' + (r.sec == null ? '' : r.sec) + '"> detik' +
        '<button class="btn ghost" type="button" title="Hapus">&times;</button>';
      row.querySelectorAll('input').forEach(function (inp) {
        inp.oninput = function () { rdRules[i][inp.dataset.f] = inp.value === '' ? '' : +inp.value; };
        inp.onchange = function () { rdRules.sort(function (a, b) { return (+a.max || 0) - (+b.max || 0); }); rdRender(); };
      });
      row.querySelector('button').onclick = function () { rdRules.splice(i, 1); rdRender(); };
      box.appendChild(row);
      prev = +r.max || prev;
    });
  }
  function rdLoad(rd) {
    rd = rd || {};
    $('#rd_enabled').checked = rd.enabled === true;
    $('#rd_typing').checked = rd.typing === true;   // v1.2.96: mengetik
    $('#rd_basis').value = rd.basis === 'question' ? 'question' : 'answer';
    $('#rd_over').value = (rd.over_sec === undefined || rd.over_sec === null) ? 8 : rd.over_sec;
    rdRules = (rd.rules && rd.rules.length ? rd.rules : [{ max: 50, sec: 3 }, { max: 200, sec: 5 }])
      .map(function (r) { return { max: r.max, sec: r.sec }; });
    rdRender();
    $('#rd_add').onclick = function () {
      var last = rdRules.length ? (+rdRules[rdRules.length - 1].max || 0) : 0;
      rdRules.push({ max: last ? last * 2 : 50, sec: '' }); rdRender();
    };
  }
  function rdCollect() {
    var seen = {}, rules = [];
    for (var i = 0; i < rdRules.length; i++) {
      var mx = Math.round(+rdRules[i].max || 0), sc = Math.round(+rdRules[i].sec || 0);
      if (mx < 1) continue;
      if (seen[mx]) return { error: 'Batas karakter ' + mx + ' dipakai dua kali.' };
      seen[mx] = 1;
      rules.push({ max: mx, sec: Math.max(0, Math.min(20, sc)) });
    }
    rules.sort(function (a, b) { return a.max - b.max; });
    return { enabled: $('#rd_enabled').checked, typing: $('#rd_typing').checked, basis: $('#rd_basis').value, rules: rules,
      over_sec: Math.max(0, Math.min(20, Math.round(+$('#rd_over').value || 0))) };
  }
  function loadEskalasi() {
    api('get_settings').then(function (res) {
      if (!res.ok) return;
      var ac = res.settings.auto_closing || {}, ec = res.settings.escalation || {};
      var hm = res.settings.wa_hemat || {};   // v1.2.89
      $('#hm_debounce').value = (hm.debounce_sec === undefined || hm.debounce_sec === null) ? 3 : hm.debounce_sec;
      $('#hm_skip_ack').checked = hm.skip_ack !== false;
      $('#hm_prompt').checked = hm.prompt !== false;
      rdLoad(res.settings.reply_delay);   // v1.2.96: jeda-balasan
      if ($('#as_enabled')) {   // v1.2.204: jam-ai
        var as_ = res.settings.ai_schedule || {}, asH = String(as_.hours || '21:00-09:00').split('-');
        $('#as_enabled').checked = as_.enabled === true;
        $('#as_start').value = asH[0] || '21:00'; $('#as_end').value = asH[1] || '09:00';
        $$('#as_days input').forEach(function (c) { c.checked = (as_.full_days || []).indexOf(+c.value) >= 0; });
        var asNow = function () {
          var el = $('#as_now'); if (!el) return;
          if (!$('#as_enabled').checked) { el.textContent = 'Jadwal mati — AI membalas 24 jam (mengikuti Mode Balasan).'; return; }
          var w = new Date(Date.now() + 7 * 3600e3), m = w.getUTCHours() * 60 + w.getUTCMinutes(), d = w.getUTCDay();
          var p = function (v) { v = String(v || '').split(':'); return (+v[0] || 0) * 60 + (+v[1] || 0); };
          var a = p($('#as_start').value), b = p($('#as_end').value);
          var full = $$('#as_days input').some(function (c) { return c.checked && +c.value === d; });
          var on = full || a === b || (a < b ? (m >= a && m < b) : (m >= a || m < b));
          var hh = ('0' + w.getUTCHours()).slice(-2) + ':' + ('0' + w.getUTCMinutes()).slice(-2);
          el.innerHTML = 'Sekarang ' + hh + ' WIB: <b>' + (on ? 'AI yang membalas' : 'agent yang membalas (AI diam)') + '</b>' + (a === b ? ' — jam mulai &amp; sampai sama, AI aktif 24 jam.' : '.');
        };
        ['#as_enabled', '#as_start', '#as_end'].forEach(function (q) { $(q).onchange = asNow; });
        $$('#as_days input').forEach(function (c) { c.onchange = asNow; });
        asNow();
      }
      var al = res.settings.ai_limit || {};   // v1.2.97: batas-ai
      $('#al_max').value = al.max || 0;
      $('#al_text').value = al.text || '';
      var hf = res.settings.handover_fallback || {};   // v1.2.126: respon-median
      if ($('#hf_enabled')) { $('#hf_enabled').checked = hf.enabled === true; $('#hf_minutes').value = hf.minutes || 15; $('#hf_text').value = hf.text || ''; }
      var hb = res.settings.handback || {};   // v1.2.137: kembali-bot
      if ($('#hb_claim_enabled')) { $('#hb_claim_enabled').checked = hb.claim_enabled !== false; $('#hb_claim_minutes').value = hb.claim_minutes || 30; $('#hb_idle_enabled').checked = hb.idle_enabled !== false; $('#hb_idle_minutes').value = hb.idle_minutes || 60; }
      $('#ac_enabled').checked = ac.enabled === true;
      $('#ac_minutes').value = ac.minutes || 10;
      $('#ac_phone').value = ac.phone || '';
      $('#ac_text_id').value = ac.text_id || '';
      $('#ac_text_id').placeholder = 'Apakah ada lagi yang bisa kami bantu? Jika ada, silakan sampaikan di sini, atau hubungi Call Center kami di {telepon} untuk respon lebih cepat. Terima kasih 🙏';
      $('#ac_text_en').value = ac.text_en || '';
      $('#ac_text_en').placeholder = 'Is there anything else we can help you with? Feel free to reply here, or call our Call Center at {telepon} for a faster response. Thank you 🙏';
      $('#ac_hours').value = ac.hours || '';
      $('#esc_enabled').checked = ec.enabled === true;
      $('#esc_l1_minutes').value = ec.l1_minutes || 5;
      $('#esc_l2_minutes').value = ec.l2_minutes || 10;
      $('#esc_hours').value = ec.hours || '';
      $('#esc_po_token').value = '';
      $('#esc_po_token').placeholder = ec.pushover_token_is_set ? '•••• (terisi — kosongkan untuk tidak mengubah)' : 'dari pushover.net › Create Application';
      $('#esc_ntfy_server').value = ec.ntfy_server || '';
      $('#esc_wa_tpl').value = ec.wa_template || '';
      $('#esc_wa_tpl_lang').value = ec.wa_template_lang || '';
      escContacts.l1 = (ec.l1_contacts || []).map(function (c) { return Object.assign({}, c); });
      escContacts.l2 = (ec.l2_contacts || []).map(function (c) { return Object.assign({}, c); });
      escRenderList('l1'); escRenderList('l2');
    });
    loadEscIncidents();
    $$('[data-esc-add]').forEach(function (b) {
      b.onclick = function () { escContacts[b.dataset.escAdd].push({ name: '', wa: '', pushover: '', ntfy: '' }); escRenderList(b.dataset.escAdd); };
    });
    $('#btnSaveEsc').onclick = saveEskalasi;
    $('#btnEscTest1').onclick = function () { escTest(1); };
    $('#btnEscTest2').onclick = function () { escTest(2); };
  }
  function escCleanList(list) {
    return list.map(function (c) {
      return { name: (c.name || '').trim(), wa: (c.wa || '').trim(), pushover: (c.pushover || '').trim(), ntfy: (c.ntfy || '').trim() };
    }).filter(function (c) { return c.wa || c.pushover || c.ntfy; });
  }
  function saveEskalasi() {
    var l1m = +$('#esc_l1_minutes').value || 5, l2m = +$('#esc_l2_minutes').value || 10;
    if (l2m <= l1m) { toast('Menit Level 2 harus lebih besar dari Level 1.', true); return; }
    var esc_ = {
      enabled: $('#esc_enabled').checked,
      l1_minutes: l1m, l2_minutes: l2m,
      hours: $('#esc_hours').value.trim(),
      ntfy_server: $('#esc_ntfy_server').value.trim(),
      wa_template: $('#esc_wa_tpl').value.trim(),
      wa_template_lang: $('#esc_wa_tpl_lang').value.trim(),
      l1_contacts: escCleanList(escContacts.l1),
      l2_contacts: escCleanList(escContacts.l2)
    };
    var po = $('#esc_po_token').value.trim();
    if (po && po.indexOf('•') === -1) esc_.pushover_app_token = po;
    if (esc_.enabled && !esc_.l1_contacts.length && !esc_.l2_contacts.length) { toast('Isi minimal satu kontak eskalasi.', true); return; }
    var rd_ = rdCollect();   // v1.2.96: jeda-balasan
    if (rd_.error) { toast(rd_.error, true); return; }
    var body = { settings: {
      auto_closing: {
        enabled: $('#ac_enabled').checked,
        minutes: Math.max(1, +$('#ac_minutes').value || 10),
        phone: $('#ac_phone').value.trim(),
        text_id: $('#ac_text_id').value.trim(),
        text_en: $('#ac_text_en').value.trim(),
        hours: $('#ac_hours').value.trim()
      },
      escalation: esc_,
      reply_delay: rd_,   // v1.2.96: jeda-balasan
      ai_limit: { max: Math.max(0, Math.min(50, Math.round(+$('#al_max').value || 0))), text: $('#al_text').value.trim() },   // v1.2.97: batas-ai
      ai_schedule: $('#as_enabled') ? { enabled: $('#as_enabled').checked, hours: ($('#as_start').value || '21:00') + '-' + ($('#as_end').value || '09:00'), full_days: $$('#as_days input').filter(function (c) { return c.checked; }).map(function (c) { return +c.value; }) } : undefined,   // v1.2.204: jam-ai
      handover_fallback: $('#hf_enabled') ? { enabled: $('#hf_enabled').checked, minutes: Math.max(5, Math.min(240, Math.round(+$('#hf_minutes').value || 15))), text: $('#hf_text').value.trim() } : undefined,   // v1.2.126: respon-median
      handback: $('#hb_claim_enabled') ? { claim_enabled: $('#hb_claim_enabled').checked, claim_minutes: Math.max(5, Math.min(1440, Math.round(+$('#hb_claim_minutes').value || 30))), idle_enabled: $('#hb_idle_enabled').checked, idle_minutes: Math.max(15, Math.min(1440, Math.round(+$('#hb_idle_minutes').value || 60))) } : undefined,   // v1.2.137: kembali-bot
      wa_hemat: {   // v1.2.89
        debounce_sec: Math.max(0, Math.min(8, Math.round(+$('#hm_debounce').value || 0))),
        skip_ack: $('#hm_skip_ack').checked,
        prompt: $('#hm_prompt').checked
      }
    } };
    api('save_settings', { method: 'POST', body: body }).then(function (res) {
      if (res.ok) { toast('Pengaturan Respon & Eskalasi tersimpan.'); loadEskalasi(); }
      else toast(res.error || 'Gagal menyimpan.', true);
    });
  }
  function escTest(level) {
    var out = $('#escTestResult');
    out.textContent = 'Mengirim tes Level ' + level + '… (simpan dulu bila baru mengubah kontak)';
    api('esc_test', { method: 'POST', body: { level: level } }).then(function (res) {
      if (!res.ok) { out.textContent = res.error || 'Gagal.'; return; }
      out.innerHTML = (res.results || []).map(function (r) {
        if (r.suppressed) return esc(r.name) + ': ditahan (rate limit)';
        var parts = [];
        ['wa', 'pushover', 'ntfy'].forEach(function (k) {
          if (r[k]) parts.push(k + ' ' + (r[k].ok ? '✅' : '❌ ' + esc(r[k].error || '')));
        });
        return '<b>' + esc(r.name) + '</b>: ' + (parts.join(' · ') || 'tidak ada saluran');
      }).join('<br>');
    });
  }
  function loadEscIncidents() {
    api('esc_incidents').then(function (res) {
      if (!res.ok) return;
      var c = res.cron;
      var st = $('#escCronStatus');
      if (!c) {
        st.innerHTML = '❌ Belum pernah ada tick. Pastikan Server Pusat memanggil <code>cron_tick</code> tiap menit (atau pasang cron cPanel: <code>php api/index.php action=cron_tick</code>).';
      } else {
        var age = Math.floor(Date.now() / 1000) - c.at;
        st.innerHTML = (age < 180 ? '✅ Aktif' : '⚠️ Tick terakhir ' + escFmtDur(age) + ' lalu') + ' · terakhir ' + esc(c.at_wib) + ' via ' + esc(c.via) + ' · ' + c.ms + ' ms';
      }
      var s = res.summary || {};
      $('#escSummary').textContent = 'Total insiden (90 hari): ' + (s.total || 0) +
        ' · rata-rata waktu respons: ' + escFmtDur(s.avg_response_sec) +
        ' · selesai sebelum Level 2: ' + (s.handled_before_l2 || 0);
      var reason = { claimed_unanswered: 'Di-claim, belum dibalas', human_unanswered: 'Handoff, belum dibalas', bot_failed: 'Bot gagal' };
      var tb = $('#tblEsc');
      var rows = res.incidents || [];
      tb.innerHTML = rows.length ? rows.map(function (i) {
        var by = i.ack_by ? ('✋ ' + esc(i.ack_by)) : (i.resolved_by ? ('↩️ ' + esc(i.resolved_by)) : '<span style="color:#c0392b">belum</span>');
        return '<tr><td>' + escFmtTs(i.opened_at) + '</td><td>+' + esc(i.contact) + (i.contact_name ? '<br><span class="help">' + esc(i.contact_name) + '</span>' : '') +
          '</td><td>' + esc(reason[i.reason] || i.reason) + '</td><td>L' + (i.level || 0) + '</td><td>' + by +
          '</td><td style="text-align:right">' + escFmtDur(i.response_sec) + '</td></tr>';
      }).join('') : '<tr><td colspan="6" class="help">Belum ada insiden.</td></tr>';
    });
  }

  /* ====================================================================== *
   *  PEMBARUAN (v1.2.65) — catatan rilis + notifikasi rilis baru (admin)
   * ====================================================================== */
  var REL_TYPE = { fitur: 'Fitur baru', peningkatan: 'Peningkatan', perbaikan: 'Perbaikan' };
  var REL_BULAN = ['Januari', 'Februari', 'Maret', 'April', 'Mei', 'Juni', 'Juli', 'Agustus', 'September', 'Oktober', 'November', 'Desember'];
  var relState = { data: null, filter: 'all' };
  function relCanSee() { return role === 'super_admin' || role === 'admin'; }
  function relVerCmp(a, b) {
    var x = String(a || '').replace(/^v/, '').split('.'), y = String(b || '').replace(/^v/, '').split('.');
    for (var i = 0; i < 3; i++) { var d = (+x[i] || 0) - (+y[i] || 0); if (d) return d > 0 ? 1 : -1; }
    return 0;
  }
  function relDate(s) {
    var m = /^(\d{4})-(\d{2})-(\d{2})/.exec(s || '');
    return m ? (+m[3]) + ' ' + REL_BULAN[+m[2] - 1].slice(0, 3) + ' ' + m[1] : '';
  }
  function relMonth(s) {
    var m = /^(\d{4})-(\d{2})/.exec(s || '');
    return m ? REL_BULAN[+m[2] - 1] + ' ' + m[1] : 'Tanpa tanggal';
  }
  function relSetBadge(n) {
    var b = document.querySelector('#nav [data-tab="pembaruan"]');
    if (!b) return;
    var el = b.querySelector('.wa-sidebar-badge');
    if (n > 0) {
      if (!el) { el = document.createElement('span'); el.className = 'wa-sidebar-badge'; b.appendChild(el); }
      el.textContent = n > 9 ? '9+' : String(n);
      el.title = n + ' pembaruan belum dilihat';
    } else if (el) el.remove();
  }
  function relDismissKey() { return 'dei_rel_dismiss_' + (user.username || ''); }
  function relRenderBanner(d) {
    var el = document.getElementById('releaseBanner');
    if (!el) return;
    var dismissed = '';
    try { dismissed = sessionStorage.getItem(relDismissKey()) || ''; } catch (e) {}
    var r = (d && d.releases && d.releases[0]) || null;
    if (!d || !(d.unread > 0) || !r || dismissed === d.latest || $('#panel-pembaruan').classList.contains('active')) { el.style.display = 'none'; return; }
    el.innerHTML = '<div class="rb"><span class="rb-ic">' + ico('sparkles', 18) + '</span>' +
      '<div class="rb-tx"><b>Pembaruan baru ' + esc(r.version) + '</b>' + (r.title ? ' — ' + esc(r.title) : '') +
      (d.unread > 1 ? ' <span style="color:var(--muted)">(+' + (d.unread - 1) + ' lainnya)</span>' : '') + '</div>' +
      '<button class="btn sm" type="button" id="rbOpen">Lihat apa yang baru</button>' +
      '<button class="rb-x" type="button" id="rbClose" title="Tutup">' + ico('x', 16) + '</button></div>';
    el.style.display = 'block';
    $('#rbOpen').onclick = function () { showTab('pembaruan'); };
    $('#rbClose').onclick = function () {
      try { sessionStorage.setItem(relDismissKey(), d.latest); } catch (e) {}
      el.style.display = 'none';
    };
  }
  function relCheck() {
    if (!relCanSee()) return;
    api('release_notes', { query: '&summary=1' }).then(function (res) {
      if (!res || !res.ok) return;
      relSetBadge(res.unread || 0);
      relRenderBanner(res);
      if (res.unread > 0) loaded.pembaruan = false;   // buka tab lagi -> muat ulang daftar
    }).catch(function () {});
  }
  function renderPembaruan() {
    var d = relState.data || {};
    var rel = d.releases || [];
    var inst = d.installed_version || '';
    $('#relInstalled').textContent = inst || '–';
    // v1.2.74: perbaikan khusus Super Admin — rilis terbaru yang terlihat bisa lebih rendah dari versi terpasang
    $('#relLatest').textContent = (d.latest && inst && relVerCmp(inst, d.latest) > 0) ? inst : (d.latest || '–');
    var st = $('#relStatus'), go = $('#relGoUpdate');
    var behind = d.latest && inst && relVerCmp(d.latest, inst) > 0;
    st.style.display = d.latest ? '' : 'none';
    st.className = 'rel-status' + (behind ? ' up' : '');
    st.innerHTML = behind ? ico('clock-3', 14) + ' Pembaruan tersedia' : ico('check-circle-2', 14) + ' Sudah versi terbaru';
    go.style.display = (behind && role === 'super_admin') ? '' : 'none';
    var note = [];
    if (behind && role !== 'super_admin') note.push('Versi baru tersedia. Minta Super Admin memasangnya dari menu Widget &amp; API.');
    if (d.stale && d.error) note.push(ico('triangle-alert', 13, 'style="vertical-align:-2px"') + ' ' + esc(d.error) + (rel.length ? ' Menampilkan data tersimpan.' : ''));
    if (d.fetched_at_wib) note.push('Diperbarui ' + esc(d.fetched_at_wib) + ' WIB');
    $('#relNote').innerHTML = note.join(' · ');
    var seen = d.seen || '';
    var list = rel.filter(function (r) { return relState.filter === 'all' || r.type === relState.filter; });
    if (!list.length) {
      $('#relList').innerHTML = '<div class="rel-empty">' + (rel.length ? 'Tidak ada rilis untuk filter ini.' : 'Belum ada catatan rilis.') + '</div>';
      return;
    }
    var html = '', month = null;
    list.forEach(function (r, i) {
      var mo = relMonth(r.released_at);
      if (mo !== month) { html += '<div class="rel-month">' + esc(mo) + '</div>'; month = mo; }
      var isNew = seen ? relVerCmp(r.version, seen) > 0 : (r.version === d.latest);
      var pending = inst && relVerCmp(r.version, inst) > 0;
      var hl = (r.highlights || []).length ? '<ul>' + r.highlights.map(function (h) { return '<li>' + esc(h) + '</li>'; }).join('') + '</ul>' : '';
      html += '<div class="rel-item' + (isNew ? ' new' : '') + '"><span class="rel-dot"></span><div class="rel-card">' +
        '<div class="rel-meta"><span class="rel-ver">' + esc(r.version) + '</span>' +
        '<span class="rel-type ' + esc(r.type) + '">' + esc(REL_TYPE[r.type] || r.type) + '</span>' +
        (isNew ? '<span class="rel-new">Baru</span>' : '') +
        (pending ? '<span class="rel-pend">Belum terpasang</span>' : '') +
        '<span>' + esc(relDate(r.released_at)) + '</span></div>' +
        (r.title ? '<h3>' + esc(r.title) + '</h3>' : '') +
        '<p>' + esc(r.changelog) + '</p>' + hl + '</div></div>';
    });
    $('#relList').innerHTML = html;
  }
  function loadPembaruan(force) {
    if (!relCanSee()) return;
    if (!relState.wired) {
      relState.wired = true;
      if (role !== 'super_admin') $$('#relFilters [data-f="perbaikan"]').forEach(function (b) { b.style.display = 'none'; });
      $$('#relFilters button').forEach(function (b) {
        b.onclick = function () {
          relState.filter = b.dataset.f;
          $$('#relFilters button').forEach(function (x) { x.classList.toggle('on', x === b); });
          renderPembaruan();
        };
      });
      $('#relRefresh').onclick = function () { loadPembaruan(true); };
      $('#relGoUpdate').onclick = function () { showTab('widget'); };
    }
    if (!relState.data) $('#relList').innerHTML = '<div class="rel-empty">Memuat catatan rilis…</div>';
    var btn = $('#relRefresh'); btn.disabled = true;
    api('release_notes', { query: force ? '&refresh=1' : '' }).then(function (res) {
      btn.disabled = false;
      if (!res || !res.ok) { $('#relList').innerHTML = '<div class="rel-empty">' + esc((res && res.error) || 'Gagal memuat catatan rilis.') + '</div>'; return; }
      relState.data = res;
      renderPembaruan();
      if (force) toast(res.stale ? 'Pusat tidak terjangkau — menampilkan data tersimpan.' : 'Catatan rilis diperbarui.', !!res.stale);
      if (res.latest && res.unread > 0) {
        api('release_seen', { method: 'POST', body: { version: res.latest } }).then(function () {
          relSetBadge(0);
          var bn = document.getElementById('releaseBanner'); if (bn) bn.style.display = 'none';
        });
      }
    }).catch(function () { btn.disabled = false; });
  }

  /* ====================================================================== *
   *  v1.2.138: filter-topik — filter & label topik/divisi Percakapan WA (klasifikasi AI) + menu Topik & Divisi
   * ====================================================================== */
  var TF_COLORS = [['#dbeafe', '#1e40af'], ['#dcfce7', '#166534'], ['#fef3c7', '#92400e'], ['#fce7f3', '#9d174d'], ['#ede9fe', '#5b21b6'],
                   ['#cffafe', '#155e75'], ['#ffedd5', '#9a3412'], ['#e0e7ff', '#3730a3'], ['#f1f5f9', '#334155'], ['#fee2e2', '#991b1b'],
                   ['#ecfccb', '#3f6212'], ['#f5f5f4', '#44403c']];
  var TF = { conf: null, presets: [], d: null, dirty: false };
  function tfOn() { return !!(waState.tp && waState.tp.on); }
  function tfTopic(id) { var l = (waState.tp && waState.tp.topics) || []; for (var i = 0; i < l.length; i++) if (l[i].id === id) return l[i]; return null; }
  function tfDiv(id) { var l = (waState.tp && waState.tp.divisions) || []; for (var i = 0; i < l.length; i++) if (l[i].id === id) return l[i]; return null; }
  function tfDivColor(id) {
    var l = (waState.tp && waState.tp.divisions) || [];
    for (var i = 0; i < l.length; i++) if (l[i].id === id) return TF_COLORS[i % TF_COLORS.length];
    return TF_COLORS[8];
  }
  function tfChip(id, extra) {
    var t = tfTopic(id); if (!t) return '';
    var c = tfDivColor(t.div);
    return '<span class="tag tf-chip" style="background:' + c[0] + ';color:' + c[1] + (extra || '') + '" title="' + esc((tfDiv(t.div) || {}).name || 'Tanpa divisi') + '">' + esc(t.name) + '</span>';
  }
  function tfQuery() {
    var q = '';
    if (waState.tfF) q += '&tpt=' + encodeURIComponent(waState.tfF);
    if (waState.tfDF) q += '&tpd=' + encodeURIComponent(waState.tfDF);
    if (waState.tfF && waState.tfEver) q += '&tpe=1';
    return q;
  }
  function tfFromList(res) {
    waState.tp = res.tp || null;
    if (!tfOn()) { waState.tfF = ''; waState.tfDF = ''; return; }
    if (res.tp.f !== undefined) waState.tfF = res.tp.f || '';
    if (res.tp.fd !== undefined) waState.tfDF = res.tp.fd || '';
  }
  function tfFilterBarHtml() {
    if (!tfOn()) return '';
    var tp = waState.tp, cn = tp.counts || {}, dc = tp.dcounts || {};
    var n = function (v) { return v != null ? ' (' + Number(v).toLocaleString('id-ID') + ')' : ''; };
    var dOpts = '<option value="">Semua divisi' + n(dc.all) + '</option>' + (tp.divisions || []).map(function (d) {
      return '<option value="' + esc(d.id) + '"' + (waState.tfDF === d.id ? ' selected' : '') + '>' + esc(d.name) + n(dc[d.id] || 0) + '</option>';
    }).join('') + '<option value="__none"' + (waState.tfDF === '__none' ? ' selected' : '') + '>Belum berlabel' + n(dc.__none || 0) + '</option>';
    var tl = (tp.topics || []).filter(function (t) { return !waState.tfDF || waState.tfDF === '__none' || t.div === waState.tfDF; });
    var tOpts = '<option value="">Semua topik' + n(cn.all) + '</option>' + tl.map(function (t) {
      return '<option value="' + esc(t.id) + '"' + (waState.tfF === t.id ? ' selected' : '') + '>' + esc(t.name) + n(cn[t.id] || 0) + '</option>';
    }).join('') + '<option value="__none"' + (waState.tfF === '__none' ? ' selected' : '') + '>Belum berlabel' + n(cn.__none || 0) + '</option>';
    return '<label class="wa-dd' + (waState.tfDF ? ' is-on' : '') + '" title="Saring per divisi">' + ico('briefcase-business', 14) + '<select class="wa-tpd-filter">' + dOpts + '</select><span class="wa-dd-chev">' + ico('chevron-down', 14) + '</span></label>' +
      '<label class="wa-dd' + (waState.tfF ? ' is-on' : '') + '" title="Saring per topik (klasifikasi AI)">' + ico('message-circle', 14) + '<select class="wa-tpt-filter">' + tOpts + '</select><span class="wa-dd-chev">' + ico('chevron-down', 14) + '</span></label>' +
      (waState.tfF && waState.tfF !== '__none' ? '<label class="wa-dd' + (waState.tfEver ? ' is-on' : '') + '" title="Topik saat ini, atau pernah ditanyakan sebelumnya (untuk follow-up)"><select class="wa-tpe-filter"><option value="">Topik saat ini</option><option value="1"' + (waState.tfEver ? ' selected' : '') + '>Pernah ditanyakan</option></select><span class="wa-dd-chev">' + ico('chevron-down', 14) + '</span></label>' : '');
  }
  function tfBindFilterBar() {
    var d = $('#waFilterBar .wa-tpd-filter'), t = $('#waFilterBar .wa-tpt-filter'), e = $('#waFilterBar .wa-tpe-filter');
    if (d) d.onchange = function () { waState.tfDF = this.value; var tt = tfTopic(waState.tfF); if (tt && waState.tfDF && waState.tfDF !== '__none' && tt.div !== waState.tfDF) waState.tfF = ''; fetchWaConvs(); };
    if (t) t.onchange = function () { waState.tfF = this.value; if (!this.value || this.value === '__none') waState.tfEver = false; fetchWaConvs(); };
    if (e) e.onchange = function () { waState.tfEver = this.value === '1'; fetchWaConvs(); };
  }
  function tfEmptySuffix() {
    if (!tfOn()) return '';
    var s = '';
    if (waState.tfDF) s += ' · divisi "' + (waState.tfDF === '__none' ? 'Belum berlabel' : ((tfDiv(waState.tfDF) || {}).name || waState.tfDF)) + '"';
    if (waState.tfF) s += ' · topik "' + (waState.tfF === '__none' ? 'Belum berlabel' : ((tfTopic(waState.tfF) || {}).name || waState.tfF)) + '"' + (waState.tfEver ? ' (pernah ditanyakan)' : '');
    return s;
  }
  /* ---- v1.2.203: sales-tag — tag Sales per chat, PO, Close Deal, laporan per Sales ---- */
  function slYmd203(d) { var p = function (n) { return String(n).padStart(2, '0'); }; d = d || new Date(); return d.getFullYear() + '-' + p(d.getMonth() + 1) + '-' + p(d.getDate()); }
  function slThreadTools203(res) {
    var S = res && res.sales; if (!S || res.group) return '';
    var cur = S.cur ? S.cur.id : '', list = S.list || [];
    var lock208 = !!(S.cur && S.lead && S.lead !== 'baru');   // v1.2.208: sales-untag: lead sudah naik status -> hanya bisa ganti sales
    var opts = '<option value=""' + (lock208 ? ' disabled' : '') + '>' + (lock208 ? 'Sales: — (lead sudah ' + esc((LEAD_STATUS[S.lead] || {}).label || S.lead) + ', pilih sales lain)' : (list.length ? 'Sales: —' : 'Sales: belum ada (atur di Tim & Agent)')) + '</option>' + list.map(function (o) {
      return '<option value="' + esc(o.id) + '"' + (o.id === cur ? ' selected' : '') + '>Sales: ' + esc(o.name) + '</option>';
    }).join('');
    if (S.cur && !list.some(function (o) { return o.id === cur; })) opts += '<option value="' + esc(cur) + '" selected>Sales: ' + esc(S.cur.name) + ' (nonaktif)</option>';
    return '<span class="wa-assign" title="Sales yang menangani chat ini' + (S.cur && S.cur.by ? ' (dipilih ' + esc(S.cur.by) + ')' : '') + '">' + ico('briefcase-business', 13) + '<select id="slTagSel">' + opts + '</select></span>' +
      ' <a href="#" id="slPoBtn" style="font-size:12px" title="Catat PO & jadikan lead Close Deal">' + ico('file-text', 13) + ' PO' + (S.po_n ? ' (' + S.po_n + ')' : '') + (S.lead === 'closed_deal' ? ' · Close Deal' : '') + '</a>';
  }
  function slBindThread203(num, res) {
    var sel = $('#slTagSel');
    if (sel) sel.onchange = function () {
      var v = this.value; sel.disabled = true;
      api('sales_tag', { method: 'POST', body: { number: num, sales: v } }).then(function (r) {
        sel.disabled = false;
        if (r && r.ok) { toast(v ? (r.lead_created ? 'Sales dipilih. Lead baru dibuat.' : 'Sales dipilih.') : (r.lead_removed ? 'Tag sales dihapus. Lead berstatus Baru ikut dihapus.' : 'Tag sales dihapus.')); loaded.leads = false; if (r.lead_created || r.lead_removed) fetchWaConvs(); }   // v1.2.206: sales-lead; v1.2.208: sales-untag
        else toast((r && r.error) || 'Gagal menyimpan sales.', true);
        if (String(waState.current) === String(num)) fetchWaThread(num, true);
      });
    };
    var b = $('#slPoBtn');
    if (b) b.onclick = function (ev) { ev.preventDefault(); slPoModal203(num); };
  }
  function slPoModal203(num) {
    var old = $('#slPoModal'); if (old) old.remove();
    var m = document.createElement('div'); m.id = 'slPoModal'; m.className = 'tf-modal';
    m.innerHTML = '<div class="tf-modal-box"><div style="color:var(--muted)">Memuat…</div></div>';
    document.body.appendChild(m);
    var box = m.querySelector('.tf-modal-box');
    var close = function () { m.remove(); };
    m.onclick = function (e) { if (e.target === m) close(); };
    var refresh = function () { if (String(waState.current) === String(num)) fetchWaThread(num, true); };
    var draw = function () {
      api('sales_po_list', { query: '&number=' + encodeURIComponent(num) }).then(function (r) {
        if (!document.body.contains(m)) return;
        if (!r || !r.ok) { box.innerHTML = '<div style="color:#b91c1c">' + esc((r && r.error) || 'Gagal memuat.') + '</div>'; return; }
        var info = r.info || {}, cur = info.cur, items = r.items || [], leadSt = info.lead || '', ls = LEAD_STATUS[leadSt];
        var rows = items.length ? items.map(function (p) {
          return '<tr><td style="white-space:nowrap">' + esc(p.date) + '</td><td>' + esc(p.no || '—') + (p.note ? '<div style="color:var(--muted);font-size:12px">' + esc(p.note) + '</div>' : '') + '</td>' +
            '<td>' + esc(p.sales_name) + '</td><td style="color:var(--muted);font-size:12px">' + esc(p.by) + '</td>' +
            (r.can_delete ? '<td><button type="button" class="btn ghost sm" data-podel="' + esc(p.id) + '" title="Hapus PO">' + ico('trash-2', 13) + '</button></td>' : '') + '</tr>';
        }).join('') : '<tr><td colspan="5" style="color:var(--muted)">Belum ada PO untuk chat ini.</td></tr>';
        box.innerHTML =
          '<div style="display:flex;justify-content:space-between;align-items:center;gap:8px"><b>PO &amp; Close Deal</b><button type="button" class="btn ghost sm" id="slPoClose">' + ico('x', 14) + '</button></div>' +
          '<p style="font-size:13px;margin:6px 0 10px">Sales: ' + (cur ? '<b>' + esc(cur.name) + '</b>' : '<span style="color:#b91c1c">belum dipilih — pilih Sales di kepala chat dulu</span>') +
            ' · Lead: ' + (ls ? '<span class="tag" style="background:' + ls.bg + ';color:' + ls.fg + '">' + esc(ls.label) + '</span>' : '<span style="color:var(--muted)">belum ada</span>') + '</p>' +
          (cur ? '<div class="grid2"><div class="row"><label class="fl">Tanggal PO</label><input type="date" id="slPoDate" value="' + slYmd203() + '"></div>' +
              '<div class="row"><label class="fl">No. PO (opsional)</label><input type="text" id="slPoNo" maxlength="60"></div></div>' +
            '<div class="row"><label class="fl">Catatan (opsional)</label><input type="text" id="slPoNote" maxlength="300" placeholder="mis. 2 unit, DP masuk"></div>' +
            '<div style="display:flex;gap:8px;flex-wrap:wrap;justify-content:flex-end">' +
              (leadSt === 'closed_deal' ? '<span class="tag" style="background:#d1fae5;color:#065f46;align-self:center">' + ico('check-circle-2', 12) + ' Lead sudah Close Deal</span>'
                : '<button type="button" class="btn ghost sm" id="slPoDeal">' + ico('check-circle-2', 14) + ' Jadikan Lead Close Deal</button>') +
              '<button type="button" class="btn sm" id="slPoAdd">' + ico('save', 14) + ' Simpan PO</button></div>' : '') +
          '<div class="scroll" style="margin-top:12px;max-height:40vh"><table class="tbl"><thead><tr><th>Tanggal</th><th>No. PO</th><th>Sales</th><th>Oleh</th>' + (r.can_delete ? '<th></th>' : '') + '</tr></thead><tbody>' + rows + '</tbody></table></div>';
        $('#slPoClose').onclick = close;
        if ($('#slPoAdd')) $('#slPoAdd').onclick = function () {
          var btn = this; btn.disabled = true;
          api('sales_po_add', { method: 'POST', body: { number: num, date: $('#slPoDate').value, no: $('#slPoNo').value, note: $('#slPoNote').value } }).then(function (x) {
            btn.disabled = false;
            if (x && x.ok) { toast('PO tersimpan.'); draw(); refresh(); } else toast((x && x.error) || 'Gagal menyimpan PO.', true);
          });
        };
        if ($('#slPoDeal')) $('#slPoDeal').onclick = function () {
          if (!confirm('Jadikan lead chat ini Close Deal atas nama sales ' + cur.name + '?')) return;
          var btn = this; btn.disabled = true;
          api('sales_deal', { method: 'POST', body: { number: num } }).then(function (x) {
            btn.disabled = false;
            if (x && x.ok) { toast('Lead ditandai Close Deal.'); loaded.leads = false; draw(); refresh(); fetchWaConvs(); } else toast((x && x.error) || 'Gagal.', true);
          });
        };
        $$('#slPoModal [data-podel]').forEach(function (d) {
          d.onclick = function () {
            if (!confirm('Hapus PO ini?')) return;
            api('sales_po_del', { method: 'POST', body: { id: d.dataset.podel } }).then(function (x) {
              if (x && x.ok) { toast('PO dihapus.'); draw(); refresh(); } else toast((x && x.error) || 'Gagal menghapus.', true);
            });
          };
        });
      });
    };
    draw();
  }
  // Tim & Agent: daftar Sales + laporan per Sales (Supervisor ke atas)
  function slTimLoad203() {
    if (!$('#slCard') || role === 'wa_agent') return;
    if (!$('#slrFrom').value) { var d = new Date(); $('#slrFrom').value = slYmd203(new Date(d.getFullYear(), d.getMonth(), 1)); $('#slrTo').value = slYmd203(d); }
    $('#btnSlrLoad').onclick = slReport203;
    $('#btnSlrCsv').onclick = slReportCsv203;
    $('#btnSlAdd').onclick = function () { slSave203({ name: $('#slName').value, phone: $('#slPhone').value, div: ($('#slDiv') || {}).value || '' }, function () { $('#slName').value = ''; $('#slPhone').value = ''; }); };   // v1.2.219: divisi-sales
    slList203(false);   // v1.2.205: laporan-pindah: laporan pindah ke Laporan & Log
  }
  function slSave203(body, ok) {
    api('sales_save', { method: 'POST', body: body }).then(function (r) {
      if (r && r.ok) { toast('Sales tersimpan.'); if (ok) ok(); slList203(false); }
      else toast((r && r.error) || 'Gagal menyimpan sales.', true);
    });
  }
  function slList203(withReport) {
    api('sales_list').then(function (r) {
      var lk = !!(r && r.locked);
      $('#slLocked').style.display = lk ? '' : 'none';
      $('#slLocked').innerHTML = lk ? ico('octagon-alert', 13) + ' ' + esc(r.locked_msg || '') : '';
      $('#slBody').style.display = lk ? 'none' : '';
      $('#slrCard').style.display = lk ? 'none' : '';
      if ($('#slrLocked')) { $('#slrLocked').style.display = lk ? '' : 'none'; $('#slrLocked').innerHTML = lk ? ico('octagon-alert', 13) + ' ' + esc(r.locked_msg || '') : ''; }   // v1.2.205: laporan-pindah
      if (!r || !r.ok || lk) return;
      var it = r.items || [];
      $('#tblSl').innerHTML = it.length ? it.map(function (s) {
        return '<tr data-sl="' + esc(s.id) + '"><td><input type="text" class="sl-nm" value="' + esc(s.name) + '" maxlength="60" style="min-width:140px"></td>' +
          '<td><input type="text" class="sl-ph" value="' + esc(s.phone) + '" maxlength="20" placeholder="opsional" style="min-width:110px"></td>' +
          '<td><input type="text" class="sl-div" value="' + esc(s.div || '') + '" maxlength="40" list="slDivList" placeholder="mis. Corporate" style="min-width:120px"></td>' +   // v1.2.219: divisi-sales
          '<td><label class="switch" title="Sales nonaktif tidak muncul di pilihan chat"><input type="checkbox" class="sl-on"' + (s.active ? ' checked' : '') + '><span class="sl"></span></label></td>' +
          '<td style="white-space:nowrap"><button type="button" class="btn ghost sm sl-save" title="Simpan">' + ico('save', 13) + '</button> <button type="button" class="btn ghost sm sl-del" title="Hapus">' + ico('trash-2', 13) + '</button></td></tr>';
      }).join('') : '<tr><td colspan="5" style="color:var(--muted)">Belum ada sales. Tambahkan di bawah.</td></tr>';
      var dl219 = document.getElementById('slDivList'), dv219 = {};   // v1.2.219: divisi-sales
      it.forEach(function (s) { if (s.div) dv219[s.div] = 1; });
      if (dl219) dl219.innerHTML = Object.keys(dv219).sort().map(function (d) { return '<option value="' + esc(d) + '">'; }).join('');
      $$('#tblSl tr[data-sl]').forEach(function (tr) {
        var id = tr.dataset.sl;
        var sv = function () { slSave203({ id: id, name: tr.querySelector('.sl-nm').value, phone: tr.querySelector('.sl-ph').value, div: tr.querySelector('.sl-div').value, active: tr.querySelector('.sl-on').checked }); };   // v1.2.219: divisi-sales
        tr.querySelector('.sl-div').onkeydown = function (e) { if (e.key === 'Enter') sv(); };
        tr.querySelector('.sl-save').onclick = sv;
        tr.querySelector('.sl-on').onchange = sv;
        tr.querySelector('.sl-del').onclick = function () {
          if (!confirm('Hapus sales ini?\n\nChat & PO yang sudah ditandai tetap tercatat dengan nama "(sales dihapus)". Untuk berhenti memakai sales, cukup matikan Aktif.')) return;
          api('sales_delete', { method: 'POST', body: { id: id } }).then(function (x) { if (x && x.ok) { toast('Sales dihapus.'); slList203(false); } else toast((x && x.error) || 'Gagal.', true); });
        };
      });
      if (withReport) slReport203();
    });
  }
  var slRep203 = null;
  function slReport203() {
    var q = '&from=' + encodeURIComponent($('#slrFrom').value) + '&to=' + encodeURIComponent($('#slrTo').value);
    $('#tblSlr').innerHTML = '<tr><td colspan="6" style="color:var(--muted)">Memuat…</td></tr>';
    api('sales_report', { query: q }).then(function (r) {
      if (!r || !r.ok) { slRep203 = null; $('#slrKpis').innerHTML = ''; $('#tblSlr').innerHTML = '<tr><td colspan="6" style="color:#b91c1c">' + esc((r && r.error) || 'Gagal memuat.') + '</td></tr>'; return; }
      slRep203 = r;
      var t = r.totals || {}, kpi = function (n, l) { return '<div class="tim-kpi"><div class="n">' + n + '</div><div class="l">' + l + '</div></div>'; };
      $('#slrKpis').innerHTML = kpi(t.chats || 0, 'Chat di-tag') + kpi(t.po || 0, 'PO') + kpi(t.deal || 0, 'Close Deal') + kpi(t.conv == null ? '–' : t.conv + '%', 'Konversi (Close Deal ÷ Chat)');
      var rows = r.rows || [];
      if (!rows.length) { $('#tblSlr').innerHTML = '<tr><td colspan="6" style="color:var(--muted)">Belum ada sales / aktivitas di rentang ini.</td></tr>'; return; }
      $('#tblSlr').innerHTML = rows.map(function (s, i) {
        return '<tr class="slr-row" data-i="' + i + '" style="cursor:pointer" title="Klik untuk rincian"><td>' + ico('chevron-down', 13) + ' ' + esc(s.name) + (s.id && !s.active ? ' <span class="tag">nonaktif</span>' : '') + '</td>' +
          '<td style="text-align:right">' + s.chats + '</td><td style="text-align:right">' + s.po + '</td>' +
          '<td style="text-align:right;font-weight:600">' + s.deal + '</td><td style="text-align:right">' + s.lost + '</td>' +
          '<td style="text-align:right">' + (s.conv == null ? '–' : s.conv + '%') + '</td></tr>' +
          '<tr class="slr-det" data-i="' + i + '" style="display:none"><td colspan="6" style="background:var(--brand-soft)">' + slDetail203(s) + '</td></tr>';
      }).join('');
      $$('#tblSlr .slr-row').forEach(function (tr) {
        tr.onclick = function () { var d = $('#tblSlr .slr-det[data-i="' + tr.dataset.i + '"]'); if (d) d.style.display = d.style.display === 'none' ? '' : 'none'; };
      });
      $$('#tblSlr [data-slnum]').forEach(function (a) { a.onclick = function (ev) { ev.preventDefault(); openLeadConv(a.dataset.slnum); }; });
    });
  }
  function slDetail203(s) {
    var it = s.items || [];
    if (!it.length) return '<span style="color:var(--muted);font-size:12px">Tidak ada chat di rentang ini.</span>';
    return '<table class="tbl" style="font-size:12px"><thead><tr><th>Kontak</th><th>Di-tag</th><th style="text-align:right">PO</th><th>Status lead</th></tr></thead><tbody>' +
      it.map(function (x) {
        var ls = LEAD_STATUS[x.status];
        return '<tr><td><a href="#" data-slnum="' + esc(x.number) + '">' + esc(x.name || ('+' + x.number)) + '</a>' + (x.name ? ' <span style="color:var(--muted)">+' + esc(x.number) + '</span>' : '') + '</td>' +
          '<td>' + (x.tagged ? ico('check-circle-2', 12) : '<span style="color:var(--muted)">—</span>') + '</td><td style="text-align:right">' + (x.po || '—') + '</td>' +
          '<td>' + (ls ? '<span class="tag" style="background:' + ls.bg + ';color:' + ls.fg + '">' + esc(ls.label) + '</span>' : '<span style="color:var(--muted)">—</span>') + '</td></tr>';
      }).join('') + '</tbody></table>' +
      (s.items_total > it.length ? '<div class="help">Menampilkan ' + it.length + ' dari ' + s.items_total + ' chat.</div>' : '');
  }
  function slReportCsv203() {
    var r = slRep203; if (!r) { toast('Tampilkan laporan dulu.', true); return; }
    var q = function (v) { v = String(v == null ? '' : v); return /[",\n;]/.test(v) ? '"' + v.replace(/"/g, '""') + '"' : v; };
    var L = [['Sales', 'Chat di-tag', 'PO', 'Close Deal', 'Close Lose', 'Konversi %'].join(',')];
    (r.rows || []).forEach(function (s) { L.push([s.name, s.chats, s.po, s.deal, s.lost, s.conv == null ? '' : s.conv].map(q).join(',')); });
    L.push(''); L.push(['Sales', 'Nomor', 'Nama kontak', 'Di-tag', 'PO', 'Status lead'].join(','));
    (r.rows || []).forEach(function (s) { (s.items || []).forEach(function (x) { L.push([s.name, "'" + x.number, x.name, x.tagged ? 'ya' : '', x.po, (LEAD_STATUS[x.status] || {}).label || ''].map(q).join(',')); }); });
    var a = document.createElement('a');
    a.href = URL.createObjectURL(new Blob(['﻿' + L.join('\n')], { type: 'text/csv;charset=utf-8' }));
    a.download = 'laporan-sales-' + r.from + '_' + r.to + '.csv';
    document.body.appendChild(a); a.click(); setTimeout(function () { URL.revokeObjectURL(a.href); a.remove(); }, 500);
  }
  // Leads: badge + filter per Sales
  var leadAll203 = [], leadSales203 = '';
  function slLeadFilt203(a) {
    if (!leadSales203) return a;
    var want = leadSales203 === '_none' ? '' : leadSales203;
    return a.filter(function (l) { return (l.sales_id || '') === want; });
  }
  function slLeadBadge203(l) { return l.sales_name ? ' <span class="tag" style="background:#e0f2fe;color:#075985" title="Sales">' + ico('briefcase-business', 11) + ' ' + esc(l.sales_name) + '</span>' : ''; }
  function slLeadSel203() {
    var sel = $('#leadSalesFlt'); if (!sel) return;
    var seen = {};
    leadAll203.forEach(function (l) { if (l.sales_id) seen[l.sales_id] = l.sales_name || l.sales_id; });
    var ids = Object.keys(seen).sort(function (a, b) { return String(seen[a]).localeCompare(String(seen[b])); });
    sel.style.display = ids.length ? '' : 'none';
    sel.innerHTML = '<option value="">Semua sales</option>' + ids.map(function (id) { return '<option value="' + esc(id) + '">' + esc(seen[id]) + '</option>'; }).join('') + '<option value="_none">Tanpa sales</option>';
    if (leadSales203 && leadSales203 !== '_none' && !seen[leadSales203]) leadSales203 = '';
    sel.value = leadSales203;
    sel.onchange = function () { leadSales203 = sel.value; leadData = slLeadFilt203(leadAll203); if (leadView === 'perf' && crmPerfS217.data) { crmPipeRender216(); crmPerfPaint217(); return; } renderLeads(); };   // v1.2.217: laporan-crm
  }
  /* ---- v1.2.209: autoreply-hp — auto reply WA Business dari HP ---- */
  function warNote209(m) {
    if (!m || m.dir !== 'manual' || !m.a) return '';
    if (m.src === 'hp_auto') return '<div class="war-note" title="Pesan ini sama dengan teks auto reply di Widget & API, jadi bot tetap aktif">' + ico('bot', 11) + ' Auto reply WhatsApp Business (HP) — bot tetap aktif</div>';
    if (m.src === 'hp' && waState.isAdmin) return '<div class="war-note"><a href="#" class="war-mark" data-ts="' + esc(m.ts) + '" title="Pesan ini otomatis dari aplikasi WhatsApp Business? Tandai supaya pesan yang sama tidak menghentikan bot">Dari HP · tandai sebagai auto reply</a></div>';
    return '';
  }
  document.addEventListener('click', function (e) {
    var a = e.target.closest && e.target.closest('.war-mark'); if (!a) return;
    e.preventDefault();
    var num = waState.current; if (!num) return;
    if (!confirm('Tandai pesan ini sebagai auto reply WhatsApp Business?\n\nPesan dari HP dengan teks yang sama tidak akan lagi menghentikan bot. Chat yang terlanjur pindah ke mode manusia karena pesan ini dikembalikan ke bot.')) return;
    api('wa_autoreply_mark', { method: 'POST', body: { number: num, ts: a.dataset.ts } }).then(function (r) {
      if (r && r.ok) { toast((r.added ? 'Ditambahkan ke daftar auto reply. ' : 'Sudah ada di daftar auto reply. ') + (r.restored ? r.restored + ' chat dikembalikan ke bot.' : '')); fetchWaConvs(); fetchWaThread(num, true); }
      else toast((r && r.error) || 'Gagal menandai.', true);
    });
  });
  function warLoad209() {
    var box = $('#warList'); if (!box) return;
    var draw = function (texts) {
      box.innerHTML = (texts.length ? texts : ['']).map(function (t) {
        return '<div class="war-row" style="display:flex;gap:6px;align-items:flex-start;margin-bottom:6px"><textarea class="war-t" rows="2" maxlength="1500" placeholder="Tempel teks Away message / Greeting message persis seperti di HP" style="flex:1">' + esc(t) + '</textarea>' +
          '<button type="button" class="btn ghost sm war-del" title="Hapus">' + ico('trash-2', 13) + '</button></div>';
      }).join('');
      $$('#warList .war-del').forEach(function (b) { b.onclick = function () { var r = b.closest('.war-row'); if ($$('#warList .war-row').length > 1) r.remove(); else r.querySelector('textarea').value = ''; }; });
    };
    api('wa_autoreply_get').then(function (r) {
      if (!r || !r.ok) return;
      draw(r.texts || []);
      $('#warInfo').textContent = r.updated_at ? 'Terakhir diubah ' + r.updated_at + (r.by ? ' oleh ' + r.by : '') : '';
      $('#btnWarAdd').onclick = function () { if ($$('#warList .war-row').length >= (r.max || 10)) { toast('Maksimal ' + (r.max || 10) + ' teks.', true); return; } var cur = $$('#warList .war-t').map(function (x) { return x.value; }); cur.push(''); draw(cur); };
      $('#btnWarSave').onclick = function () {
        var btn = this; btn.disabled = true;
        var texts = $$('#warList .war-t').map(function (x) { return x.value.trim(); }).filter(Boolean);
        api('wa_autoreply_save', { method: 'POST', body: { texts: texts, restore: $('#war_restore').checked } }).then(function (x) {
          btn.disabled = false;
          if (x && x.ok) { toast('Daftar auto reply tersimpan.' + (x.restored ? ' ' + x.restored + ' chat dikembalikan ke bot.' : '')); warLoad209(); loaded.wachat = false; }
          else toast((x && x.error) || 'Gagal menyimpan.', true);
        });
      };
    });
  }
  function tfBadgeHtml(tp) {
    if (!tfOn() || !tp || !tp.t || !tp.t.length) return '';
    var main = tp.m || tp.t[0];
    var more = tp.t.length - 1;
    return ' ' + tfChip(main) + (more > 0 ? ' <span class="tag" style="background:#f1f5f9;color:#475569" title="' + esc(tp.t.filter(function (x) { return x !== main; }).map(function (x) { return (tfTopic(x) || {}).name || x; }).join(', ')) + '">+' + more + '</span>' : '') +
      (tp.lk ? ' <span title="Label dikoreksi manual (' + esc(tp.by) + ')" style="color:var(--muted)">' + ico('pen-tool', 11) + '</span>' : '');
  }
  function tfThreadRowHtml(res) {
    if (!tfOn()) return '';
    var tp = res.tp;
    // v1.2.166: topik-ringkas-hp — di HP hanya topik utama; sisanya + "Pernah tanya" dilipat di tombol +N
    var _tl = (tp && tp.t) ? tp.t.filter(function (x) { return tfTopic(x); }) : [];
    var _main = _tl.length ? ((tp.m && _tl.indexOf(tp.m) > -1) ? tp.m : _tl[0]) : '';
    var chips = _tl.length ? [_main].concat(_tl.filter(function (x) { return x !== _main; })).map(function (x) { return tfChip(x, x === tp.m ? ';outline:2px solid currentColor;outline-offset:-1px' : '').replace('class="tag tf-chip"', 'class="tag tf-chip' + (x === _main ? ' tf-main' : ' tf-x') + '"'); }).join(' ') : '<span style="color:var(--muted);font-size:12px">Topik belum terdeteksi</span>';
    var past = (tp && tp.h) ? tp.h.filter(function (x) { return (!tp.t || tp.t.indexOf(x) < 0) && tfTopic(x); }) : [];
    var info = tp ? (tp.lk ? 'dikoreksi ' + esc(tp.by) : 'AI') : '';
    var hidN = Math.max(0, _tl.length - 1) + past.length;
    return '<div class="tf-th-row' + (waState.tfXp ? '' : ' tf-collapsed') + '">' + ico('message-circle', 12) + ' ' + chips +
      (hidN ? ' <a href="#" class="tf-xp" id="tfXpBtn" data-n="' + hidN + '" title="Tampilkan semua topik">' + (waState.tfXp ? 'sembunyikan' : '+' + hidN) + '</a>' : '') +
      (info ? ' <span class="tf-info" style="color:var(--muted);font-size:11px">· ' + info + '</span>' : '') +
      ' <a href="#" id="tfEditBtn" style="font-size:12px;text-decoration:none">' + ico('pen-tool', 12) + ' ubah</a>' +
      (past.length ? '<div class="tf-past" style="font-size:11px;color:var(--muted);margin-top:2px">Pernah tanya: ' + past.map(function (x) { return esc(tfTopic(x).name); }).join(', ') + '</div>' : '') +
      '</div>';
  }
  function tfBindThread(num, res) {
    var b = $('#tfEditBtn');
    if (b) b.onclick = function (ev) { ev.preventDefault(); tfEditModal(num, res.tp); };
    var xb = $('#tfXpBtn');   // v1.2.166: topik-ringkas-hp
    if (xb) xb.onclick = function (ev) { ev.preventDefault(); waState.tfXp = !waState.tfXp; var r = xb.closest('.tf-th-row'); if (r) r.classList.toggle('tf-collapsed', !waState.tfXp); xb.textContent = waState.tfXp ? 'sembunyikan' : '+' + xb.getAttribute('data-n'); };
  }
  function tfEditModal(num, tp) {
    var old = $('#tfModal'); if (old) old.remove();
    var sel = (tp && tp.t) ? tp.t.slice() : [], main = (tp && tp.m) || '';
    var conf = waState.tp || {};
    var groups = (conf.divisions || []).concat([{ id: '', name: 'Tanpa divisi' }]).map(function (d) {
      var ts = (conf.topics || []).filter(function (t) { return (t.div || '') === d.id; });
      if (!ts.length) return '';
      return '<div class="tf-m-grp"><div class="tf-m-gh">' + esc(d.name) + '</div>' + ts.map(function (t) {
        var on = sel.indexOf(t.id) > -1;
        return '<div class="tf-m-row"><label><input type="checkbox" data-tpc="' + esc(t.id) + '"' + (on ? ' checked' : '') + '> ' + esc(t.name) + '</label>' +
          '<label class="tf-m-main" title="Topik utama"><input type="radio" name="tfMain" value="' + esc(t.id) + '"' + (main === t.id ? ' checked' : '') + '> utama</label></div>';
      }).join('') + '</div>';
    }).join('');
    var m = document.createElement('div');
    m.id = 'tfModal'; m.className = 'tf-modal';
    m.innerHTML = '<div class="tf-modal-box"><div style="display:flex;justify-content:space-between;align-items:center;gap:8px"><b>Topik percakapan</b><button type="button" class="btn ghost sm" id="tfMClose">' + ico('x', 14) + '</button></div>' +
      '<p style="font-size:12px;color:var(--muted);margin:4px 0 10px">Label yang Anda simpan dikunci — AI tidak akan menimpanya. Pilih "Kembalikan ke AI" untuk klasifikasi otomatis lagi.</p>' +
      '<div class="tf-m-list">' + groups + '</div>' +
      '<div style="display:flex;gap:8px;justify-content:flex-end;margin-top:12px;flex-wrap:wrap">' +
        (tp ? '<button type="button" class="btn ghost sm" id="tfMAuto">' + ico('sparkles', 14) + ' Kembalikan ke AI</button>' : '') +
        '<button type="button" class="btn sm" id="tfMSave">' + ico('save', 14) + ' Simpan</button></div></div>';
    document.body.appendChild(m);
    var close = function () { m.remove(); };
    m.onclick = function (e) { if (e.target === m) close(); };
    $('#tfMClose').onclick = close;
    $$('#tfModal [data-tpc]').forEach(function (c) { c.onchange = function () { var r = $('#tfModal input[name="tfMain"][value="' + c.dataset.tpc + '"]'); if (!c.checked && r && r.checked) r.checked = false; if (c.checked && !$('#tfModal input[name="tfMain"]:checked') && r) r.checked = true; }; });
    $$('#tfModal input[name="tfMain"]').forEach(function (r) { r.onchange = function () { var c = $('#tfModal [data-tpc="' + r.value + '"]'); if (c) c.checked = true; }; });
    var done = function (r) {
      if (r && r.ok) { toast('Topik disimpan.'); close(); fetchWaConvs(); if (String(waState.current) === String(num)) fetchWaThread(num, true); }
      else toast((r && r.error) || 'Gagal menyimpan topik.', true);
    };
    $('#tfMSave').onclick = function () {
      var t = $$('#tfModal [data-tpc]').filter(function (c) { return c.checked; }).map(function (c) { return c.dataset.tpc; });
      var mm = $('#tfModal input[name="tfMain"]:checked');
      api('tp_label', { method: 'POST', body: { number: num, op: 'set', t: t, m: mm ? mm.value : (t[0] || '') } }).then(done);
    };
    if ($('#tfMAuto')) $('#tfMAuto').onclick = function () {
      api('tp_label', { method: 'POST', body: { number: num, op: 'auto' } }).then(function (r) { if (r && r.ok) toast('AI akan mengklasifikasi ulang dalam ±1 menit.'); done(r); });
    };
  }

  /* ---- menu Topik & Divisi ---- */
  function loadTopik() {
    tfBindPanel();
    api('tp_get').then(function (r) {
      if (!r || !r.ok) { toast((r && r.error) || 'Gagal memuat Topik & Divisi.', true); return; }
      TF.d = r; TF.conf = JSON.parse(JSON.stringify(r.conf)); TF.presets = r.presets || []; TF.dirty = false;
      tfRender();
    });
  }
  function tfRender() {
    var r = TF.d, c = TF.conf, q = r.quota || {};
    var lk = $('#tfLock');
    lk.classList.toggle('hide', !r.locked);
    if (r.locked) lk.innerHTML = '<div class="gc-lock-ic">' + ico('crown', 22) + '</div><div><b>Fitur paket Growth</b><p>' + esc(r.locked_msg) +
      (r.plan && r.plan.tier ? ' Paket Anda saat ini: <b>' + esc(r.plan.tier.charAt(0).toUpperCase() + r.plan.tier.slice(1)) + '</b>.' : '') + '</p>' + planBtn() + '</div>';   // v1.2.172: trial-paket
    var st = $('#tfStatus');
    st.className = 'pill ' + (r.active ? 'on' : 'off');
    st.textContent = r.active ? 'Aktif' : (r.locked ? 'Terkunci' : 'Nonaktif');
    // kuota & backfill
    var qh = '';
    if (q.central) {
      if (q.limit > 0) {
        var pct = Math.min(100, q.pct || 0);
        qh = '<div style="display:flex;justify-content:space-between;font-size:13px"><span>Kuota klasifikasi bulan ini</span><b>' + Number(q.used).toLocaleString('id-ID') + ' / ' + Number(q.limit).toLocaleString('id-ID') + '</b></div>' +
          '<div class="tf-bar"><span style="width:' + pct + '%;background:' + (pct >= 100 ? '#dc2626' : pct >= 80 ? '#f59e0b' : 'var(--brand)') + '"></span></div>' +
          '<div style="font-size:12px;color:var(--muted)">Reset ' + esc(q.reset) + '. Satu chat rata-rata 1–3 klasifikasi.' + (q.out ? ' <b style="color:#b91c1c">Kuota habis — label lama tetap bisa difilter, label baru berhenti sampai reset.</b>' : (pct >= 80 ? ' <b style="color:#b45309">Kuota hampir habis.</b>' : '')) + '</div>';
      } else qh = '<div style="font-size:13px;color:var(--muted)">Kuota klasifikasi: ' + (q.limit === 0 ? 'tidak termasuk paket ini.' : 'akan tampil setelah klasifikasi pertama.') + '</div>';
    } else qh = '<div style="font-size:13px;color:var(--muted)">Instalasi mandiri: klasifikasi memakai API key AI di menu Widget &amp; API (tanpa kuota).</div>';
    var bf = r.backfill;
    if (bf) {
      var tot = bf.total || 0, dn = (bf.done || 0) + (bf.fail || 0);
      qh += '<div style="margin-top:10px;font-size:13px">' + ico('rotate-cw', 13) + ' Klasifikasi chat lama: ' +
        (bf.finished_at ? 'selesai — ' + bf.done + ' chat' + (bf.fail ? ', ' + bf.fail + ' gagal' : '') : dn + ' / ' + tot + ' chat (berjalan di latar, ±20 chat per menit)') +
        ' · ' + (bf.days ? bf.days + ' hari terakhir' : 'semua periode') + (bf.capped ? ' · dibatasi dari ' + Number(bf.found).toLocaleString('id-ID') + ' chat' : '') + '</div>';   // v1.2.139: topik-riwayat
    }
    if (r.labeled != null) qh += '<div style="font-size:12px;color:var(--muted);margin-top:4px">' + Number(r.labeled).toLocaleString('id-ID') + ' kontak sudah berlabel topik.</div>';
    qh += '<div style="margin-top:10px;display:flex;gap:8px;flex-wrap:wrap;align-items:center"><select id="tfBfDays" style="width:auto"' + (r.active ? '' : ' disabled') + '>' +   // v1.2.139: topik-riwayat
      '<option value="7">7 hari terakhir</option><option value="30" selected>30 hari terakhir</option><option value="90">90 hari terakhir</option><option value="0">Semua chat</option></select>' +
      '<button type="button" class="btn ghost sm" id="tfBackfillBtn"' + (r.active ? '' : ' disabled') + '>' + ico('rotate-cw', 14) + ' Scan chat lama</button>' +
      '<span style="font-size:12px;color:var(--muted)">Termasuk riwayat chat yang diimpor dari WhatsApp. Maks 3.000 chat / 50% kuota per scan.</span></div>';
    $('#tfQuota').innerHTML = qh;
    // pengaturan
    $('#tfEnabled').checked = !!c.enabled;
    $('#tfEnabled').disabled = !!r.locked && !c.enabled;
    $('#tfPreset').innerHTML = '<option value="">— Pilih preset industri —</option>' + TF.presets.map(function (p) {
      return '<option value="' + esc(p.key) + '"' + (c.preset === p.key ? ' selected' : '') + '>' + esc(p.name) + '</option>';
    }).join('');
    tfRenderLists();
    $('#tfBackfillBtn').onclick = function () {   // v1.2.139: topik-riwayat: perkiraan dulu, lalu konfirmasi
      var days = +$('#tfBfDays').value, fmt = function (n) { return Number(n).toLocaleString('id-ID'); };
      api('tp_backfill', { method: 'POST', body: { days: days, estimate: 1 } }).then(function (x) {
        if (!x || !x.ok) { toast((x && x.error) || 'Gagal menghitung.', true); return; }
        var e = x.estimate;
        if (!e.take) { toast(e.cap <= 0 ? 'Kuota klasifikasi bulan ini tidak cukup.' : 'Tidak ada chat belum berlabel di periode ini.', true); return; }
        var msg = 'Ditemukan ' + fmt(e.found) + ' chat belum berlabel (' + (days ? days + ' hari terakhir' : 'semua periode') + ').\n' +
          (e.capped ? 'Yang di-scan: ' + fmt(e.take) + ' chat terbaru (batas ' + fmt(e.cap) + ' per scan).\n' : '') +
          'Memakai ' + fmt(e.take) + ' kuota' + (e.cost_idr != null ? ' · perkiraan biaya ±Rp' + fmt(e.cost_idr) : '') + ' · selesai ±' + fmt(e.minutes) + ' menit.\n\nLanjutkan?';   // v1.2.140: biaya-sa
        if (!confirm(msg)) return;
        var go = function (force) {
          api('tp_backfill', { method: 'POST', body: { days: days, force: force ? 1 : 0 } }).then(function (y) {
            if (y && y.ok) { toast('Diantrekan ' + fmt(y.backfill.total) + ' chat.'); loadTopik(); }
            else if (y && y.running && confirm(y.error + ' Ganti dengan scan baru?')) go(true);
            else toast((y && y.error) || 'Gagal.', true);
          });
        };
        go(false);
      });
    };
  }
  function tfRenderLists() {
    var c = TF.conf;
    $('#tfDivList').innerHTML = c.divisions.map(function (d, i) {
      var col = TF_COLORS[i % TF_COLORS.length];
      return '<div class="tf-row"><span class="tf-dot" style="background:' + col[1] + '"></span><input type="text" data-tpdn="' + i + '" value="' + esc(d.name) + '" maxlength="40" placeholder="Nama divisi">' +
        '<button type="button" class="btn ghost sm" data-tpdx="' + i + '" title="Hapus">' + ico('trash-2', 14) + '</button></div>';
    }).join('') || '<div style="color:var(--muted);font-size:13px">Belum ada divisi.</div>';
    var dSel = function (cur) { return '<option value="">Tanpa divisi</option>' + c.divisions.map(function (d) { return '<option value="' + esc(d.id) + '"' + (cur === d.id ? ' selected' : '') + '>' + esc(d.name) + '</option>'; }).join(''); };
    $('#tfTopicList').innerHTML = c.topics.map(function (t, i) {
      return '<div class="tf-trow"><input type="text" data-tptn="' + i + '" value="' + esc(t.name) + '" maxlength="50" placeholder="Nama topik">' +
        '<input type="text" data-tptd="' + i + '" value="' + esc(t.desc || '') + '" maxlength="160" placeholder="Petunjuk untuk AI (contoh kata/kalimat pelanggan)">' +
        '<select data-tpts="' + i + '">' + dSel(t.div) + '</select>' +
        '<button type="button" class="btn ghost sm" data-tptx="' + i + '" title="Hapus">' + ico('trash-2', 14) + '</button></div>';
    }).join('') || '<div style="color:var(--muted);font-size:13px">Belum ada topik. Pilih preset industri atau tambah manual.</div>';
    $('#tfCount').textContent = c.topics.length + ' topik · ' + c.divisions.length + ' divisi';
    var mark = function () { TF.dirty = true; };
    $$('#tfDivList [data-tpdn]').forEach(function (el) { el.oninput = function () { c.divisions[+el.dataset.tpdn].name = el.value; mark(); }; });
    $$('#tfDivList [data-tpdx]').forEach(function (el) { el.onclick = function () {
      var id = c.divisions[+el.dataset.tpdx].id; c.divisions.splice(+el.dataset.tpdx, 1);
      c.topics.forEach(function (t) { if (t.div === id) t.div = ''; }); mark(); tfRenderLists(); }; });
    $$('#tfTopicList [data-tptn]').forEach(function (el) { el.oninput = function () { c.topics[+el.dataset.tptn].name = el.value; mark(); }; });
    $$('#tfTopicList [data-tptd]').forEach(function (el) { el.oninput = function () { c.topics[+el.dataset.tptd].desc = el.value; mark(); }; });
    $$('#tfTopicList [data-tpts]').forEach(function (el) { el.onchange = function () { c.topics[+el.dataset.tpts].div = el.value; mark(); }; });
    $$('#tfTopicList [data-tptx]').forEach(function (el) { el.onclick = function () { c.topics.splice(+el.dataset.tptx, 1); mark(); tfRenderLists(); }; });
  }
  function tfNewId(name, list) {
    var b = String(name || 'x').toLowerCase().normalize('NFD').replace(/[̀-ͯ]/g, '').replace(/[^a-z0-9]+/g, '_').replace(/^_+|_+$/g, '').slice(0, 28) || 'x', id = b, i = 2;
    while (list.some(function (x) { return x.id === id; })) id = b + '_' + i++;
    return id;
  }
  function tfBindPanel() {
    if (tfBindPanel.done) return; tfBindPanel.done = true;
    $('#tfApplyPreset').onclick = function () {
      var k = $('#tfPreset').value; if (!k) { toast('Pilih preset dulu.', true); return; }
      var p = TF.presets.filter(function (x) { return x.key === k; })[0]; if (!p) return;
      if ((TF.conf.topics.length || TF.conf.divisions.length) && !confirm('Ganti semua divisi & topik dengan preset "' + p.name + '"? Label chat lama dengan topik yang tidak ada di preset tidak lagi tampil di filter.')) return;
      TF.conf.preset = k; TF.conf.divisions = JSON.parse(JSON.stringify(p.divisions)); TF.conf.topics = JSON.parse(JSON.stringify(p.topics)); TF.dirty = true;
      tfRenderLists(); toast('Preset diterapkan — klik Simpan.');
    };
    $('#tfAddDiv').onclick = function () {
      if (TF.conf.divisions.length >= 12) { toast('Maksimal 12 divisi.', true); return; }
      TF.conf.divisions.push({ id: tfNewId('divisi ' + (TF.conf.divisions.length + 1), TF.conf.divisions), name: '' }); TF.dirty = true; tfRenderLists();
      var l = $$('#tfDivList [data-tpdn]'); if (l.length) l[l.length - 1].focus();
    };
    $('#tfAddTopic').onclick = function () {
      if (TF.conf.topics.length >= 40) { toast('Maksimal 40 topik.', true); return; }
      TF.conf.topics.push({ id: tfNewId('topik ' + (TF.conf.topics.length + 1), TF.conf.topics), name: '', desc: '', div: '' }); TF.dirty = true; tfRenderLists();
      var l = $$('#tfTopicList [data-tptn]'); if (l.length) l[l.length - 1].focus();
    };
    $('#tfSave').onclick = function () {
      var c = TF.conf;
      c.enabled = $('#tfEnabled').checked;
      if (c.topics.some(function (t) { return !String(t.name || '').trim(); })) { toast('Ada topik tanpa nama.', true); return; }
      if (c.divisions.some(function (d) { return !String(d.name || '').trim(); })) { toast('Ada divisi tanpa nama.', true); return; }
      var first = c.enabled && !TF.d.conf.enabled;
      api('tp_save', { method: 'POST', body: c }).then(function (r) {
        if (!r || !r.ok) { toast((r && r.error) || 'Gagal menyimpan.', true); return; }
        toast(first && r.backfill && r.backfill.total ? 'Tersimpan. ' + r.backfill.total + ' chat 7 hari terakhir sedang diklasifikasi di latar.' : 'Pengaturan topik tersimpan.');
        loaded.wachat && fetchWaConvs && fetchWaConvs(true);
        loadTopik();
      });
    };
  }

  /* ====================================================================== *
   *  v1.2.109: guest-comment / v1.2.110: customer-feedback — survei kepuasan pelanggan (WA + form web), mulai paket Growth
   * ====================================================================== */
  ICONS['qr-code'] = '<rect width="5" height="5" x="3" y="3" rx="1"/><rect width="5" height="5" x="16" y="3" rx="1"/><rect width="5" height="5" x="3" y="16" rx="1"/><path d="M21 16h-3a2 2 0 0 0-2 2v3"/><path d="M21 21v.01"/><path d="M12 7v3a2 2 0 0 1-2 2H7"/><path d="M3 12h.01"/><path d="M12 3h.01"/><path d="M12 16v.01"/><path d="M16 12h1"/><path d="M21 12v.01"/><path d="M12 21v-1"/>';
  ICONS['external-link'] = '<path d="M15 3h6v6"/><path d="M10 14 21 3"/><path d="M18 13v6a2 2 0 0 1-2 2H5a2 2 0 0 1-2-2V8a2 2 0 0 1 2-2h6"/>';
  /* qrcode-generator 1.4.4 — (c) 2009 Kazuhiko Arase, MIT license — http://www.d-project.com/ */
  var gcQr = (function () {
    var define, exports, module;   // jangan sentuh global
    var qrcode=function(){var t=function(t,r){var e=t,n=g[r],o=null,i=0,a=null,u=[],f={},c=function(t,r){o=function(t){for(var r=new Array(t),e=0;e<t;e+=1){r[e]=new Array(t);for(var n=0;n<t;n+=1)r[e][n]=null}return r}(i=4*e+17),l(0,0),l(i-7,0),l(0,i-7),s(),h(),d(t,r),e>=7&&v(t),null==a&&(a=p(e,n,u)),w(a,r)},l=function(t,r){for(var e=-1;e<=7;e+=1)if(!(t+e<=-1||i<=t+e))for(var n=-1;n<=7;n+=1)r+n<=-1||i<=r+n||(o[t+e][r+n]=0<=e&&e<=6&&(0==n||6==n)||0<=n&&n<=6&&(0==e||6==e)||2<=e&&e<=4&&2<=n&&n<=4)},h=function(){for(var t=8;t<i-8;t+=1)null==o[t][6]&&(o[t][6]=t%2==0);for(var r=8;r<i-8;r+=1)null==o[6][r]&&(o[6][r]=r%2==0)},s=function(){for(var t=B.getPatternPosition(e),r=0;r<t.length;r+=1)for(var n=0;n<t.length;n+=1){var i=t[r],a=t[n];if(null==o[i][a])for(var u=-2;u<=2;u+=1)for(var f=-2;f<=2;f+=1)o[i+u][a+f]=-2==u||2==u||-2==f||2==f||0==u&&0==f}},v=function(t){for(var r=B.getBCHTypeNumber(e),n=0;n<18;n+=1){var a=!t&&1==(r>>n&1);o[Math.floor(n/3)][n%3+i-8-3]=a}for(n=0;n<18;n+=1){a=!t&&1==(r>>n&1);o[n%3+i-8-3][Math.floor(n/3)]=a}},d=function(t,r){for(var e=n<<3|r,a=B.getBCHTypeInfo(e),u=0;u<15;u+=1){var f=!t&&1==(a>>u&1);u<6?o[u][8]=f:u<8?o[u+1][8]=f:o[i-15+u][8]=f}for(u=0;u<15;u+=1){f=!t&&1==(a>>u&1);u<8?o[8][i-u-1]=f:u<9?o[8][15-u-1+1]=f:o[8][15-u-1]=f}o[i-8][8]=!t},w=function(t,r){for(var e=-1,n=i-1,a=7,u=0,f=B.getMaskFunction(r),c=i-1;c>0;c-=2)for(6==c&&(c-=1);;){for(var g=0;g<2;g+=1)if(null==o[n][c-g]){var l=!1;u<t.length&&(l=1==(t[u]>>>a&1)),f(n,c-g)&&(l=!l),o[n][c-g]=l,-1==(a-=1)&&(u+=1,a=7)}if((n+=e)<0||i<=n){n-=e,e=-e;break}}},p=function(t,r,e){for(var n=A.getRSBlocks(t,r),o=b(),i=0;i<e.length;i+=1){var a=e[i];o.put(a.getMode(),4),o.put(a.getLength(),B.getLengthInBits(a.getMode(),t)),a.write(o)}var u=0;for(i=0;i<n.length;i+=1)u+=n[i].dataCount;if(o.getLengthInBits()>8*u)throw"code length overflow. ("+o.getLengthInBits()+">"+8*u+")";for(o.getLengthInBits()+4<=8*u&&o.put(0,4);o.getLengthInBits()%8!=0;)o.putBit(!1);for(;!(o.getLengthInBits()>=8*u||(o.put(236,8),o.getLengthInBits()>=8*u));)o.put(17,8);return function(t,r){for(var e=0,n=0,o=0,i=new Array(r.length),a=new Array(r.length),u=0;u<r.length;u+=1){var f=r[u].dataCount,c=r[u].totalCount-f;n=Math.max(n,f),o=Math.max(o,c),i[u]=new Array(f);for(var g=0;g<i[u].length;g+=1)i[u][g]=255&t.getBuffer()[g+e];e+=f;var l=B.getErrorCorrectPolynomial(c),h=k(i[u],l.getLength()-1).mod(l);for(a[u]=new Array(l.getLength()-1),g=0;g<a[u].length;g+=1){var s=g+h.getLength()-a[u].length;a[u][g]=s>=0?h.getAt(s):0}}var v=0;for(g=0;g<r.length;g+=1)v+=r[g].totalCount;var d=new Array(v),w=0;for(g=0;g<n;g+=1)for(u=0;u<r.length;u+=1)g<i[u].length&&(d[w]=i[u][g],w+=1);for(g=0;g<o;g+=1)for(u=0;u<r.length;u+=1)g<a[u].length&&(d[w]=a[u][g],w+=1);return d}(o,n)};f.addData=function(t,r){var e=null;switch(r=r||"Byte"){case"Numeric":e=M(t);break;case"Alphanumeric":e=x(t);break;case"Byte":e=m(t);break;case"Kanji":e=L(t);break;default:throw"mode:"+r}u.push(e),a=null},f.isDark=function(t,r){if(t<0||i<=t||r<0||i<=r)throw t+","+r;return o[t][r]},f.getModuleCount=function(){return i},f.make=function(){if(e<1){for(var t=1;t<40;t++){for(var r=A.getRSBlocks(t,n),o=b(),i=0;i<u.length;i++){var a=u[i];o.put(a.getMode(),4),o.put(a.getLength(),B.getLengthInBits(a.getMode(),t)),a.write(o)}var g=0;for(i=0;i<r.length;i++)g+=r[i].dataCount;if(o.getLengthInBits()<=8*g)break}e=t}c(!1,function(){for(var t=0,r=0,e=0;e<8;e+=1){c(!0,e);var n=B.getLostPoint(f);(0==e||t>n)&&(t=n,r=e)}return r}())},f.createTableTag=function(t,r){t=t||2;var e="";e+='<table style="',e+=" border-width: 0px; border-style: none;",e+=" border-collapse: collapse;",e+=" padding: 0px; margin: "+(r=void 0===r?4*t:r)+"px;",e+='">',e+="<tbody>";for(var n=0;n<f.getModuleCount();n+=1){e+="<tr>";for(var o=0;o<f.getModuleCount();o+=1)e+='<td style="',e+=" border-width: 0px; border-style: none;",e+=" border-collapse: collapse;",e+=" padding: 0px; margin: 0px;",e+=" width: "+t+"px;",e+=" height: "+t+"px;",e+=" background-color: ",e+=f.isDark(n,o)?"#000000":"#ffffff",e+=";",e+='"/>';e+="</tr>"}return e+="</tbody>",e+="</table>"},f.createSvgTag=function(t,r,e,n){var o={};"object"==typeof arguments[0]&&(t=(o=arguments[0]).cellSize,r=o.margin,e=o.alt,n=o.title),t=t||2,r=void 0===r?4*t:r,(e="string"==typeof e?{text:e}:e||{}).text=e.text||null,e.id=e.text?e.id||"qrcode-description":null,(n="string"==typeof n?{text:n}:n||{}).text=n.text||null,n.id=n.text?n.id||"qrcode-title":null;var i,a,u,c,g=f.getModuleCount()*t+2*r,l="";for(c="l"+t+",0 0,"+t+" -"+t+",0 0,-"+t+"z ",l+='<svg version="1.1" xmlns="http://www.w3.org/2000/svg"',l+=o.scalable?"":' width="'+g+'px" height="'+g+'px"',l+=' viewBox="0 0 '+g+" "+g+'" ',l+=' preserveAspectRatio="xMinYMin meet"',l+=n.text||e.text?' role="img" aria-labelledby="'+y([n.id,e.id].join(" ").trim())+'"':"",l+=">",l+=n.text?'<title id="'+y(n.id)+'">'+y(n.text)+"</title>":"",l+=e.text?'<description id="'+y(e.id)+'">'+y(e.text)+"</description>":"",l+='<rect width="100%" height="100%" fill="white" cx="0" cy="0"/>',l+='<path d="',a=0;a<f.getModuleCount();a+=1)for(u=a*t+r,i=0;i<f.getModuleCount();i+=1)f.isDark(a,i)&&(l+="M"+(i*t+r)+","+u+c);return l+='" stroke="transparent" fill="black"/>',l+="</svg>"},f.createDataURL=function(t,r){t=t||2,r=void 0===r?4*t:r;var e=f.getModuleCount()*t+2*r,n=r,o=e-r;return I(e,e,(function(r,e){if(n<=r&&r<o&&n<=e&&e<o){var i=Math.floor((r-n)/t),a=Math.floor((e-n)/t);return f.isDark(a,i)?0:1}return 1}))},f.createImgTag=function(t,r,e){t=t||2,r=void 0===r?4*t:r;var n=f.getModuleCount()*t+2*r,o="";return o+="<img",o+=' src="',o+=f.createDataURL(t,r),o+='"',o+=' width="',o+=n,o+='"',o+=' height="',o+=n,o+='"',e&&(o+=' alt="',o+=y(e),o+='"'),o+="/>"};var y=function(t){for(var r="",e=0;e<t.length;e+=1){var n=t.charAt(e);switch(n){case"<":r+="&lt;";break;case">":r+="&gt;";break;case"&":r+="&amp;";break;case'"':r+="&quot;";break;default:r+=n}}return r};return f.createASCII=function(t,r){if((t=t||1)<2)return function(t){t=void 0===t?2:t;var r,e,n,o,i,a=1*f.getModuleCount()+2*t,u=t,c=a-t,g={"██":"█","█ ":"▀"," █":"▄","  ":" "},l={"██":"▀","█ ":"▀"," █":" ","  ":" "},h="";for(r=0;r<a;r+=2){for(n=Math.floor((r-u)/1),o=Math.floor((r+1-u)/1),e=0;e<a;e+=1)i="█",u<=e&&e<c&&u<=r&&r<c&&f.isDark(n,Math.floor((e-u)/1))&&(i=" "),u<=e&&e<c&&u<=r+1&&r+1<c&&f.isDark(o,Math.floor((e-u)/1))?i+=" ":i+="█",h+=t<1&&r+1>=c?l[i]:g[i];h+="\n"}return a%2&&t>0?h.substring(0,h.length-a-1)+Array(a+1).join("▀"):h.substring(0,h.length-1)}(r);t-=1,r=void 0===r?2*t:r;var e,n,o,i,a=f.getModuleCount()*t+2*r,u=r,c=a-r,g=Array(t+1).join("██"),l=Array(t+1).join("  "),h="",s="";for(e=0;e<a;e+=1){for(o=Math.floor((e-u)/t),s="",n=0;n<a;n+=1)i=1,u<=n&&n<c&&u<=e&&e<c&&f.isDark(o,Math.floor((n-u)/t))&&(i=0),s+=i?g:l;for(o=0;o<t;o+=1)h+=s+"\n"}return h.substring(0,h.length-1)},f.renderTo2dContext=function(t,r){r=r||2;for(var e=f.getModuleCount(),n=0;n<e;n++)for(var o=0;o<e;o++)t.fillStyle=f.isDark(n,o)?"black":"white",t.fillRect(n*r,o*r,r,r)},f};t.stringToBytes=(t.stringToBytesFuncs={default:function(t){for(var r=[],e=0;e<t.length;e+=1){var n=t.charCodeAt(e);r.push(255&n)}return r}}).default,t.createStringToBytes=function(t,r){var e=function(){for(var e=S(t),n=function(){var t=e.read();if(-1==t)throw"eof";return t},o=0,i={};;){var a=e.read();if(-1==a)break;var u=n(),f=n()<<8|n();i[String.fromCharCode(a<<8|u)]=f,o+=1}if(o!=r)throw o+" != "+r;return i}(),n="?".charCodeAt(0);return function(t){for(var r=[],o=0;o<t.length;o+=1){var i=t.charCodeAt(o);if(i<128)r.push(i);else{var a=e[t.charAt(o)];"number"==typeof a?(255&a)==a?r.push(a):(r.push(a>>>8),r.push(255&a)):r.push(n)}}return r}};var r,e,n,o,i,a=1,u=2,f=4,c=8,g={L:1,M:0,Q:3,H:2},l=0,h=1,s=2,v=3,d=4,w=5,p=6,y=7,B=(r=[[],[6,18],[6,22],[6,26],[6,30],[6,34],[6,22,38],[6,24,42],[6,26,46],[6,28,50],[6,30,54],[6,32,58],[6,34,62],[6,26,46,66],[6,26,48,70],[6,26,50,74],[6,30,54,78],[6,30,56,82],[6,30,58,86],[6,34,62,90],[6,28,50,72,94],[6,26,50,74,98],[6,30,54,78,102],[6,28,54,80,106],[6,32,58,84,110],[6,30,58,86,114],[6,34,62,90,118],[6,26,50,74,98,122],[6,30,54,78,102,126],[6,26,52,78,104,130],[6,30,56,82,108,134],[6,34,60,86,112,138],[6,30,58,86,114,142],[6,34,62,90,118,146],[6,30,54,78,102,126,150],[6,24,50,76,102,128,154],[6,28,54,80,106,132,158],[6,32,58,84,110,136,162],[6,26,54,82,110,138,166],[6,30,58,86,114,142,170]],e=1335,n=7973,i=function(t){for(var r=0;0!=t;)r+=1,t>>>=1;return r},(o={}).getBCHTypeInfo=function(t){for(var r=t<<10;i(r)-i(e)>=0;)r^=e<<i(r)-i(e);return 21522^(t<<10|r)},o.getBCHTypeNumber=function(t){for(var r=t<<12;i(r)-i(n)>=0;)r^=n<<i(r)-i(n);return t<<12|r},o.getPatternPosition=function(t){return r[t-1]},o.getMaskFunction=function(t){switch(t){case l:return function(t,r){return(t+r)%2==0};case h:return function(t,r){return t%2==0};case s:return function(t,r){return r%3==0};case v:return function(t,r){return(t+r)%3==0};case d:return function(t,r){return(Math.floor(t/2)+Math.floor(r/3))%2==0};case w:return function(t,r){return t*r%2+t*r%3==0};case p:return function(t,r){return(t*r%2+t*r%3)%2==0};case y:return function(t,r){return(t*r%3+(t+r)%2)%2==0};default:throw"bad maskPattern:"+t}},o.getErrorCorrectPolynomial=function(t){for(var r=k([1],0),e=0;e<t;e+=1)r=r.multiply(k([1,C.gexp(e)],0));return r},o.getLengthInBits=function(t,r){if(1<=r&&r<10)switch(t){case a:return 10;case u:return 9;case f:case c:return 8;default:throw"mode:"+t}else if(r<27)switch(t){case a:return 12;case u:return 11;case f:return 16;case c:return 10;default:throw"mode:"+t}else{if(!(r<41))throw"type:"+r;switch(t){case a:return 14;case u:return 13;case f:return 16;case c:return 12;default:throw"mode:"+t}}},o.getLostPoint=function(t){for(var r=t.getModuleCount(),e=0,n=0;n<r;n+=1)for(var o=0;o<r;o+=1){for(var i=0,a=t.isDark(n,o),u=-1;u<=1;u+=1)if(!(n+u<0||r<=n+u))for(var f=-1;f<=1;f+=1)o+f<0||r<=o+f||0==u&&0==f||a==t.isDark(n+u,o+f)&&(i+=1);i>5&&(e+=3+i-5)}for(n=0;n<r-1;n+=1)for(o=0;o<r-1;o+=1){var c=0;t.isDark(n,o)&&(c+=1),t.isDark(n+1,o)&&(c+=1),t.isDark(n,o+1)&&(c+=1),t.isDark(n+1,o+1)&&(c+=1),0!=c&&4!=c||(e+=3)}for(n=0;n<r;n+=1)for(o=0;o<r-6;o+=1)t.isDark(n,o)&&!t.isDark(n,o+1)&&t.isDark(n,o+2)&&t.isDark(n,o+3)&&t.isDark(n,o+4)&&!t.isDark(n,o+5)&&t.isDark(n,o+6)&&(e+=40);for(o=0;o<r;o+=1)for(n=0;n<r-6;n+=1)t.isDark(n,o)&&!t.isDark(n+1,o)&&t.isDark(n+2,o)&&t.isDark(n+3,o)&&t.isDark(n+4,o)&&!t.isDark(n+5,o)&&t.isDark(n+6,o)&&(e+=40);var g=0;for(o=0;o<r;o+=1)for(n=0;n<r;n+=1)t.isDark(n,o)&&(g+=1);return e+=Math.abs(100*g/r/r-50)/5*10},o),C=function(){for(var t=new Array(256),r=new Array(256),e=0;e<8;e+=1)t[e]=1<<e;for(e=8;e<256;e+=1)t[e]=t[e-4]^t[e-5]^t[e-6]^t[e-8];for(e=0;e<255;e+=1)r[t[e]]=e;var n={glog:function(t){if(t<1)throw"glog("+t+")";return r[t]},gexp:function(r){for(;r<0;)r+=255;for(;r>=256;)r-=255;return t[r]}};return n}();function k(t,r){if(void 0===t.length)throw t.length+"/"+r;var e=function(){for(var e=0;e<t.length&&0==t[e];)e+=1;for(var n=new Array(t.length-e+r),o=0;o<t.length-e;o+=1)n[o]=t[o+e];return n}(),n={getAt:function(t){return e[t]},getLength:function(){return e.length},multiply:function(t){for(var r=new Array(n.getLength()+t.getLength()-1),e=0;e<n.getLength();e+=1)for(var o=0;o<t.getLength();o+=1)r[e+o]^=C.gexp(C.glog(n.getAt(e))+C.glog(t.getAt(o)));return k(r,0)},mod:function(t){if(n.getLength()-t.getLength()<0)return n;for(var r=C.glog(n.getAt(0))-C.glog(t.getAt(0)),e=new Array(n.getLength()),o=0;o<n.getLength();o+=1)e[o]=n.getAt(o);for(o=0;o<t.getLength();o+=1)e[o]^=C.gexp(C.glog(t.getAt(o))+r);return k(e,0).mod(t)}};return n}var A=function(){var t=[[1,26,19],[1,26,16],[1,26,13],[1,26,9],[1,44,34],[1,44,28],[1,44,22],[1,44,16],[1,70,55],[1,70,44],[2,35,17],[2,35,13],[1,100,80],[2,50,32],[2,50,24],[4,25,9],[1,134,108],[2,67,43],[2,33,15,2,34,16],[2,33,11,2,34,12],[2,86,68],[4,43,27],[4,43,19],[4,43,15],[2,98,78],[4,49,31],[2,32,14,4,33,15],[4,39,13,1,40,14],[2,121,97],[2,60,38,2,61,39],[4,40,18,2,41,19],[4,40,14,2,41,15],[2,146,116],[3,58,36,2,59,37],[4,36,16,4,37,17],[4,36,12,4,37,13],[2,86,68,2,87,69],[4,69,43,1,70,44],[6,43,19,2,44,20],[6,43,15,2,44,16],[4,101,81],[1,80,50,4,81,51],[4,50,22,4,51,23],[3,36,12,8,37,13],[2,116,92,2,117,93],[6,58,36,2,59,37],[4,46,20,6,47,21],[7,42,14,4,43,15],[4,133,107],[8,59,37,1,60,38],[8,44,20,4,45,21],[12,33,11,4,34,12],[3,145,115,1,146,116],[4,64,40,5,65,41],[11,36,16,5,37,17],[11,36,12,5,37,13],[5,109,87,1,110,88],[5,65,41,5,66,42],[5,54,24,7,55,25],[11,36,12,7,37,13],[5,122,98,1,123,99],[7,73,45,3,74,46],[15,43,19,2,44,20],[3,45,15,13,46,16],[1,135,107,5,136,108],[10,74,46,1,75,47],[1,50,22,15,51,23],[2,42,14,17,43,15],[5,150,120,1,151,121],[9,69,43,4,70,44],[17,50,22,1,51,23],[2,42,14,19,43,15],[3,141,113,4,142,114],[3,70,44,11,71,45],[17,47,21,4,48,22],[9,39,13,16,40,14],[3,135,107,5,136,108],[3,67,41,13,68,42],[15,54,24,5,55,25],[15,43,15,10,44,16],[4,144,116,4,145,117],[17,68,42],[17,50,22,6,51,23],[19,46,16,6,47,17],[2,139,111,7,140,112],[17,74,46],[7,54,24,16,55,25],[34,37,13],[4,151,121,5,152,122],[4,75,47,14,76,48],[11,54,24,14,55,25],[16,45,15,14,46,16],[6,147,117,4,148,118],[6,73,45,14,74,46],[11,54,24,16,55,25],[30,46,16,2,47,17],[8,132,106,4,133,107],[8,75,47,13,76,48],[7,54,24,22,55,25],[22,45,15,13,46,16],[10,142,114,2,143,115],[19,74,46,4,75,47],[28,50,22,6,51,23],[33,46,16,4,47,17],[8,152,122,4,153,123],[22,73,45,3,74,46],[8,53,23,26,54,24],[12,45,15,28,46,16],[3,147,117,10,148,118],[3,73,45,23,74,46],[4,54,24,31,55,25],[11,45,15,31,46,16],[7,146,116,7,147,117],[21,73,45,7,74,46],[1,53,23,37,54,24],[19,45,15,26,46,16],[5,145,115,10,146,116],[19,75,47,10,76,48],[15,54,24,25,55,25],[23,45,15,25,46,16],[13,145,115,3,146,116],[2,74,46,29,75,47],[42,54,24,1,55,25],[23,45,15,28,46,16],[17,145,115],[10,74,46,23,75,47],[10,54,24,35,55,25],[19,45,15,35,46,16],[17,145,115,1,146,116],[14,74,46,21,75,47],[29,54,24,19,55,25],[11,45,15,46,46,16],[13,145,115,6,146,116],[14,74,46,23,75,47],[44,54,24,7,55,25],[59,46,16,1,47,17],[12,151,121,7,152,122],[12,75,47,26,76,48],[39,54,24,14,55,25],[22,45,15,41,46,16],[6,151,121,14,152,122],[6,75,47,34,76,48],[46,54,24,10,55,25],[2,45,15,64,46,16],[17,152,122,4,153,123],[29,74,46,14,75,47],[49,54,24,10,55,25],[24,45,15,46,46,16],[4,152,122,18,153,123],[13,74,46,32,75,47],[48,54,24,14,55,25],[42,45,15,32,46,16],[20,147,117,4,148,118],[40,75,47,7,76,48],[43,54,24,22,55,25],[10,45,15,67,46,16],[19,148,118,6,149,119],[18,75,47,31,76,48],[34,54,24,34,55,25],[20,45,15,61,46,16]],r=function(t,r){var e={};return e.totalCount=t,e.dataCount=r,e},e={};return e.getRSBlocks=function(e,n){var o=function(r,e){switch(e){case g.L:return t[4*(r-1)+0];case g.M:return t[4*(r-1)+1];case g.Q:return t[4*(r-1)+2];case g.H:return t[4*(r-1)+3];default:return}}(e,n);if(void 0===o)throw"bad rs block @ typeNumber:"+e+"/errorCorrectionLevel:"+n;for(var i=o.length/3,a=[],u=0;u<i;u+=1)for(var f=o[3*u+0],c=o[3*u+1],l=o[3*u+2],h=0;h<f;h+=1)a.push(r(c,l));return a},e}(),b=function(){var t=[],r=0,e={getBuffer:function(){return t},getAt:function(r){var e=Math.floor(r/8);return 1==(t[e]>>>7-r%8&1)},put:function(t,r){for(var n=0;n<r;n+=1)e.putBit(1==(t>>>r-n-1&1))},getLengthInBits:function(){return r},putBit:function(e){var n=Math.floor(r/8);t.length<=n&&t.push(0),e&&(t[n]|=128>>>r%8),r+=1}};return e},M=function(t){var r=a,e=t,n={getMode:function(){return r},getLength:function(t){return e.length},write:function(t){for(var r=e,n=0;n+2<r.length;)t.put(o(r.substring(n,n+3)),10),n+=3;n<r.length&&(r.length-n==1?t.put(o(r.substring(n,n+1)),4):r.length-n==2&&t.put(o(r.substring(n,n+2)),7))}},o=function(t){for(var r=0,e=0;e<t.length;e+=1)r=10*r+i(t.charAt(e));return r},i=function(t){if("0"<=t&&t<="9")return t.charCodeAt(0)-"0".charCodeAt(0);throw"illegal char :"+t};return n},x=function(t){var r=u,e=t,n={getMode:function(){return r},getLength:function(t){return e.length},write:function(t){for(var r=e,n=0;n+1<r.length;)t.put(45*o(r.charAt(n))+o(r.charAt(n+1)),11),n+=2;n<r.length&&t.put(o(r.charAt(n)),6)}},o=function(t){if("0"<=t&&t<="9")return t.charCodeAt(0)-"0".charCodeAt(0);if("A"<=t&&t<="Z")return t.charCodeAt(0)-"A".charCodeAt(0)+10;switch(t){case" ":return 36;case"$":return 37;case"%":return 38;case"*":return 39;case"+":return 40;case"-":return 41;case".":return 42;case"/":return 43;case":":return 44;default:throw"illegal char :"+t}};return n},m=function(r){var e=f,n=t.stringToBytes(r),o={getMode:function(){return e},getLength:function(t){return n.length},write:function(t){for(var r=0;r<n.length;r+=1)t.put(n[r],8)}};return o},L=function(r){var e=c,n=t.stringToBytesFuncs.SJIS;if(!n)throw"sjis not supported.";!function(t,r){var e=n("友");if(2!=e.length||38726!=(e[0]<<8|e[1]))throw"sjis not supported."}();var o=n(r),i={getMode:function(){return e},getLength:function(t){return~~(o.length/2)},write:function(t){for(var r=o,e=0;e+1<r.length;){var n=(255&r[e])<<8|255&r[e+1];if(33088<=n&&n<=40956)n-=33088;else{if(!(57408<=n&&n<=60351))throw"illegal char at "+(e+1)+"/"+n;n-=49472}n=192*(n>>>8&255)+(255&n),t.put(n,13),e+=2}if(e<r.length)throw"illegal char at "+(e+1)}};return i},D=function(){var t=[],r={writeByte:function(r){t.push(255&r)},writeShort:function(t){r.writeByte(t),r.writeByte(t>>>8)},writeBytes:function(t,e,n){e=e||0,n=n||t.length;for(var o=0;o<n;o+=1)r.writeByte(t[o+e])},writeString:function(t){for(var e=0;e<t.length;e+=1)r.writeByte(t.charCodeAt(e))},toByteArray:function(){return t},toString:function(){var r="";r+="[";for(var e=0;e<t.length;e+=1)e>0&&(r+=","),r+=t[e];return r+="]"}};return r},S=function(t){var r=t,e=0,n=0,o=0,i={read:function(){for(;o<8;){if(e>=r.length){if(0==o)return-1;throw"unexpected end of file./"+o}var t=r.charAt(e);if(e+=1,"="==t)return o=0,-1;t.match(/^\s$/)||(n=n<<6|a(t.charCodeAt(0)),o+=6)}var i=n>>>o-8&255;return o-=8,i}},a=function(t){if(65<=t&&t<=90)return t-65;if(97<=t&&t<=122)return t-97+26;if(48<=t&&t<=57)return t-48+52;if(43==t)return 62;if(47==t)return 63;throw"c:"+t};return i},I=function(t,r,e){for(var n=function(t,r){var e=t,n=r,o=new Array(t*r),i={setPixel:function(t,r,n){o[r*e+t]=n},write:function(t){t.writeString("GIF87a"),t.writeShort(e),t.writeShort(n),t.writeByte(128),t.writeByte(0),t.writeByte(0),t.writeByte(0),t.writeByte(0),t.writeByte(0),t.writeByte(255),t.writeByte(255),t.writeByte(255),t.writeString(","),t.writeShort(0),t.writeShort(0),t.writeShort(e),t.writeShort(n),t.writeByte(0);var r=a(2);t.writeByte(2);for(var o=0;r.length-o>255;)t.writeByte(255),t.writeBytes(r,o,255),o+=255;t.writeByte(r.length-o),t.writeBytes(r,o,r.length-o),t.writeByte(0),t.writeString(";")}},a=function(t){for(var r=1<<t,e=1+(1<<t),n=t+1,i=u(),a=0;a<r;a+=1)i.add(String.fromCharCode(a));i.add(String.fromCharCode(r)),i.add(String.fromCharCode(e));var f,c,g,l=D(),h=(f=l,c=0,g=0,{write:function(t,r){if(t>>>r!=0)throw"length over";for(;c+r>=8;)f.writeByte(255&(t<<c|g)),r-=8-c,t>>>=8-c,g=0,c=0;g|=t<<c,c+=r},flush:function(){c>0&&f.writeByte(g)}});h.write(r,n);var s=0,v=String.fromCharCode(o[s]);for(s+=1;s<o.length;){var d=String.fromCharCode(o[s]);s+=1,i.contains(v+d)?v+=d:(h.write(i.indexOf(v),n),i.size()<4095&&(i.size()==1<<n&&(n+=1),i.add(v+d)),v=d)}return h.write(i.indexOf(v),n),h.write(e,n),h.flush(),l.toByteArray()},u=function(){var t={},r=0,e={add:function(n){if(e.contains(n))throw"dup key:"+n;t[n]=r,r+=1},size:function(){return r},indexOf:function(r){return t[r]},contains:function(r){return void 0!==t[r]}};return e};return i}(t,r),o=0;o<r;o+=1)for(var i=0;i<t;i+=1)n.setPixel(i,o,e(i,o));var a=D();n.write(a);for(var u=function(){var t=0,r=0,e=0,n="",o={},i=function(t){n+=String.fromCharCode(a(63&t))},a=function(t){if(t<0);else{if(t<26)return 65+t;if(t<52)return t-26+97;if(t<62)return t-52+48;if(62==t)return 43;if(63==t)return 47}throw"n:"+t};return o.writeByte=function(n){for(t=t<<8|255&n,r+=8,e+=1;r>=6;)i(t>>>r-6),r-=6},o.flush=function(){if(r>0&&(i(t<<6-r),t=0,r=0),e%3!=0)for(var o=3-e%3,a=0;a<o;a+=1)n+="="},o.toString=function(){return n},o}(),f=a.toByteArray(),c=0;c<f.length;c+=1)u.writeByte(f[c]);return u.flush(),"data:image/gif;base64,"+u};return t}();qrcode.stringToBytesFuncs["UTF-8"]=function(t){return function(t){for(var r=[],e=0;e<t.length;e++){var n=t.charCodeAt(e);n<128?r.push(n):n<2048?r.push(192|n>>6,128|63&n):n<55296||n>=57344?r.push(224|n>>12,128|n>>6&63,128|63&n):(e++,n=65536+((1023&n)<<10|1023&t.charCodeAt(e)),r.push(240|n>>18,128|n>>12&63,128|n>>6&63,128|63&n))}return r}(t)},function(t){"function"==typeof define&&define.amd?define([],t):"object"==typeof exports&&(module.exports=t())}((function(){return qrcode}));
    qrcode.stringToBytes = qrcode.stringToBytesFuncs['UTF-8'];
    return qrcode;
  })();
  var GC = { d: null, list: null, off: 0, view: 'list' };
  var GC_ST = { baru: ['Baru', '#b45309', '#fef3c7'], ditindak: ['Ditindaklanjuti', '#1d4ed8', '#dbeafe'], selesai: ['Selesai', '#15803d', '#dcfce7'] };
  function gcStars(v) {
    v = +v || 0; var h = '';
    for (var i = 1; i <= 5; i++) h += '<span class="gc-st' + (i <= Math.round(v) ? ' on' : '') + '">★</span>';
    return h;
  }
  function gcQrImg(text, size) {
    try { var q = gcQr(0, 'M'); q.addData(text); q.make(); var n = q.getModuleCount(); var cell = Math.max(2, Math.floor((size || 220) / (n + 8)));
      return q.createDataURL(cell, cell * 4); } catch (e) { return ''; }
  }
  function gcCopy(t) {
    var done = function () { toast('Disalin.'); };
    if (navigator.clipboard && navigator.clipboard.writeText) { navigator.clipboard.writeText(t).then(done, function () { gcCopyOld(t); }); return; }
    gcCopyOld(t);
  }
  function gcCopyOld(t) { var ta = document.createElement('textarea'); ta.value = t; document.body.appendChild(ta); ta.select(); try { document.execCommand('copy'); toast('Disalin.'); } catch (e) { toast('Salin manual.', true); } ta.remove(); }
  function loadGc() {
    $$('#gcTabs [data-gcv]').forEach(function (b) { b.onclick = function () { gcView(b.dataset.gcv); }; });
    $('#gcApply').onclick = function () { GC.off = 0; gcLoadList(); };
    $('#gcExport').onclick = gcExport;
    $('#gcQ').onkeydown = function (e) { if (e.key === 'Enter') { GC.off = 0; gcLoadList(); } };
    if (!$('#gcFrom').value) { var d = new Date(Date.now() - 29 * 86400000 + 7 * 3600000); $('#gcFrom').value = d.toISOString().slice(0, 10); }
    api('gc_admin', { query: '&op=get' }).then(function (r) {
      if (!r || !r.ok) { toast((r && r.error) || 'Gagal memuat Customer Feedback.', true); return; }
      GC.d = r;
      var lk = $('#gcLock');
      lk.classList.toggle('hide', !r.locked);
      if (r.locked) lk.innerHTML = '<div class="gc-lock-ic">' + ico('crown', 22) + '</div><div><b>Fitur paket Growth</b><p>' + esc(r.locked_msg) +
        (r.plan && r.plan.tier ? ' Paket Anda saat ini: <b>' + esc(r.plan.tier.charAt(0).toUpperCase() + r.plan.tier.slice(1)) + '</b>.' : '') +
        (r.count ? ' Data feedback yang sudah masuk tetap bisa dilihat & diekspor.' : '') + '</p>' + planBtn() + '</div>';   // v1.2.172: trial-paket
      gcStatus();
      gcFillSettings();
      gcRenderLinks();
      gcView(r.locked && !r.count ? 'set' : GC.view);
      gcLoadList();
    });
  }
  function gcStatus() {
    var r = GC.d, el = $('#gcStatus');
    if (!r) return;
    var on = !r.locked && r.conf.enabled;
    el.className = 'pill ' + (on ? 'on' : 'off');
    el.innerHTML = on ? ico('check-circle-2', 13) + ' Aktif' : (r.locked ? ico('ban', 13) + ' Terkunci (paket)' : ico('clock-3', 13) + ' Belum aktif');
  }
  function gcView(v) {
    if (v === 'set' && !can('super_admin,admin')) v = 'list';
    GC.view = v;
    $$('#gcTabs [data-gcv]').forEach(function (b) { b.classList.toggle('active', b.dataset.gcv === v); });
    ['list', 'set', 'link'].forEach(function (k) { $('#gcView-' + k).classList.toggle('hide', k !== v); });
  }
  function gcQuery() {
    return { op: 'list', from: $('#gcFrom').value, to: $('#gcTo').value, channel: $('#gcChan').value, rating: $('#gcRate').value,
             status: $('#gcStat').value, q: $('#gcQ').value.trim() };
  }
  function gcLoadList(more) {
    var body = gcQuery(); body.offset = more ? GC.off : 0; body.limit = 50;
    if (!more) $('#gcList').innerHTML = '<div class="card gc-empty">Memuat…</div>';
    api('gc_admin', { method: 'POST', body: body }).then(function (r) {
      if (!r || !r.ok) { $('#gcList').innerHTML = '<div class="card gc-empty">' + esc((r && r.error) || 'Gagal memuat.') + '</div>'; return; }
      if (!more) { GC.list = r; gcRenderStats(r); } else { GC.list.items = GC.list.items.concat(r.items); }
      GC.off = GC.list.items.length;
      gcRenderList();
    });
  }
  function gcRenderStats(r) {
    var s = r.stats;
    var lowPct = s.n ? Math.round(s.low / s.n * 100) : 0;
    $('#gcKpis').innerHTML =
      '<div class="gc-kpi"><small>Feedback masuk</small><b>' + s.n + '</b><span>WA ' + s.by_channel.whatsapp + ' · Web ' + s.by_channel.web + '</span></div>' +
      '<div class="gc-kpi"><small>Rata-rata</small><b>' + (s.n ? s.avg.toFixed(2) : '–') + '<i>/5</i></b><span class="gc-stars">' + gcStars(s.avg) + '</span></div>' +
      '<div class="gc-kpi' + (s.low ? ' warn' : '') + '"><small>Ada rating rendah (≤' + r.low_th + ')</small><b>' + s.low + '</b><span>' + lowPct + '% dari total</span></div>' +
      '<div class="gc-kpi"><small>Sebaran rata-rata</small><div class="gc-dist">' + [5, 4, 3, 2, 1].map(function (k) {
        var n = s.dist[k] || 0, w = s.n ? Math.round(n / s.n * 100) : 0;
        return '<div><em>' + k + '★</em><span><i style="width:' + w + '%"></i></span><em>' + n + '</em></div>'; }).join('') + '</div></div>';
    $('#gcAsp').innerHTML = s.aspects.length ? s.aspects.map(function (a) {
      var w = Math.round((a.avg || 0) / 5 * 100);
      var cls = !a.n ? '' : (a.avg <= r.low_th + 0.5 ? ' bad' : (a.avg < 4 ? ' mid' : ''));
      return '<div class="gc-asp' + cls + '"><div class="gc-asp-l">' + esc(a.label) + (a.old ? ' <span class="tag none">dihapus</span>' : '') + '</div>' +
        '<div class="gc-bar"><i style="width:' + w + '%"></i></div><div class="gc-asp-v">' + (a.n ? a.avg.toFixed(2) : '–') + '<small> · ' + a.n + '</small></div></div>';
    }).join('') : '<div class="help">Belum ada data.</div>';
  }
  function gcRenderList() {
    var r = GC.list, el = $('#gcList');
    if (!r.items.length) {
      el.innerHTML = '<div class="card gc-empty">' + ico('star', 22) + '<p>Belum ada feedback pada filter ini.</p>' +
        (GC.d && !GC.d.locked && !GC.d.conf.enabled && can('super_admin,admin') ? '<button class="btn sm" type="button" id="gcGoSet">Aktifkan di Pengaturan</button>' : '') + '</div>';
      var g = $('#gcGoSet'); if (g) g.onclick = function () { gcView('set'); };
      $('#gcMore').innerHTML = '';
      return;
    }
    el.innerHTML = r.items.map(gcItemHtml).join('');
    $('#gcMore').innerHTML = r.items.length < r.total ? '<button class="btn ghost sm" type="button" id="gcMoreBtn">Muat lagi (' + (r.total - r.items.length) + ')</button>' : '';
    var mb = $('#gcMoreBtn'); if (mb) mb.onclick = function () { gcLoadList(true); };
    $$('#gcList [data-gcact]').forEach(function (b) { b.onclick = function () { gcAct(b.dataset.gcact, b.dataset.id); }; });
  }
  function gcItemHtml(e) {
    var st = GC_ST[e.status] || GC_ST.baru;
    var asp = Object.keys(e.ratings || {}).map(function (k) {
      var v = e.ratings[k], low = v <= (GC.list ? GC.list.low_th : 2);
      return '<span class="gc-rt' + (low ? ' low' : '') + '">' + esc((e.labels && e.labels[k]) || k) + ' <b>' + v + '</b></span>';
    }).join('');
    var who = esc(e.name || 'Pelanggan') + (e.room ? ' · <span class="gc-room">' + esc(gcRef()) + ' ' + esc(e.room) + '</span>' : '');
    var ct = e.channel === 'whatsapp' ? (ico('message-circle', 13) + ' WhatsApp' + (e.num ? ' · +' + esc(e.num) : '')) : (ico('globe', 13) + ' Form web' + (e.phone ? ' · ' + esc(e.phone) : ''));
    var canDel = can('super_admin,admin');
    return '<div class="card gc-item' + (e.low ? ' low' : '') + '" id="gci-' + esc(e.id) + '">' +
      '<div class="gc-top"><div><div class="gc-who">' + who + '</div><div class="gc-meta">' + ct + ' · ' + esc(e.ts) + (e.lang === 'en' ? ' · EN' : '') + '</div></div>' +
      '<div class="gc-avg"><span class="gc-stars">' + gcStars(e.avg) + '</span><b>' + (+e.avg).toFixed(1) + '</b></div></div>' +
      '<div class="gc-rts">' + asp + '</div>' +
      (e.comment ? '<div class="gc-cm">' + esc(e.comment).replace(/\n/g, '<br>') + '</div>' : '<div class="gc-cm none">(tanpa komentar)</div>') +
      '<div class="gc-foot"><span class="gc-badge" style="color:' + st[1] + ';background:' + st[2] + '">' + st[0] + '</span>' +
      (e.handled_by ? '<span class="gc-meta">oleh ' + esc(e.handled_by) + ' · ' + esc(e.handled_at || '') + '</span>' : '') +
      '<span class="gc-acts">' +
      (e.channel === 'whatsapp' && e.num ? '<button class="btn ghost sm" type="button" data-gcact="wa" data-id="' + esc(e.id) + '">' + ico('message-circle', 13) + ' Buka chat</button>' : '') +
      '<button class="btn ghost sm" type="button" data-gcact="edit" data-id="' + esc(e.id) + '">Tindak lanjut</button>' +
      (canDel ? '<button class="btn danger sm" type="button" data-gcact="del" data-id="' + esc(e.id) + '" title="Hapus">' + ico('trash-2', 13) + '</button>' : '') +
      '</span></div>' +
      (e.note ? '<div class="gc-note"><small>Catatan</small>' + esc(e.note).replace(/\n/g, '<br>') + '</div>' : '') +
      '<div class="gc-edit hide" id="gce-' + esc(e.id) + '"></div></div>';
  }
  function gcFind(id) { var it = null; (GC.list ? GC.list.items : []).forEach(function (x) { if (x.id === id) it = x; }); return it; }
  function gcAct(act, id) {
    var e = gcFind(id); if (!e) return;
    if (act === 'wa') {
      openLeadConv(e.num);
      return;
    }
    if (act === 'del') {
      if (!confirm('Hapus feedback dari ' + (e.name || 'pelanggan') + '? Tidak bisa dibatalkan.')) return;
      api('gc_admin', { method: 'POST', body: { op: 'delete', id: id } }).then(function (r) {
        if (!r || !r.ok) { toast((r && r.error) || 'Gagal menghapus.', true); return; }
        toast('Dihapus.'); gcLoadList();
      });
      return;
    }
    var box = $('#gce-' + id);
    if (!box.classList.contains('hide')) { box.classList.add('hide'); return; }
    box.innerHTML = '<div class="row"><label class="fl">Status</label><select id="gcs-' + esc(id) + '">' + Object.keys(GC_ST).map(function (k) {
        return '<option value="' + k + '"' + (e.status === k ? ' selected' : '') + '>' + GC_ST[k][0] + '</option>'; }).join('') + '</select></div>' +
      '<div class="row"><label class="fl">Catatan tindak lanjut (internal)</label><textarea id="gcn-' + esc(id) + '" rows="2" maxlength="1000" placeholder="mis. sudah dicek ke tim terkait, pelanggan sudah dihubungi">' + esc(e.note || '') + '</textarea></div>' +
      '<button class="btn sm" type="button" id="gcsv-' + esc(id) + '">Simpan</button>';
    box.classList.remove('hide');
    $('#gcsv-' + id).onclick = function () {
      api('gc_admin', { method: 'POST', body: { op: 'update', id: id, status: $('#gcs-' + id).value, note: $('#gcn-' + id).value } }).then(function (r) {
        if (!r || !r.ok) { toast((r && r.error) || 'Gagal menyimpan.', true); return; }
        for (var k in r.item) e[k] = r.item[k];
        var card = $('#gci-' + id); card.outerHTML = gcItemHtml(e);
        $$('#gci-' + id + ' [data-gcact]').forEach(function (b) { b.onclick = function () { gcAct(b.dataset.gcact, b.dataset.id); }; });
        toast('Tersimpan.');
      });
    };
  }
  function gcExport() {
    var body = gcQuery(); body.all = 1;
    api('gc_admin', { method: 'POST', body: body }).then(function (r) {
      if (!r || !r.ok) { toast((r && r.error) || 'Gagal ekspor.', true); return; }
      if (!r.items.length) { toast('Tidak ada data untuk diekspor.', true); return; }
      var asp = r.stats.aspects;
      var head = ['Tanggal', 'Kanal', 'Nama', gcRef(), 'No. WA / HP', 'Bahasa'].concat(asp.map(function (a) { return a.label; })).concat(['Rata-rata', 'Rating rendah', 'Komentar', 'Status', 'Catatan', 'Ditangani oleh']);
      var q = function (v) { v = String(v == null ? '' : v); if (/^[=+\-@]/.test(v)) v = "'" + v; return '"' + v.replace(/"/g, '""') + '"'; };
      var lines = [head.map(q).join(',')];
      r.items.forEach(function (e) {
        lines.push([e.ts, e.channel === 'whatsapp' ? 'WhatsApp' : 'Web', e.name, e.room, e.num ? '+' + e.num : e.phone, (e.lang || 'id').toUpperCase()]
          .concat(asp.map(function (a) { return (e.ratings || {})[a.id] || ''; }))
          .concat([e.avg, e.low ? 'ya' : '', e.comment, (GC_ST[e.status] || GC_ST.baru)[0], e.note, e.handled_by || '']).map(q).join(','));
      });
      var blob = new Blob(['﻿' + lines.join('\r\n')], { type: 'text/csv;charset=utf-8' });
      var a = document.createElement('a'); a.href = URL.createObjectURL(blob); a.download = 'customer-feedback-' + new Date().toISOString().slice(0, 10) + '.csv';
      document.body.appendChild(a); a.click(); setTimeout(function () { URL.revokeObjectURL(a.href); a.remove(); }, 500);
    });
  }
  function gcRef() { return (GC.d && GC.d.conf && GC.d.conf.ref_label) || 'Nomor pesanan'; }
  /* v1.2.110: preset aspek per industri */
  var GC_PRESETS = {
    umum:   { ref: ['Nomor pesanan', 'Order number'], room: false, a: [['Kesan keseluruhan', 'Overall experience'], ['Kualitas produk / layanan', 'Product / service quality'], ['Keramahan & bantuan staf', 'Staff friendliness & help'], ['Kecepatan pelayanan', 'Speed of service'], ['Harga sesuai kualitas', 'Value for money']] },
    hotel:  { ref: ['Nomor kamar', 'Room number'], room: true, a: [['Kesan keseluruhan', 'Overall experience'], ['Kamar', 'Room'], ['Kebersihan', 'Cleanliness'], ['Pelayanan staf', 'Staff service'], ['Makanan & minuman', 'Food & beverage']] },
    resto:  { ref: ['Nomor meja', 'Table number'], room: true, a: [['Kesan keseluruhan', 'Overall experience'], ['Rasa makanan & minuman', 'Food & drink taste'], ['Kecepatan penyajian', 'Serving speed'], ['Pelayanan', 'Service'], ['Kebersihan', 'Cleanliness'], ['Harga sesuai porsi', 'Value for money']] },
    bus:    { ref: ['Kode booking', 'Booking code'], room: true, a: [['Kesan keseluruhan', 'Overall experience'], ['Ketepatan waktu', 'Punctuality'], ['Kenyamanan armada', 'Bus comfort'], ['Kebersihan armada', 'Bus cleanliness'], ['Pengemudi & kru', 'Driver & crew'], ['Proses pemesanan', 'Booking process']] },
    klinik: { ref: ['Nomor antrean', 'Queue number'], room: false, a: [['Kesan keseluruhan', 'Overall experience'], ['Waktu tunggu', 'Waiting time'], ['Keramahan staf', 'Staff friendliness'], ['Penjelasan dokter / tenaga medis', 'Explanation by doctor / medical staff'], ['Kebersihan fasilitas', 'Facility cleanliness']] },
    toko:   { ref: ['Nomor pesanan', 'Order number'], room: false, a: [['Kesan keseluruhan', 'Overall experience'], ['Kualitas produk', 'Product quality'], ['Kecepatan pengiriman', 'Delivery speed'], ['Respons admin', 'Admin responsiveness'], ['Harga sesuai kualitas', 'Value for money']] },
    jasa:   { ref: ['Nomor proyek / invoice', 'Project / invoice number'], room: false, a: [['Kesan keseluruhan', 'Overall experience'], ['Kualitas hasil kerja', 'Quality of work'], ['Ketepatan waktu', 'Timeliness'], ['Komunikasi', 'Communication'], ['Harga sesuai hasil', 'Value for money']] }
  };
  function gcApplyPreset(k) {
    var p = GC_PRESETS[k]; if (!p) return;
    if (!confirm('Ganti daftar aspek & label nomor referensi dengan preset ini? Klik Simpan setelahnya.')) return;
    $('#gc_aspects').innerHTML = p.a.map(function (x) { return gcAspRow({ label: x[0], label_en: x[1] }); }).join('');
    gcWireAsp();
    $('#gc_ref_label').value = p.ref[0]; $('#gc_ref_label_en').value = p.ref[1]; $('#gc_ask_room').checked = p.room;
    toast('Preset diterapkan — klik Simpan Pengaturan.');
  }
  /* --- pengaturan --- */
  function gcAspRow(a) {
    return '<div class="gc-asprow"><input type="hidden" value="' + esc(a.id || '') + '"><input type="text" maxlength="60" placeholder="Label (Indonesia)" value="' + esc(a.label || '') + '">' +
      '<input type="text" maxlength="60" placeholder="Label (English)" value="' + esc(a.label_en || '') + '"><button class="btn danger sm" type="button" title="Hapus aspek">' + ico('x', 13) + '</button></div>';
  }
  function gcWireAsp() {
    $$('#gc_aspects .gc-asprow button').forEach(function (b) { b.onclick = function () {
      if ($$('#gc_aspects .gc-asprow').length <= 1) { toast('Minimal satu aspek.', true); return; }
      b.parentNode.remove(); }; });
    $('#gc_asp_add').disabled = $$('#gc_aspects .gc-asprow').length >= 8;
  }
  function gcFillSettings() {
    var c = GC.d.conf, ed = GC.d.can_edit, lockd = GC.d.locked;
    $('#gc_enabled').checked = !!c.enabled && !lockd;
    $('#gc_enabled').disabled = lockd || !ed;
    $('#gc_aspects').innerHTML = c.aspects.map(gcAspRow).join('');
    gcWireAsp();
    $('#gc_asp_add').onclick = function () { $('#gc_aspects').insertAdjacentHTML('beforeend', gcAspRow({})); gcWireAsp(); };
    ['ask_name', 'ask_room', 'ask_phone_web', 'ai_hint'].forEach(function (k) { $('#gc_' + k).checked = !!c[k]; });
    ['intro', 'intro_en', 'thanks', 'thanks_en', 'review_url', 'review_text', 'review_text_en', 'alert_wa', 'ref_label', 'ref_label_en'].forEach(function (k) { $('#gc_' + k).value = c[k] || ''; });
    $('#gc_preset').onchange = function () { gcApplyPreset(this.value); this.value = ''; };   // v1.2.110
    $('#gc_low').value = String(c.low);
    $('#gc_keywords').value = (c.keywords || []).join(', ');
    $('#gc_save').disabled = !ed;
    $('#gc_save').onclick = gcSave;
  }
  function gcSave() {
    var asp = $$('#gc_aspects .gc-asprow').map(function (r) { var i = r.querySelectorAll('input'); return { id: i[0].value, label: i[1].value.trim(), label_en: i[2].value.trim() }; })
      .filter(function (a) { return a.label || a.label_en; });
    if (!asp.length) { toast('Isi minimal satu aspek penilaian.', true); return; }
    var ru = $('#gc_review_url').value.trim();
    if (ru && !/^https?:\/\//i.test(ru)) { toast('Tautan ulasan harus diawali https://', true); return; }
    var conf = { enabled: $('#gc_enabled').checked, aspects: asp, low: +$('#gc_low').value, keywords: $('#gc_keywords').value };
    ['ask_name', 'ask_room', 'ask_phone_web', 'ai_hint'].forEach(function (k) { conf[k] = $('#gc_' + k).checked; });
    ['intro', 'intro_en', 'thanks', 'thanks_en', 'review_url', 'review_text', 'review_text_en', 'alert_wa', 'ref_label', 'ref_label_en'].forEach(function (k) { conf[k] = $('#gc_' + k).value; });
    var b = $('#gc_save'); b.disabled = true;
    api('gc_admin', { method: 'POST', body: { op: 'save', conf: conf } }).then(function (r) {
      b.disabled = false;
      if (!r || !r.ok) { toast((r && r.error) || 'Gagal menyimpan.', true); return; }
      GC.d.conf = r.conf; gcFillSettings(); gcStatus(); gcRenderLinks();
      toast(r.conf.enabled ? 'Tersimpan. Customer Feedback aktif.' : 'Tersimpan.');
    });
  }
  /* --- tautan & QR --- */
  function gcRenderLinks() {
    var r = GC.d, room = ($('#gcRoom') ? $('#gcRoom').value : '').replace(/[^A-Za-z0-9-]/g, '').slice(0, 10);
    var kw = ((r.conf.keywords || [])[0] || 'customer feedback').toUpperCase();
    var fu = r.form_url ? r.form_url + (room ? '&room=' + encodeURIComponent(room) : '') : '';
    var items = [];
    if (fu) items.push({ t: 'Form web', s: 'Untuk QR di meja, kasir, kamar, atau tiket — juga bisa ditaruh di email, struk, dan pesan setelah transaksi.', u: fu, k: 'web' });
    (r.wa || []).forEach(function (w) {
      items.push({ t: 'WhatsApp · ' + w.label, s: 'Membuka WA dengan pesan "' + kw + (room ? ' #' + room : '') + '" — bot langsung memandu survei.',
                   u: 'https://wa.me/' + w.number + '?text=' + encodeURIComponent(kw + (room ? ' #' + room : '')), k: 'wa' });
    });
    var off = r.locked ? '<div class="help" style="color:var(--warn)">' + esc(r.locked_msg) + '</div>' : (!r.conf.enabled ? '<div class="help" style="color:var(--warn)">Customer Feedback belum diaktifkan — tautan baru berfungsi setelah diaktifkan di Pengaturan.</div>' : '');
    $('#gcLinks').innerHTML = off + (items.length ? items.map(function (x, i) {
      var img = gcQrImg(x.u, 220);
      return '<div class="gc-link"><div class="gc-qr">' + (img ? '<img src="' + img + '" alt="QR">' : '') + '</div><div class="gc-link-b"><b>' + esc(x.t) + '</b><p>' + esc(x.s) + '</p>' +
        '<code>' + esc(x.u) + '</code><div class="gc-link-a"><button class="btn ghost sm" type="button" data-gccp="' + i + '">' + ico('copy', 13) + ' Salin</button>' +
        '<a class="btn ghost sm" href="' + esc(x.u) + '" target="_blank" rel="noopener">' + ico('external-link', 13) + ' Buka</a>' +
        (img ? '<a class="btn ghost sm" download="qr-feedback-' + x.k + (room ? '-' + room : '') + '.gif" href="' + img + '">' + ico('download', 13) + ' Unduh QR</a>' : '') + '</div></div></div>';
    }).join('') : '<div class="help">Belum ada nomor WhatsApp & URL form belum terbaca. Buka dashboard dari domain tenant Anda.</div>');
    $$('#gcLinks [data-gccp]').forEach(function (b) { b.onclick = function () { gcCopy(items[+b.dataset.gccp].u); }; });
    var rm = $('#gcRoom'); if (rm && !rm.dataset.w) { rm.dataset.w = '1'; rm.oninput = function () { gcRenderLinks(); }; }
  }

  var loaders = {
    eskalasi: loadEskalasi,   // v1.2.56
    reports: function () {
      initReportsControls(); loadUsageCard(); loadReports();
      var v = 'summary'; try { v = localStorage.getItem('dei_rep_view') || 'summary'; } catch (e) {}
      repView(v);   // v1.2.66/67
    },
    wachat: loadWachat,
    webchat: loadWebchat,
    blast: loadBlast,
    qrtpl: function () { waQrManager($('#qrtplRoot')); },   // v1.2.199: template-menu
    leads: loadLeads,
    tasks: loadTasks214,   // v1.2.214: task
    salesrep: srLoad221,   // v1.2.221: laporan-sales
    kontak: loadKontak,
    kb: loadKb,
    content: loadContent,
    test: initTest,
    widget: function () { loadWidget(); loadCentral(); wireCentralButtons(); ntfLoad222(); },   // v1.2.222: notif-wa
    users: loadUsers,
    tim: loadTim,             // v1.2.58
    install: loadInstall,
    profile: function () { loadProfile(); ntfProfile222(); },   // v1.2.222: notif-wa
    pembaruan: function () { loadPembaruan(false); },   // v1.2.65
    topik: loadTopik,   // v1.2.138: filter-topik
    gc: loadGc   // v1.2.109: guest-comment
  };

  /* ====================================================================== *
   *  v1.2.74: PANDUAN — guided walkthrough per peran
   *  Muncul sekali saat pertama login (per akun: users.json → tour_seen),
   *  bisa dibuka lagi lewat tombol "Panduan" di bawah menu / Profil Saya.
   *  Naikkan TOUR_VER bila isi panduan berubah besar → semua akun melihat lagi.
   * ====================================================================== */
  var TOUR_VER = 1;
  var TOUR_ORDER = ['super_admin', 'admin', 'supervisor', 'wa_agent'];
  var tour = null;   // { role, steps, i, preview, home, t }

  // Kartu di sebuah panel berdasarkan judul <h3>-nya (tahan perubahan urutan kartu)
  function tourCard(panel, title) {
    return function () {
      var cards = document.querySelectorAll('#panel-' + panel + ' .card');
      for (var k = 0; k < cards.length; k++) {
        var h = cards[k].querySelector('h3');
        if (h && h.textContent.indexOf(title) !== -1) return cards[k];
      }
      return null;
    };
  }
  var TS = {
    nav: function (body) { return { el: '#nav', side: true, title: 'Menu Anda', body: body }; },
    waList: function (body) { return { tab: 'wachat', el: '#waConvList', title: 'Percakapan WhatsApp', body: body }; },
    waThread: function (title, body) { return { tab: 'wachat', el: '#panel-wachat .wachat-thread', title: title, body: body }; },
    webchat: { tab: 'webchat', el: '#webConvList', title: 'Percakapan Web',
      body: '<p>Chat dari widget di website Anda. Pantau apa yang ditanyakan pengunjung dan bagaimana bot menjawab.</p><p>Bila pengunjung mengisi <b>Form Data Pengunjung</b>, nama &amp; nomornya menjadi judul percakapan.</p>' },
    reports: { tab: 'reports', el: '#repSeg', title: 'Laporan &amp; Log',
      body: '<ul><li><b>Ringkasan</b> — statistik percakapan, sumber traffic (UTM), dan tren harian.</li><li><b>Log Percakapan</b> — status tiap chat: dijawab AI, menunggu balasan, dibalas agent.</li><li><b>Topik</b> — hal yang paling sering ditanyakan pelanggan.</li></ul>' },
    leads: function (extra) { return { tab: 'leads', el: '#panel-leads .card', title: 'Leads',
      body: '<p>Kartu ringkasan dibuat otomatis oleh AI saat percakapan mencapai 8 pesan. AI menyiapkan bahannya — Anda yang menentukan statusnya.</p><p>Pakai filter <b>Baru</b>, <b>Qualified</b>, <b>Follow-up</b>, <b>Closed</b> untuk menindaklanjuti.' + (extra || '') + '</p>' }; },
    kontak: function (extra) { return { tab: 'kontak', el: '#panel-kontak .card', title: 'Kontak',
      body: '<p>Semua kontak WhatsApp dengan tag pipeline: Cold, Warm, Hot Prospect, Active Customer, dan lainnya.</p><p>Klik satu kontak untuk mengubah tag atau <b>Simpan ke HP</b>.' + (extra || '') + '</p>' }; },
    blast: { tab: 'blast', el: '#panel-blast .card', title: 'Blast WA',
      body: '<p>Kirim pesan template resmi Meta ke banyak kontak sekaligus.</p><p>Hanya ke kontak yang sudah <b>opt-in</b> dan memakai template yang sudah <b>disetujui Meta</b>.</p>' },
    agentReport: function (title, body) { return { tab: 'reports', pre: function () { repView('agent'); }, el: '#arCard', title: title, body: body }; },   // v1.2.205: laporan-pindah
    users: function (body) { return { tab: 'users', el: tourCard('users', 'Pengguna'), title: 'Kelola akun tim', body: body }; },
    usage: { tab: 'reports', el: '#usageCard', title: 'Penggunaan bulan ini',
      body: '<p>Kuota percakapan paket Anda dan grafik 30 hari terakhir.</p><p>Bila kuota hampir habis, peringatan muncul di bagian atas dashboard.</p>' },
    kb: { tab: 'kb', el: '#kbTabEntri .card', title: 'Knowledge Base — sumber jawaban AI',
      body: '<p>Isi tanya-jawab tentang bisnis Anda: <b>+ Tambah Entri</b>, atau <b>Impor CSV / PDF</b>. Jangan lupa klik <b>Simpan Perubahan</b>.</p><p><b>Belum Terjawab</b> menampilkan pertanyaan pelanggan yang belum ada jawabannya — tambahkan ke KB agar AI makin akurat. Tab <b>Produk</b> untuk harga, varian &amp; detail produk/layanan.</p>' },
    content: { tab: 'content', el: '#panel-content .card', title: 'Balasan &amp; Tampilan',
      body: '<p>Mulai dari <b>Konfigurasi Terstruktur</b>: sapaan, bahasa, aturan respon, dan apa yang dilakukan AI saat tidak tahu jawabannya.</p><p>Di bawahnya: teks balasan bawaan dan tampilan widget (warna, posisi) di website.</p>' },
    test: { tab: 'test', el: '#panel-test .card', title: 'Tes Chatbot',
      body: '<p>Bertanya seperti pelanggan untuk memeriksa jawaban AI — lakukan setiap selesai mengubah Knowledge Base.</p>' },
    widget: { tab: 'widget', el: tourCard('widget', 'Status Widget'), title: 'Widget &amp; API',
      body: '<p>Nyalakan / matikan <b>bubble AI</b> dan <b>tombol WhatsApp</b> di website.</p><p>Di halaman ini juga: <b>Form Data Pengunjung</b> (minta nama &amp; nomor sebelum chat) dan pengaturan nomor WhatsApp.</p>' },
    eskalasi: { tab: 'eskalasi', el: tourCard('eskalasi', 'Auto-Closing'), title: 'Respon &amp; Eskalasi',
      body: '<p><b>Auto-Closing</b> mengirim pesan penutup ke tamu yang sudah diam.</p><p><b>Eskalasi Darurat</b> membunyikan alarm ke Supervisor/Manager bila tamu menunggu terlalu lama tanpa balasan.</p>' },
    install: { tab: 'install', el: tourCard('install', 'Langkah Pemasangan'), title: 'Pemasangan widget',
      body: '<p>Salin kode untuk <b>Google Tag Manager</b>, atau pasang langsung di HTML website. Cukup sekali — perubahan setelahnya otomatis ikut.</p>' },
    pembaruan: { tab: 'pembaruan', el: '#panel-pembaruan .rel-hero', title: 'Pembaruan',
      body: '<p>Catatan rilis fitur baru dan peningkatan. Saat ada versi baru, tanda muncul di menu ini dan Anda bisa memasangnya dari sini.</p>' },
    notif: { el: '#btnNotif', side: true, optional: true, title: 'Aktifkan notifikasi',
      body: '<p>Klik sekali dan izinkan notifikasi: browser / HP akan memberi tahu setiap ada pesan baru, walau dashboard tidak sedang dibuka.</p><p>Di HP, pasang dashboard ke layar utama (Add to Home Screen) agar notifikasi lebih andal.</p>' },
    profile: { tab: 'profile', el: tourCard('profile', 'Ganti Password'), title: 'Profil &amp; password',
      body: '<p>Ganti password Anda di sini. Setelah tersimpan, Anda diminta login ulang.</p>' },
    done: { el: '#btnTour', side: true, title: 'Selesai — siap bekerja!',
      body: '<p>Bingung di tengah jalan? Klik <b>Panduan</b> di bawah menu (atau tekan <b>/</b>) lalu ketik pertanyaan Anda, mis. <i>"cara lihat kontak leads"</i>.</p><p>Tur ini juga bisa diulang dari sana.</p>' }
  };

  function tourSteps(r) {
    var W = { el: null, welcome: true };
    if (r === 'wa_agent') return [
      tourWelcome(W, '<p>Peran <b>WA Agent</b>: membalas chat pelanggan yang diteruskan dari bot, dan menindaklanjuti leads.</p><p>Panduan ini sekitar 1 menit.</p>'),
      TS.nav('<p>Menu hanya berisi halaman yang bisa Anda pakai.</p><p>Di HP, buka menu lewat tombol <b>&#9776;</b> di pojok kiri atas.</p>'),
      TS.waList('<p>Chat WhatsApp masuk tampil di sini secara real-time, yang terbaru di atas. Klik satu chat untuk membukanya.</p>'),
      TS.waThread('Claim, balas, lalu Release', '<ul><li>Klik <b>Claim</b> — bot berhenti menjawab nomor itu dan chat menjadi milik Anda.</li><li>Ketik balasan di kolom bawah, lalu <b>Kirim</b>.</li><li>Selesai? Klik <b>Release</b> / <b>Lepas ke antrean</b>.</li></ul><p>Aturan WhatsApp: balasan teks bebas hanya bisa dikirim dalam <b>24 jam</b> sejak pesan terakhir pelanggan.</p>'),
      TS.webchat,
      TS.leads(),
      TS.kontak(),
      TS.notif,
      TS.profile,
      TS.done
    ];
    if (r === 'supervisor') return [
      tourWelcome(W, '<p>Peran <b>Supervisor</b>: memantau tim agent, membagi chat, dan menjaga waktu respon.</p><p>Panduan ini sekitar 2 menit.</p>'),
      TS.nav('<p>Menu hanya berisi halaman yang bisa Anda pakai.</p><p>Di HP, buka menu lewat tombol <b>&#9776;</b> di pojok kiri atas.</p>'),
      TS.waList('<p>Anda melihat chat milik tim Anda secara real-time. Klik satu chat untuk membukanya.</p>'),
      TS.waThread('Bagi chat ke agent', '<ul><li><b>Serahkan ke…</b> / <b>Pindahkan ke…</b> di kepala chat — bagi chat ke agent yang tepat.</li><li>Atau <b>Claim</b> dan balas sendiri.</li></ul><p>Balasan teks bebas hanya bisa dikirim dalam <b>24 jam</b> sejak pesan terakhir pelanggan.</p>'),
      TS.webchat,
      TS.reports,
      TS.blast,
      TS.leads(),
      TS.kontak(' Tombol <b>Ekspor CSV</b> mengunduh kontak sesuai filter aktif.'),
      TS.agentReport('Pantau kinerja tim', '<p>Pilih rentang tanggal lalu <b>Tampilkan</b>: chat ditangani, balasan, respon pertama, dan chat yang <b>belum dibalas</b> per agent.</p><p>Kartu <b>Kursi Tim</b> di atasnya menunjukkan sisa akun sesuai paket.</p>'),
      TS.users('<p>Buat akun <b>WA Agent</b> untuk tim Anda: isi username, nama, password, lalu simpan.</p><p>Jumlah akun dibatasi kursi paket.</p>'),
      TS.notif,
      TS.done
    ];
    var sa = r === 'super_admin';
    var steps = [
      tourWelcome(W, sa
        ? '<p>Peran <b>Super Admin</b>: akses penuh — konfigurasi AI &amp; WhatsApp, isi jawaban bot, tim, dan semua pengguna.</p><p>Panduan ini sekitar 3 menit. Urutannya mengikuti langkah menyiapkan chatbot.</p>'
        : '<p>Peran <b>Admin</b>: mengatur isi jawaban bot, tampilan widget, tim, dan laporan.</p><p>Panduan ini sekitar 3 menit. Urutannya mengikuti langkah menyiapkan chatbot.</p>'),
      TS.nav('<p>Semua halaman yang bisa Anda kelola ada di sini. <b>Leads</b>, <b>Kontak</b>, dan <b>Blast WA</b> dipakai bersama tim untuk tindak lanjut pelanggan.</p><p>Di HP, buka menu lewat tombol <b>&#9776;</b> di pojok kiri atas.</p>'),
      TS.usage,
      TS.reports,
      TS.kb,
      TS.content,
      TS.test,
      TS.widget
    ];
    if (sa) steps.push(
      { tab: 'widget', el: tourCard('widget', 'Konfigurasi API AI'), title: 'Konfigurasi API AI',
        body: '<p>Pilih provider AI (Anthropic / OpenRouter), API key, dan model. Kartu rahasia seperti ini hanya terlihat oleh Super Admin.</p>' },
      { tab: 'widget', el: tourCard('widget', 'WhatsApp Bot'), title: 'WhatsApp Bot',
        body: '<p>Hubungkan nomor WhatsApp Business (Meta Cloud API) agar bot menjawab chat WhatsApp. Di bawahnya ada <b>Notifikasi Telegram</b> dan <b>Handoff Otomatis</b>.</p>' }
    );
    steps.push(TS.install, TS.eskalasi);
    steps.push(TS.waList('<p>Anda melihat <b>semua</b> chat. Buka chat untuk <b>Claim</b> dan membalas sendiri, atau <b>Serahkan ke</b> agent.</p>'));
    if (sa) steps.push({ tab: 'tim', el: '#timModeCard', title: 'Mode balasan WhatsApp',
      body: '<p><b>AI + Agent</b>: bot menjawab otomatis, agent mengambil alih lewat Claim.<br><b>Manual</b>: semua chat dibalas agent.</p><p>Di sini juga: agent hanya melihat chat miliknya atau tidak.</p>' });
    steps.push(
      TS.agentReport('Kinerja tim', '<p>Chat ditangani, balasan, respon pertama, dan chat yang belum dibalas — per agent, untuk rentang tanggal pilihan Anda.</p>'),
      TS.users(sa
        ? '<p>Buat akun untuk semua peran: <b>Admin</b>, <b>Supervisor</b>, dan <b>WA Agent</b>. Jumlah Supervisor &amp; Agent dibatasi kursi paket.</p>'
        : '<p>Buat akun <b>Supervisor</b> dan <b>WA Agent</b>. Akun Admin hanya bisa dibuat oleh Super Admin. Jumlah akun dibatasi kursi paket.</p>'),
      TS.pembaruan,
      TS.notif,
      TS.done
    );
    return steps;
  }
  function tourWelcome(base, body) {
    var s = {}; for (var k in base) s[k] = base[k];
    s.body = body;
    return s;
  }

  function tourTabAllowed(tab) {
    var b = document.querySelector('#nav button[data-tab="' + tab + '"]');
    return !!b && can(b.dataset.role);
  }
  function tourTarget(st) {
    if (!st.el) return null;
    var n = typeof st.el === 'function' ? st.el() : document.querySelector(st.el);
    if (!n || !n.getClientRects().length || n.closest('.hide')) return null;
    return n;
  }
  function tourIsMobile() { return window.innerWidth <= 860; }

  function tourEls() {
    var r = document.getElementById('tourRoot');
    if (r) return r;
    r = document.createElement('div');
    r.id = 'tourRoot';
    r.innerHTML = '<div class="tour-block"></div><div class="tour-hole"></div>' +
      '<div class="tour-pop" role="dialog" aria-modal="true" aria-labelledby="tourTitle">' +
        '<button type="button" class="tour-x" data-t="close" title="Tutup panduan (Esc)">' + ico('x', 16) + '</button>' +
        '<div class="tour-step" id="tourStepNo"></div><div id="tourPrev"></div>' +
        '<h4 id="tourTitle"></h4><div class="tour-body" id="tourBody"></div>' +
        '<div class="tour-prog"><i id="tourProg"></i></div>' +
        '<div class="tour-foot"><span class="tour-hint">&larr; &rarr; untuk berpindah</span><div class="tour-btns" id="tourBtnsBar"></div></div>' +
      '</div>';
    document.body.appendChild(r);
    // stopPropagation: handler "klik di luar sidebar" di document tidak boleh menutup menu saat tur
    r.addEventListener('click', function (e) {
      e.stopPropagation();
      var b = e.target.closest('[data-t]');
      if (!b || !tour) return;
      var t = b.dataset.t;
      if (t === 'next') tourGo(tour.i + 1);
      else if (t === 'back') tourGo(tour.i - 1);
      else if (t === 'finish') tourEnd(true);
      else if (t === 'help') { tourEnd(true, true); helpOpen(tour_lastQ()); }
      else tourEnd(false);
    });
    return r;
  }

  function tourGo(i) {
    if (!tour) return;
    var steps = tour.steps;
    // lewati langkah opsional yang targetnya tidak tampil (mis. tombol notifikasi di browser tanpa push)
    var dir = i < tour.i ? -1 : 1;
    i = Math.max(0, Math.min(steps.length - 1, i));
    while (steps[i] && steps[i].optional && i > 0 && i < steps.length - 1) {
      if (steps[i].tab) showTab(steps[i].tab);
      if (tourTarget(steps[i])) break;
      i += dir;
    }
    tour.i = i;
    var st = steps[i];
    if (st.tab) showTab(st.tab);
    if (st.pre) try { st.pre(); } catch (e) {}
    if (tourIsMobile()) toggleSide(!!st.side);
    var node = tourTarget(st);
    if (node) {
      var tall = node.getBoundingClientRect().height > window.innerHeight * 0.6;
      try { node.scrollIntoView({ block: tall ? 'start' : 'center', behavior: 'auto' }); } catch (e) { node.scrollIntoView(); }
    } else if (st.tab) {
      window.scrollTo(0, 0);
    }
    tourText();
    tourPaint();
    clearTimeout(tour.t); clearTimeout(tour.t2);
    tour.t = setTimeout(tourPaint, 320);    // tunggu animasi panel (fade) / sidebar HP
    tour.t2 = setTimeout(tourPaint, 700);
  }

  function tourText() {
    var st = tour.steps[tour.i], n = tour.steps.length, last = tour.i === n - 1;
    var who = ROLE_LABEL[tour.role] || tour.role;
    if (tour.custom) {
      $('#tourStepNo').textContent = n > 1 ? (tour.custom + ' · ' + (tour.i + 1) + '/' + n) : tour.custom;
      $('#tourPrev').innerHTML = '';
      $('#tourTitle').innerHTML = st.title;
      $('#tourBody').innerHTML = st.body;
      $('#tourProg').style.width = Math.round((tour.i + 1) / n * 100) + '%';
      $('#tourBtnsBar').innerHTML = (tour.i === 0 ? '<button type="button" class="btn ghost sm" data-t="help">Cari lagi</button>' : '<button type="button" class="btn ghost sm" data-t="back">Kembali</button>') +
        (last ? '<button type="button" class="btn sm" data-t="finish">Mengerti</button>' : '<button type="button" class="btn sm" data-t="next">Lanjut</button>');
      var fc = document.querySelector('#tourBtnsBar .btn:last-child');
      if (fc) try { fc.focus({ preventScroll: true }); } catch (e) {}
      return;
    }
    $('#tourStepNo').textContent = st.welcome ? ('Panduan ' + who) : ('Langkah ' + tour.i + ' dari ' + (n - 1));
    $('#tourPrev').innerHTML = tour.preview ? '<span class="tour-prev">Pratinjau — tampilan untuk akun ' + esc(who) + '</span>' : '';
    $('#tourTitle').innerHTML = st.welcome
      ? (tour.preview ? 'Panduan untuk ' + esc(who) : 'Selamat datang, ' + esc(user.name || user.username) + '!')
      : st.title;
    $('#tourBody').innerHTML = st.body;
    $('#tourProg').style.width = Math.round(tour.i / (n - 1) * 100) + '%';
    $('#tourBtnsBar').innerHTML = st.welcome
      ? '<button type="button" class="btn ghost sm" data-t="close">Nanti saja</button><button type="button" class="btn sm" data-t="next">Mulai panduan</button>'
      : '<button type="button" class="btn ghost sm" data-t="back">Kembali</button>' +
        (last ? '<button type="button" class="btn sm" data-t="finish">Selesai</button>'
              : '<button type="button" class="btn sm" data-t="next">Lanjut</button>');
    var f = document.querySelector('#tourBtnsBar .btn:last-child');
    if (f) try { f.focus({ preventScroll: true }); } catch (e) {}
  }

  function tourPaint() {
    if (!tour) return;
    var root = tourEls(), st = tour.steps[tour.i];
    var hole = root.querySelector('.tour-hole'), pop = root.querySelector('.tour-pop');
    var vw = window.innerWidth, vh = window.innerHeight, pad = 6, gap = 12, m = 12;
    var node = tourTarget(st), x, y, x2, y2;
    if (node) {
      var r = node.getBoundingClientRect();
      x = Math.max(4, r.left - pad); y = Math.max(4, r.top - pad);
      x2 = Math.min(vw - 4, r.right + pad); y2 = Math.min(vh - 4, r.bottom + pad);
      if (x2 - x < 10 || y2 - y < 10) node = null;   // di luar layar
    }
    if (node) {
      root.classList.remove('center');
      hole.style.left = x + 'px'; hole.style.top = y + 'px';
      hole.style.width = (x2 - x) + 'px'; hole.style.height = (y2 - y) + 'px';
    } else {
      root.classList.add('center');
      hole.style.left = (vw / 2) + 'px'; hole.style.top = (vh / 2) + 'px';
      hole.style.width = '0px'; hole.style.height = '0px';
    }
    var pw = Math.min(380, vw - 2 * m);
    pop.style.width = pw + 'px';
    var ph = pop.offsetHeight, L, T;
    var clampL = function (v) { return Math.max(m, Math.min(vw - pw - m, v)); };
    var clampT = function (v) { return Math.max(m, Math.min(vh - ph - m, v)); };
    if (!node)                              { L = (vw - pw) / 2; T = clampT((vh - ph) / 2); }
    else if (vw - x2 >= pw + gap + m)       { L = x2 + gap; T = clampT(y); }          // kanan (menu samping)
    else if (vh - y2 >= ph + gap + m)       { L = clampL(x); T = y2 + gap; }          // bawah
    else if (y >= ph + gap + m)             { L = clampL(x); T = y - gap - ph; }      // atas
    else if (x >= pw + gap + m)             { L = x - gap - pw; T = clampT(y); }      // kiri
    else                                    { L = (vw - pw) / 2; T = vh - ph - m; }   // menimpa bawah layar
    pop.style.left = Math.round(L) + 'px';
    pop.style.top = Math.round(T) + 'px';
  }
  var tourRaf = 0;
  function tourRepaint() { if (!tour || tourRaf) return; tourRaf = requestAnimationFrame(function () { tourRaf = 0; tourPaint(); }); }
  window.addEventListener('resize', tourRepaint);
  window.addEventListener('scroll', tourRepaint, true);
  document.addEventListener('keydown', function (e) {
    if (!tour) return;
    if (e.key === 'Escape') { e.preventDefault(); tourEnd(false); }
    else if (e.key === 'ArrowRight') { e.preventDefault(); if (tour.i < tour.steps.length - 1) tourGo(tour.i + 1); }
    else if (e.key === 'ArrowLeft') { e.preventDefault(); if (tour.i > 0) tourGo(tour.i - 1); }
  });

  function tourStart(r, preview) {
    if (tour) tourEnd(true, true);
    var steps = tourSteps(r).filter(function (s) { return !s.tab || tourTabAllowed(s.tab); });
    var act = document.querySelector('#nav button.active');
    tour = { role: r, steps: steps, i: 0, preview: !!preview, home: act ? act.dataset.tab : firstTab, t: 0 };
    document.body.classList.add('tour-on');
    tourEls();
    tourGo(0);
  }
  function tourStartCustom(steps, title) {
    if (tour) tourEnd(true, true);
    steps = steps.filter(function (s) { return !s.tab || tourTabAllowed(s.tab); });
    if (!steps.length) return;
    tour = { role: role, steps: steps, i: 0, preview: true, custom: title, home: null, t: 0 };
    document.body.classList.add('tour-on');
    tourEls();
    tourGo(0);
  }
  function tour_lastQ() { var q = document.getElementById('helpQ'); return q ? q.value : ''; }
  function tourEnd(finished, silent) {
    if (!tour) return;
    var t = tour; tour = null;
    clearTimeout(t.t); clearTimeout(t.t2);
    var root = document.getElementById('tourRoot');
    if (root) root.parentNode.removeChild(root);
    document.body.classList.remove('tour-on');
    if (silent) return;
    if (tourIsMobile()) toggleSide(false);
    if (t.custom) return;   // tur mini dari pencarian: biarkan user di halaman tujuan
    if (!t.preview) tourMarkSeen();
    showTab(t.home);
    window.scrollTo(0, 0);
    if (!finished) toast('Cari panduan kapan saja lewat tombol "Panduan" di bawah menu.');
  }

  function tourLsKey() { return 'dei_tour_' + (user.username || ''); }
  function tourSeen() {
    if ((+user.tour_seen || 0) >= TOUR_VER) return true;
    try { return (+localStorage.getItem(tourLsKey()) || 0) >= TOUR_VER; } catch (e) { return false; }
  }
  function tourMarkSeen() {
    user.tour_seen = TOUR_VER;
    try { localStorage.setItem(tourLsKey(), String(TOUR_VER)); localStorage.setItem(UK, JSON.stringify(user)); } catch (e) {}
    api('tour_seen', { method: 'POST', body: { ver: TOUR_VER } }).catch(function () {});
  }

  /* ====================================================================== *
   *  v1.2.74: PUSAT BANTUAN — cari panduan ("cara lihat kontak leads")
   *  Artikel singkat per tugas, disaring per peran. "Tunjukkan di layar"
   *  menjalankan tur mini (mesin tur yang sama) lalu tetap di halaman tujuan.
   * ====================================================================== */
  var R_ALL = 'super_admin,admin,supervisor,wa_agent', R_SPV = 'super_admin,admin,supervisor', R_ADM = 'super_admin,admin', R_SA = 'super_admin';
  function hClick(sel) { return function () { var b = document.querySelector(sel); if (b) b.click(); }; }
  var HELP = [
    { id: 'leads', roles: R_ALL, t: 'Melihat leads (calon pelanggan)', k: 'leads lead prospek calon pelanggan qualified follow up closed ringkasan kartu',
      s: ['Buka menu <b>Leads</b>.', 'Kartu dibuat otomatis oleh AI saat percakapan WhatsApp mencapai 8 pesan.', 'Pakai filter <b>Baru</b>, <b>Qualified</b>, <b>Follow-up</b>, <b>Closed</b>, lalu ubah status di kartu.'],
      show: [{ tab: 'leads', el: '#panel-leads .card', title: 'Filter leads', body: '<p>Pilih status untuk menyaring kartu leads. Kartunya tampil di bawah.</p>' }] },
    { id: 'task', roles: R_ALL, t: 'Membuat to-do (Task) dari bubble chat & kanban Task', k: 'task tugas todo to-do to do kanban pekerjaan catatan notes note bubble pesan new progress pending done closed tenggat deadline',   // v1.2.214: task
      s: ['Di <b>Percakapan WA</b>, klik <b>To-do</b> di bawah bubble pesan. Isi judul, status, ditugaskan ke, tenggat, dan catatan, lalu Simpan.', 'Buka menu <b>Task</b>: kanban New, On Progress, Pending, Done, Closed. Seret kartu (atau ganti dropdown di kartu) untuk mengubah status.', 'Klik kartu untuk detail: tambah catatan, ganti penanggung jawab, atau <b>Buka di chat</b> untuk melompat ke pesan asalnya.'],
      show: [{ tab: 'tasks', el: '#panel-tasks .card', title: 'Task', body: '<p>Saring <b>Tugas saya</b> / <b>Saya buat</b>, cari, atau klik <b>+ Task baru</b>. Papan kanban ada di bawah.</p>' }] },
    { id: 'crm', roles: R_ALL, t: 'Input lead manual, catat aktivitas sales & pengingat follow-up', k: 'crm lead manual input tambah lead aktivitas sales activity record telepon meeting kunjungan follow up pengingat reminder email jatuh tempo due date task lead',   // v1.2.215: crm-aktivitas
      s: ['Di menu <b>Leads</b>, klik <b>+ Lead manual</b> untuk menambah lead dari luar chat (telepon, referensi, event, dll.).', 'Klik <b>Aktivitas &amp; Task</b> di kartu lead: catat telepon, meeting, kunjungan, penawaran, dan jadwalkan <b>follow-up berikutnya</b>. Semua perubahan status, catatan, tag sales, PO dan task tercatat otomatis di riwayat.', 'Centang follow-up saat selesai. Follow-up dan task yang jatuh tempo dikirim lewat email pengingat harian; Admin mengatur jamnya lewat tombol <b>Pengingat</b>.'],
      show: [{ tab: 'leads', el: '#panel-leads .card', title: 'Leads', body: '<p><b>+ Lead manual</b> untuk input lead, <b>Pengingat</b> untuk email jatuh tempo (Admin).</p>' }] },
    { id: 'pipeline', roles: R_ALL, t: 'Pipeline, nilai deal & akun Sales', k: 'pipeline nilai deal rupiah perkiraan closing forecast tertimbang win rate penawaran negosiasi tahap peluang sales login akun sales role',   // v1.2.216: pipeline-sales
      s: ['Isi <b>Nilai deal</b> dan <b>Perkiraan closing</b> di modal Aktivitas &amp; Task lead (atau saat + Lead manual). Kartu lead & kolom kanban menampilkan nilainya.', 'Kartu <b>Pipeline</b> di atas Leads: total terbuka, nilai tertimbang (nilai × peluang tahap), perkiraan closing bulan ini, Close Deal bulan ini, win rate, dan lead yang lewat perkiraan closing. Filter per sales ikut berlaku.', 'Admin: <b>Tahap pipeline</b> untuk ganti nama tahap, peluang (%), dan menyalakan/mematikan Penawaran &amp; Negosiasi. Akun <b>Sales</b> dibuat di Pengguna (data sales &amp; divisi dibuat dari form yang sama) — hanya melihat lead &amp; task miliknya.'],
      show: [{ tab: 'leads', el: '#crmPipe', title: 'Pipeline', body: '<p>Ringkasan nilai pipeline dan perkiraan closing. Ikut filter sales.</p>' }] },
    { id: 'performa', roles: R_ALL, t: 'Laporan performa sales & laporan mingguan', k: 'laporan performa sales kinerja mingguan weekly report email win rate close deal pipeline aktivitas csv',   // v1.2.217: laporan-crm
      s: ['Buka <b>Leads</b>, klik tampilan <b>Performa</b>. Pilih periode (Minggu lalu, Bulan ini, dst. atau tanggal sendiri).', 'Tabel per sales: lead baru, aktivitas, follow-up, PO, Close Deal (jumlah &amp; Rp), win rate, lama closing, pipeline dan perkiraan closing. Unduh lewat <b>CSV</b>. Akun Sales hanya melihat kinerjanya sendiri.', 'Admin: tombol <b>Laporan mingguan</b> untuk mengatur email otomatis (hari, jam, penerima) dan mengirim uji.'],
      show: [{ tab: 'leads', el: '#panel-leads .card', title: 'Performa', body: '<p>Klik <b>Performa</b> di samping Daftar / Kanban.</p>' }] },
    { id: 'notif-wa', roles: 'super_admin,admin,supervisor,wa_agent', t: 'Notifikasi tim lewat WhatsApp (pengingat, laporan, task, lead)', k: 'notifikasi whatsapp wa pengingat reminder jatuh tempo laporan mingguan task baru lead sales transfer chat nomor pengirim notif tim',   // v1.2.222: notif-wa
      s: ['Admin: buka <b>Widget &amp; API</b> &gt; <b>Notifikasi Tim via WhatsApp</b>. Nyalakan, lalu pilih <b>Nomor pengirim</b> dari nomor WhatsApp bisnis yang sudah terhubung (WAHA).', 'Atur tiap jenis: pengingat jatuh tempo &amp; laporan mingguan bisa Email saja, WhatsApp saja, atau keduanya; task baru, lead untuk Sales, dan chat yang diserahkan bisa Mati atau WhatsApp.', 'Isi nomor WhatsApp tiap anggota tim di kartu itu (atau masing-masing lewat <b>Profil Saya</b>), lalu klik <b>Uji</b>. Pesan dari nomor tim ke nomor bisnis tidak dijawab bot.'],
      show: [{ tab: 'widget', el: '#ntfCard', title: 'Notifikasi Tim via WhatsApp', body: '<p>Pilih nomor pengirim, jenis notifikasi, dan nomor WhatsApp tim.</p>' }] },
    { id: 'laporan-sales', roles: 'super_admin,admin,supervisor,sales', t: 'Laporan Sales: performa vs target, aktivitas, produktivitas, forecast, funnel', k: 'laporan sales report activity aktivitas forecast proyeksi produktivitas productivity performa performance target kuota funnel konversi win loss kalah menang umur lead aging diam sumber lead',   // v1.2.221: laporan-sales
      s: ['Buka menu <b>Laporan Sales</b>. Pilih periode (Bulan ini, Kuartal ini, dst.), lalu saring per sales atau divisi bila perlu.', '<b>Performa &amp; Target</b>: nilai &amp; jumlah Close Deal dibanding target, win rate, rata-rata deal, lama closing. <b>Aktivitas</b>: grafik harian, per sales &amp; jenis, daftar aktivitas. <b>Produktivitas</b>: aktivitas per hari kerja, lead disentuh, kepatuhan follow-up, kecepatan respons lead baru.', '<b>Forecast</b>: pipeline per bulan perkiraan closing (commit, best case, tertimbang) dan proyeksi vs target. <b>Funnel &amp; Win/Loss</b>: konversi antar tahap, per sumber lead, alasan kalah. <b>Umur Lead</b>: lead yang lama tidak disentuh.', 'Admin: tombol <b>Target sales</b> untuk mengisi target bulanan per sales. Semua tampilan bisa diunduh lewat <b>CSV</b>. Akun Sales melihat sesuai hak lihatnya.'],
      show: [{ tab: 'salesrep', el: '#srSeg', title: 'Laporan Sales', body: '<p>Pilih tampilan laporan di sini, lalu atur periode &amp; filter di bawahnya.</p>' }] },
    { id: 'divisi-sales', roles: R_ALL, t: 'Divisi sales & hak lihat akun Sales', k: 'divisi sales industri government corporate hak lihat akses role peran cakupan laporan sales lain lihat saja',   // v1.2.219: divisi-sales
      s: ['Di <b>Pengguna</b>, pilih peran <b>Sales</b>, lalu pilih <b>Divisi</b> yang ada atau <b>＋ Divisi baru</b> (mis. Industri, Government, Corporate).', 'Di <b>Pengguna</b>, akun Sales punya <b>Hak lihat</b>: Miliknya saja, Satu divisi (semua sales dengan divisi yang sama), atau Semua sales.', 'Lead &amp; laporan sales lain dalam cakupan itu hanya bisa dilihat (tanda <b>Lihat saja</b>); yang bisa diubah tetap lead miliknya sendiri.'],
      show: [{ tab: 'users', el: '#u_role', title: 'Peran Sales', body: '<p>Pilih Sales, data Sales, lalu Hak lihat.</p>' }] },
    { id: 'kontak', roles: R_ALL, t: 'Melihat kontak & mengubah tag pipeline', k: 'kontak contact nomor pelanggan customer tag pipeline cold warm hot prospect unrated unqualified active churned daftar',
      s: ['Buka menu <b>Kontak</b>.', 'Saring dengan tag: Cold, Warm, Hot Prospect, Active Customer, dst.', 'Klik satu kontak untuk mengubah tag atau melihat detailnya.'],
      show: [{ tab: 'kontak', el: '#panel-kontak .card', title: 'Saring kontak', body: '<p>Klik tag untuk menyaring. Daftar kontak ada di bawah — klik satu kontak untuk mengubah tag.</p>' }] },
    { id: 'kontak-lead', roles: R_ALL, t: 'Melihat kontak yang jadi leads / hot prospect', k: 'kontak leads lead hot prospect warm calon pembeli nomor prospek',
      s: ['Ringkasan percakapannya ada di menu <b>Leads</b> (filter <b>Qualified</b> / <b>Follow-up</b>).', 'Nomor & tag pipeline-nya ada di menu <b>Kontak</b> → filter <b>Hot Prospect</b> atau <b>Warm</b>.', 'Dari kartu kontak, klik <b>Simpan ke HP</b> untuk menyimpan nomornya.'],
      show: [{ tab: 'leads', el: '#panel-leads .card', title: '1. Leads', body: '<p>Ringkasan tiap calon pelanggan. Saring <b>Qualified</b> / <b>Follow-up</b>.</p>' },
             { tab: 'kontak', el: '.contact-filter[data-contact-stage="hot_prospect"]', title: '2. Kontak Hot Prospect', body: '<p>Klik <b>Hot Prospect</b> untuk melihat nomor-nomor yang paling siap membeli.</p>' }] },
    { id: 'simpan-hp', roles: R_ALL, t: 'Menyimpan nomor kontak ke HP', k: 'simpan save nomor hp handphone vcf vcard kontak',
      s: ['Buka menu <b>Kontak</b>.', 'Klik kontak yang diinginkan.', 'Klik <b>Simpan ke HP</b> — file .vcf terunduh dan bisa dibuka di HP.'],
      show: [{ tab: 'kontak', el: '#contactList', title: 'Pilih kontak', body: '<p>Klik satu kontak, lalu tombol <b>Simpan ke HP</b> di kartunya.</p>' }] },
    { id: 'ekspor-kontak', roles: R_SPV, t: 'Ekspor / unduh daftar kontak (CSV)', k: 'ekspor export unduh download csv excel kontak daftar nomor',
      s: ['Buka menu <b>Kontak</b>.', 'Pilih filter bila perlu (mis. Hot Prospect).', 'Klik <b>Ekspor CSV</b> — hanya kontak sesuai filter yang diunduh.'],
      show: [{ tab: 'kontak', el: '#btnExportKontakCsv', title: 'Ekspor CSV', body: '<p>Mengunduh kontak sesuai filter aktif. Bisa dibuka di Excel / Google Sheets.</p>' }] },
    { id: 'vip', roles: R_ALL, t: 'Melihat pelanggan VIP yang ulang tahun hari ini', k: 'ulang tahun birthday vip ultah pelanggan',
      s: ['Buka menu <b>Kontak</b>.', 'Klik filter <b>Ulang Tahun VIP Hari Ini</b>.'],
      show: [{ tab: 'kontak', el: '.contact-filter[data-contact-stage="vip_birthday_today"]', title: 'Ulang Tahun VIP', body: '<p>Menampilkan kontak VIP yang berulang tahun hari ini.</p>' }] },
    { id: 'balas', roles: R_ALL, t: 'Membalas chat WhatsApp pelanggan', k: 'balas reply jawab chat pesan whatsapp wa claim ambil alih manual kirim pelanggan',
      s: ['Buka menu <b>Percakapan WA</b> dan klik chat pelanggan.', 'Klik <b>Claim</b> — bot berhenti menjawab nomor itu.', 'Tulis balasan di kolom bawah, lalu <b>Kirim</b>.'],
      show: [{ tab: 'wachat', el: '#waConvList', title: 'Pilih chat', body: '<p>Klik chat pelanggan yang ingin dibalas.</p>' },
             { tab: 'wachat', el: '#panel-wachat .wachat-thread', title: 'Claim lalu balas', body: '<p>Klik <b>Claim</b>, tulis balasan di kolom bawah, lalu <b>Kirim</b>.</p>' }] },
    { id: 'template', roles: R_ALL, t: 'Memakai template balasan (teks & lampiran)', k: 'template balasan cepat quick reply pintasan shortcut garis miring slash lampiran gambar foto brosur pdf katalog video file attach media',
      s: ['Di kotak balas <b>Percakapan WA</b>, klik tombol <b>Template</b> atau ketik <b>/</b> lalu nama pintasan (mis. <b>/harga</b>), pilih dengan panah lalu <b>Enter</b>.',
          'Bila template punya lampiran (brosur, foto, PDF, video), file langsung terpasang di atas kotak balas dan isi template menjadi keterangannya. Periksa, lalu <b>Kirim</b> atau <b>Jadwalkan</b>.',
          'Membuat/mengubah template (Admin/Supervisor): buka menu <b>Template Balasan</b> di kiri (atau <b>Kelola template</b> di daftar template), isi judul, pintasan, isi, lalu <b>Pilih file</b> di Lampiran bila perlu &rsaquo; <b>Simpan template</b>.',
          'Lampiran: JPG/PNG maks 5 MB, video/audio/PDF/dokumen maks 16 MB. Keterangan maks 1.024 karakter; pesan suara dikirim tanpa keterangan.'],
      show: [{ tab: 'qrtpl', el: '#qrtplRoot', title: 'Template Balasan', body: '<p>Tambah, ubah, atau hapus template beserta lampirannya di sini.</p>' }] },   // v1.2.199: template-media; v1.2.199: template-menu
    { id: 'edit-hapus', roles: R_ALL, t: 'Mengedit atau menghapus pesan yang sudah terkirim', k: 'edit ubah ralat salah ketik typo hapus tarik unsend delete batal kirim pesan terkirim bubble',
      s: ['Di <b>Percakapan WA</b>, arahkan kursor ke bubble pesan keluar (di HP tautan selalu tampil), lalu klik <b>Edit</b> atau <b>Hapus</b> di baris jam pesan.',
          '<b>Edit</b>: ubah isi lalu <b>Simpan</b>. Pesan di WhatsApp pelanggan ikut berubah dengan label Diedit. Hanya pesan teks, paling lama 15 menit setelah dikirim.',
          '<b>Hapus</b>: menarik pesan untuk semua orang (pelanggan melihat Pesan ini telah dihapus), paling lama 48 jam setelah dikirim. Di dashboard isinya tetap terlihat dicoret untuk tim.',
          'Hanya untuk nomor WhatsApp lewat WAHA. WhatsApp API resmi (Meta) tidak menyediakan edit/hapus. WA Agent hanya bisa mengubah pesan yang ia kirim sendiri; Supervisor/Admin semua pesan keluar.'] },   // v1.2.200: edit-hapus-pesan
    { id: 'release', roles: R_ALL, t: 'Mengembalikan chat ke bot / antrean', k: 'release lepas kembalikan bot antrean selesai claim',
      s: ['Buka chat yang sedang Anda pegang di <b>Percakapan WA</b>.', 'Klik <b>Release</b> (kembali ke bot) atau <b>Lepas ke antrean</b> bila mode Manual.'],
      show: [{ tab: 'wachat', el: '#panel-wachat .wachat-thread', title: 'Release', body: '<p>Tombol <b>Release</b> / <b>Lepas ke antrean</b> ada di kepala chat yang sedang Anda pegang.</p>' }] },
    { id: 'serahkan', roles: R_SPV, t: 'Menyerahkan / memindahkan chat ke agent lain', k: 'serahkan pindahkan transfer assign bagi chat agent lain',
      s: ['Buka chat di <b>Percakapan WA</b>.', 'Di kepala chat, pilih agent pada menu <b>Serahkan ke…</b> / <b>Pindahkan ke…</b>.'],
      show: [{ tab: 'wachat', el: '#panel-wachat .wachat-thread', title: 'Serahkan ke agent', body: '<p>Menu <b>Serahkan ke…</b> ada di kepala chat setelah chat dibuka.</p>' }] },
    { id: '24jam', roles: R_ALL, t: 'Kenapa tidak bisa membalas chat? (jendela 24 jam)', k: 'tidak bisa balas gagal kirim 24 jam jendela tertutup template error',
      s: ['WhatsApp hanya mengizinkan balasan teks bebas dalam <b>24 jam</b> sejak pesan terakhir pelanggan.', 'Lewat dari itu, tunggu pelanggan mengirim pesan lagi, atau kirim template resmi lewat <b>Blast WA</b> (Supervisor/Admin).'],
      show: [{ tab: 'wachat', el: '#panel-wachat .wachat-thread', title: 'Catatan jendela 24 jam', body: '<p>Status jendela 24 jam tampil di atas kolom balasan saat chat dibuka.</p>' }] },
    { id: 'webchat', roles: R_ALL, t: 'Melihat chat dari website (widget)', k: 'web website widget pengunjung percakapan web chat situs',
      s: ['Buka menu <b>Percakapan Web</b>.', 'Klik percakapan untuk melihat tanya-jawab pengunjung dengan bot.'],
      show: [{ tab: 'webchat', el: '#webConvList', title: 'Percakapan Web', body: '<p>Daftar percakapan dari widget website.</p>' }] },
    { id: 'notif', roles: R_ALL, t: 'Mengaktifkan notifikasi pesan baru', k: 'notifikasi notif pemberitahuan bunyi alert pesan baru hp push',
      s: ['Klik tombol <b>Notifikasi</b> di bawah menu.', 'Pilih <b>Izinkan</b> pada pertanyaan browser.', 'Di HP, pasang dashboard ke layar utama dulu agar lebih andal (lihat panduan <b>Memasang dashboard di HP</b>).'],   // v1.2.198: pasang-di-hp
      show: [{ el: '#btnNotif', side: true, title: 'Notifikasi', body: '<p>Klik di sini lalu izinkan notifikasi.</p>' }] },
    { id: 'pasang-hp', roles: R_ALL, hot: 1, pdf: 'https://chat.deintegra.com/panduan/pasang-dashboard-di-hp.pdf', t: 'Memasang dashboard di HP (ikon di layar utama)', k: 'pasang install instal shortcut pintasan layar utama home screen homescreen ikon icon aplikasi app hp handphone android iphone ios safari chrome dock pwa tambah bagikan share',
      s: ['Buka alamat dashboard tenant Anda di HP lalu login: <b>Android</b> pakai <b>Chrome</b>, <b>iPhone</b> pakai <b>Safari</b>.',
          '<b>Android (Chrome):</b> ketuk menu <b>&#8942;</b> di kanan atas &rsaquo; <b>Tambahkan ke layar utama</b> atau <b>Instal aplikasi</b> &rsaquo; <b>Instal</b>.',
          '<b>iPhone (Safari):</b> ketuk tombol <b>Bagikan</b> (kotak dengan panah ke atas; bila tidak terlihat, ketuk <b>&bull;&bull;&bull;</b> dulu) &rsaquo; <b>Tambah ke Layar Utama</b> &rsaquo; <b>Tambah</b>.',
          'Ikon <b>DEI</b> muncul di layar utama. Selalu buka dashboard dari ikon itu, lalu aktifkan <b>Notifikasi</b> dan pilih <b>Izinkan</b>. Di iPhone notifikasi hanya jalan bila dibuka dari ikon (iOS 16.4 ke atas).',
          'Satu ikon untuk satu tenant: bila memegang beberapa tenant, pasang dari alamat masing-masing.'] },   // v1.2.198: pasang-di-hp
    { id: 'password', roles: R_ALL, t: 'Mengganti password', k: 'password sandi kata sandi ganti ubah akun login lupa',
      s: ['Buka menu <b>Profil Saya</b>.', 'Isi password lama, password baru (min. 8 karakter), dan konfirmasinya.', 'Klik <b>Simpan Password</b> — Anda akan diminta login ulang.', 'Lupa password? Minta Admin / Supervisor mengaturnya di menu <b>Pengguna</b>.'],
      show: [{ tab: 'profile', el: tourCard('profile', 'Ganti Password'), title: 'Ganti Password', body: '<p>Isi ketiga kolom lalu klik <b>Simpan Password</b>.</p>' }] },
    { id: 'laporan', roles: R_SPV, t: 'Melihat laporan & statistik percakapan', k: 'laporan statistik report jumlah chat traffic utm sumber tren grafik data',
      s: ['Buka menu <b>Laporan &amp; Log</b> → <b>Ringkasan</b>.', 'Atur tanggal & channel, lalu <b>Terapkan Filter</b>.', '<b>Unduh CSV</b> untuk data mentahnya.'],
      show: [{ tab: 'reports', pre: hClick('#repSeg [data-v="summary"]'), el: '#btnExport', title: 'Filter & unduh', body: '<p>Atur tanggal dan channel, lalu <b>Terapkan Filter</b> atau <b>Unduh CSV</b>.</p>' }] },
    { id: 'log', roles: R_SPV, t: 'Melihat log / riwayat semua percakapan', k: 'log riwayat history percakapan status dijawab ai menunggu balasan error',
      s: ['Buka menu <b>Laporan &amp; Log</b> → <b>Log Percakapan</b>.', 'Lihat status tiap chat: dijawab AI, menunggu balasan, dibalas agent.', 'Klik baris untuk detail, atau <b>Unduh CSV</b>.'],
      show: [{ tab: 'reports', pre: hClick('#repSeg [data-v="logs"]'), el: '#repLogs', title: 'Log Percakapan', body: '<p>Klik satu baris untuk melihat detail percakapannya.</p>' }] },
    { id: 'topik', roles: R_SPV, t: 'Melihat topik yang paling sering ditanyakan', k: 'topik pertanyaan sering ditanyakan faq tren analisa',
      s: ['Buka menu <b>Laporan &amp; Log</b> → <b>Topik</b>.', 'Jalankan pemindaian untuk mengelompokkan pertanyaan pelanggan.'],
      show: [{ tab: 'reports', pre: hClick('#repSeg [data-v="topics"]'), el: '#repTopics', title: 'Topik', body: '<p>Ringkasan topik pertanyaan pelanggan.</p>' }] },
    { id: 'kuota', roles: R_SPV, t: 'Melihat sisa kuota / penggunaan bulan ini', k: 'kuota sisa paket limit batas penggunaan usage habis bulan',
      s: ['Buka menu <b>Laporan &amp; Log</b> → <b>Ringkasan</b>.', 'Kartu <b>Penggunaan Bulan Ini</b> menunjukkan balasan AI terpakai, reset, dan pesan WA keluar.'],
      show: [{ tab: 'reports', pre: hClick('#repSeg [data-v="summary"]'), el: '#usageCard', title: 'Penggunaan Bulan Ini', body: '<p>Kuota paket dan grafik 30 hari.</p>' }] },
    { id: 'blast', roles: R_SPV, t: 'Mengirim pesan massal (Blast WA)', k: 'blast broadcast massal kirim banyak template promo pengumuman',
      s: ['Buka menu <b>Blast WA</b>.', 'Pilih template yang sudah disetujui Meta dan isi variabelnya.', 'Pilih penerima (hanya kontak opt-in), lalu kirim. Hasilnya ada di <b>Riwayat Blast</b>.'],
      show: [{ tab: 'blast', el: '#panel-blast .card', title: 'Buat Blast Baru', body: '<p>Pilih template, isi variabel, pilih penerima, lalu kirim.</p>' }] },
    { id: 'kinerja', roles: R_SPV, t: 'Melihat kinerja agent & waktu respon', k: 'kinerja performa agent waktu respon response time ditangani belum dibalas tim laporan agent',
      s: ['Buka menu <b>Laporan &amp; Log</b>, tab <b>Per Agent</b>.', 'Pilih tanggal lalu <b>Tampilkan</b>.'],
      show: [{ tab: 'reports', pre: hClick('#repSeg [data-v="agent"]'), el: '#arCard', title: 'Laporan per Agent', body: '<p>Chat ditangani, balasan, respon pertama, dan belum dibalas per agent.</p>' }] },
    { id: 'laporansales', roles: R_SPV, t: 'Melihat laporan per Sales (chat, PO, Close Deal)', k: 'laporan sales penjualan po close deal lose konversi csv per sales',   // v1.2.205: laporan-pindah
      s: ['Buka menu <b>Laporan &amp; Log</b>, tab <b>Per Sales</b>.', 'Pilih tanggal lalu <b>Tampilkan</b>, atau <b>Unduh CSV</b>.'],
      show: [{ tab: 'reports', pre: hClick('#repSeg [data-v="sales"]'), el: '#slrCard', title: 'Laporan per Sales', body: '<p>Chat di-tag, PO, Close Deal, Close Lose, dan konversi per sales.</p>' }] },
    { id: 'akun', roles: R_SPV, t: 'Menambah akun agent / supervisor', k: 'tambah akun user pengguna agent supervisor admin buat baru staf tim kursi hapus edit reset password',
      s: ['Buka menu <b>Pengguna</b>.', 'Isi username, nama, password, dan pilih peran.', 'Klik simpan. Jumlah akun dibatasi kursi paket.', 'Edit / hapus akun lewat tombol di tabel bawah.'],
      show: [{ tab: 'users', el: tourCard('users', 'Pengguna'), title: 'Tambah Pengguna', body: '<p>Isi formulir lalu simpan.</p>' }] },
    { id: 'kb-tambah', roles: R_ADM, t: 'Menambah / mengubah jawaban bot (Knowledge Base)', k: 'knowledge base kb jawaban bot ai tambah entri ubah edit pertanyaan info produk',
      s: ['Buka menu <b>Knowledge Base</b>.', 'Klik <b>+ Tambah Entri</b> atau edit entri yang ada.', 'Klik <b>Simpan Perubahan</b>, lalu cek di <b>Tes Chatbot</b>.'],
      show: [{ tab: 'kb', pre: hClick('.kb-tab[data-kbtab="entri"]'), el: '#btnAddKb', title: '+ Tambah Entri', body: '<p>Tambahkan tanya-jawab baru. Jangan lupa <b>Simpan Perubahan</b>.</p>' }] },
    { id: 'kb-impor', roles: R_ADM, t: 'Impor Knowledge Base dari CSV / PDF', k: 'impor import csv pdf upload unggah dokumen brosur kb massal',
      s: ['Buka menu <b>Knowledge Base</b>.', 'Klik <b>Impor CSV</b> (format: category, question, answer) atau <b>Impor PDF</b>.', 'Periksa hasilnya lalu klik <b>Simpan Perubahan</b>.'],
      show: [{ tab: 'kb', pre: hClick('.kb-tab[data-kbtab="entri"]'), el: '#btnImportCsv', title: 'Impor', body: '<p><b>Impor CSV</b> atau <b>Impor PDF</b> ada di sini.</p>' }] },
    { id: 'harga', roles: R_ADM, t: 'Mengatur produk & harga', k: 'harga price pricelist daftar harga tarif biaya produk paket varian detail',   // v1.2.171: produk-varian
      s: ['Buka menu <b>Knowledge Base</b> → tab <b>Produk</b>.', 'Klik <b>+ Tambah Produk</b>, isi nama, harga (atau <b>+ Tambah varian</b> untuk beberapa pilihan harga) dan detail produk, lalu simpan.', 'Bot memakai harga & detail ini saat pelanggan bertanya tentang produk.'],
      show: [{ tab: 'kb', pre: hClick('.kb-tab[data-kbtab="harga"]'), el: '#kbTabHarga', title: 'Produk', body: '<p>Kelola produk, varian harga &amp; detailnya di sini.</p>' }] },
    { id: 'gaps', roles: R_ADM, t: 'Melihat pertanyaan yang belum bisa dijawab bot', k: 'belum terjawab tidak tahu gagal jawab gap pertanyaan kosong',
      s: ['Buka menu <b>Knowledge Base</b>.', 'Klik <b>Belum Terjawab</b>.', 'Tambahkan jawabannya ke KB.'],
      show: [{ tab: 'kb', pre: hClick('.kb-tab[data-kbtab="entri"]'), el: '#btnFindGaps', title: 'Belum Terjawab', body: '<p>Daftar pertanyaan pelanggan yang belum ada jawabannya di KB.</p>' }] },
    { id: 'tes', roles: R_ADM, t: 'Mencoba / menguji jawaban bot', k: 'tes test uji coba bot jawaban simulasi',
      s: ['Buka menu <b>Tes Chatbot</b>.', 'Ketik pertanyaan seperti pelanggan, lalu <b>Kirim</b>.'],
      show: [{ tab: 'test', el: '#panel-test .card', title: 'Tes Chatbot', body: '<p>Ketik pertanyaan di kolom bawah.</p>' }] },
    { id: 'sapaan', roles: R_ADM, t: 'Mengubah sapaan, gaya bahasa & teks balasan bot', k: 'sapaan salam greeting gaya bahasa persona teks balasan pesan pembuka bahasa',
      s: ['Buka menu <b>Balasan &amp; Tampilan</b>.', '<b>Konfigurasi Terstruktur</b>: sapaan, bahasa, aturan respon.', '<b>Teks Balasan</b>: pesan pembuka & balasan bawaan. Simpan setelah mengubah.'],
      show: [{ tab: 'content', el: tourCard('content', 'Teks Balasan'), title: 'Teks Balasan', body: '<p>Pesan pembuka dan balasan bawaan bot.</p>' }] },
    { id: 'tampilan', roles: R_ADM, t: 'Mengubah warna & tampilan widget', k: 'warna tampilan widget desain posisi logo bubble look',
      s: ['Buka menu <b>Balasan &amp; Tampilan</b>.', 'Ubah di kartu <b>Tampilan Widget</b>, lalu simpan.'],
      show: [{ tab: 'content', el: tourCard('content', 'Tampilan Widget'), title: 'Tampilan Widget', body: '<p>Warna, posisi, dan tampilan widget di website.</p>' }] },
    { id: 'widget-onoff', roles: R_ADM, t: 'Menyalakan / mematikan widget & tombol WhatsApp', k: 'nyalakan matikan aktifkan nonaktif widget bubble tombol whatsapp website',
      s: ['Buka menu <b>Widget &amp; API</b>.', 'Di <b>Status Widget</b>, geser saklar <b>AI Chatbot Bubble</b> atau <b>WhatsApp Floating Button</b>.'],
      show: [{ tab: 'widget', el: tourCard('widget', 'Status Widget'), title: 'Status Widget', body: '<p>Saklar untuk bubble AI dan tombol WhatsApp.</p>' }] },
    { id: 'form', roles: R_ADM, t: 'Meminta nama & nomor pengunjung sebelum chat', k: 'form data pengunjung nama nomor hp lead form isian sebelum chat',
      s: ['Buka menu <b>Widget &amp; API</b>.', 'Aktifkan <b>Form Data Pengunjung</b>. Datanya masuk ke menu Kontak.'],
      show: [{ tab: 'widget', el: tourCard('widget', 'Form Data Pengunjung'), title: 'Form Data Pengunjung', body: '<p>Aktifkan form dan atur labelnya.</p>' }] },
    { id: 'pasang', roles: R_ADM, t: 'Memasang widget di website', k: 'pasang install embed website gtm google tag manager kode script html',
      s: ['Buka menu <b>Pemasangan (GTM)</b>.', 'Salin kode Custom HTML ke Google Tag Manager, atau pakai kode pasang langsung.'],
      show: [{ tab: 'install', el: tourCard('install', 'Langkah Pemasangan'), title: 'Pemasangan', body: '<p>Ikuti langkahnya, lalu salin kode di bawah.</p>' }] },
    { id: 'eskalasi', roles: R_ADM, t: 'Mengatur pesan penutup otomatis & alarm darurat', k: 'auto closing penutup eskalasi darurat alarm emergency pushover tamu menunggu lama',
      s: ['Buka menu <b>Respon &amp; Eskalasi</b>.', '<b>Auto-Closing</b>: pesan penutup ke tamu yang diam.', '<b>Eskalasi Darurat</b>: alarm ke Supervisor/Manager bila tamu menunggu tanpa balasan.'],
      show: [{ tab: 'eskalasi', el: tourCard('eskalasi', 'Auto-Closing'), title: 'Auto-Closing', body: '<p>Pesan penutup otomatis.</p>' },
             { tab: 'eskalasi', el: tourCard('eskalasi', 'Eskalasi Darurat'), title: 'Eskalasi Darurat', body: '<p>Alarm saat tamu menunggu terlalu lama.</p>' }] },
    { id: 'jamai', roles: R_ADM, t: 'Mengatur jam aktif AI (mis. AI malam, agent siang)', k: 'jam aktif ai jadwal timer malam siang jam kerja kantor agent shift luar jam operasional',   // v1.2.204: jam-ai
      s: ['Buka menu <b>Respon &amp; Eskalasi</b>.', 'Di kartu <b>Jam Aktif AI (WhatsApp)</b>, nyalakan jadwal dan isi jam AI aktif (mis. 21:00 sampai 09:00).', 'Di luar jam itu semua chat WhatsApp ditangani agent. Klik <b>Simpan</b>.'],
      show: [{ tab: 'eskalasi', el: tourCard('eskalasi', 'Jam Aktif AI (WhatsApp)'), title: 'Jam Aktif AI', body: '<p>Atur kapan AI membalas.</p>' }] },
    { id: 'mode', roles: R_SA, t: 'Mengubah mode balasan WhatsApp (AI / Manual)', k: 'mode manual ai otomatis matikan bot agent saja balasan whatsapp',
      s: ['Buka menu <b>Tim &amp; Agent</b>.', 'Pilih <b>AI + Agent</b> atau <b>Manual</b>, lalu <b>Simpan</b>.'],
      show: [{ tab: 'tim', el: '#timModeCard', title: 'Mode Balasan WhatsApp', body: '<p>Pilih mode lalu Simpan.</p>' }] },
    { id: 'api', roles: R_SA, t: 'Mengganti API key / model AI', k: 'api key model ai claude openrouter gemini gpt provider konfigurasi',
      s: ['Buka menu <b>Widget &amp; API</b>.', 'Ubah di kartu <b>Konfigurasi API AI</b>, lalu simpan.'],
      show: [{ tab: 'widget', el: tourCard('widget', 'Konfigurasi API AI'), title: 'Konfigurasi API AI', body: '<p>Provider, API key, dan model.</p>' }] },
    { id: 'wa-connect', roles: R_SA, t: 'Menghubungkan nomor WhatsApp ke bot', k: 'hubungkan connect whatsapp nomor meta cloud api bot token webhook',
      s: ['Buka menu <b>Widget &amp; API</b>.', 'Isi kartu <b>WhatsApp Bot</b> (Meta Cloud API), lalu simpan.'],
      show: [{ tab: 'widget', el: tourCard('widget', 'WhatsApp Bot'), title: 'WhatsApp Bot', body: '<p>Pengaturan koneksi WhatsApp.</p>' }] },
    { id: 'update', roles: R_ADM, t: 'Memasang pembaruan / melihat fitur baru', k: 'pembaruan update versi rilis fitur baru upgrade',
      s: ['Buka menu <b>Pembaruan</b>.', 'Bila ada versi baru, klik <b>Pasang pembaruan</b>.'],
      show: [{ tab: 'pembaruan', el: '#panel-pembaruan .rel-hero', title: 'Pembaruan', body: '<p>Versi Anda dan rilis terbaru.</p>' }] },
    { id: 'tur', roles: R_ALL, t: 'Mengulang tur panduan lengkap', k: 'tur panduan tutorial ulang awal pengenalan belajar',
      s: ['Klik <b>Mulai tur lengkap</b> di bagian bawah jendela ini.'], show: null }
  ];
  var HELP_STOP = ' cara gimana bagaimana gmn gimna untuk utk buat bisa mau ingin saya aku kita yang yg di ke dari dan atau ini itu nya dong deh ya apa mana kok kenapa tolong mohon how to the a ';
  var HELP_SYN = { chat: 'percakapan pesan', pesan: 'chat', wa: 'whatsapp', whatsapp: 'wa', customer: 'pelanggan', pelanggan: 'customer kontak', tamu: 'pelanggan',
    lead: 'leads', prospek: 'leads prospect', contact: 'kontak', nomor: 'kontak', export: 'ekspor', download: 'unduh', unduh: 'ekspor', sandi: 'password',
    notif: 'notifikasi', kb: 'knowledge', jawaban: 'knowledge', harga: 'price', lihat: 'melihat', liat: 'melihat', cek: 'melihat', user: 'akun pengguna',
    akun: 'pengguna', staf: 'agent', cs: 'agent', admin: 'pengguna', report: 'laporan', statistik: 'laporan', broadcast: 'blast', reply: 'balas', jawab: 'balas', ga: 'tidak', gak: 'tidak', nggak: 'tidak', gk: 'tidak', engga: 'tidak', gagal: 'tidak' };
  function helpNorm(s) { return String(s || '').toLowerCase().replace(/<[^>]+>/g, ' ').replace(/&amp;/g, '&').replace(/[^a-z0-9À-ɏ]+/g, ' ').trim(); }
  function helpTokens(q) {
    var out = [];
    helpNorm(q).split(' ').forEach(function (w) {
      if (!w || HELP_STOP.indexOf(' ' + w + ' ') !== -1) return;
      w = w.replace(/(nya|kah|lah)$/, '') || w;
      out.push([w]);
      if (HELP_SYN[w]) out[out.length - 1] = out[out.length - 1].concat(HELP_SYN[w].split(' '));
    });
    return out;   // tiap token = daftar alternatif (sinonim)
  }
  function helpScore(a, toks) {
    if (!a._t) { a._t = ' ' + helpNorm(a.t) + ' '; a._k = ' ' + helpNorm(a.k) + ' '; a._s = ' ' + helpNorm(a.s.join(' ')) + ' '; }
    var score = 0, hit = 0;
    toks.forEach(function (alts) {
      var best = 0;
      alts.forEach(function (w) {
        var whole = ' ' + w + ' ', part = w.length >= 4 ? w : null;
        if (a._t.indexOf(whole) !== -1) best = Math.max(best, 6); else if (part && a._t.indexOf(part) !== -1) best = Math.max(best, 4);
        if (a._k.indexOf(whole) !== -1) best = Math.max(best, 4); else if (part && a._k.indexOf(part) !== -1) best = Math.max(best, 3);
        if (a._s.indexOf(whole) !== -1) best = Math.max(best, 1.5); else if (part && a._s.indexOf(part) !== -1) best = Math.max(best, 1);
      });
      if (best) { hit++; score += best; }
    });
    return hit ? score * (hit / toks.length) : 0;   // utamakan artikel yang cocok dengan lebih banyak kata
  }
  function helpList() {
    return HELP.filter(function (a) {
      if (!can(a.roles)) return false;
      return !a.show || a.show.every(function (s) { return !s.tab || tourTabAllowed(s.tab); });
    });
  }
  var HELP_POPULAR = { wa_agent: ['pasang-hp', 'balas', 'kontak-lead', 'leads', 'kontak', '24jam', 'password'],
    supervisor: ['pasang-hp', 'serahkan', 'kinerja', 'kontak-lead', 'akun', 'laporan', 'blast'],
    admin: ['pasang-hp', 'kb-tambah', 'kontak-lead', 'laporan', 'akun', 'pasang', 'sapaan'],
    super_admin: ['pasang-hp', 'kb-tambah', 'kontak-lead', 'laporan', 'akun', 'mode', 'api'] };

  function helpEls() {
    var r = document.getElementById('helpRoot');
    if (r) return r;
    r = document.createElement('div');
    r.id = 'helpRoot';
    r.innerHTML = '<div class="help-back" data-h="close"></div>' +
      '<div class="help-box" role="dialog" aria-modal="true" aria-labelledby="helpTitle">' +
        '<div class="help-head"><div><b id="helpTitle">Pusat Bantuan</b><small>Ketik pertanyaan Anda, mis. "cara lihat kontak leads"</small></div>' +
          '<button type="button" class="help-x" data-h="close" title="Tutup (Esc)">' + ico('x', 18) + '</button></div>' +
        '<div class="help-search">' + ico('search', 17) + '<input type="search" id="helpQ" placeholder="Cari panduan… (kontak, balas chat, password)" autocomplete="off" enterkeyhint="search"></div>' +
        '<div class="help-res" id="helpRes"></div>' +
        '<div class="help-foot"><span>Baru memakai dashboard?</span><button type="button" class="btn sm" data-h="tour">' + ico('circle-help', 15) + ' Mulai tur lengkap</button></div>' +
      '</div>';
    document.body.appendChild(r);
    r.addEventListener('click', function (e) {
      e.stopPropagation();
      var b = e.target.closest('[data-h]'); if (!b) return;
      var h = b.dataset.h;
      if (h === 'close') helpClose();
      else if (h === 'tour') { helpClose(); tourStart(role, false); }
      else if (h === 'open') { var it = b.closest('.help-item'); var was = it.classList.contains('open'); $$('#helpRes .help-item').forEach(function (x) { x.classList.remove('open'); }); if (!was) it.classList.add('open'); }
      else if (h === 'show') helpShow(b.dataset.id);
      else if (h === 'q') { $('#helpQ').value = b.dataset.q; helpRender(); }
      else if (h === 'install' && pwaPrompt) { var pp = pwaPrompt; pwaPrompt = null; pp.prompt(); (pp.userChoice || Promise.resolve({})).then(function () { helpRender(); }); }   // v1.2.198: pasang-di-hp
    });
    var deb;
    $('#helpQ').addEventListener('input', function () { clearTimeout(deb); deb = setTimeout(helpRender, 120); });
    $('#helpQ').addEventListener('keydown', function (e) {
      if (e.key === 'Enter') { e.preventDefault(); var first = document.querySelector('#helpRes .help-item [data-h="show"]'); if (first) first.click(); }
    });
    hsMount(r);   // v1.2.194: asisten-bantuan
    return r;
  }
  // v1.2.198: pasang-di-hp: prompt instal bawaan browser (Android/Chrome); iPhone tidak punya, cukup ikuti langkah
  var pwaPrompt = null;
  window.addEventListener('beforeinstallprompt', function (e) { e.preventDefault(); pwaPrompt = e; });
  window.addEventListener('appinstalled', function () { pwaPrompt = null; toast('Dashboard terpasang di layar utama.'); });
  function pwaStandalone() { try { return window.matchMedia('(display-mode: standalone)').matches || window.navigator.standalone === true; } catch (e) { return false; } }
  function helpExtra(a) {
    if (!a.pdf) return '';
    var h = '';
    if (a.id === 'pasang-hp' && pwaStandalone()) h += '<p class="help-ok">' + ico('check-circle-2', 14) + ' Dashboard ini sudah terbuka dari ikon layar utama.</p>';
    else if (a.id === 'pasang-hp' && pwaPrompt) h += '<button type="button" class="btn sm primary" data-h="install">' + ico('monitor-smartphone', 14) + ' Pasang sekarang</button> ';
    return h + '<a class="btn sm" href="' + a.pdf + '" target="_blank" rel="noopener">' + ico('file-text', 14) + ' Unduh panduan PDF bergambar</a> ';
  }
  function helpItem(a, open) {
    return '<div class="help-item' + (open ? ' open' : '') + (a.hot ? ' hot' : '') + '">' +
      '<button type="button" class="help-q" data-h="open"><span>' + a.t + (a.hot ? ' <em class="help-hot">Sering ditanyakan</em>' : '') + '</span>' + ico('chevron-down', 16) + '</button>' +
      '<div class="help-a"><ol>' + a.s.map(function (x) { return '<li>' + x + '</li>'; }).join('') + '</ol>' + helpExtra(a) +
      (a.pdf && !a.show ? '' : a.show ? '<button type="button" class="btn sm" data-h="show" data-id="' + a.id + '">' + ico('sparkles', 14) + ' Tunjukkan di layar</button>'
              : '<button type="button" class="btn sm" data-h="tour">' + ico('circle-help', 14) + ' Mulai tur lengkap</button>') +
      '</div></div>';
  }
  function helpRender() {
    var q = $('#helpQ').value.trim(), list = helpList(), box = $('#helpRes');
    if (!q) {
      var pop = (HELP_POPULAR[role] || []).map(function (id) { return list.filter(function (a) { return a.id === id; })[0]; }).filter(Boolean);
      box.innerHTML = '<div class="help-lbl">Sering dicari</div>' + pop.map(function (a) { return helpItem(a, false); }).join('') +
        '<div class="help-lbl">Semua topik (' + list.length + ')</div>' +
        '<div class="help-chips">' + list.filter(function (a) { return pop.indexOf(a) === -1; }).map(function (a) {
          return '<button type="button" data-h="q" data-q="' + esc(helpNorm(a.t)) + '">' + a.t + '</button>'; }).join('') + '</div>';
      return;
    }
    var toks = helpTokens(q);
    var res = toks.length ? list.map(function (a) { return { a: a, s: helpScore(a, toks) }; })
      .filter(function (x) { return x.s > 0; }).sort(function (x, y) { return y.s - x.s; }).slice(0, 6) : [];
    if (res.length) res = res.filter(function (x) { return x.s >= res[0].s * 0.35; });   // buang hasil yang terlalu lemah
    box.innerHTML = res.length
      ? '<div class="help-lbl">' + res.length + ' hasil</div>' + res.map(function (x, i) { return helpItem(x.a, i === 0); }).join('')
      : '<div class="help-empty">Belum ketemu panduan untuk "<b>' + esc(q) + '</b>".<br>Coba kata lain, misalnya <a href="#" data-h="q" data-q="kontak">kontak</a>, <a href="#" data-h="q" data-q="balas chat">balas chat</a>, atau <a href="#" data-h="q" data-q="password">password</a>.</div>';
  }
  function helpOpen(q) {
    if (tour) tourEnd(true, true);
    var r = helpEls();
    r.classList.add('on');
    document.body.classList.add('help-on');
    if (tourIsMobile()) toggleSide(false);
    $('#helpQ').value = q || '';
    helpRender();
    hsOnOpen();   // v1.2.194: asisten-bantuan
    setTimeout(function () { try { $('#helpQ').focus(); } catch (e) {} }, 30);
  }
  function helpClose() {
    var r = document.getElementById('helpRoot');
    if (r) r.classList.remove('on');
    document.body.classList.remove('help-on');
  }
  function helpShow(id) {
    var a = HELP.filter(function (x) { return x.id === id; })[0];
    if (!a || !a.show) return;
    helpClose();
    tourStartCustom(a.show, a.t);
  }
  document.addEventListener('keydown', function (e) {
    var on = document.body.classList.contains('help-on');
    if (on && e.key === 'Escape') { e.preventDefault(); helpClose(); return; }
    // "/" membuka pencarian panduan (kecuali sedang mengetik)
    if (!on && !tour && e.key === '/' && !/^(input|textarea|select)$/i.test((e.target.tagName || '')) && !e.target.isContentEditable) { e.preventDefault(); helpOpen(''); }
  });
  window.deiHelp = helpOpen;

  /* ====================================================================== *
   *  v1.2.194: asisten-bantuan — Asisten Bantuan di dalam Pusat Bantuan.
   *  Pertanyaan dikirim ke tenant Support (alamat dari pusat lewat
   *  support_info) beserta konteks: bisnis, peran, paket, versi, menu aktif.
   *  Di bawah jawaban: "Tunjukkan di layar" (artikel Pusat Bantuan yang cocok)
   *  dan "Buka menu …" (menu yang disebut jawaban).
   * ====================================================================== */
  var HS = { info: null, at: 0, conv: '', busy: false, msgs: [], wa: null, waAsked: false, human: null, seen: 0, hold: '', agentName: '', timer: null };   // v1.2.195: web-balas
  var HS_MENUS = { reports: 'Laporan & Log', wachat: 'Percakapan WA', webchat: 'Percakapan Web', blast: 'Blast WA', leads: 'Leads', kontak: 'Kontak',
    topik: 'Topik & Divisi', gc: 'Customer Feedback', tim: 'Tim & Agent', kb: 'Knowledge Base', content: 'Balasan & Tampilan', test: 'Tes Chatbot',
    widget: 'Widget & API', eskalasi: 'Respon & Eskalasi', users: 'Pengguna', profile: 'Profil Saya', install: 'Pemasangan (GTM)', pembaruan: 'Pembaruan' };
  function hsLoad(cb) {
    if (HS.info && Date.now() - HS.at < 300000) { cb(HS.info); return; }
    api('support_info').then(function (r) {
      HS.info = (r && r.ok && r.enabled && r.base) ? r : { enabled: false }; HS.at = Date.now(); cb(HS.info);
    }).catch(function () { cb({ enabled: false }); });
  }
  function hsPost(action, body) {
    return fetch(HS.info.base + '/api/index.php?action=' + action, { method: 'POST', headers: { 'Content-Type': 'application/json' }, body: JSON.stringify(body || {}) })
      .then(function (r) { return r.json(); });
  }
  function hsVid(v) {
    var k = 'dei_sp_vid';
    try { if (v) { localStorage.setItem(k, v); return v; } return localStorage.getItem(k) || ''; } catch (e) { return v || ''; }
  }
  function hsCtx() {
    var c = {}, src = (HS.info && HS.info.ctx) || {}, a = document.querySelector('#nav button.active');
    Object.keys(src).forEach(function (k) { c[k] = src[k]; });
    if (a && a.dataset.tab) c.tab = a.dataset.tab;
    return c;
  }
  function hsMount(r) {
    var box = r.querySelector('.help-box'), res = r.querySelector('#helpRes'), foot = r.querySelector('.help-foot');
    if (!box || !res || r.querySelector('#helpAsk')) return;
    var ask = document.createElement('div');
    ask.className = 'help-ask'; ask.id = 'helpAsk'; ask.hidden = true;
    ask.innerHTML = '<button type="button" data-hs="ask">' + ico('sparkles', 15) + ' <span id="helpAskTxt">Tanya Asisten Bantuan</span></button>';
    box.insertBefore(ask, res);
    var chat = document.createElement('div');
    chat.className = 'help-chat'; chat.id = 'helpChat';
    chat.innerHTML = '<div class="hc-top"><button type="button" class="btn sm" data-hs="back">' + ico('arrow-left', 14) + ' Panduan</button><b>Asisten Bantuan</b><small>Dijawab AI. Periksa lagi hal penting.</small></div>' +
      '<div class="hc-list" id="hcList"></div>' +
      '<div class="hc-wa" id="hcWa" hidden></div>' +
      '<form class="hc-in" id="hcForm"><textarea id="hcQ" rows="1" maxlength="1000" placeholder="Tulis pertanyaan… mis. cara tambah nomor WhatsApp"></textarea><button type="submit" class="btn" id="hcSend">Kirim</button></form>';
    box.insertBefore(chat, foot);
    r.addEventListener('click', function (e) {
      var b = e.target.closest('[data-hs]'); if (!b) return;
      var h = b.dataset.hs;
      if (h === 'ask') hsOpenChat($('#helpQ').value.trim());
      else if (h === 'back') { box.classList.remove('chat'); try { $('#helpQ').focus(); } catch (er) {} }
      else if (h === 'show') helpShow(b.dataset.id);
      else if (h === 'menu') { helpClose(); showTab(b.dataset.tab); }
      else if (h === 'human') hsHuman();   // v1.2.195: web-balas
    });
    $('#hcForm').addEventListener('submit', function (e) { e.preventDefault(); var t = $('#hcQ').value.trim(); if (t) { $('#hcQ').value = ''; hsSend(t); } });
    $('#hcQ').addEventListener('keydown', function (e) { if (e.key === 'Enter' && !e.shiftKey) { e.preventDefault(); $('#hcForm').dispatchEvent(new Event('submit', { cancelable: true })); } });
    $('#helpQ').addEventListener('input', hsAskLabel);
    $('#helpQ').addEventListener('keydown', function (e) {   // Enter tanpa hasil panduan -> tanya asisten
      if (e.key === 'Enter' && !$('#helpAsk').hidden && $('#helpQ').value.trim() && !document.querySelector('#helpRes .help-item [data-h="show"]')) { e.preventDefault(); hsOpenChat($('#helpQ').value.trim()); }
    });
  }
  function hsAskLabel() {
    var q = ($('#helpQ') ? $('#helpQ').value.trim() : ''), t = $('#helpAskTxt');
    if (t) t.textContent = q ? 'Tanya Asisten: "' + (q.length > 48 ? q.slice(0, 48) + '…' : q) + '"' : 'Tanya Asisten Bantuan';
  }
  function hsOnOpen() {
    var r = document.getElementById('helpRoot'); if (!r) return;
    var box = r.querySelector('.help-box'); if (box) box.classList.remove('chat');
    hsAskLabel();
    hsLoad(function (inf) { var a = $('#helpAsk'); if (a) a.hidden = !inf.enabled; });
  }
  function hsOpenChat(q) {
    var box = document.querySelector('#helpRoot .help-box'); if (!box || !HS.info || !HS.info.enabled) return;
    box.classList.add('chat');
    if (!HS.msgs.length) HS.msgs.push({ r: 'a', t: 'Halo! Saya Asisten Bantuan DEI Chatbot. Tanyakan cara pengaturan, letak menu, atau paket.' });
    hsRender();
    hsWa();
    if (HS.conv) hsPoll();   // v1.2.195: web-balas
    if (q) hsSend(q); else setTimeout(function () { try { $('#hcQ').focus(); } catch (e) {} }, 30);
  }
  function hsWa() {
    if (HS.waAsked) return; HS.waAsked = true;
    fetch(HS.info.base + '/api/index.php?action=bootstrap').then(function (r) { return r.json(); }).then(function (j) {
      var c = (j && j.config) || {}, n = String(c.whatsapp_number || '').replace(/\D/g, '');
      if (c.web_human && c.web_human.enabled) HS.human = c.web_human;   // v1.2.195: web-balas — tim DEI membalas di panel ini
      else if (c.whatsapp_enabled && n.length >= 8) {
        var x = hsCtx(), txt = 'Halo tim DEI, saya butuh bantuan DEI Chatbot.' + (x.tenant_id ? ' (tenant ' + x.tenant_id + (x.version ? ', ' + x.version : '') + ')' : '');
        HS.wa = 'https://wa.me/' + n + '?text=' + encodeURIComponent(txt);
      }
      hsFoot();
    }).catch(function () {});
  }
  function hsActions(q, ans) {
    var acts = [], toks = helpTokens(q);
    if (toks.length) {
      var best = helpList().map(function (a) { return { a: a, s: helpScore(a, toks) }; }).filter(function (x) { return x.a.show && x.s >= 5; }).sort(function (x, y) { return y.s - x.s; })[0];
      if (best) acts.push({ k: 'show', id: best.a.id, t: best.a.t });
    }
    var low = String(ans || '').toLowerCase(), n = 0;
    Object.keys(HS_MENUS).forEach(function (tab) {
      if (n >= 2 || low.indexOf(HS_MENUS[tab].toLowerCase()) === -1) return;
      if (!document.querySelector('#nav button[data-tab="' + tab + '"]') || !tourTabAllowed(tab)) return;
      if (acts.some(function (x) { return x.k === 'show' && (HELP.filter(function (h) { return h.id === x.id; })[0].show[0] || {}).tab === tab; })) return;   // sudah diwakili "Tunjukkan di layar"
      acts.push({ k: 'menu', tab: tab, t: HS_MENUS[tab] }); n++;
    });
    return acts;
  }
  function hsRender(typing) {
    var el = $('#hcList'); if (!el) return;
    el.innerHTML = HS.msgs.map(function (m) {
      var h = '<div class="hc-m ' + (m.r === 'u' ? 'u' : m.r === 't' ? 'a t' : 'a') + (m.err ? ' err' : '') + '"><div class="hc-b">' + (m.by ? '<div class="hc-by">' + esc(m.by) + ' · tim DEI</div>' : '') + esc(m.t).replace(/\n/g, '<br>') + '</div>';   // v1.2.195: web-balas
      if (m.acts && m.acts.length) h += '<div class="hc-acts">' + m.acts.map(function (x) {
        return x.k === 'show' ? '<button type="button" data-hs="show" data-id="' + esc(x.id) + '">' + ico('sparkles', 13) + ' Tunjukkan di layar: ' + x.t + '</button>'
                              : '<button type="button" data-hs="menu" data-tab="' + esc(x.tab) + '">Buka menu ' + esc(x.t) + ' →</button>'; }).join('') + '</div>';
      return h + '</div>';
    }).join('') + (typing ? '<div class="hc-m a"><div class="hc-b hc-typing">Asisten sedang mengetik…</div></div>' : '');
    el.scrollTop = el.scrollHeight;
  }
  function hsSend(text) {
    if (HS.busy || !HS.info || !HS.info.enabled) return;
    text = String(text).slice(0, 1000);
    HS.busy = true; HS.msgs.push({ r: 'u', t: text }); hsRender(true);
    if ($('#hcSend')) $('#hcSend').disabled = true;
    var fail = function (msg) { HS.msgs.push({ r: 'a', err: true, t: msg || 'Asisten sedang tidak bisa dihubungi. Coba lagi sebentar lagi' + (HS.human ? ', atau klik ' + (HS.human.label || 'Bicara dengan tim DEI') + ' di bawah.' : HS.wa ? ', atau chat tim DEI lewat WhatsApp di bawah.' : '.') }); };
    var conv = hsEnsureConv();   // v1.2.195: web-balas
    conv.then(function (cid) {
      return hsPost('chat', { message: text, conversation_id: cid, visitor_id: hsVid(), history: [], context: hsCtx() });
    }).then(function (j) {
      if (j && j.ok && j.held) { HS.hold = (j.status || {}).hold || 'req'; HS.agentName = (j.status || {}).agent_name || ''; hsFoot(); }   // v1.2.195: web-balas
      else if (j && j.ok && j.answer) HS.msgs.push({ r: 'a', t: String(j.answer), acts: (j.suspended || j.cap_reached) ? [] : hsActions(text, j.answer) });
      else fail(j && j.error && /terlalu banyak/i.test(j.error) ? j.error : '');
    }).catch(function () { fail(''); }).then(function () {
      HS.busy = false; hsRender(false);
      if ($('#hcSend')) $('#hcSend').disabled = false;
      try { $('#hcQ').focus(); } catch (e) {}
      hsPollSchedule();
    });
  }
  /* v1.2.195: web-balas — bicara dengan tim DEI langsung di panel Asisten */
  function hsEnsureConv() {
    if (HS.conv) return Promise.resolve(HS.conv);
    return hsPost('web_conv_new', { visitor_id: hsVid() }).then(function (j) {
      if (!j || !j.ok || !j.conversation_id) throw new Error((j && j.error) || 'conv');
      hsVid(j.visitor_id || ''); HS.conv = j.conversation_id; HS.seen = 1; return HS.conv;
    });
  }
  function hsFoot() {
    var el = $('#hcWa'); if (!el) return;
    if (HS.hold === 'agent') { el.hidden = false; el.innerHTML = '<b style="color:#15803d">Terhubung dengan ' + esc(HS.agentName || 'tim DEI') + '.</b> Balasan tim muncul di percakapan ini.'; return; }
    if (HS.hold === 'req') { el.hidden = false; el.innerHTML = 'Pesan Anda diteruskan ke tim DEI. Mohon tunggu, balasan muncul di sini (panel boleh ditutup).'; return; }
    if (HS.human) { el.hidden = false; el.innerHTML = 'Belum terjawab? <button type="button" class="hc-human" data-hs="human">' + esc(HS.human.label || 'Bicara dengan tim DEI') + '</button>'; return; }
    if (HS.wa) { el.hidden = false; el.innerHTML = 'Belum terjawab? <a href="' + esc(HS.wa) + '" target="_blank" rel="noopener">Chat tim DEI lewat WhatsApp</a>'; return; }
    el.hidden = true;
  }
  function hsHuman() {
    if (!HS.info || !HS.info.enabled) return;
    var el = $('#hcWa'); if (el) el.textContent = 'Menghubungi tim DEI…';
    hsEnsureConv().then(function (cid) {
      return hsPost('web_human', { conversation_id: cid, visitor_id: hsVid(), context: hsCtx() });
    }).then(function (j) {
      if (!j || !j.ok) throw new Error((j && j.error) || 'gagal');
      (j.messages || []).forEach(function (m) { if (m.sys === 'human_req') HS.msgs.push({ r: 'a', t: m.content }); });
      HS.seen = Math.max(HS.seen, j.total || 0);
      HS.hold = (j.status || {}).hold || 'req'; HS.agentName = (j.status || {}).agent_name || '';
      hsRender(); hsFoot(); hsPollSchedule();
    }).catch(function () { HS.msgs.push({ r: 'a', err: true, t: 'Gagal menghubungi tim DEI. Coba lagi sebentar lagi.' }); hsRender(); hsFoot(); });
  }
  /* v1.2.196: tombol-bantuan — tombol headset di sebelah nama pengguna, langsung ke chat Asisten */
  function hsSupInit() {
    var b = $('#btnSupport'); if (!b || b.dataset.wired) return;
    b.dataset.wired = '1';
    b.innerHTML = ico('headphones', 18) + '<i class="dot"></i>';
    b.onclick = function (e) {
      e.stopPropagation();
      b.classList.remove('has-new', 'pulse');
      helpOpen('');
      hsLoad(function (inf) { if (inf.enabled) hsOpenChat(''); });
    };
    hsLoad(function (inf) {
      b.hidden = !inf.enabled;
      if (inf.enabled) b.classList.add('pulse');
    });
  }
  setTimeout(hsSupInit, 0);
  function hsPollSchedule() {
    if (HS.timer) { clearTimeout(HS.timer); HS.timer = null; }
    if (!HS.conv || !HS.info) return;
    var isOpen = !!document.querySelector('#helpRoot.on .help-box.chat');
    if (!isOpen && !HS.hold) return;   // panel tertutup: tetap memeriksa hanya selama menunggu / terhubung dengan tim
    HS.timer = setTimeout(hsPoll, isOpen && HS.hold ? 4000 : 15000);
  }
  function hsPoll() {
    if (HS.timer) { clearTimeout(HS.timer); HS.timer = null; }
    if (!HS.conv || !HS.info) return;
    var isOpen = !!document.querySelector('#helpRoot.on .help-box.chat');
    fetch(HS.info.base + '/api/index.php?action=web_poll&conversation_id=' + encodeURIComponent(HS.conv) + '&visitor_id=' + encodeURIComponent(hsVid()) + '&after=' + HS.seen)
      .then(function (r) { return r.json(); })
      .then(function (j) {
        if (!j || !j.ok) return;
        var got = 0;
        (j.messages || []).forEach(function (m) {
          if (m.role === 'agent') { HS.msgs.push({ r: 't', t: m.content, by: m.by || 'Tim' }); got++; }
          else if (m.sys && m.sys !== 'human_req') { HS.msgs.push({ r: 'a', t: m.content }); got++; }
        });
        HS.seen = Math.max(HS.seen, j.total || 0);
        var st = j.status || {}; HS.hold = st.hold || ''; HS.agentName = st.agent_name || '';
        if (got) { if (isOpen && !HS.busy) hsRender(false); else if (!isOpen) { toast('Balasan baru dari tim DEI. Klik tombol Bantuan (ikon headset) di bawah menu.'); if ($('#btnSupport')) $('#btnSupport').classList.add('has-new'); } }   // v1.2.196: tombol-bantuan
        hsFoot();
      }).catch(function () {}).then(hsPollSchedule);
  }

  function tourInit() {
    if ($('#btnTour')) $('#btnTour').onclick = function (e) { e.stopPropagation(); helpOpen(''); };
    if ($('#tourCariBtn')) {
      $('#tourCariBtn').onclick = function () { helpOpen($('#tourCariQ').value); };
      $('#tourCariQ').onkeydown = function (e) { if (e.key === 'Enter') { e.preventDefault(); helpOpen($('#tourCariQ').value); } };
    }
    var box = $('#tourBtns');
    if (box) {
      var me = TOUR_ORDER.indexOf(role);
      var lower = me >= 0 ? TOUR_ORDER.slice(me + 1) : [];
      box.innerHTML = '<button type="button" class="btn sm" data-tour-role="' + role + '">' + ico('circle-help', 15) + ' Mulai panduan ' + esc(ROLE_LABEL[role] || role) + '</button>' +
        lower.map(function (r) { return '<button type="button" class="btn ghost sm" data-tour-role="' + r + '" data-tour-preview="1">Lihat panduan ' + esc(ROLE_LABEL[r]) + '</button>'; }).join('');
      if (lower.length && $('#tourCardNote')) $('#tourCardNote').innerHTML = 'Tur singkat menu &amp; fitur sesuai peran Anda. Untuk melatih tim, lihat juga pratinjau panduan yang ditampilkan ke peran lain saat pertama login.';
      $$('#tourBtns [data-tour-role]').forEach(function (b) {
        b.onclick = function () { tourStart(b.dataset.tourRole, !!b.dataset.tourPreview); };
      });
    }
    // otomatis sekali untuk akun yang belum pernah melihat versi panduan ini
    if (!tourSeen() && location.hash !== '#pembaruan') {
      setTimeout(function () { if (!tour) tourStart(role, false); }, 700);
    }
  }

  /* ---- v1.2.169: tema-warna: pemilih tema warna dashboard (per browser) ---- */
  var THM_PIE0 = PIE_COLORS.slice(), THM_TP0 = TP_COL.slice();
  function thmSync() {
    var t = window.DEI_THEME;
    BRAND_C1 = (t && t.c1) || (BRAND && BRAND.c1) || '#140383';
    BRAND_C2 = (t && t.c2) || (BRAND && BRAND.c2) || '#a855f7';
    var p = (t && t.palette && t.palette.length) ? t.palette : null;
    PIE_COLORS.splice.apply(PIE_COLORS, [0, PIE_COLORS.length].concat(p || THM_PIE0));
    TP_COL.splice.apply(TP_COL, [0, TP_COL.length].concat(p || THM_TP0));
    LG_ST.ai[1] = BRAND_C1;
  }
  function thmCur() { try { return localStorage.getItem('dei_theme') || ''; } catch (e) { return ''; } }
  function thmCard(id, name, desc, c, dots) {
    var on = thmCur() === id;
    return '<button type="button" class="thm-card' + (on ? ' on' : '') + '" data-thm="' + id + '">' +
      '<div class="thm-pv" style="background:radial-gradient(120% 140% at 100% 0%,' + c[2] + ' 0%,transparent 55%),linear-gradient(135deg,' + c[0] + ' 0%,' + c[1] + ' 100%)">' +
        '<div class="sb"><i></i><i style="background:' + c[0] + ';opacity:.35"></i><i></i><i></i></div>' +
        '<div class="mn"><i style="background:' + c[2] + '"></i><i></i></div></div>' +
      '<div class="thm-dots">' + dots.slice(0, 6).map(function (d) { return '<span style="background:' + d + '"></span>'; }).join('') + '</div>' +
      '<div class="thm-nm">' + esc(name) + '<small>' + esc(desc) + '</small></div><span class="thm-ok">&#10003;</span></button>';
  }
  function thmOpen() {
    var T = window.DEI_THEMES || {};
    var d1 = (BRAND && BRAND.c1) || '#140383', d2 = (BRAND && BRAND.c2) || '#a855f7';
    var dPal = THM_PIE0.length ? THM_PIE0 : [d1, d2];
    var h = thmCard('', 'Bawaan ' + BRAND_VENDOR, BRAND ? 'Warna brand ' + BRAND_VENDOR : 'Indigo khas DEI', [d1, BRAND ? d2 : '#3b2fb8', BRAND ? d2 : '#5b4fe0'], dPal);
    Object.keys(T).forEach(function (id) { var t = T[id]; h += thmCard(id, t.n, t.d, [t.c[0], t.c[1], t.c[3]], t.p); });
    var ov = document.createElement('div');
    ov.className = 'thm-ov';
    ov.innerHTML = '<div class="thm-box" role="dialog" aria-label="Tema warna"><div class="thm-hd"><h3>Tema warna</h3><button type="button" class="thm-x" aria-label="Tutup">' + ico('x', 18) + '</button></div>' +
      '<div class="thm-sub">Ganti suasana dashboard. Tersimpan di browser/perangkat ini saja. Warna widget chat untuk pengunjung tetap diatur di <b>Balasan &amp; Tampilan</b>.</div>' +
      '<div class="thm-grid">' + h + '</div></div>';
    function close() { ov.remove(); document.removeEventListener('keydown', onKey); }
    function onKey(e) { if (e.key === 'Escape') close(); }
    ov.addEventListener('click', function (e) {
      if (e.target === ov || e.target.closest('.thm-x')) { close(); return; }
      var c = e.target.closest('[data-thm]'); if (!c) return;
      var id = c.dataset.thm;
      try { if (id) localStorage.setItem('dei_theme', id); else localStorage.removeItem('dei_theme'); } catch (er) {}
      if (window.deiThemeApply) window.deiThemeApply(id);
      thmSync();
      Array.prototype.forEach.call(ov.querySelectorAll('.thm-card'), function (x) { x.classList.toggle('on', x === c); });
      toast('Tema "' + (id && T[id] ? T[id].n : 'Bawaan') + '" diterapkan. Grafik ikut berubah saat dimuat ulang.');
    });
    document.addEventListener('keydown', onKey);
    document.body.appendChild(ov);
  }
  thmSync();
  if ($('#btnTheme')) $('#btnTheme').onclick = function (e) { e.stopPropagation(); thmOpen(); };

  // first tab per role
  var firstTab = role === 'sales' ? 'leads'   // v1.2.216: pipeline-sales
               : role === 'wa_agent' ? 'wachat'
               : role === 'supervisor' ? 'wachat'   // v1.2.58
               : role === 'admin'    ? 'reports'
               :                       'reports';   // super_admin
  // v1.2.65: tautan langsung #pembaruan (mis. dari notifikasi push rilis baru)
  if (location.hash === '#pembaruan' && relCanSee()) firstTab = 'pembaruan';
  if (location.hash === '#gc' && can('super_admin,admin,supervisor')) firstTab = 'gc';   // v1.2.109: guest-comment
  window.addEventListener('hashchange', function () { if (location.hash === '#pembaruan' && relCanSee()) showTab('pembaruan'); });
  showTab(firstTab);
  tourInit();                                   // v1.2.74: panduan pertama kali
  maybeAutoCheck();
  renderLicenseBanner();
  renderCapBanner();
  planNav();   // v1.2.172: trial-paket
  renderOnboarding();                           // v1.2.90
  relCheck();                                   // v1.2.65: lencana + banner rilis baru (admin)
  if (relCanSee()) setInterval(relCheck, 30 * 60 * 1000);
})();
