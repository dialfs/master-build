<?php
/**
 * DEI AI Chat Widget — Unified API
 * Single endpoint: api/index.php?action=<action>
 * Flat-file JSON storage. No database required. PHP 7.4+.
 */

date_default_timezone_set('Asia/Jakarta');
// v1.2.43: versi yang TERTANAM di berkas ini. Nilainya disuntik otomatis
// oleh skrip build saat mengemas master ZIP. Berbeda dari version.json yang
// ditulis updater, konstanta ini tidak bisa berbohong: ia bagian dari berkas
// yang diganti. Kalau update gagal dan berkas tidak terganti, nilainya tetap
// lama -- itulah cara kita mendeteksi update gagal senyap.
// Nilai 'dev' berarti berkas ini sumber yang dipatch manual (deintegra),
// bukan hasil pemasangan dari rilis -- itu jujur, bukan tanda masalah.
define('DEI_VERSION', 'v1.2.116');   // v1.2.116: pindah-nomor
error_reporting(E_ALL & ~E_NOTICE & ~E_WARNING & ~E_DEPRECATED);

define('DATA_DIR', __DIR__ . '/../data');
define('SETTINGS_FILE', DATA_DIR . '/settings.json');
define('USERS_FILE', DATA_DIR . '/users.json');
define('KB_FILE', DATA_DIR . '/knowledge-base.json');
define('LOG_FILE', DATA_DIR . '/chatbot-log.json');
define('PUSH_CATEGORIES_FILE', DATA_DIR . '/push-categories.json');  // v1.2.13: kategori custom (file sendiri, bukan settings)
define('CONTACTS_FILE', DATA_DIR . '/wa-contacts.json');  // v1.2.19: nama kontak WA (file sendiri — log dipangkas log_limit)
define('LEADS_FILE', DATA_DIR . '/leads.json');           // v1.2.20: kartu lead hasil analisa AI
define('PRICELIST_FILE', DATA_DIR . '/pricelist.json');   // v1.2.22: daftar harga resmi (terpisah dari KB)
define('GAPS_DISMISSED_FILE', DATA_DIR . '/kb-gaps-dismissed.json');  // v1.2.25: pertanyaan yang disembunyikan
define('LEAD_TRIGGER_MSGS', 8);                            // v1.2.20: analisa saat percakapan mencapai N pesan
define('RATELIMIT_FILE', DATA_DIR . '/ratelimit.json');
define('SECRET_FILE', DATA_DIR . '/.secret.php');
define('WA_SESSIONS_DIR', DATA_DIR . '/wa-sessions');
define('WA_MODES_FILE', DATA_DIR . '/wa-modes.json');
define('WEB_CONV_FILE', DATA_DIR . '/web-conversations.json');  // v1.2.45: percakapan web per-sesi
define('WEB_SESSIONS_DIR', DATA_DIR . '/web-sessions');          // v1.2.45: riwayat pesan per conversation_id
define('WEB_VISITORS_FILE', DATA_DIR . '/web-visitors.json');   // v1.2.53: data lead pengunjung web (nama + no HP)

/* ----------------------------------------------------------------------------
 *  CORS — the widget runs on the client's site (loaded via GTM) so public
 *  endpoints must allow cross-origin requests.
 * ------------------------------------------------------------------------- */
$PUBLIC_ACTIONS = ['bootstrap', 'chat', 'web_conv_list', 'web_conv_thread', 'web_conv_new', 'web_lead_save', 'web_closing', 'gc_submit'];   // v1.2.56; v1.2.109: guest-comment
$action = isset($_GET['action']) ? $_GET['action'] : '';
// v1.2.56: mode CLI untuk cron cPanel per tenant: php api/index.php action=cron_tick
if (PHP_SAPI === 'cli' && $action === '' && !empty($argv[1])) {
    parse_str(implode('&', array_slice($argv, 1)), $deiCliArgs);
    $_GET = array_merge($_GET, $deiCliArgs);
    $action = (string)($_GET['action'] ?? '');
    if (!in_array($action, ['cron_tick', 'wa_worker', 'wa_queue_status', 'db_init', 'db_import', 'update_cli', 'redbus_scan'], true)) { fwrite(STDERR, "CLI: action=cron_tick|wa_worker|wa_queue_status|db_init|db_import|update_cli|redbus_scan\n"); exit(1); }   // v1.2.71
    // v1.2.71: update_cli = update_check lalu langsung update_apply (dipakai update-all.sh di server sendiri)
    if ($action === 'update_cli') { $action = 'update_check'; $GLOBALS['dei_cli_chain'] = true; }
}

if (in_array($action, $PUBLIC_ACTIONS, true)) {
    header('Access-Control-Allow-Origin: *');
    header('Access-Control-Allow-Methods: GET, POST, OPTIONS');
    header('Access-Control-Allow-Headers: Content-Type, X-Auth-Token');
    header('Access-Control-Expose-Headers: X-Auth-Refresh');  // fix auto sign out: biar JS bisa baca token refresh
}
if ($_SERVER['REQUEST_METHOD'] === 'OPTIONS') {
    http_response_code(204);
    exit;
}

/* ----------------------------------------------------------------------------
 *  Helpers
 * ------------------------------------------------------------------------- */
function jsonOut($arr, $code = 200) {
    http_response_code($code);
    header('Content-Type: application/json; charset=utf-8');
    echo json_encode($arr, JSON_UNESCAPED_UNICODE | JSON_UNESCAPED_SLASHES);
    exit;
}

function readJson($file, $fallback) {
    if (!file_exists($file)) return $fallback;
    $raw = file_get_contents($file);
    $data = json_decode($raw, true);
    return ($data === null) ? $fallback : $data;
}

function writeJson($file, $data) {
    $json = json_encode($data, JSON_UNESCAPED_UNICODE | JSON_UNESCAPED_SLASHES | JSON_PRETTY_PRINT);
    // v1.2.40 LUBANG 1: json_encode() bisa gagal dan mengembalikan false --
    // paling sering karena ada byte UTF-8 tidak valid (pesan WhatsApp, nama
    // kontak, emoji terpotong). Versi lama melewatkan false itu ke
    // file_put_contents, yang menuliskannya sebagai STRING KOSONG: isi file
    // hilang total, tapi fungsinya tetap melaporkan sukses. Sekarang: jangan
    // tulis apa pun, catat sebabnya, biarkan berkas lama utuh.
    if ($json === false) {
        error_log('writeJson: json_encode GAGAL untuk ' . $file . ' -- ' . json_last_error_msg() . ' (berkas lama dibiarkan utuh)');
        return false;
    }
    // v1.2.40 LUBANG 2: file_put_contents memotong berkas dulu baru menulis,
    // jadi kalau proses mati di tengah jalan (timeout/fatal/memory limit)
    // yang tersisa berkas separuh. Tulis ke berkas sementara di direktori
    // yang SAMA lalu rename() -- rename dalam satu filesystem bersifat
    // atomic: pembaca tidak pernah melihat berkas setengah tertulis, dan
    // kalau gagal sebelum rename, berkas asli tidak tersentuh sama sekali.
    $tmp = $file . '.tmp.' . getmypid() . '.' . mt_rand(1000, 9999);
    if (file_put_contents($tmp, $json, LOCK_EX) === false) {
        @unlink($tmp);
        error_log('writeJson: gagal menulis berkas sementara untuk ' . $file);
        return false;
    }
    // pertahankan hak akses seperti berkas aslinya
    if (file_exists($file)) {
        $perm = @fileperms($file);
        if ($perm !== false) @chmod($tmp, $perm & 0777);
    }
    if (!@rename($tmp, $file)) {
        @unlink($tmp);
        error_log('writeJson: rename gagal untuk ' . $file);
        return false;
    }
    return true;
}

// v1.2.41: cari folder di dalam hasil ekstrak ZIP yang benar-benar berisi
// api/index.php. Tidak lagi hardcode nama folder -- 'dei-chatbot-ai' dan
// 'dei-update' cuma tebakan pertama supaya cepat. Kalau kemasan ZIP berubah
// lagi di masa depan, ini tetap menemukannya asal strukturnya tidak lebih
// dalam dari satu tingkat.
/* v1.2.58: chatbot-log.json diubah di bawah satu kunci. Sebelumnya tiap
 * penulis membaca -> menambah -> menulis tanpa kunci; dua pesan yang masuk
 * bersamaan bisa saling menimpa (entri hilang). Risiko itu membesar saat
 * log_limit dinaikkan (file lebih besar = waktu tulis lebih lama).
 * $fn menerima &$logs (terbaru-dulu); kembalikan false untuk batal menulis. */
function logMutate($fn, $limit = null) {
    if (deiStorageMysql()) return logDbMutate($fn);   // v1.2.71: tabel dei_log, riwayat tidak dipangkas
    $lock = @fopen(DATA_DIR . '/chatbot-log.lock', 'c');
    if ($lock) @flock($lock, LOCK_EX);
    try {
        $logs = readJson(LOG_FILE, []);
        if (!is_array($logs)) $logs = [];
        $r = $fn($logs);
        if ($r !== false) {
            if ($limit !== null) $logs = array_slice($logs, 0, max(1, (int)$limit));
            writeJson(LOG_FILE, $logs);
        }
        return $logs;
    } finally {
        if ($lock) { @flock($lock, LOCK_UN); @fclose($lock); }
    }
}
// Tambah satu entri di depan log (aman dari tulis bersamaan). Mengembalikan isi log terbaru.
// v1.2.71: di mode mysql cukup INSERT; nilai kembali hanya [entri baru] -- jangan diandalkan.
function logPrepend($entry, $limit) {
    if (deiStorageMysql()) { logDbInsert($entry); return [$entry]; }
    return logMutate(function (&$logs) use ($entry) { array_unshift($logs, $entry); }, $limit);
}

/* ============================================================================
 * v1.2.71: DRIVER PENYIMPANAN & ANTREAN (server self-hosted, mis. Halte Bus)
 *
 * Satu kode untuk dua mesin. Berkas OPSIONAL data/server.php (tidak pernah
 * ikut paket update, karena data/ tidak disentuh updater) mengembalikan:
 *
 *   <?php return [
 *     'storage' => 'mysql',            // 'file' (bawaan) | 'mysql'
 *     'queue'   => 'redis',            // 'sync' (bawaan) | 'redis'
 *     'db'      => ['host' => '127.0.0.1', 'port' => 3306, 'name' => 'sj_chat', 'user' => 'sj', 'pass' => '...'],
 *     'redis'   => ['host' => '127.0.0.1', 'port' => 6379, 'db' => 0, 'prefix' => 'sj:'],
 *   ];
 *
 * Tanpa berkas itu: 'file' + 'sync' = perilaku lama di shared hosting.
 * ATURAN PENGEMBANGAN: data yang ditulis tiap pesan (log, sesi WA, kontak)
 * HANYA lewat fungsi di blok ini — jangan readJson/writeJson berkasnya
 * langsung. tools/cek-storage.sh menolak rilis yang melanggar.
 * ========================================================================= */
function deiServerConf() {
    static $c = null;
    if ($c === null) {
        $c = [];
        $f = DATA_DIR . '/server.php';
        if (is_file($f)) { $r = include $f; if (is_array($r)) $c = $r; }
        $c['storage'] = (($c['storage'] ?? 'file') === 'mysql') ? 'mysql' : 'file';
        $c['queue']   = (($c['queue'] ?? 'sync') === 'redis') ? 'redis' : 'sync';
    }
    return $c;
}
function deiStorageMysql() { return deiServerConf()['storage'] === 'mysql'; }
// Mode antrean hanya aktif kalau Redis benar-benar bisa dihubungi. Kalau Redis mati,
// webhook jatuh ke pemrosesan langsung dan idempotensi/kunci memakai MySQL/berkas.
function deiQueueRedis() {
    static $ok = null;
    if ($ok === null) {
        $ok = false;
        if (deiServerConf()['queue'] === 'redis' && class_exists('Redis')) {
            try { $ok = (bool)deiRedis()->ping(); }
            catch (\Throwable $e) { error_log('Redis tidak bisa dihubungi: ' . $e->getMessage()); }
        }
    }
    return $ok;
}

/* v1.2.73: BRAND per instalasi (server sendiri). data/server.php:
 *   'brand' => 'haltebus'                       // preset
 *   'brand' => ['preset' => 'haltebus', 'vendor' => '...']   // timpa sebagian
 * Tanpa kunci itu = tampilan DEI apa adanya. Ikon, logo & manifest.json ditimpa per
 * instalasi oleh add-client.sh (berkas itu tidak pernah diganti updater); warna & nama
 * diterapkan saat halaman dimuat lewat action=brand_js. */
function deiBrandPresets() {
    return [
        'haltebus' => [
            'key' => 'haltebus', 'vendor' => 'Haltebus', 'product' => 'Haltebus Chatbot',
            'theme' => '#B32B26',
            'css' => [
                '--brand' => '#B32B26', '--brand-2' => '#E0533F', '--brand-soft' => '#FCEBE8',
                '--brand-line' => '#F1C3BB', '--brand-tint' => '#FDF4F2', '--brand-tint-2' => '#FDEEEA',
                '--brand-mid' => '#C83A30', '--brand-hero' => '#F08A2A',
                '--brand-rgb' => '179,43,38', '--brand-2-rgb' => '224,83,63', '--brand-hero-rgb' => '240,138,42',
            ],
            'c1' => '#B32B26', 'c2' => '#F08A2A',
            'palette' => ['#B32B26', '#E0533F', '#F08A2A', '#D9A066', '#8C1D22', '#F4B183', '#C9584C', '#94a3b8'],
        ],
    ];
}
function deiBrand() {
    static $b = false;
    if ($b === false) {
        $b = null;
        $c = deiServerConf()['brand'] ?? null;
        $p = deiBrandPresets();
        if (is_string($c) && isset($p[$c])) $b = $p[$c];
        elseif (is_array($c)) {
            $base = $p[(string)($c['preset'] ?? '')] ?? [];
            unset($c['preset']);
            $b = array_replace_recursive($base, $c);
            if (empty($b['vendor']) || empty($b['product'])) $b = null;
        }
    }
    return $b;
}
function deiBrandVendor()  { $b = deiBrand(); return $b ? (string)$b['vendor'] : 'DEI'; }
function deiBrandProduct() { $b = deiBrand(); return $b ? (string)$b['product'] : 'DEI Chatbot'; }

function deiDb() {
    static $pdo = null;
    if ($pdo === null) {
        $d = deiServerConf()['db'] ?? [];
        $dsn = 'mysql:host=' . ($d['host'] ?? '127.0.0.1') . ';port=' . (int)($d['port'] ?? 3306)
             . ';dbname=' . ($d['name'] ?? '') . ';charset=utf8mb4';
        $pdo = new PDO($dsn, (string)($d['user'] ?? ''), (string)($d['pass'] ?? ''), [
            PDO::ATTR_ERRMODE            => PDO::ERRMODE_EXCEPTION,
            PDO::ATTR_DEFAULT_FETCH_MODE => PDO::FETCH_ASSOC,
            PDO::ATTR_EMULATE_PREPARES   => false,
        ]);
        $pdo->exec("SET time_zone = '+07:00'");
    }
    return $pdo;
}
function deiRedis() {
    static $r = null;
    if ($r === null) {
        $c = deiServerConf()['redis'] ?? [];
        $x = new Redis();
        $x->connect((string)($c['host'] ?? '127.0.0.1'), (int)($c['port'] ?? 6379), 2.0);
        if (!empty($c['pass'])) $x->auth((string)$c['pass']);
        if (!empty($c['db'])) $x->select((int)$c['db']);
        $x->setOption(Redis::OPT_PREFIX, (string)($c['prefix'] ?? 'dei:'));
        $x->setOption(Redis::OPT_READ_TIMEOUT, -1);
        $r = $x;
    }
    return $r;
}

// Skema MySQL — satu sumber; dijalankan lewat `php api/index.php action=db_init`.
function deiDbSchema() {
    return [
        "CREATE TABLE IF NOT EXISTS dei_log (
            id BIGINT UNSIGNED NOT NULL AUTO_INCREMENT PRIMARY KEY,
            ts DATETIME NULL,
            num VARCHAR(32) NOT NULL DEFAULT '',
            channel VARCHAR(16) NOT NULL DEFAULT '',
            body MEDIUMTEXT NOT NULL,
            KEY num_id (num, id),
            KEY ts (ts)
        ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci",
        "CREATE TABLE IF NOT EXISTS dei_wa_sessions (
            num VARCHAR(32) NOT NULL PRIMARY KEY,
            ts INT UNSIGNED NOT NULL,
            turns MEDIUMTEXT NOT NULL,
            KEY ts (ts)
        ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci",
        "CREATE TABLE IF NOT EXISTS dei_contacts (
            num VARCHAR(32) NOT NULL PRIMARY KEY,
            body TEXT NOT NULL,
            updated_at TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP
        ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci",
        "CREATE TABLE IF NOT EXISTS dei_conv_state (
            num VARCHAR(32) NOT NULL PRIMARY KEY,
            last_at INT UNSIGNED NOT NULL DEFAULT 0,
            body TEXT NOT NULL,
            KEY last_at (last_at)
        ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci",
        "CREATE TABLE IF NOT EXISTS dei_wa_seen (
            wamid VARCHAR(191) NOT NULL PRIMARY KEY,
            ts INT UNSIGNED NOT NULL,
            KEY ts (ts)
        ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci",
        convDbSchemaSql(),   // v1.2.101: percakapan
    ];
}

/* ---------- Kunci lintas proses (dua mode) ----------
 * flock di data/.locks/<nama>.lock. Reentrant per proses: fungsi yang sudah
 * memegang kunci boleh memanggil fungsi lain yang meminta kunci yang sama. */
function deiWithLock($name, $fn) {
    static $held = [];
    if (!empty($held[$name])) return $fn();
    $dir = DATA_DIR . '/.locks';
    if (!is_dir($dir)) @mkdir($dir, 0755, true);
    $fp = @fopen($dir . '/' . preg_replace('/[^a-z0-9_-]/i', '_', $name) . '.lock', 'c');
    if ($fp) @flock($fp, LOCK_EX);
    $held[$name] = true;
    try {
        return $fn();
    } finally {
        unset($held[$name]);
        if ($fp) { @flock($fp, LOCK_UN); @fclose($fp); }
    }
}

/* ---------- Log percakapan ---------- */
function logEncode($e) {
    return json_encode($e, JSON_UNESCAPED_UNICODE | JSON_UNESCAPED_SLASHES | JSON_INVALID_UTF8_SUBSTITUTE);
}
function logRowNum($e) {
    return (($e['channel'] ?? '') === 'whatsapp') ? substr(preg_replace('/\D/', '', (string)($e['ip'] ?? '')), 0, 32) : '';
}
// Jendela baca untuk dashboard/statistik: sama dengan log_limit di mode file.
function logWindow() {
    static $w = null;
    if ($w === null) {
        $s = readJson(SETTINGS_FILE, []);
        $w = max(500, (int)($s['api']['log_limit'] ?? 500));
    }
    return $w;
}
function logDbInsert($e) {
    $ts = (string)($e['ts'] ?? '');
    $st = deiDb()->prepare('INSERT INTO dei_log (ts, num, channel, body) VALUES (?, ?, ?, ?)');
    $st->execute([preg_match('/^\d{4}-\d{2}-\d{2} \d{2}:\d{2}:\d{2}$/', $ts) ? $ts : null,
                  logRowNum($e), substr((string)($e['channel'] ?? ''), 0, 16), logEncode($e)]);
}
// Semua entri log terbaru-dulu (bentuk persis isi chatbot-log.json).
function logReadAll() {
    if (!deiStorageMysql()) {
        $l = readJson(LOG_FILE, []);
        return is_array($l) ? $l : [];
    }
    $out = [];
    foreach (deiDb()->query('SELECT body FROM dei_log ORDER BY id DESC LIMIT ' . (int)logWindow(), PDO::FETCH_COLUMN, 0) as $b) {
        $e = json_decode($b, true);
        if (is_array($e)) $out[] = $e;
    }
    return $out;
}
// Entri WhatsApp satu nomor, terbaru-dulu.
function logReadByNumber($num, $max = 200) {
    $num = preg_replace('/\D/', '', (string)$num);
    if ($num === '') return [];
    if (!deiStorageMysql()) {
        $out = [];
        foreach (logReadAll() as $e) {
            if (($e['channel'] ?? '') !== 'whatsapp') continue;
            if (preg_replace('/\D/', '', (string)($e['ip'] ?? '')) !== $num) continue;
            $out[] = $e;
            if (count($out) >= $max) break;
        }
        return $out;
    }
    $st = deiDb()->prepare('SELECT body FROM dei_log WHERE num = ? ORDER BY id DESC LIMIT ' . (int)$max);
    $st->execute([$num]);
    $out = [];
    foreach ($st->fetchAll(PDO::FETCH_COLUMN, 0) as $b) { $e = json_decode($b, true); if (is_array($e)) $out[] = $e; }
    return $out;
}
function logDbMutate($fn) {
    $db = deiDb();
    $db->query("SELECT GET_LOCK('dei_log_mutate', 30)");
    try {
        $logs = []; $orig = [];
        foreach ($db->query('SELECT id, body FROM dei_log ORDER BY id DESC LIMIT ' . (int)logWindow())->fetchAll() as $r) {
            $e = json_decode($r['body'], true);
            if (!is_array($e)) $e = [];
            $e['_dei_id'] = (int)$r['id'];
            $orig[(int)$r['id']] = $r['body'];
            $logs[] = $e;
        }
        $res = $fn($logs);
        if (!is_array($logs)) $logs = [];
        if ($res !== false) {
            $keep = []; $new = [];
            $upd = $db->prepare('UPDATE dei_log SET ts = ?, num = ?, channel = ?, body = ? WHERE id = ?');
            foreach ($logs as $e) {
                if (!is_array($e)) continue;
                $id = (int)($e['_dei_id'] ?? 0);
                unset($e['_dei_id']);
                if ($id > 0 && isset($orig[$id]) && !isset($keep[$id])) {
                    $keep[$id] = true;
                    $b = logEncode($e);
                    if ($b !== $orig[$id]) {
                        $ts = (string)($e['ts'] ?? '');
                        $upd->execute([preg_match('/^\d{4}-\d{2}-\d{2} \d{2}:\d{2}:\d{2}$/', $ts) ? $ts : null,
                                       logRowNum($e), substr((string)($e['channel'] ?? ''), 0, 16), $b, $id]);
                    }
                } else {
                    $new[] = $e;
                }
            }
            // Elemen paling depan = paling baru -> disisipkan paling akhir (id terbesar).
            foreach (array_reverse($new) as $e) logDbInsert($e);
            $gone = array_diff_key($orig, $keep);
            if ($gone) $db->exec('DELETE FROM dei_log WHERE id IN (' . implode(',', array_map('intval', array_keys($gone))) . ')');
        }
        foreach ($logs as &$e) { if (is_array($e)) unset($e['_dei_id']); }
        unset($e);
        return $logs;
    } finally {
        $db->query("SELECT RELEASE_LOCK('dei_log_mutate')");
    }
}

/* ---------- Kontak WhatsApp ---------- */
function waContactDefaults() {
    $now = date('Y-m-d H:i:s');
    return ['name_wa' => '', 'name_manual' => '', 'first_seen' => $now, 'last_seen' => $now];
}
// Satu kontak (null kalau belum ada).
function waContactGet($number) {
    $number = preg_replace('/\D/', '', (string)$number);
    if ($number === '') return null;
    if (!deiStorageMysql()) {
        $all = waGetContacts();
        return (isset($all[$number]) && is_array($all[$number])) ? $all[$number] : null;
    }
    $st = deiDb()->prepare('SELECT body FROM dei_contacts WHERE num = ?');
    $st->execute([$number]);
    $b = $st->fetchColumn();
    $c = ($b === false) ? null : json_decode($b, true);
    return is_array($c) ? $c : null;
}
// Peta [nomor => kontak] yang cukup untuk membaca satu nomor.
function waContactsFor($number) {
    if (!deiStorageMysql()) return waGetContacts();
    $number = preg_replace('/\D/', '', (string)$number);
    $c = waContactGet($number);
    return $c === null ? [] : [$number => $c];
}
// Ubah satu kontak secara atomik. $fn(array &$row, bool $isNew); kembalikan false untuk batal.
function waContactUpdate($number, $fn) {
    $number = preg_replace('/\D/', '', (string)$number);
    if ($number === '') return null;
    if (!deiStorageMysql()) {
        return deiWithLock('wa-contacts', function () use ($number, $fn) {
            $all = waGetContacts();
            $isNew = !isset($all[$number]) || !is_array($all[$number]);
            $row = $isNew ? waContactDefaults() : $all[$number];
            if ($fn($row, $isNew) === false) return $isNew ? null : $all[$number];
            $all[$number] = $row;
            writeJson(CONTACTS_FILE, $all);
            return $row;
        });
    }
    // Baris dibuat dulu (INSERT IGNORE, autocommit) supaya FOR UPDATE mengunci baris,
    // bukan celah indeks — dua kontak baru bersamaan tidak saling deadlock.
    $db = deiDb();
    for ($attempt = 1; ; $attempt++) {
        try {
            $ins = $db->prepare('INSERT IGNORE INTO dei_contacts (num, body) VALUES (?, ?)');
            $ins->execute([$number, logEncode(waContactDefaults())]);
            $isNew = ($ins->rowCount() === 1);
            $db->beginTransaction();
            $st = $db->prepare('SELECT body FROM dei_contacts WHERE num = ? FOR UPDATE');
            $st->execute([$number]);
            $row = json_decode((string)$st->fetchColumn(), true);
            if (!is_array($row)) $row = waContactDefaults();
            $before = $row;
            if ($fn($row, $isNew) === false) {
                if ($isNew) $db->prepare('DELETE FROM dei_contacts WHERE num = ?')->execute([$number]);
                $db->commit();
                return $isNew ? null : $before;
            }
            $db->prepare('UPDATE dei_contacts SET body = ? WHERE num = ?')->execute([logEncode($row), $number]);
            $db->commit();
            return $row;
        } catch (\PDOException $e) {
            if ($db->inTransaction()) $db->rollBack();
            if ((int)($e->errorInfo[1] ?? 0) === 1213 && $attempt < 4) { usleep(50000 * $attempt); continue; }
            throw $e;
        }
    }
}

/* ---------- Pesan WA sudah diproses? (idempotensi wamid) ---------- */
function waMsgSeen($wamid) {
    $wamid = substr((string)$wamid, 0, 191);
    if ($wamid === '') return false;
    if (deiQueueRedis()) return (bool)deiRedis()->exists('seen:' . $wamid);
    if (deiStorageMysql()) {
        $st = deiDb()->prepare('SELECT 1 FROM dei_wa_seen WHERE wamid = ?');
        $st->execute([$wamid]);
        return (bool)$st->fetchColumn();
    }
    $all = readJson(DATA_DIR . '/wa-seen.json', []);
    return is_array($all) && isset($all[$wamid]);
}
function waMsgMarkSeen($wamid) {
    $wamid = substr((string)$wamid, 0, 191);
    if ($wamid === '') return;
    if (deiQueueRedis()) { deiRedis()->set('seen:' . $wamid, 1, ['ex' => 3 * 86400]); return; }
    if (deiStorageMysql()) {
        deiDb()->prepare('INSERT IGNORE INTO dei_wa_seen (wamid, ts) VALUES (?, ?)')->execute([$wamid, time()]);
        return;
    }
    deiWithLock('wa-seen', function () use ($wamid) {
        $f = DATA_DIR . '/wa-seen.json';
        $all = readJson($f, []);
        if (!is_array($all)) $all = [];
        $all[$wamid] = time();
        if (count($all) > 3000) { asort($all); $all = array_slice($all, -2000, null, true); }
        writeJson($f, $all);
    });
}

/* ---------- Kunci per nomor (hanya mode antrean) ----------
 * Pesan dari satu nomor diproses berurutan; nomor berbeda tetap paralel. */
function deiNumLock($num, $fn) {
    if (!deiQueueRedis()) return $fn();
    $r = deiRedis();
    $key = 'lock:wa:' . preg_replace('/\D/', '', (string)$num);
    // Nilai kunci = "<slot>:<token>" supaya slot yang hidup lagi bisa melepas kunci peninggalannya.
    $tok = ($GLOBALS['dei_worker_slot'] ?? 'web') . ':' . bin2hex(random_bytes(8));
    $deadline = microtime(true) + 130;
    while (!$r->set($key, $tok, ['nx', 'ex' => 120])) {
        if (microtime(true) > $deadline) break;   // jangan macet selamanya
        usleep(200000);
    }
    try {
        return $fn();
    } finally {
        if ($r->get($key) === $tok) $r->del($key);
    }
}

/* ---------- Bersih-bersih berkala (cron_tick) ----------
 * Sesi WA > 7 hari dihapus (bot sudah mengabaikannya setelah 6 jam) supaya
 * jumlah berkas/baris tidak tumbuh tanpa batas. */
function deiPurgeSessions() {
    if (deiStorageMysql()) {
        $db = deiDb();
        $n  = $db->exec('DELETE FROM dei_wa_sessions WHERE ts < ' . (time() - 7 * 86400));
        $db->exec('DELETE FROM dei_wa_seen WHERE ts < ' . (time() - 3 * 86400));
        $db->exec('DELETE FROM dei_conv_state WHERE last_at < ' . (time() - 3 * 86400));
        return (int)$n;
    }
    if (!is_dir(WA_SESSIONS_DIR)) return 0;
    $n = 0; $cut = time() - 7 * 86400;
    foreach ((array)glob(WA_SESSIONS_DIR . '/*.json') as $f) {
        if (@filemtime($f) < $cut && @unlink($f)) $n++;
        if ($n >= 500) break;   // sisanya di tick berikutnya
    }
    return $n;
}

/* ---------- Jejak percakapan (conv-state) untuk auto-closing & eskalasi ----------
 * Mode file: conv-state.json (dipangkas 3 hari). Mode mysql: tabel dei_conv_state. */
function convStateReadAll() {
    if (!deiStorageMysql()) {
        $f = CONV_STATE_FILE;   // lewat variabel: langkah 6c patch mengganti pola pembaca langsung
        $a = readJson($f, []);
        return is_array($a) ? $a : [];
    }
    $out = [];
    $st = deiDb()->prepare('SELECT num, body FROM dei_conv_state WHERE last_at >= ?');
    $st->execute([time() - 3 * 86400]);
    foreach ($st->fetchAll() as $r) { $b = json_decode($r['body'], true); if (is_array($b)) $out[(string)$r['num']] = $b; }
    return $out;
}
// Mode mysql: hanya baris $num yang dikunci & diberikan ke $fn sebagai [$num => state].
function convStateDbMutateOne($fn, $num) {
    $num = waNormNum($num);
    $db = deiDb();
    for ($attempt = 1; ; $attempt++) {
        try {
            $ins = $db->prepare("INSERT IGNORE INTO dei_conv_state (num, last_at, body) VALUES (?, 0, '{}')");
            $ins->execute([$num]);
            $isNew = ($ins->rowCount() === 1);
            $db->beginTransaction();
            $st = $db->prepare('SELECT body FROM dei_conv_state WHERE num = ? FOR UPDATE');
            $st->execute([$num]);
            $row = json_decode((string)$st->fetchColumn(), true);
            $all = (!$isNew && is_array($row) && $row) ? [$num => $row] : [];
            $res = $fn($all);
            if (isset($all[$num]) && is_array($all[$num])) {
                $db->prepare('UPDATE dei_conv_state SET last_at = ?, body = ? WHERE num = ?')
                   ->execute([(int)($all[$num]['last_at'] ?? 0), logEncode($all[$num]), $num]);
            } else {
                $db->prepare('DELETE FROM dei_conv_state WHERE num = ?')->execute([$num]);
            }
            $db->commit();
            return $res;
        } catch (\PDOException $e) {
            if ($db->inTransaction()) $db->rollBack();
            if ((int)($e->errorInfo[1] ?? 0) === 1213 && $attempt < 4) { usleep(50000 * $attempt); continue; }
            throw $e;
        }
    }
}


/* v1.2.101: percakapan — lapisan penyimpanan */
/* ---------- v1.2.101: percakapan — penyimpanan dua mode ----------
 * file : conv-open.json {nomor: record terakhir} = yang masih terbuka + yang selesai <= 24 jam
 *        (untuk buka-ulang & balasan susulan). Record selesai/kedaluwarsa di-append ke
 *        convs/YYYY-MM.jsonl (bulan percakapan dibuka); pembaca memakai baris TERAKHIR per id.
 * mysql: tabel dei_conversations (satu baris per percakapan). */
define('CONV_OPEN_FILE', DATA_DIR . '/conv-open.json');
define('CONV_DIR', DATA_DIR . '/convs');
if (!defined('CONV_ATTACH_SEC')) define('CONV_ATTACH_SEC', 86400);   // record selesai disimpan di "terbuka" selama ini
function convDbSchemaSql() {
    return "CREATE TABLE IF NOT EXISTS dei_conversations (
            id VARCHAR(48) NOT NULL PRIMARY KEY,
            num VARCHAR(32) NOT NULL,
            ch VARCHAR(48) NOT NULL DEFAULT '',
            status VARCHAR(12) NOT NULL DEFAULT 'open',
            opened_at INT UNSIGNED NOT NULL,
            last_at INT UNSIGNED NOT NULL DEFAULT 0,
            resolved_at INT UNSIGNED NOT NULL DEFAULT 0,
            agent VARCHAR(64) NOT NULL DEFAULT '',
            body TEXT NOT NULL,
            KEY num_opened (num, opened_at),
            KEY opened (opened_at),
            KEY status_last (status, last_at)
        ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci";
}
function convIsFinal($c) { return is_array($c) && in_array((string)($c['status'] ?? ''), ['resolved', 'expired'], true); }
// Tabel belum dibuat (server sendiri yang belum menjalankan db_init setelah update) -> buat sekali, ulangi.
function convDbRun($fn) {
    try { return $fn(); }
    catch (\PDOException $e) {
        if ((string)$e->getCode() !== '42S02') throw $e;
        deiDb()->exec(convDbSchemaSql());
        return $fn();
    }
}
function convDbSave($c) {
    deiDb()->prepare('INSERT INTO dei_conversations (id, num, ch, status, opened_at, last_at, resolved_at, agent, body) VALUES (?,?,?,?,?,?,?,?,?)
        ON DUPLICATE KEY UPDATE ch = VALUES(ch), status = VALUES(status), last_at = VALUES(last_at),
        resolved_at = VALUES(resolved_at), agent = VALUES(agent), body = VALUES(body)')
        ->execute([(string)$c['id'], (string)$c['num'], substr((string)($c['ch'] ?? ''), 0, 48), (string)$c['status'],
                   (int)$c['opened_at'], (int)($c['last_at'] ?? 0), (int)($c['resolved_at'] ?? 0),
                   substr((string)($c['agent'] ?? ''), 0, 64), logEncode($c)]);
}
function convFileAppend($c) {
    if (!is_dir(CONV_DIR)) @mkdir(CONV_DIR, 0755, true);
    @file_put_contents(CONV_DIR . '/' . wibDate('Y-m', (int)$c['opened_at']) . '.jsonl', logEncode($c) . "\n", FILE_APPEND | LOCK_EX);
}
// Baca-ubah-tulis percakapan terakhir satu nomor di bawah kunci. $fn(&$c, &$flush):
// $c = record terakhir (null bila tidak ada / sudah lewat masa susulan); boleh diganti record baru.
// $flush = record lain (yang baru diselesaikan) untuk disimpan juga.
function convStoreMutate($num, $fn) {
    $num = waNormNum($num);
    if ($num === '') return null;
    if (deiStorageMysql()) {
        return deiWithLock('conv-' . $num, function () use ($num, $fn) {
            return convDbRun(function () use ($num, $fn) {
                $st = deiDb()->prepare('SELECT body FROM dei_conversations WHERE num = ? ORDER BY opened_at DESC, id DESC LIMIT 1');
                $st->execute([$num]);
                $c = json_decode((string)$st->fetchColumn(), true);
                if (!is_array($c) || (convIsFinal($c) && time() - (int)($c['ended_at'] ?? 0) > CONV_ATTACH_SEC)) $c = null;
                $before = ($c === null) ? '' : logEncode($c);
                $flush = [];
                $res = $fn($c, $flush);
                foreach ($flush as $x) if (is_array($x)) convDbSave($x);
                if (is_array($c) && logEncode($c) !== $before) convDbSave($c);
                return $res;
            });
        });
    }
    return deiWithLock('conv', function () use ($num, $fn) {
        $f = CONV_OPEN_FILE;
        $all = readJson($f, []);
        if (!is_array($all)) $all = [];
        $c = is_array($all[$num] ?? null) ? $all[$num] : null;
        if ($c !== null && convIsFinal($c) && time() - (int)($c['ended_at'] ?? 0) > CONV_ATTACH_SEC) $c = null;
        $before = ($c === null) ? '' : logEncode($c);
        $flush = [];
        $res = $fn($c, $flush);
        $dirty = false;
        foreach ($flush as $x) { if (is_array($x) && convIsFinal($x)) convFileAppend($x); $dirty = true; }
        if (is_array($c) && logEncode($c) !== $before) {
            $all[$num] = $c;
            if (convIsFinal($c)) convFileAppend($c);
            $dirty = true;
        } elseif ($c === null && isset($all[$num]) && $flush) {
            unset($all[$num]);
        }
        if ($dirty) writeJson($f, $all);
        return $res;
    });
}
// Record terakhir satu nomor (hanya baca).
function convStoreGet($num) {
    $num = waNormNum($num);
    if ($num === '') return null;
    if (deiStorageMysql()) {
        return convDbRun(function () use ($num) {
            $st = deiDb()->prepare('SELECT body FROM dei_conversations WHERE num = ? ORDER BY opened_at DESC, id DESC LIMIT 1');
            $st->execute([$num]);
            $c = json_decode((string)$st->fetchColumn(), true);
            return is_array($c) ? $c : null;
        });
    }
    $f = CONV_OPEN_FILE;
    $all = readJson($f, []);
    return is_array($all[$num] ?? null) ? $all[$num] : null;
}
// Semua record yang belum selesai (untuk sapu timeout).
function convStoreOpen() {
    if (deiStorageMysql()) {
        return convDbRun(function () {
            $out = [];
            foreach (deiDb()->query("SELECT body FROM dei_conversations WHERE status IN ('open','handover','assigned')")->fetchAll() as $r) {
                $c = json_decode((string)$r['body'], true);
                if (is_array($c)) $out[] = $c;
            }
            return $out;
        });
    }
    $f = CONV_OPEN_FILE;
    $all = readJson($f, []);
    $out = [];
    foreach ((is_array($all) ? $all : []) as $c) if (is_array($c) && !convIsFinal($c)) $out[] = $c;
    return $out;
}
// Mode file: buang record selesai yang sudah lewat masa susulan (sudah tersimpan di convs/*.jsonl).
function convStoreEvict($now = null) {
    if (deiStorageMysql()) return 0;
    $now = $now ?? time();
    return deiWithLock('conv', function () use ($now) {
        $f = CONV_OPEN_FILE;
        $all = readJson($f, []);
        if (!is_array($all)) return 0;
        $n = 0;
        foreach ($all as $k => $c) {
            if (!is_array($c) || (convIsFinal($c) && $now - (int)($c['ended_at'] ?? 0) > CONV_ATTACH_SEC)) { unset($all[$k]); $n++; }
        }
        if ($n) writeJson($f, $all);
        return $n;
    });
}
// Percakapan yang DIBUKA dalam rentang [from, to] (ts).
function convStoreRange($fromTs, $toTs) {
    if (deiStorageMysql()) {
        return convDbRun(function () use ($fromTs, $toTs) {
            $st = deiDb()->prepare('SELECT body FROM dei_conversations WHERE opened_at BETWEEN ? AND ? ORDER BY opened_at');
            $st->execute([(int)$fromTs, (int)$toTs]);
            $out = [];
            while (($r = $st->fetch()) !== false) { $c = json_decode((string)$r['body'], true); if (is_array($c)) $out[] = $c; }
            return $out;
        });
    }
    $out = [];
    $y = (int)wibDate('Y', $fromTs); $mo = (int)wibDate('n', $fromTs);
    $endKey = wibDate('Y-m', $toTs);
    for ($i = 0; $i < 40; $i++) {
        $key = sprintf('%04d-%02d', $y, $mo);
        if ($key > $endKey) break;
        $mo++; if ($mo > 12) { $mo = 1; $y++; }
        $fh = @fopen(CONV_DIR . '/' . $key . '.jsonl', 'r');
        if (!$fh) continue;
        while (($line = fgets($fh)) !== false) {
            $c = json_decode($line, true);
            if (!is_array($c) || empty($c['id'])) continue;
            $t = (int)($c['opened_at'] ?? 0);
            if ($t >= $fromTs && $t <= $toTs) $out[$c['id']] = $c;   // baris terakhir per id yang berlaku
        }
        fclose($fh);
    }
    $f = CONV_OPEN_FILE;
    foreach ((array)readJson($f, []) as $c) {
        if (!is_array($c) || empty($c['id'])) continue;
        $t = (int)($c['opened_at'] ?? 0);
        if ($t >= $fromTs && $t <= $toTs) $out[$c['id']] = $c;
    }
    $out = array_values($out);
    usort($out, function ($a, $b) { return (int)$a['opened_at'] <=> (int)$b['opened_at']; });
    return $out;
}

// Lepas kunci nomor milik slot worker yang mati (dipanggil saat slot itu start lagi).
function deiNumLockRelease($job, $slot) {
    $j = is_array($job) ? $job : json_decode((string)$job, true);
    $p = json_decode((string)($j['raw'] ?? ''), true);
    if (!is_array($p)) return;
    $r = deiRedis();
    foreach (($p['entry'] ?? []) as $en) foreach (($en['changes'] ?? []) as $ch) foreach (($ch['value']['messages'] ?? []) as $m) {
        $key = 'lock:wa:' . preg_replace('/\D/', '', (string)($m['from'] ?? ''));
        $v = (string)$r->get($key);
        if ($v !== '' && strpos($v, $slot . ':') === 0) $r->del($key);
    }
}

function deiCariRootPayload($tmpDir) {
    $penanda = '/api/index.php';
    if (file_exists($tmpDir . $penanda)) return $tmpDir;
    foreach (['dei-chatbot-ai', 'dei-update'] as $tebak) {
        if (file_exists($tmpDir . '/' . $tebak . $penanda)) return $tmpDir . '/' . $tebak;
    }
    $anak = @scandir($tmpDir);
    if (is_array($anak)) {
        foreach ($anak as $c) {
            if ($c === '.' || $c === '..') continue;
            $p = $tmpDir . '/' . $c;
            if (is_dir($p) && file_exists($p . $penanda)) return $p;
        }
    }
    return null;
}

function bodyInput() {
    $raw = file_get_contents('php://input');
    $data = json_decode($raw, true);
    return is_array($data) ? $data : [];
}

function clientIp() {
    foreach (['HTTP_CF_CONNECTING_IP', 'HTTP_X_FORWARDED_FOR', 'REMOTE_ADDR'] as $k) {
        if (!empty($_SERVER[$k])) {
            $ip = trim(explode(',', $_SERVER[$k])[0]);
            if (filter_var($ip, FILTER_VALIDATE_IP)) return $ip;
        }
    }
    return '0.0.0.0';
}

/* v1.2.46: label lokasi dari IP (best-effort, sekali saat percakapan dibuat).
 * Dipakai jadi ID percakapan web: "IP · Kota". Aman kalau egress diblokir. */
function deiGeoCity($ip) {
    if ($ip === '' || $ip === '0.0.0.0' || $ip === '127.0.0.1' || strpos($ip, '::1') === 0) return '';
    if (preg_match('/^(10\\.|192\\.168\\.|172\\.(1[6-9]|2\\d|3[01])\\.)/', $ip)) return '';
    $url = 'http://ip-api.com/json/' . urlencode($ip) . '?fields=status,city,regionName,country';
    $ctx = stream_context_create(['http' => ['timeout' => 3, 'ignore_errors' => true]]);
    $raw = @file_get_contents($url, false, $ctx);
    if ($raw === false) return '';
    $d = json_decode($raw, true);
    if (!is_array($d) || ($d['status'] ?? '') !== 'success') return '';
    $parts = array_values(array_filter([$d['city'] ?? '', $d['country'] ?? '']));
    return implode(', ', array_slice($parts, 0, 2));
}

/* Label ID percakapan web: "IP · Kota" (kota opsional). */
function deiWebConvLabel($ip, $city) {
    $ip = ($ip && $ip !== '0.0.0.0') ? $ip : 'Pengunjung';
    return $city ? ($ip . ' · ' . $city) : $ip;
}

/* ----------------------------------------------------------------------------
 *  Secret key (auto-generated, stored as PHP so it is never served as text)
 * ------------------------------------------------------------------------- */
function getSecret() {
    if (file_exists(SECRET_FILE)) {
        $s = @include SECRET_FILE;
        if (is_string($s) && strlen($s) >= 32) return $s;
    }
    $s = bin2hex(random_bytes(32));
    @file_put_contents(SECRET_FILE, "<?php return '" . $s . "';\n", LOCK_EX);
    return $s;
}

/* ----------------------------------------------------------------------------
 *  Auth — stateless token with idle + absolute expiry
 *  Format: base64url(username) . hex(issued_at) . hex(last_seen) . hmac
 * ------------------------------------------------------------------------- */
define('TOKEN_IDLE_SEC', 28800);         // 8 jam tanpa aktivitas (fix auto sign out)
define('TOKEN_MAX_SEC',  7 * 86400);     // 7 hari maksimum sejak login

function makeToken($username) {
    $secret = getSecret();
    $u = rtrim(strtr(base64_encode($username), '+/', '-_'), '=');
    $now = time();
    $iss = dechex($now);
    $seen = dechex($now);
    $sig = hash_hmac('sha256', "$u|$iss|$seen", $secret);
    return "$u.$iss.$seen.$sig";
}

/**
 * Returns the username for a still-valid token, or null.
 * Updates last_seen by issuing a fresh token via setTokenRefreshHeader().
 */
function tokenUsername($token) {
    if (!$token || substr_count($token, '.') !== 3) return null;
    list($u, $iss, $seen, $sig) = explode('.', $token, 4);
    $secret = getSecret();
    $expected = hash_hmac('sha256', "$u|$iss|$seen", $secret);
    if (!hash_equals($expected, $sig)) return null;
    $issued = @hexdec($iss);
    $lastSeen = @hexdec($seen);
    $now = time();
    if ($issued <= 0 || $lastSeen <= 0) return null;
    if (($now - $lastSeen) > TOKEN_IDLE_SEC) return null;          // idle expired
    if (($now - $issued)   > TOKEN_MAX_SEC)  return null;          // absolute expired
    $username = base64_decode(strtr($u, '-_', '+/'));
    if (!$username) return null;
    // Hand a refreshed token back via response header so the client can rotate.
    if (!headers_sent()) {
        $newSeen = dechex($now);
        $newSig = hash_hmac('sha256', "$u|$iss|$newSeen", $secret);
        header('X-Auth-Refresh: ' . "$u.$iss.$newSeen.$newSig");
    }
    return $username;
}

function requestToken() {
    if (!empty($_SERVER['HTTP_X_AUTH_TOKEN'])) return $_SERVER['HTTP_X_AUTH_TOKEN'];
    if (!empty($_SERVER['HTTP_AUTHORIZATION'])) {
        return trim(str_ireplace('Bearer', '', $_SERVER['HTTP_AUTHORIZATION']));
    }
    if (!empty($_GET['token'])) return $_GET['token'];
    $b = bodyInput();
    if (!empty($b['token'])) return $b['token'];
    return null;
}

define('LOCKOUT_FILE', DATA_DIR . '/lockout.json');
define('LOCKOUT_MAX_TRIES', 3);   // v1.2.115: 3x gagal -> kunci 15 menit
define('LOCKOUT_WINDOW_SEC', 15 * 60);

/** Read lockout map; expire entries past window automatically. */
function lockoutRead() {
    $m = readJson(LOCKOUT_FILE, []);
    $now = time();
    $changed = false;
    foreach ($m as $k => $row) {
        $until = $row['locked_until'] ?? 0;
        $last = $row['last_try'] ?? 0;
        if ($until <= $now && ($now - $last) > LOCKOUT_WINDOW_SEC) {
            unset($m[$k]); $changed = true;
        }
    }
    if ($changed) writeJson(LOCKOUT_FILE, $m);
    return $m;
}
function lockoutKey($username) { return strtolower(trim($username)); }
function lockoutCheck($username) {
    $m = lockoutRead();
    $k = lockoutKey($username);
    if (!isset($m[$k])) return 0;
    $until = (int)($m[$k]['locked_until'] ?? 0);
    return ($until > time()) ? $until - time() : 0;
}
function lockoutRecordFail($username) {
    $m = lockoutRead();
    $k = lockoutKey($username);
    $now = time();
    $tries = (int)($m[$k]['tries'] ?? 0);
    // reset counter if no failure within window
    if (!empty($m[$k]['last_try']) && ($now - (int)$m[$k]['last_try']) > LOCKOUT_WINDOW_SEC) {
        $tries = 0;
    }
    $tries++;
    $row = ['tries' => $tries, 'last_try' => $now];
    if ($tries >= LOCKOUT_MAX_TRIES) {
        $row['locked_until'] = $now + LOCKOUT_WINDOW_SEC;
        $row['tries'] = 0;   // reset counter after locking
    }
    $m[$k] = $row;
    writeJson(LOCKOUT_FILE, $m);
    // v1.2.115: balikan sisa percobaan (0 = baru saja dikunci)
    return isset($row['locked_until']) ? 0 : max(0, LOCKOUT_MAX_TRIES - $tries);
}
function lockoutClear($username) {
    $m = lockoutRead();
    $k = lockoutKey($username);
    if (isset($m[$k])) { unset($m[$k]); writeJson(LOCKOUT_FILE, $m); }
}

/* ---------- v1.2.112: login-log ----------
 * Riwayat masuk dasbor: setiap percobaan login (password / tautan pusat), berhasil maupun gagal.
 * data/login-log.json, terbaru di depan, maks LOGIN_LOG_MAX entri & LOGIN_LOG_DAYS hari.
 * Field: t (unix), ts (WIB), u, ok, m (password|sso), r (alasan gagal), ip, dev, ua, name, role, in (akun internal DEI). */
define('LOGIN_LOG_FILE', DATA_DIR . '/login-log.json');
define('LOGIN_LOG_MAX', 3000);
define('LOGIN_LOG_DAYS', 180);

/** Label ringkas perangkat dari User-Agent: "Chrome · Android". */
function deiUaLabel($ua) {
    $ua = (string)$ua;
    if ($ua === '') return '';
    if (preg_match('/curl|python|wget|okhttp|Go-http|bot|spider|httpclient|postman/i', $ua)) return 'Skrip/Bot';
    $b = 'Browser';
    if (strpos($ua, 'Edg/') !== false || strpos($ua, 'EdgA/') !== false) $b = 'Edge';
    elseif (strpos($ua, 'OPR/') !== false || strpos($ua, 'Opera') !== false) $b = 'Opera';
    elseif (strpos($ua, 'SamsungBrowser') !== false) $b = 'Samsung Internet';
    elseif (strpos($ua, 'Firefox/') !== false || strpos($ua, 'FxiOS') !== false) $b = 'Firefox';
    elseif (strpos($ua, 'Chrome/') !== false || strpos($ua, 'CriOS') !== false) $b = 'Chrome';
    elseif (strpos($ua, 'Safari/') !== false) $b = 'Safari';
    $o = '';
    if (strpos($ua, 'Android') !== false) $o = 'Android';
    elseif (preg_match('/iPhone|iPad|iPod/', $ua)) $o = 'iOS';
    elseif (strpos($ua, 'Windows') !== false) $o = 'Windows';
    elseif (strpos($ua, 'CrOS') !== false) $o = 'ChromeOS';
    elseif (preg_match('/Mac OS X|Macintosh/', $ua)) $o = 'macOS';
    elseif (strpos($ua, 'Linux') !== false) $o = 'Linux';
    return $o !== '' ? ($b . ' · ' . $o) : $b;
}

/** Catat satu percobaan login. Tidak pernah menggagalkan proses login. */
function deiLoginLog($username, $ok, $method, $reason = '', $extra = []) {
    try {
        deiWithLock('login-log', function () use ($username, $ok, $method, $reason, $extra) {
            $all = readJson(LOGIN_LOG_FILE, []);
            if (!is_array($all)) $all = [];
            $now = time();
            $ua  = substr((string)($_SERVER['HTTP_USER_AGENT'] ?? ''), 0, 300);
            $e = [
                't'   => $now,
                'ts'  => wibDate('Y-m-d H:i:s', $now),
                'u'   => mb_substr(trim((string)$username), 0, 60),
                'ok'  => (bool)$ok,
                'm'   => (string)$method,
                'ip'  => clientIp(),
                'dev' => deiUaLabel($ua),
                'ua'  => $ua,
            ];
            if ($reason !== '') $e['r'] = (string)$reason;
            foreach ((array)$extra as $k => $v) $e[$k] = is_string($v) ? mb_substr($v, 0, 80) : $v;
            array_unshift($all, $e);
            $cut = $now - LOGIN_LOG_DAYS * 86400;
            $all = array_values(array_filter(array_slice($all, 0, LOGIN_LOG_MAX), function ($x) use ($cut) {
                return is_array($x) && (int)($x['t'] ?? 0) >= $cut;
            }));
            writeJson(LOGIN_LOG_FILE, $all);
        });
    } catch (\Throwable $ex) {
        error_log('login-log: ' . $ex->getMessage());
    }
}

/** username => entri login berhasil terakhir. */
function deiLoginLastMap() {
    $m = [];
    foreach ((array)readJson(LOGIN_LOG_FILE, []) as $e) {
        if (!is_array($e) || empty($e['ok'])) continue;
        $u = (string)($e['u'] ?? '');
        if ($u !== '' && !isset($m[$u])) $m[$u] = $e;
    }
    return $m;
}

/** Returns null if OK, or an error string explaining why password is too weak. */
function checkPasswordStrength($pw) {
    $pw = (string)$pw;
    if (strlen($pw) < 8) return 'Password minimal 8 karakter.';
    if (!preg_match('/[a-z]/', $pw)) return 'Password harus mengandung huruf kecil.';
    if (!preg_match('/[A-Z]/', $pw)) return 'Password harus mengandung huruf besar.';
    if (!preg_match('/[0-9]/', $pw)) return 'Password harus mengandung angka.';
    return null;
}

/** Returns the authenticated user array or sends 401. */
/* v1.2.4: silent auth for admin test chatbot bypass — mirror requireAuth tapi return null (no exit) */
function getAuthenticatedUserSilent() {
    $username = tokenUsername(requestToken());
    if (!$username) return null;
    $users = readJson(USERS_FILE, []);
    foreach ($users as $u) {
        if (isset($u['username']) && $u['username'] === $username) {
            $role = $u['role'] ?? 'admin';
            // Apply same role migration as requireAuth (in-memory only, no write)
            if ($role === 'admin' && empty($u['migrated_3role'])) $role = 'super_admin';
            elseif ($role === 'editor' && empty($u['migrated_3role'])) $role = 'admin';
            $u['role'] = $role;
            return $u;
        }
    }
    return null;
}
// === /v1.2.4 silent auth ===

function requireAuth($roles = null) {
    $username = tokenUsername(requestToken());
    if (!$username) jsonOut(['ok' => false, 'error' => 'Tidak terautentikasi. Silakan login kembali.'], 401);
    $users = readJson(USERS_FILE, []);
    $changed = false;
    foreach ($users as $idx => $u) {
        if (isset($u['username']) && $u['username'] === $username) {
            // Migrate legacy roles: 'admin' (akses penuh lama) -> 'super_admin'; 'editor' -> 'admin'
            $role = $u['role'] ?? 'admin';
            if ($role === 'admin' && empty($u['migrated_3role'])) {
                $users[$idx]['role'] = 'super_admin';
                $users[$idx]['migrated_3role'] = true;
                $role = 'super_admin';
                $changed = true;
            } elseif ($role === 'editor' && empty($u['migrated_3role'])) {
                $users[$idx]['role'] = 'admin';
                $users[$idx]['migrated_3role'] = true;
                $role = 'admin';
                $changed = true;
            }
            if ($changed) writeJson(USERS_FILE, $users);
            $u['role'] = $role;
            if ($roles !== null) {
                $allowed = (array)$roles;
                // v1.2.58: Supervisor = semua yang boleh dilakukan agent, plus
                // aksi yang mencantumkan 'supervisor' secara eksplisit.
                if ($role === 'supervisor' && in_array('wa_agent', $allowed, true)) $allowed[] = 'supervisor';
                if (!in_array($role, $allowed, true)) {
                    jsonOut(['ok' => false, 'error' => 'Akses ditolak untuk peran Anda.'], 403);
                }
            }
            // v1.2.58: akun di luar batas kursi paket tidak bisa dipakai
            if (($role === 'wa_agent' || $role === 'supervisor') && !deiSeatAllowed($username, $role, $users)) {
                jsonOut(['ok' => false, 'error' => deiSeatMsg($role, deiFeatures()), 'seat_locked' => true], 403);
            }
            return $u;
        }
    }
    jsonOut(['ok' => false, 'error' => 'Pengguna tidak ditemukan.'], 401);
}

/** Allowed roles for masking-aware settings save (mirrors get_settings). */
function roleCanEditSecrets($role)   { return $role === 'super_admin'; }
function roleCanEditApiBlock($role)  { return $role === 'super_admin'; }   // Claude API block
function roleCanEditWaBlock($role)   { return $role === 'super_admin'; }   // WhatsApp API + config
function roleCanEditTelegram($role)  { return $role === 'super_admin'; }
function roleCanEditBotPersona($role){ return in_array($role, ['super_admin', 'admin'], true); }
function roleCanEditWidget($role)    { return in_array($role, ['super_admin', 'admin'], true); }   // toggles, branding (non-secret)
function roleCanEditHandoff($role)   { return in_array($role, ['super_admin', 'admin'], true); }

/* ----------------------------------------------------------------------------
 *  Settings — never leak the raw API key to clients
 * ------------------------------------------------------------------------- */
function getSettings() {
    return readJson(SETTINGS_FILE, []);
}

/* ============================================================
 * v1.2.53: penggabung settings yang benar.
 *
 * array_replace_recursive() menggabung array BERINDEKS per-indeks, bukan
 * mengganti. Akibatnya daftar tidak pernah bisa menyusut: hapus 1 bahasa
 * atau 1 saran cepat, lalu simpan -> item lama muncul lagi dari $current.
 *
 * Aturan di sini: array asosiatif digabung rekursif (perilaku lama,
 * supaya rahasia yang tidak dikirim tetap aman), sedangkan array
 * berindeks (daftar) dan skalar DIGANTI UTUH oleh nilai baru.
 * ============================================================ */
function deiIsList($a) {
    if (!is_array($a)) return false;
    if ($a === []) return true;   // daftar kosong = pengosongan yang disengaja
    return array_keys($a) === range(0, count($a) - 1);
}
function deiMergeSettings($current, $incoming) {
    if (!is_array($current)) return $incoming;
    foreach ($incoming as $k => $v) {
        if (is_array($v) && !deiIsList($v) && isset($current[$k]) && is_array($current[$k]) && !deiIsList($current[$k])) {
            $current[$k] = deiMergeSettings($current[$k], $v);
        } else {
            $current[$k] = $v;   // daftar & skalar: ganti utuh
        }
    }
    return $current;
}

function maskKey($key) {
    if (!$key) return '';
    $len = strlen($key);
    if ($len <= 8) return str_repeat('•', $len);
    return substr($key, 0, 6) . str_repeat('•', 8) . substr($key, -4);
}

/* ----------------------------------------------------------------------------
 *  Knowledge-base relevance search (keyword scoring)
 * ------------------------------------------------------------------------- */
function searchKB($query, $max) {
    $kb = readJson(KB_FILE, []);
    if (!$kb) return [];
    $words = preg_split('/\s+/', mb_strtolower(trim($query)));
    $words = array_filter($words, function ($w) { return mb_strlen($w) >= 3; });
    $scored = [];
    foreach ($kb as $entry) {
        $hay = mb_strtolower(($entry['title'] ?? '') . ' ' . ($entry['category'] ?? '') . ' ' . ($entry['content'] ?? ''));
        $score = 0;
        foreach ($words as $w) {
            $score += substr_count($hay, $w);
        }
        if ($score > 0) $scored[] = ['s' => $score, 'e' => $entry];
    }
    usort($scored, function ($a, $b) { return $b['s'] - $a['s']; });
    $top = array_slice($scored, 0, max(1, (int)$max));
    return array_map(function ($r) { return $r['e']; }, $top);
}

/* ----------------------------------------------------------------------------
 *  Rate limiting — per IP per hour
 * ------------------------------------------------------------------------- */
// v1.2.71: mode antrean memakai Redis (INCR per jam); mode file memakai kunci berkas.
function checkRateLimit($ip, $limit) {
    if (deiQueueRedis()) {
        try {
            $k = 'rl:' . $ip . ':' . intdiv(time(), 3600);
            $n = deiRedis()->incr($k);
            if ($n === 1) deiRedis()->expire($k, 3700);
            return $n <= $limit;
        } catch (\Throwable $e) { error_log('ratelimit redis: ' . $e->getMessage()); return true; }
    }
    return deiWithLock('ratelimit', function () use ($ip, $limit) { return checkRateLimit_nolock($ip, $limit); });
}
function checkRateLimit_nolock($ip, $limit) {
    $store = readJson(RATELIMIT_FILE, []);
    $now = time();
    // prune entries older than 1 hour
    foreach ($store as $k => $v) {
        if (!is_array($v)) { unset($store[$k]); continue; }
        $store[$k] = array_values(array_filter($v, function ($t) use ($now) { return $t > $now - 3600; }));
        if (empty($store[$k])) unset($store[$k]);
    }
    $count = isset($store[$ip]) ? count($store[$ip]) : 0;
    if ($count >= $limit) {
        writeJson(RATELIMIT_FILE, $store);
        return false;
    }
    $store[$ip][] = $now;
    writeJson(RATELIMIT_FILE, $store);
    return true;
}

/* ----------------------------------------------------------------------------
 *  Call Anthropic API
 * ------------------------------------------------------------------------- */
/* ============================================================
 *  License enforcement (v1.1.3)
 *  Tenant caches license_status from central in license-cache.json
 *  Refreshes lazily: if cache empty or >24h old, fetch from central.
 *  When status changes to 'suspended', backs up + clears tokens.
 *  When status changes back to 'active', requires manual token re-entry.
 * ============================================================ */
define('LIC_CACHE_FILE', DATA_DIR . '/license-cache.json');
define('LIC_CACHE_TTL', 24 * 3600);
define('LIC_DEFAULT_SUSPEND_MSG', 'Maaf, layanan chat sementara tidak tersedia. Silakan hubungi kami melalui kontak yang tersedia.');

/* v1.1.4: WIB helpers — Indonesia UTC+7 */
function wibNow() { return time() + 7 * 3600; }
function wibDate($fmt, $ts = null) { return gmdate($fmt, ($ts ?? time()) + 7 * 3600); }
function wibMonthKey($ts = null) { return wibDate('Y-m', $ts); }
function wibToday($ts = null) { return wibDate('Y-m-d', $ts); }

/* v1.1.4: cap cache + getCapStatus
 * Cap status comes from central via update_check response.
 * Cached 24h. When stale, refreshed lazily on next chat.
 */
define('CAP_CACHE_FILE', DATA_DIR . '/cap-cache.json');
define('CAP_DEFAULT_MSG', 'Maaf, layanan chat sedang sibuk. Silakan hubungi kami melalui kontak yang tersedia.');

/* ======================================================================
 * v1.2.90: trial pendaftaran mandiri. Pusat mengirim features.trial =
 * {start, ends (unix), cap (balasan AI), upgrade_url}. Penegakan dihitung
 * LOKAL dari usage.json (tanpa menunggu cache 24 jam) -> tepat di batas.
 * ==================================================================== */
function deiTrialNorm($t) {
    if (!is_array($t) || empty($t['ends'])) return null;
    return ['start' => (int)($t['start'] ?? 0), 'ends' => (int)$t['ends'],
            'cap' => max(0, (int)($t['cap'] ?? 0)),
            'upgrade_url' => substr((string)($t['upgrade_url'] ?? ''), 0, 300)];
}
function deiTrialUsed($t) {
    $from = wibDate('Y-m-d', (int)($t['start'] ?? 0));
    $n = 0;
    foreach ((array)readJson(DATA_DIR . '/usage.json', []) as $day => $d) {
        if ((string)$day >= $from && is_array($d)) $n += (int)($d['calls'] ?? 0);
    }
    return $n;
}
function deiTrialOverlay($c) {
    $t = deiTrialNorm($c['features']['trial'] ?? null);
    if (!$t) return $c;
    $now  = time();
    $used = deiTrialUsed($t);
    $expired = $now >= $t['ends'];
    $out     = $t['cap'] > 0 && $used >= $t['cap'];
    $c['trial'] = $t + ['used' => $used, 'days_left' => max(0, (int)ceil(($t['ends'] - $now) / 86400)),
                        'expired' => $expired, 'quota_out' => $out];
    $c['reached'] = $expired || $out;
    $c['warning'] = false;            // trial: tidak berhenti di 90%
    $c['cap']  = $t['cap'];
    $c['used'] = $used;
    $c['pct']  = $t['cap'] > 0 ? round($used / $t['cap'] * 100, 1) : 0;
    if (trim((string)($c['message'] ?? '')) === '') $c['message'] = CAP_DEFAULT_MSG;
    return $c;
}
function getCapStatus($settings, $forceRefresh = false) {
    return deiTrialOverlay(deiCapStatusRaw($settings, $forceRefresh));
}
// v1.2.90: trial — versi mentah (cache + pusat), dibungkus getCapStatus()
function deiCapStatusRaw($settings, $forceRefresh = false) {
    $cs = $settings['central_server'] ?? [];
    // No central configured → no cap enforcement
    if (empty($cs['url']) || empty($cs['tenant_id']) || empty($cs['license_key'])) {
        return ['reached' => false, 'warning' => false, 'pct' => 0, 'message' => '', 'source' => 'no-central'];
    }
    $cache = readJson(CAP_CACHE_FILE, []);
    $now = time();
    $age = $now - (int)($cache['cached_at'] ?? 0);
    // v1.2.69: status "habis" dicek ulang tiap 10 menit (bukan 24 jam) supaya bot pulih
    // segera setelah kuota dinaikkan / aturan pusat berubah. Status normal tetap 24 jam.
    $ttl = !empty($cache['reached']) ? 600 : 24 * 3600;
    if (!$forceRefresh && !empty($cache['cached_at']) && $age < $ttl) {
        return [
            'reached' => !empty($cache['reached']),
            'warning' => !empty($cache['warning']),
            'pct'     => (float)($cache['pct'] ?? 0),
            'message' => $cache['message'] ?? '',
            'tier'    => $cache['tier']    ?? '',
            'cap'     => $cache['cap']     ?? 0,
            'used'    => $cache['used']    ?? 0,
            'features'=> $cache['features'] ?? null,   // v1.2.58
            'source'  => 'cache-' . $age . 's',
        ];
    }
    // Stale or missing → refresh by calling update_check (lightweight; same path license uses)
    $stats = deiCollectStats();   // v1.2.57: kirim lengkap supaya pusat ikut segar
    $url = rtrim($cs['url'], '/') . '/backend/index.php?action=check_update';
    $payload = json_encode([
        'tenant_id'   => $cs['tenant_id'],
        'license_key' => $cs['license_key'],
        'current'     => readJson(DATA_DIR . '/version.json', [])['version'] ?? 'v1.1.4',
        'stats'       => $stats,
    ]);
    $ch = curl_init($url);
    curl_setopt_array($ch, [
        CURLOPT_RETURNTRANSFER => true, CURLOPT_POST => true,
        CURLOPT_POSTFIELDS => $payload,
        CURLOPT_HTTPHEADER => ['Content-Type: application/json'],
        CURLOPT_TIMEOUT => 10,
    ]);
    $resp = curl_exec($ch);
    curl_close($ch);
    if (!$resp) {
        // fail-open with stale cache or default
        if (!empty($cache['cached_at'])) {
            $cache['source'] = 'stale-fallback';
            return $cache;
        }
        return ['reached' => false, 'warning' => false, 'pct' => 0, 'message' => '', 'source' => 'fail-open'];
    }
    $data = json_decode($resp, true) ?: [];
    $cap = $data['cap_info'] ?? null;
    if (!$cap) {
        return ['reached' => false, 'warning' => false, 'pct' => 0, 'message' => '', 'source' => 'no-cap-info'];
    }
    $msg = trim($cap['cap_message'] ?? '');
    if ($msg === '') $msg = CAP_DEFAULT_MSG;
    $newCache = [
        'reached'   => !empty($cap['cap_reached']),
        'warning'   => !empty($cap['cap_warning']),
        'pct'       => (float)($cap['usage_pct'] ?? 0),
        'tier'      => $cap['tier'] ?? '',
        'cap'       => (int)($cap['monthly_chat_cap'] ?? 0),
        'used'      => (int)($cap['chats_this_month'] ?? 0),
        'message'   => $msg,
        'features'  => deiFeaturesFromCap($cap),   // v1.2.58
        'cached_at' => $now,
    ];
    writeJson(CAP_CACHE_FILE, $newCache);
    $newCache['source'] = 'refreshed';
    return $newCache;
}

/* Compute chat count + cost for current WIB month from data/usage.json */
/* v1.2.57: pencacah pesan WA keluar via Meta Cloud API (per bulan WIB).
 * Meta: tiap nomor dapat 1.000 service message gratis/bulan sejak 1 Okt 2026;
 * template (marketing/utility/auth) selalu berbayar. Fonnte tidak dihitung. */
if (!defined('WA_OUT_FILE')) define('WA_OUT_FILE', DATA_DIR . '/wa-out.json');
if (!defined('WA_FREE_SERVICE_QUOTA')) define('WA_FREE_SERVICE_QUOTA', 1000);
function waOutCount($kind) {
    try {
        $fp = @fopen(WA_OUT_FILE, 'c+');
        if (!$fp) return;
        @flock($fp, LOCK_EX);
        $raw = stream_get_contents($fp);
        $all = json_decode((string)$raw, true);
        if (!is_array($all)) $all = [];
        $m = wibDate('Y-m');
        if (!isset($all[$m]) || !is_array($all[$m])) $all[$m] = ['service' => 0, 'template' => 0];
        $k = in_array($kind, ['template', 'saved'], true) ? $kind : 'service';   // v1.2.89: 'saved' = bubble yang tidak jadi dikirim
        $all[$m][$k] = (int)($all[$m][$k] ?? 0) + 1;
        $och = (string)($GLOBALS['wa_out_ch'] ?? '');   // v1.2.98: multi-nomor
        if ($k !== 'saved' && $och !== '') {
            if (!isset($all[$m]['ch']) || !is_array($all[$m]['ch'])) $all[$m]['ch'] = [];
            $all[$m]['ch'][$och][$k] = (int)($all[$m]['ch'][$och][$k] ?? 0) + 1;
        }
        ksort($all);
        if (count($all) > 13) $all = array_slice($all, -13, null, true);
        ftruncate($fp, 0); rewind($fp);
        fwrite($fp, json_encode($all, JSON_PRETTY_PRINT));
        fflush($fp); @flock($fp, LOCK_UN); fclose($fp);
    } catch (\Throwable $e) { error_log('waOutCount: ' . $e->getMessage()); }
}
function waOutMonth($monthKey = null) {
    $all = readJson(WA_OUT_FILE, []);
    $r = is_array($all[$monthKey ?? wibDate('Y-m')] ?? null) ? $all[$monthKey ?? wibDate('Y-m')] : [];
    return ['service' => (int)($r['service'] ?? 0), 'template' => (int)($r['template'] ?? 0), 'saved' => (int)($r['saved'] ?? 0),   // v1.2.89
            'ch' => is_array($r['ch'] ?? null) ? $r['ch'] : []];   // v1.2.98: multi-nomor
}

/* v1.2.89: HEMAT PESAN WA. Sejak 1 Okt 2026 Meta menagih tiap service message yang
 * terkirim (lewat 1.000 gratis/nomor/bulan). settings.wa_hemat:
 *   debounce_sec (0-8, bawaan 3) — bubble beruntun satu nomor dijawab sekali
 *   skip_ack     (bawaan true)  — "ok makasih" setelah jawaban bot (bukan pertanyaan) tidak dibalas
 *   prompt       (bawaan true)  — instruksi "satu jawaban tuntas" untuk kanal WhatsApp */
function deiHematConf($s = null) {
    if ($s === null) $s = getSettings();
    $h = is_array($s['wa_hemat'] ?? null) ? $s['wa_hemat'] : [];
    return [
        'debounce_sec' => array_key_exists('debounce_sec', $h) ? max(0.0, min(8.0, (float)$h['debounce_sec'])) : 3.0,
        'skip_ack'     => !array_key_exists('skip_ack', $h) || !empty($h['skip_ack']),
        'prompt'       => !array_key_exists('prompt', $h) || !empty($h['prompt']),
    ];
}
/* v1.2.96: jeda-balasan — JEDA BALASAN AI (WhatsApp) berdasarkan jumlah karakter.
 * settings.reply_delay = { enabled, basis: 'answer'|'question',
 *   rules: [{max: 50, sec: 3}, {max: 200, sec: 5}], over_sec: 8 }
 * Teks <= max pertama -> sec-nya; dst. Lebih panjang dari semua max -> over_sec.
 * Jeda dihitung sejak AI mulai memproses (waktu AI berpikir ikut dihitung). Maks 20 detik. */
define('DEI_REPLY_DELAY_MAX', 20);
function deiReplyDelayConf($s = null) {
    if ($s === null) $s = getSettings();
    $r = is_array($s['reply_delay'] ?? null) ? $s['reply_delay'] : [];
    $rules = [];
    foreach ((array)($r['rules'] ?? [['max' => 50, 'sec' => 3], ['max' => 200, 'sec' => 5]]) as $x) {
        if (!is_array($x)) continue;
        $max = (int)($x['max'] ?? 0);
        if ($max < 1) continue;
        $rules[$max] = ['max' => min(100000, $max), 'sec' => max(0, min(DEI_REPLY_DELAY_MAX, (int)($x['sec'] ?? 0)))];
    }
    ksort($rules);
    return [
        'enabled'  => !empty($r['enabled']),
        'basis'    => (($r['basis'] ?? 'answer') === 'question') ? 'question' : 'answer',
        'rules'    => array_slice(array_values($rules), 0, 10),
        'over_sec' => max(0, min(DEI_REPLY_DELAY_MAX, (int)($r['over_sec'] ?? 8))),
        'typing'   => !empty($r['typing']),   // v1.2.96: mengetik
    ];
}
function deiReplyDelaySec($c, $len) {
    foreach ($c['rules'] as $x) { if ($len <= $x['max']) return $x['sec']; }
    return $c['over_sec'];
}
// Tunggu sisa jeda sebelum balasan AI dikirim. $t0 = microtime(true) saat AI mulai memproses.
function deiReplyDelayWait($s, $question, $answer, $t0) {
    try {
        $c = deiReplyDelayConf($s);
        if (!$c['enabled']) return 0;
        $len = mb_strlen(trim((string)($c['basis'] === 'question' ? $question : $answer)));
        if ($len < 1) return 0;
        $sisa = deiReplyDelaySec($c, $len) - (microtime(true) - (float)$t0);
        if ($sisa > 0.05) usleep((int)(min(DEI_REPLY_DELAY_MAX, $sisa) * 1000000));
        return max(0, $sisa);
    } catch (\Throwable $e) { error_log('reply_delay: ' . $e->getMessage()); return 0; }
}
/* v1.2.96: mengetik — tampilkan "sedang mengetik…" ke pelanggan selama AI berpikir + jeda.
 * Meta: wajib menyertakan id pesan masuk (dipasang waHandleMetaMessage di $GLOBALS['dei_in_wamid']);
 * panggilan ini sekaligus menandai pesan dibaca (centang biru). WAHA: startTyping/stopTyping. */
function deiTypingStart($s, $wa, $to) {
    $wa = waChanFor($wa, $to);   // v1.2.98: multi-nomor
    $GLOBALS['dei_typing_on'] = false;
    try {
        if (!deiReplyDelayConf($s)['typing']) return false;
        $prov = (string)($wa['provider'] ?? 'meta');
        if ($prov === 'waha') {
            $num = waNormNum($to);
            if ($num === '') return false;
            list($c) = wahaApi($wa, 'POST', '/api/startTyping', ['session' => wahaSession($wa), 'chatId' => $num . '@c.us']);
            $GLOBALS['dei_typing_on'] = ($c >= 200 && $c < 300);
            return $GLOBALS['dei_typing_on'];
        }
        if ($prov !== 'meta') return false;
        $wamid = (string)($GLOBALS['dei_in_wamid'] ?? '');
        $token = (string)($wa['access_token'] ?? ''); $pnid = (string)($wa['phone_number_id'] ?? '');
        if ($wamid === '' || $token === '' || $pnid === '') return false;
        $ch = curl_init('https://graph.facebook.com/v21.0/' . rawurlencode($pnid) . '/messages');
        curl_setopt_array($ch, [
            CURLOPT_RETURNTRANSFER => true, CURLOPT_POST => true, CURLOPT_TIMEOUT => 5, CURLOPT_CONNECTTIMEOUT => 3,
            CURLOPT_HTTPHEADER => ['Content-Type: application/json', 'Authorization: Bearer ' . $token],
            CURLOPT_POSTFIELDS => json_encode(['messaging_product' => 'whatsapp', 'status' => 'read',
                'message_id' => $wamid, 'typing_indicator' => ['type' => 'text']]),
        ]);
        $resp = curl_exec($ch); $code = curl_getinfo($ch, CURLINFO_HTTP_CODE); curl_close($ch);
        if ($code < 200 || $code >= 300) { error_log('typing Meta HTTP ' . $code . ': ' . mb_substr((string)$resp, 0, 200)); return false; }
        $GLOBALS['dei_typing_on'] = true;
        return true;
    } catch (\Throwable $e) { error_log('typing: ' . $e->getMessage()); return false; }
}
// Meta menghapus indikator sendiri saat balasan masuk; WAHA perlu dihentikan.
function deiTypingStop($wa, $to) {
    $wa = waChanFor($wa, $to);   // v1.2.98: multi-nomor
    if (empty($GLOBALS['dei_typing_on'])) return;
    $GLOBALS['dei_typing_on'] = false;
    try {
        if ((string)($wa['provider'] ?? 'meta') === 'waha') {
            wahaApi($wa, 'POST', '/api/stopTyping', ['session' => wahaSession($wa), 'chatId' => waNormNum($to) . '@c.us']);
        }
    } catch (\Throwable $e) { error_log('typing stop: ' . $e->getMessage()); }
}
/* v1.2.97: batas-ai — BATAS BALASAN AI per percakapan WhatsApp.
 * settings.ai_limit = { max: 0 (mati) .. 50, text: pesan serah terima (kosong = tidak dikirim) }
 * Hitungan = conv-state[nomor].bot_n (naik di convReply('bot')). */
function deiAiLimitConf($s = null) {
    if ($s === null) $s = getSettings();
    $a = is_array($s['ai_limit'] ?? null) ? $s['ai_limit'] : [];
    return [
        'max'  => max(0, min(50, (int)($a['max'] ?? 0))),
        'text' => mb_substr(trim((string)($a['text'] ?? '')), 0, 500),
    ];
}
function convBotCount($num) {
    $num = waNormNum($num);
    if ($num === '') return 0;
    try {
        return (int)convStateMutate(function (&$all) use ($num) { return (int)($all[$num]['bot_n'] ?? 0); }, $num);
    } catch (\Throwable $e) { error_log('convBotCount: ' . $e->getMessage()); return 0; }
}
function convBotReset($num) {
    $num = waNormNum($num);
    if ($num === '') return;
    try {
        convStateMutate(function (&$all) use ($num) { if (isset($all[$num]) && is_array($all[$num])) $all[$num]['bot_n'] = 0; }, $num);
    } catch (\Throwable $e) { error_log('convBotReset: ' . $e->getMessage()); }
}
// Pesan sistem ke satu nomor maks sekali per $ttl detik. true = boleh kirim sekarang (dan dicatat).
function deiSysOnce($num, $kind, $ttl) {
    $k = preg_replace('/\D/', '', (string)$num) . ':' . $kind;
    try {
        return deiWithLock('sysonce', function () use ($k, $ttl) {
            $f = DATA_DIR . '/sys-once.json';
            $all = readJson($f, []);
            if (!is_array($all)) $all = [];
            $now = time();
            foreach ($all as $kk => $t) { if ((int)$t < $now - 86400) unset($all[$kk]); }
            if (isset($all[$k]) && (int)$all[$k] > $now - $ttl) return false;
            $all[$k] = $now;
            writeJson($f, $all);
            return true;
        });
    } catch (\Throwable $e) { error_log('deiSysOnce: ' . $e->getMessage()); return true; }
}
// Instruksi gaya balasan WhatsApp. Ditempel di blok SETELAH titik cache supaya cache KB tetap utuh.
function deiHematPromptBlock() {
    return "=== GAYA BALASAN WHATSAPP (HEMAT PESAN) ===\n"
         . "Setiap balasanmu dikirim sebagai SATU pesan WhatsApp dan setiap pesan berbiaya. Karena itu:\n"
         . "- Jawab tuntas dalam satu balasan. Sertakan sekaligus info yang hampir pasti ditanyakan berikutnya (mis. harga + jadwal + cara pesan/link).\n"
         . "- Bila perlu data dari pelanggan, tanyakan SEMUA yang dibutuhkan sekaligus dalam satu pesan, jangan satu per satu.\n"
         . "- Jangan menutup dengan basa-basi yang memancing balasan tanpa isi (mis. \"Ada lagi yang bisa dibantu?\") kecuali memang perlu.\n"
         . "- Tetap ringkas dan mudah dibaca.";
}

/* v1.2.57: satu sumber statistik untuk report_back, check_update & cron_tick
 * (sebelumnya hanya tombol cek update manual yang mengirim, jadi angka di pusat basi). */
function deiCollectStats() {
    $logs = logReadAll();
    if (!is_array($logs)) $logs = [];
    $kb = readJson(KB_FILE, []);
    $today = wibToday();
    $chats_today = 0; $chats_total = 0; $wa_chats_today = 0; $visitors_today = [];
    foreach ($logs as $l) {
        if (!is_array($l)) continue;
        if (in_array(($l['dir'] ?? ''), ['manual', 'closing'], true)) continue;
        $chats_total++;
        if (strpos((string)($l['ts'] ?? ''), $today) === 0) {
            $chats_today++;
            if (($l['channel'] ?? '') === 'whatsapp') $wa_chats_today++;
            if (!empty($l['ip'])) $visitors_today[$l['ip']] = 1;
        }
    }
    $usage = readJson(DATA_DIR . '/usage.json', []);
    $u = array_merge(['calls' => 0, 'input' => 0, 'output' => 0, 'cache_write' => 0, 'cache_read' => 0], (array)($usage[$today] ?? []));
    $cost_today = round(deiDayCost(array_merge($u, (array)($usage[$today] ?? []))), 5);
    $month = computeMonthStats();
    $wo = waOutMonth();
    return [
        'chats_today'           => $chats_today,
        'chats_total'           => $chats_total,
        'wa_chats_today'        => $wa_chats_today,
        'kb_entries'            => is_array($kb) ? count($kb) : 0,
        'unique_visitors_today' => count($visitors_today),
        'tokens_in_today'       => (int)$u['input'],
        'tokens_out_today'      => (int)$u['output'],
        'cache_write_today'     => (int)$u['cache_write'],
        'cache_read_today'      => (int)$u['cache_read'],
        'cost_today_usd'        => $cost_today,
        'chats_this_month'      => $month['chats_this_month'],
        'cost_this_month_usd'   => $month['cost_this_month_usd'],
        'wa_out_service_month'  => $wo['service'],
        'wa_out_template_month' => $wo['template'],
        'seats'                 => deiSeatCounts(),   // v1.2.60: pemakaian kursi tim untuk tabel pusat
        'wa_provider'           => (function () { $w = (array)(getSettings()['whatsapp_api'] ?? []); return (!empty($w['enabled']) || deiWaConnected($w)) ? (string)($w['provider'] ?? 'meta') : 'off'; })(),   // v1.2.93: wa-bot-off   // v1.2.92: fonnte-off
        'trial_used'            => (function () { $t = deiTrialNorm(readJson(CAP_CACHE_FILE, [])['features']['trial'] ?? null); return $t ? deiTrialUsed($t) : null; })(),   // v1.2.90
        'wa_health'             => (function () { try { return whStatsSummary(); } catch (\Throwable $e) { return null; } })(),   // v1.2.104: skor-risiko-wa
        'topic_scans'           => (function () { try { $q = deiTopicQuota(true); return ['used' => $q['used'], 'limit' => $q['limit']]; } catch (\Throwable $e) { return null; } })(),   // v1.2.68
    ];
}

function computeMonthStats() {
    $usage = readJson(DATA_DIR . '/usage.json', []);
    $monthKey = wibDate('Y-m');
    $chats = 0; $cost = 0.0;
    foreach ($usage as $day => $d) {
        if (strpos($day, $monthKey) !== 0) continue;
        $chats += (int)($d['calls'] ?? 0);
        $cost  += deiDayCost($d);   // v1.2.69
    }
    return ['chats_this_month' => $chats, 'cost_this_month_usd' => round($cost, 6)];
}

/**
 * Aggregate Claude usage per day into data/usage.json — used for:

/**
 * Returns ['status' => 'active'|'expired'|'suspended', 'message' => string, 'expires_at' => string, 'days_left' => int|null]
 *
 * If central is unreachable AND cache exists, returns stale cache (fail-open behavior — we don't punish tenant for our pusat being down).
 * If central is unreachable AND no cache, returns 'active' (fail-open default).
 */
function getLicenseStatus($settings, $forceRefresh = false) {
    $cs = $settings['central_server'] ?? [];
    // No central configured → no enforcement (e.g. legacy installs)
    if (empty($cs['url']) || empty($cs['tenant_id']) || empty($cs['license_key'])) {
        return ['status' => 'active', 'message' => '', 'expires_at' => '', 'days_left' => null, 'source' => 'no-central'];
    }

    $cache = readJson(LIC_CACHE_FILE, []);
    $now = time();
    $age = $now - (int)($cache['cached_at'] ?? 0);

    if (!$forceRefresh && !empty($cache['status']) && $age < LIC_CACHE_TTL) {
        return [
            'status'     => $cache['status'],
            'message'    => $cache['message']    ?? '',
            'expires_at' => $cache['expires_at'] ?? '',
            'days_left'  => $cache['days_left']  ?? null,
            'source'     => 'cache-' . $age . 's',
        ];
    }

    // Refresh from central
    $url = rtrim($cs['url'], '/') . '/backend/index.php?action=check_update';
    $payload = json_encode([
        'tenant_id'   => $cs['tenant_id'],
        'license_key' => $cs['license_key'],
        'current'     => readJson(DATA_DIR . '/version.json', [])['version'] ?? 'v1.1.3',
        'stats'       => deiCollectStats(),   // v1.2.57
        'lic_caps'    => ['blocked'],   // v1.2.111: paham status blocked
    ]);
    $ch = curl_init($url);
    curl_setopt_array($ch, [
        CURLOPT_RETURNTRANSFER => true,
        CURLOPT_POST           => true,
        CURLOPT_POSTFIELDS     => $payload,
        CURLOPT_HTTPHEADER     => ['Content-Type: application/json'],
        CURLOPT_TIMEOUT        => 10,
    ]);
    $resp = curl_exec($ch);
    $code = curl_getinfo($ch, CURLINFO_HTTP_CODE);
    curl_close($ch);

    if ($resp === false || $code !== 200) {
        // FAIL-OPEN: use stale cache if any, else default active
        if (!empty($cache['status'])) {
            return [
                'status'     => $cache['status'],
                'message'    => $cache['message']    ?? '',
                'expires_at' => $cache['expires_at'] ?? '',
                'days_left'  => $cache['days_left']  ?? null,
                'source'     => 'stale-fallback',
            ];
        }
        return ['status' => 'active', 'message' => '', 'expires_at' => '', 'days_left' => null, 'source' => 'fail-open'];
    }
    $data = json_decode($resp, true) ?: [];
    if (empty($data['ok'])) {
        // Central explicitly rejected (e.g. tenant tidak terdaftar lagi → treat as suspended)
        $newCache = [
            'status'     => 'suspended',
            'message'    => LIC_DEFAULT_SUSPEND_MSG,
            'expires_at' => '',
            'days_left'  => null,
            'cached_at'  => $now,
            'reason'     => $data['error'] ?? 'rejected',
        ];
        writeJson(LIC_CACHE_FILE, $newCache);
        applyStatusSideEffects('suspended', $settings);
        return $newCache + ['source' => 'rejected'];
    }

    $newStatus = $data['license_status'] ?? 'active';
    $msg = trim($data['suspend_message'] ?? '');
    if ($msg === '') $msg = LIC_DEFAULT_SUSPEND_MSG;

    $newCache = [
        'status'     => $newStatus,
        'message'    => $msg,
        'expires_at' => $data['expires_at'] ?? '',
        'days_left'  => $data['days_left']  ?? null,
        'cached_at'  => $now,
    ];
    // Detect transition (was-active, now-suspended) → backup & clear tokens
    $oldStatus = $cache['status'] ?? null;
    if (!deiLicOff($oldStatus) && deiLicOff($newStatus)) {   // v1.2.111
        applyStatusSideEffects($newStatus, $settings);
    }
    writeJson(LIC_CACHE_FILE, $newCache);
    deiSyncBlock($newStatus);   // v1.2.111: blokir-total
    return $newCache + ['source' => 'refreshed'];
}

/**
 * Side-effects of status transitions.
 * Currently only 'suspended' has a side-effect: backup + clear tokens
 * (Claude API key, WA access_token + app_secret, Telegram bot_token).
 *
 * Backup saved to data/settings.json.suspended-backup.<timestamp> for SSH recovery.
 * To unsuspend → super_admin/admin must manually re-enter tokens in dashboard.
 */
function applyStatusSideEffects($newStatus, $settings) {
    if (!deiLicOff($newStatus)) return;   // v1.2.111: blocked juga
    $path = SETTINGS_FILE;
    if (!file_exists($path)) return;
    $current = readJson($path, []);
    // Already cleared? skip.
    $hasToken =
        !empty($current['api']['claude_api_key']) ||
        !empty($current['whatsapp_api']['access_token']) ||
        !empty($current['telegram']['bot_token']);
    if (!$hasToken) return;

    // Backup current settings (with tokens) for SSH recovery
    $stamp = date('Ymd-His');
    @copy($path, $path . '.suspended-backup.' . $stamp);

    // Clear tokens
    if (isset($current['api']['claude_api_key']))        $current['api']['claude_api_key'] = '';
    if (isset($current['api']['key_is_set']))            $current['api']['key_is_set'] = false;
    if (isset($current['whatsapp_api']['access_token'])) $current['whatsapp_api']['access_token'] = '';
    if (isset($current['whatsapp_api']['app_secret']))   $current['whatsapp_api']['app_secret'] = '';
    if (isset($current['telegram']['bot_token']))        $current['telegram']['bot_token'] = '';
    writeJson($path, $current);
}

/**
 * Aggregate Claude usage per day into data/usage.json — used for:
 *  - report-back to central (estimated cost per tenant)
 *  - super_admin dashboard transparency
 *
 * Schema: { "YYYY-MM-DD": { calls, input, output, cache_write, cache_read } }
 * Keeps last 90 days; trims older entries.
 */
/* v1.2.69: biaya per panggilan AI.
 * Sebelumnya semua dihitung dengan tarif Claude Haiku ($1/$5) apa pun modelnya,
 * sehingga tenant OpenRouter/Gemini terlihat jauh lebih mahal dari aslinya.
 * Urutan: biaya asli dari penyedia (OpenRouter usage.cost) -> tarif per model -> tarif Haiku. */
function deiModelPrice($model) {
    $m = strtolower((string)$model);
    // v1.2.103: model-terbaru — tarif USD per 1 juta token [input, output], Okt 2026
    $c5 = (bool)preg_match('/claude-(opus|sonnet|haiku|fable)-5/', $m);
    if (strpos($m, 'fable') !== false)  return [10.00, 50.00];
    if (strpos($m, 'opus') !== false)   return $c5 ? [4.00, 20.00] : [5.00, 25.00];
    if (strpos($m, 'sonnet') !== false) return $c5 ? [2.00, 10.00] : [3.00, 15.00];
    if (strpos($m, 'haiku-3') !== false || strpos($m, '3-haiku') !== false || strpos($m, '3.5-haiku') !== false) return [0.25, 1.25];
    if (strpos($m, 'haiku') !== false)  return $c5 ? [0.10, 0.50] : [1.00, 5.00];
    if (strpos($m, 'gemini') !== false) {
        $g2 = (bool)preg_match('/gemini-2/', $m);
        if (strpos($m, 'flash-lite') !== false) return $g2 ? [0.10, 0.40] : [0.30, 2.50];
        if (strpos($m, 'flash') !== false) {
            if (strpos($m, 'gemini-2.5') !== false) return [0.30, 2.50];
            return $g2 ? [0.10, 0.40] : [0.75, 3.75];
        }
        return [2.00, 12.00];   // pro / argon
    }
    if (strpos($m, 'gpt-6-luna') !== false) return [0.10, 0.50];
    if (strpos($m, 'luna') !== false) return [0.20, 1.20];
    if (strpos($m, 'nano') !== false) return [0.05, 0.40];
    if (strpos($m, 'gpt-4o-mini') !== false) return [0.15, 0.60];
    if (strpos($m, 'sol') !== false || strpos($m, 'gpt-4o') !== false) return [2.00, 10.00];
    if (strpos($m, 'deepseek') !== false) return [0.30, 1.20];
    if (strpos($m, 'qwen') !== false) return strpos($m, 'max') !== false ? [2.00, 6.00] : [0.20, 0.60];
    return [1.00, 5.00];   // tidak dikenal: tarif aman (cenderung lebih tinggi)
}
function deiUsageCost($usage) {
    if (isset($usage['cost_usd']) && is_numeric($usage['cost_usd'])) return max(0.0, (float)$usage['cost_usd']);
    list($pi, $po) = deiModelPrice($usage['model'] ?? '');
    return ((int)($usage['input_tokens'] ?? 0)                / 1e6 * $pi)
         + ((int)($usage['output_tokens'] ?? 0)               / 1e6 * $po)
         + ((int)($usage['cache_creation_input_tokens'] ?? 0) / 1e6 * $pi * 1.25)
         + ((int)($usage['cache_read_input_tokens'] ?? 0)     / 1e6 * $pi * 0.10);
}
// Estimasi lama (tarif Haiku) untuk hari yang tercatat sebelum v1.2.69.
function deiLegacyDayCost($d) {
    return ((int)($d['input'] ?? 0) / 1e6 * 1.00) + ((int)($d['output'] ?? 0) / 1e6 * 5.00)
         + ((int)($d['cache_write'] ?? 0) / 1e6 * 1.25) + ((int)($d['cache_read'] ?? 0) / 1e6 * 0.10);
}
function deiDayCost($d) {
    if (!is_array($d)) return 0.0;
    return isset($d['cost']) ? (float)$d['cost'] : deiLegacyDayCost($d);
}

// v1.2.71: dibungkus kunci 'usage' supaya worker paralel tidak saling menimpa.
function recordUsage($usage) {
    return deiWithLock('usage', function () use ($usage) { return recordUsage_nolock($usage); });
}
function recordUsage_nolock($usage) {
    if (!is_array($usage) || !$usage) return;
    $path = DATA_DIR . '/usage.json';
    $all  = readJson($path, []);
    $day  = date('Y-m-d');
    if (!isset($all[$day])) {
        $all[$day] = ['calls' => 0, 'input' => 0, 'output' => 0, 'cache_write' => 0, 'cache_read' => 0];
    }
    $all[$day]['calls']++;
    $all[$day]['input']       += (int)($usage['input_tokens']                ?? 0);
    $all[$day]['output']      += (int)($usage['output_tokens']               ?? 0);
    $all[$day]['cache_write'] += (int)($usage['cache_creation_input_tokens'] ?? 0);
    $all[$day]['cache_read']  += (int)($usage['cache_read_input_tokens']     ?? 0);
    // v1.2.69: akumulasi biaya per hari (hari lama tanpa 'cost' diawali estimasi lama)
    if (!isset($all[$day]['cost'])) {
        $prev = $all[$day]; $prev['calls']--;
        $prev['input'] -= (int)($usage['input_tokens'] ?? 0); $prev['output'] -= (int)($usage['output_tokens'] ?? 0);
        $prev['cache_write'] -= (int)($usage['cache_creation_input_tokens'] ?? 0); $prev['cache_read'] -= (int)($usage['cache_read_input_tokens'] ?? 0);
        $all[$day]['cost'] = deiLegacyDayCost($prev);
    }
    $all[$day]['cost'] = round((float)$all[$day]['cost'] + deiUsageCost($usage), 6);

    // Keep last 90 days
    if (count($all) > 95) {
        ksort($all);
        $all = array_slice($all, -90, null, true);
    }
    writeJson($path, $all);
}

/* v1.2.49: OpenRouter (OpenAI-compatible) — 1 API key untuk Gemini/GPT/Claude/Qwen/DeepSeek. */
function callOpenRouter($settings, $systemBlocks, $messages) {
    $key = $settings['api']['openrouter_api_key'] ?? '';
    if (!$key) return [false, 'OpenRouter API key belum dikonfigurasi di dashboard.', []];

    // Ratakan system blocks (format Anthropic) menjadi satu string sistem.
    $sys = '';
    if (is_array($systemBlocks)) {
        foreach ($systemBlocks as $b) { $sys .= (is_array($b) ? ($b['text'] ?? '') : (string)$b) . "\n"; }
    } else { $sys = (string)$systemBlocks; }
    $sys = trim($sys);

    $msgs = [];
    if ($sys !== '') $msgs[] = ['role' => 'system', 'content' => $sys];
    foreach ($messages as $m) {
        $content = $m['content'] ?? '';
        if (is_array($content)) {
            $t = '';
            foreach ($content as $cb) { $t .= is_array($cb) ? ($cb['text'] ?? '') : (string)$cb; }
            $content = $t;
        }
        $msgs[] = ['role' => ($m['role'] ?? 'user'), 'content' => (string)$content];
    }

    $payload = [
        'model'      => $settings['api']['openrouter_model'] ?? 'anthropic/claude-haiku-5.5',
        'max_tokens' => (int)($settings['api']['max_tokens'] ?? 400),
        'messages'   => $msgs,
        'usage'      => ['include' => true],   // v1.2.69: OpenRouter mengembalikan usage.cost (USD) asli
    ];
    if (!empty($settings['api']['_or_reasoning'])) $payload['reasoning'] = $settings['api']['_or_reasoning'];   // v1.2.102: or-kosong
    $ch = curl_init('https://openrouter.ai/api/v1/chat/completions');
    curl_setopt_array($ch, [
        CURLOPT_RETURNTRANSFER => true,
        CURLOPT_POST           => true,
        CURLOPT_TIMEOUT        => (int)($settings['api']['_timeout'] ?? 45),
        CURLOPT_HTTPHEADER     => [
            'Content-Type: application/json',
            'Authorization: Bearer ' . $key,
            'X-Title: ' . deiBrandProduct(),   // v1.2.73
        ],
        CURLOPT_POSTFIELDS     => json_encode($payload, JSON_UNESCAPED_UNICODE),
    ]);
    $res  = curl_exec($ch);
    $code = curl_getinfo($ch, CURLINFO_HTTP_CODE);
    $err  = curl_error($ch);
    curl_close($ch);

    if ($res === false) return [false, 'Gagal terhubung ke OpenRouter: ' . $err, []];
    $data = json_decode($res, true);
    if ($code !== 200) {
        $msg = $data['error']['message'] ?? ('HTTP ' . $code);
        return [false, 'AI error: ' . $msg, []];
    }
    if (isset($data['error']) && empty($data['choices'])) return [false, 'AI error: ' . (string)($data['error']['message'] ?? 'tanpa pesan'), []];   // v1.2.102: or-kosong
    $answer = $data['choices'][0]['message']['content'] ?? '';
    if (is_array($answer)) { // beberapa model balas array segmen
        $t=''; foreach ($answer as $seg){ $t .= is_array($seg)?($seg['text']??''):(string)$seg; } $answer=$t;
    }
    // v1.2.102: or-kosong — konten kosong (penalaran memakan max_tokens / respons hampa): ulang sekali, jatah lebih besar, penalaran minim
    if (trim((string)$answer) === '' && empty($settings['api']['_or_retry'])) {
        $fin = (string)($data['choices'][0]['finish_reason'] ?? '');
        error_log('openrouter: jawaban kosong (finish=' . $fin . ', out=' . (int)($data['usage']['completion_tokens'] ?? 0) . ') -> coba ulang');
        $s2 = $settings; $s2['api']['_or_retry'] = 1;
        $s2['api']['max_tokens'] = max(1500, (int)($settings['api']['max_tokens'] ?? 400) * 4);
        $s2['api']['_or_reasoning'] = ['effort' => 'low', 'exclude' => true];
        $r2 = callOpenRouter($s2, $systemBlocks, $messages);
        if (!empty($r2[0]) && trim((string)$r2[1]) !== '') return $r2;
        return [false, 'AI error: jawaban kosong (finish=' . $fin . ')', []];
    }
    $usage = [
        'input_tokens'                => (int)($data['usage']['prompt_tokens']     ?? 0),
        'output_tokens'               => (int)($data['usage']['completion_tokens'] ?? 0),
        'cache_creation_input_tokens' => 0,
        'cache_read_input_tokens'     => 0,
        'model'                       => (string)($payload['model'] ?? ''),
    ];
    if (isset($data['usage']['cost']) && is_numeric($data['usage']['cost'])) {
        $usage['cost_usd'] = (float)$data['usage']['cost'];   // v1.2.69: biaya asli dari OpenRouter
    }
    return [true, trim($answer), $usage];
}

/* v1.2.72: model cadangan (server sendiri). data/server.php:
 *   'ai_fallback' => ['provider' => 'openrouter', 'model' => 'google/gemini-3.5-flash-lite']
 * Kalau AI utama gagal, dicoba sekali dengan model cadangan. Tanpa kunci itu = perilaku lama. */
/* v1.2.80: model cadangan dipilih Super Admin di dashboard (settings.api.fallback = "provider:model").
 * "" = bawaan (data/server.php 'ai_fallback' bila ada), "none" = tanpa cadangan. */
function deiAiFallback($settings) {
    $v = trim((string)($settings['api']['fallback'] ?? ''));
    if ($v === 'none') return null;
    if ($v !== '' && strpos($v, ':') !== false) {
        list($p, $m) = explode(':', $v, 2);
        $p = ($p === 'openrouter') ? 'openrouter' : 'anthropic';
        $m = trim($m);
        if ($m === '') return null;
        $fb = ['provider' => $p, 'model' => $m];
    } else {
        $fb = deiServerConf()['ai_fallback'] ?? null;
        if (!is_array($fb) || empty($fb['model'])) return null;
        $fb = ['provider' => (string)($fb['provider'] ?? ($settings['api']['provider'] ?? 'anthropic')), 'model' => (string)$fb['model']];
    }
    // sama dengan model utama = tidak ada gunanya dicoba ulang
    $pp = (string)($settings['api']['provider'] ?? 'anthropic');
    $pm = $pp === 'openrouter' ? (string)($settings['api']['openrouter_model'] ?? '') : (string)($settings['api']['model'] ?? '');
    if ($fb['provider'] === $pp && $fb['model'] === $pm) return null;
    return $fb;
}
function callClaude($settings, $systemBlocks, $messages) {
    $r = callClaudeOnce($settings, $systemBlocks, $messages);
    // v1.2.102: closing-sekali — galat sementara (timeout/overloaded/429/5xx) dicoba ulang sekali
    if (empty($r[0]) && preg_match('/Gagal terhubung|overload|rate.?limit|HTTP (429|5\d\d)|timed? ?out|internal server|529|503|502/i', (string)($r[1] ?? ''))) {
        usleep(1500000);
        $r = callClaudeOnce($settings, $systemBlocks, $messages);
    }
    if (empty($r[0])) $GLOBALS['dei_ai_last_err'] = mb_substr((string)($r[1] ?? ''), 0, 200);
    if (!empty($r[0])) return $r;
    $fb = deiAiFallback($settings);
    if (!is_array($fb) || empty($fb['model'])) return $r;
    $s2 = $settings;
    $prov = (string)($fb['provider'] ?? ($settings['api']['provider'] ?? 'anthropic'));
    if ($prov === 'openrouter') { $s2['api']['provider'] = 'openrouter'; $s2['api']['openrouter_model'] = (string)$fb['model']; }
    else { $s2['api']['provider'] = 'anthropic'; $s2['api']['model'] = (string)$fb['model']; }
    error_log('AI utama gagal (' . mb_substr((string)($r[1] ?? ''), 0, 120) . ') -> coba cadangan ' . $fb['model']);
    $r2 = callClaudeOnce($s2, $systemBlocks, $messages);
    if (!empty($r2[0])) { $GLOBALS['dei_ai_fallback_used'] = (string)$fb['model']; return $r2; }
    return $r;
}
function callClaudeOnce($settings, $systemBlocks, $messages) {
    // v1.2.49: pilih penyedia AI. 'openrouter' -> 1 API key, banyak model.
    if (($settings['api']['provider'] ?? 'anthropic') === 'openrouter') {
        return callOpenRouter($settings, $systemBlocks, $messages);
    }
    $key = $settings['api']['claude_api_key'] ?? '';
    if (!$key) return [false, 'API key belum dikonfigurasi di dashboard.', []];

    // $systemBlocks can be a plain string (legacy) or an array of blocks
    // (with optional cache_control on individual blocks for prompt caching).
    $systemParam = is_array($systemBlocks) ? $systemBlocks : (string)$systemBlocks;

    $payload = [
        'model'      => $settings['api']['model'] ?? 'claude-haiku-5-5',
        'max_tokens' => (int)($settings['api']['max_tokens'] ?? 400),
        'system'     => $systemParam,
        'messages'   => $messages,
    ];

    $ch = curl_init('https://api.anthropic.com/v1/messages');
    curl_setopt_array($ch, [
        CURLOPT_RETURNTRANSFER => true,
        CURLOPT_POST           => true,
        CURLOPT_TIMEOUT        => (int)($settings['api']['_timeout'] ?? 30),
        CURLOPT_HTTPHEADER     => [
            'Content-Type: application/json',
            'x-api-key: ' . $key,
            'anthropic-version: 2023-06-01',
        ],
        CURLOPT_POSTFIELDS     => json_encode($payload, JSON_UNESCAPED_UNICODE),
    ]);
    $res  = curl_exec($ch);
    $code = curl_getinfo($ch, CURLINFO_HTTP_CODE);
    $err  = curl_error($ch);
    curl_close($ch);

    if ($res === false) return [false, 'Gagal terhubung ke server AI: ' . $err, []];
    $data = json_decode($res, true);
    if ($code !== 200) {
        $msg = $data['error']['message'] ?? ('HTTP ' . $code);
        return [false, 'AI error: ' . $msg, []];
    }
    $answer = '';
    if (!empty($data['content']) && is_array($data['content'])) {
        foreach ($data['content'] as $block) {
            if (($block['type'] ?? '') === 'text') $answer .= $block['text'];
        }
    }
    // Capture cache usage from response for monitoring/cost transparency
    $usage = [
        'input_tokens'                => (int)($data['usage']['input_tokens']                ?? 0),
        'output_tokens'               => (int)($data['usage']['output_tokens']               ?? 0),
        'cache_creation_input_tokens' => (int)($data['usage']['cache_creation_input_tokens'] ?? 0),
        'cache_read_input_tokens'     => (int)($data['usage']['cache_read_input_tokens']     ?? 0),
        'model'                       => (string)($payload['model'] ?? ''),   // v1.2.69: harga per model
    ];
    return [true, trim($answer), $usage];
}

/* ============================================================
 * v1.2.3: Structured prompt builder — merge form fields to prompt prefix.
 * Return empty string if all structured fields are empty (backward compat).
 * ============================================================ */
function buildStructuredPromptPrefix($bot) {
    $parts = [];

    // Identity — skip, already in existing system_prompt (v1.2.3 fix)

    // Languages — v1.2.53: dipindah ke deiAturanBahasa() yang ditempel PALING AKHIR.
    // Dulu di sini, di posisi paling awal, jadi kalah oleh ~17 baris instruksi
    // berbahasa Indonesia + persona + Knowledge Base yang semuanya Bahasa Indonesia.

    // User address
    $address = trim((string)($bot['user_address'] ?? ''));
    if ($address !== '') {
        $parts[] = "Sapa user dengan \"" . $address . "\".";
    }

    // Style
    $style = trim((string)($bot['language_style'] ?? ''));
    $styleMap = [
        'formal' => 'Gunakan bahasa formal profesional.',
        'semi_formal' => 'Gunakan bahasa semi-formal, ramah namun tetap profesional.',
        'casual' => 'Gunakan bahasa casual friendly, seperti teman.',
        'enthusiastic' => 'Gunakan bahasa antusias dengan energy tinggi.',
    ];
    if (isset($styleMap[$style])) $parts[] = $styleMap[$style];

    // Response rules
    $rules = $bot['response_rules'] ?? [];
    if (is_array($rules)) {
        if (!empty($rules['no_asterisk'])) $parts[] = "JANGAN pakai tanda * atau ** di jawaban (no markdown formatting).";
        if (!empty($rules['one_question_at_a_time'])) $parts[] = "Tanya hanya 1 pertanyaan per turn, jangan langsung banyak.";
        if (!empty($rules['summary_before_confirm'])) $parts[] = "Buat summary sebelum minta konfirmasi user.";
        if (!empty($rules['use_emoji'])) $parts[] = "Gunakan emoji ramah secukupnya.";
        if (!empty($rules['concise_response'])) $parts[] = "Jawaban maksimal 3 kalimat.";
    }

    // Fallback behavior
    $fallback = trim((string)($bot['fallback_behavior'] ?? ''));
    $fallbackMap = [
        'say_dont_know' => "Kalau tidak tahu jawaban dari knowledge base, katakan dengan sopan bahwa Anda belum memiliki info.",
        'ask_contact' => "PENTING: Kalau tidak tahu jawaban dari knowledge base, JANGAN bilang \"tidak tahu\" atau \"tidak memiliki info detail\". Langsung tanyakan nama dan no HP user untuk dihubungi kembali oleh tim kami.",
        'redirect_wa' => "Kalau tidak tahu jawaban, arahkan user untuk chat langsung dengan admin via WhatsApp.",
    ];
    if (isset($fallbackMap[$fallback])) $parts[] = $fallbackMap[$fallback];

    return implode("\n", $parts);
}
// === /v1.2.3 Structured prompt builder ===

/* ============================================================
 * v1.2.53: ATURAN BAHASA sebagai override terakhir.
 *
 * Masalah: seluruh system prompt (konteks waktu, field terstruktur,
 * persona tenant, Knowledge Base) ditulis dalam Bahasa Indonesia.
 * Satu baris "deteksi bahasa user" di posisi paling awal kalah telak,
 * sehingga chat berbahasa Inggris/Mandarin tetap dibalas Bahasa Indonesia.
 *
 * Blok ini ditempel di URUTAN PALING AKHIR (setelah persona tenant),
 * menegaskan bahwa Bahasa Indonesia di prompt adalah bahasa SUMBER,
 * bukan bahasa jawaban, dan menyesuaikan sapaan hormat per bahasa.
 * ============================================================ */
/* v1.2.53: deteksi bahasa pesan tamu, deterministik (tanpa panggilan AI).
 * Mengembalikan kode bahasa ('id','en','zh','ar','ja','ko') atau '' kalau
 * tidak yakin. Sengaja konservatif: lebih baik mengembalikan '' dan
 * menyerahkan ke model daripada memaksa bahasa yang salah. */
function deiDeteksiBahasa($teks) {
    $t = trim((string)$teks);
    if ($t === '') return '';

    // 1) Aksara non-Latin -> hampir pasti, tidak perlu tebak-tebakan.
    //    Cek Jepang (kana) & Korea dulu: keduanya bisa memuat aksara Han.
    if (preg_match('/[\x{3040}-\x{309F}\x{30A0}-\x{30FF}]/u', $t)) return 'ja';
    if (preg_match('/[\x{AC00}-\x{D7AF}\x{1100}-\x{11FF}]/u', $t)) return 'ko';
    if (preg_match('/[\x{4E00}-\x{9FFF}\x{3400}-\x{4DBF}]/u', $t)) return 'zh';
    if (preg_match('/[\x{0600}-\x{06FF}\x{0750}-\x{077F}]/u', $t)) return 'ar';

    // 2) Latin: bedakan Indonesia vs Inggris lewat kata fungsi.
    //    Butuh kalimat, bukan sepatah kata -> pesan sangat pendek dilepas.
    $low = ' ' . preg_replace('/[^a-z\s]/', ' ', mb_strtolower($t, 'UTF-8')) . ' ';
    $kata = preg_split('/\s+/', trim($low), -1, PREG_SPLIT_NO_EMPTY);
    if (count($kata) < 3) return '';   // "hi", "halo", "ok" -> biar model yang menilai

    $id = ['yang','dan','di','ke','dari','untuk','dengan','tidak','ada','saya','anda','kamu',
           'bisa','mau','ingin','berapa','apakah','bagaimana','kapan','dimana','harga','kamar',
           'sudah','belum','juga','atau','kalau','karena','pak','bu','mas','mbak','nya','itu','ini'];
    $en = ['the','and','is','are','do','does','you','your','can','could','would','what','when',
           'where','how','how much','price','room','have','has','need','want','please','thanks',
           'there','with','for','from','about','book','booking','available','a','an','of','to','my'];
    $skorId = 0; $skorEn = 0;
    foreach ($kata as $w) {
        if (in_array($w, $id, true)) $skorId++;
        if (in_array($w, $en, true)) $skorEn++;
    }
    // butuh selisih jelas, bukan menang tipis
    if ($skorId >= 2 && $skorId > $skorEn)      return 'id';
    if ($skorEn >= 2 && $skorEn > $skorId)      return 'en';
    return '';
}

function deiAturanBahasa($bot, $bahasaTerdeteksi = '') {
    $langs = $bot['languages'] ?? [];
    if (!is_array($langs) || count($langs) < 2) return '';   // 1 bahasa: tidak perlu
    $langMap = ['id'=>'Bahasa Indonesia', 'en'=>'English', 'zh'=>'Mandarin', 'ar'=>'Arabic', 'ja'=>'Japanese'];
    $sapaan  = ['id'=>'Bapak/Ibu', 'en'=>'Sir/Madam', 'zh'=>"\xE5\x85\x88\xE7\x94\x9F/\xE5\xA5\xB3\xE5\xA3\xAB",
                'ar'=>'sayyidi/sayyidati', 'ja'=>"\xE3\x81\x8A\xE5\xAE\xA2\xE6\xA7\x98"];
    $names = []; $sap = [];
    foreach ($langs as $l) {
        $nm = $langMap[$l] ?? $l;
        $names[] = $nm;
        if (isset($sapaan[$l])) $sap[] = $sapaan[$l] . ' untuk ' . $nm;
    }
    $behavior = $bot['language_prompt_behavior'] ?? 'ask_user';

    $o  = "=== ATURAN BAHASA (PALING UTAMA \xE2\x80\x94 MENGALAHKAN SEMUA ATURAN DI ATAS) ===\n";
    $o .= "Bahasa yang didukung: " . implode(', ', $names) . ".\n";
    // v1.2.53: kalau server sudah yakin bahasanya, sebut eksplisit — jauh lebih
    // patuh daripada menyuruh model mendeteksi sendiri.
    if ($bahasaTerdeteksi !== '' && isset($langMap[$bahasaTerdeteksi])) {
        $o .= "1. Pesan tamu ditulis dalam " . $langMap[$bahasaTerdeteksi] . ". "
            . "WAJIB tulis SELURUH jawaban dalam " . $langMap[$bahasaTerdeteksi] . ", "
            . "tanpa mencampur bahasa lain. JANGAN menanyakan tamu ingin memakai bahasa apa.\n";
    } elseif ($behavior === 'ask_user') {
        $o .= "1. HANYA pada pesan pertama percakapan, tanyakan tamu ingin memakai bahasa apa. "
            . "Setelah tamu menjawab (atau kalau bahasa pesannya sudah jelas), JANGAN bertanya lagi.\n";
    } else {
        $o .= "1. Kenali bahasa dari pesan TERAKHIR tamu, lalu tulis SELURUH jawaban dalam bahasa itu. "
            . "JANGAN PERNAH menanyakan tamu ingin memakai bahasa apa.\n";
    }
    $o .= "2. Instruksi di atas, contoh-contoh kalimatnya, dan seluruh Knowledge Base ditulis dalam "
        . "Bahasa Indonesia. Itu bahasa SUMBER, BUKAN bahasa jawaban. Terjemahkan isinya ke bahasa tamu \xE2\x80\x94 "
        . "jangan menyalin kalimat Bahasa Indonesia apa adanya.\n";
    if (!empty($sap)) {
        $o .= "3. Sapaan hormat mengikuti bahasa jawaban: " . implode(', ', $sap) . ". "
            . "JANGAN memakai sapaan Bahasa Indonesia ketika menjawab dalam bahasa lain.";
        if ($bahasaTerdeteksi !== '' && isset($sapaan[$bahasaTerdeteksi])) {
            $o .= " Untuk jawaban ini pakai \"" . $sapaan[$bahasaTerdeteksi] . "\".";
        }
        $o .= "\n";
    }
    $o .= "4. Kalau tamu berganti bahasa di tengah percakapan, ikut berganti mulai jawaban berikutnya.\n";
    $o .= "5. Nama tempat, nama menu, dan tautan tetap ditulis apa adanya, tidak diterjemahkan.\n";
    return $o;
}

/* ============================================================
 * v1.2.5: Strip markdown formatting auto — post-process AI response
 * kalau rule no_asterisk aktif di structured config.
 * ============================================================ */
function stripMarkdownIfEnabled($answer, $settings) {
    if (empty($settings['bot']['response_rules']['no_asterisk'])) return $answer;
    if (!is_string($answer) || $answer === '') return $answer;

    // Strip **bold** dan __bold__ (double)
    $answer = preg_replace('/\*\*([^*\n]+?)\*\*/', '$1', $answer);
    $answer = preg_replace('/__([^_\n]+?)__/', '$1', $answer);

    // Strip *italic* dan _italic_ (single, dengan word boundary supaya tidak break code/var)
    $answer = preg_replace('/(?<![a-zA-Z0-9])\*([^*\n]+?)\*(?![a-zA-Z0-9])/', '$1', $answer);
    $answer = preg_replace('/(?<![a-zA-Z0-9])_([^_\n]+?)_(?![a-zA-Z0-9])/', '$1', $answer);

    // Strip headers (# H1, ## H2, ### H3, dst)
    $answer = preg_replace('/^\s*#{1,6}\s+/m', '', $answer);

    return $answer;
}
// === /v1.2.5 ===

/* ----------------------------------------------------------------------------
 *  Shared answer engine — used by BOTH the web chat widget and WhatsApp.
 *  Returns [bool ok, string answer, int kbUsed].
 * ------------------------------------------------------------------------- */
/* ============================================================
 * v1.2.8: deiDashboardUrl — auto-detect dashboard URL per tenant
 * ============================================================ */
function deiDashboardUrl() {
    $host   = $_SERVER['HTTP_HOST'] ?? 'localhost';
    $scheme = (!empty($_SERVER['HTTPS']) && $_SERVER['HTTPS'] !== 'off') ? 'https' : 'http';
    $uri    = $_SERVER['REQUEST_URI'] ?? '';
    $basePath = '';
    if (($pos = strpos($uri, '/api/')) !== false) {
        $basePath = substr($uri, 0, $pos);
    }
    return $scheme . '://' . $host . $basePath . '/dashboard/chatbot-ai/';
}

/* ============================================================
/* ============================================================
 * v1.2.35: konteks waktu — dipakai SEMUA jalur pembangunan prompt
 * ============================================================ */
// Sebelumnya blok ini hanya ada di jalur KB besar, sehingga tenant ber-KB kecil
// tidak tahu hari ini tanggal berapa dan menanyakan bulan/tahun kepada tamu.
function deiKonteksWaktu() {
    $hari_id  = ['Sunday'=>'Minggu','Monday'=>'Senin','Tuesday'=>'Selasa','Wednesday'=>'Rabu',
                 'Thursday'=>'Kamis','Friday'=>'Jumat','Saturday'=>'Sabtu'];
    $bulan_id = ['January'=>'Januari','February'=>'Februari','March'=>'Maret','April'=>'April',
                 'May'=>'Mei','June'=>'Juni','July'=>'Juli','August'=>'Agustus',
                 'September'=>'September','October'=>'Oktober','November'=>'November','December'=>'Desember'];
    $now = new DateTime('now', new DateTimeZone('Asia/Jakarta'));
    $tanggalIndo = $hari_id[$now->format('l')] . ', ' . $now->format('j') . ' '
                 . $bulan_id[$now->format('F')] . ' ' . $now->format('Y');
    $th = $now->format('Y');
    $iso = $now->format('Y-m-d');
    $jam = $now->format('H:i');
    $blnIni = $bulan_id[$now->format('F')];
    $thDepan = (string)((int)$th + 1);
    return "KONTEKS WAKTU (WAJIB DIINGAT, INI SUMBER KEBENARAN TANGGAL):\n"
        . "Hari ini: {$tanggalIndo}, pukul {$jam} WIB. (Format ISO: {$iso}.)\n"
        . "Tahun sekarang: {$th}. Bulan sekarang: {$blnIni} {$th}.\n"
        . "Abaikan pengetahuan tanggalmu sendiri — pakai HANYA tanggal di atas sebagai 'hari ini'.\n"
        . "ATURAN TANGGAL:\n"
        . "1) Jika user menyebut tanggal tanpa bulan/tahun (mis. '21-22' atau '5 Agustus'), asumsikan bulan berjalan & tahun {$th}; JANGAN tanya tahun.\n"
        . "2) Jika tanggal yang disebut SUDAH LEWAT dibanding hari ini ({$iso}) — termasuk jika user menyebut tahun yang sudah lewat — JANGAN langsung proses. Konfirmasi dulu, mis.: 'Tanggal itu sudah lewat, Bapak/Ibu. Apakah maksudnya {$thDepan}?' \n"
        . "3) Untuk booking/reservasi, tanggal check-in HARUS hari ini atau setelahnya. JANGAN PERNAH memproses reservasi dengan tanggal/tahun yang sudah lewat.\n"
        . "4) WAJIB konfirmasi tanggal lengkap (tanggal + bulan + tahun) setelah user menyebut tanggal, mis.: 'Baik, jadi check-in 21 {$blnIni} {$th} ya, Bapak/Ibu?' sebelum lanjut proses.";
}

/* ============================================================
 * v1.2.22: Daftar harga resmi — sumber tunggal untuk pertanyaan harga
 * ============================================================ */
function pricelistGet() {
    $p = readJson(PRICELIST_FILE, []);
    if (!is_array($p)) return ['items' => [], 'updated_at' => '', 'updated_by' => ''];
    return [
        'items'      => is_array($p['items'] ?? null) ? $p['items'] : [],
        'updated_at' => (string)($p['updated_at'] ?? ''),
        'updated_by' => (string)($p['updated_by'] ?? ''),
    ];
}

// Susun blok instruksi + daftar harga untuk dikirim ke model.
// Return '' kalau daftar kosong — jangan kirim blok kosong.
function pricelistPromptBlock() {
    $pl = pricelistGet();
    $rows = '';
    foreach ($pl['items'] as $it) {
        if (!is_array($it)) continue;
        $nama  = trim((string)($it['item'] ?? ''));
        $harga = trim((string)($it['price'] ?? ''));
        if ($nama === '' || $harga === '') continue;
        $note  = trim((string)($it['note'] ?? ''));
        $rows .= '- ' . $nama . ' : ' . $harga . ($note !== '' ? ' (' . $note . ')' : '') . "\n";
    }
    if ($rows === '') return '';

    $blk  = "=== DAFTAR HARGA RESMI ===\n";
    $blk .= "Ini sumber harga SATU-SATUNYA. Aturan yang WAJIB dipatuhi:\n";
    $blk .= "1. Untuk pertanyaan harga/tarif/biaya, pakai HANYA angka dari daftar ini.\n";
    $blk .= "2. Kalau ada angka berbeda di Knowledge Base, daftar ini yang benar.\n";
    $blk .= "3. JANGAN menghitung apa pun — tidak boleh mengalikan jumlah malam/unit,\n";
    $blk .= "   menjumlahkan beberapa item, menghitung diskon, pajak, atau total.\n";
    $blk .= "   Sebutkan harga satuan apa adanya, lalu arahkan customer untuk konfirmasi\n";
    $blk .= "   perhitungan total ke admin/tim kami.\n";
    $blk .= "4. Kalau item yang ditanya TIDAK ada di daftar, katakan terus terang belum\n";
    $blk .= "   tersedia informasinya dan arahkan ke kontak resmi. JANGAN menebak.\n\n";
    $blk .= $rows;
    if ($pl['updated_at'] !== '') {
        $blk .= "\n(Daftar diperbarui " . substr($pl['updated_at'], 0, 10) . ")";
    }
    return $blk;
}

/* ============================================================
 * v1.2.20: Leads — AI mengekstrak fakta, agent yang memutuskan qualified
 * ============================================================ */
function leadsGetAll() {
    $l = readJson(LEADS_FILE, []);
    return is_array($l) ? $l : [];
}
function leadStatusValid($s) {
    return in_array($s, ['baru', 'qualified', 'follow_up', 'closed'], true);
}

// Minta Claude MENGEKSTRAK fakta dari transkrip — bukan menilai keseriusan.
// Return array hasil ekstraksi, atau null kalau gagal.
function leadExtract($settings, $transcript) {
    $transcript = trim((string)$transcript);
    if ($transcript === '') return null;

    $sys = "Anda menganalisa transkrip percakapan customer service.\n"
         . "Kembalikan HANYA JSON valid, tanpa penjelasan, tanpa tanda kutip markdown.\n"
         . "Struktur persis:\n"
         . '{"nama":"","kebutuhan":"","waktu":"","anggaran":"","ringkasan":""}' . "\n\n"
         . "Aturan:\n"
         . "- nama: nama customer kalau disebut di percakapan\n"
         . "- kebutuhan: apa yang dicari/ditanyakan customer\n"
         . "- waktu: tanggal atau jangka waktu yang disebut customer\n"
         . "- anggaran: angka/kisaran biaya yang disebut customer\n"
         . "- ringkasan: satu kalimat singkat isi percakapan\n"
         . "- Kosongkan string kalau TIDAK disebut. JANGAN menebak atau mengarang.";

    $msgs = [['role' => 'user', 'content' => "Transkrip percakapan:\n\n" . $transcript]];
    list($ok, $answer, $usage) = callClaude($settings, $sys, $msgs);
    if (!$ok) return null;

    // v1.2.20: biaya analisa MASUK KUOTA (kuota dihitung dari 'calls' di usage.json)
    recordUsage($usage);

    // Bersihkan pagar markdown kalau model tetap menambahkannya
    $raw = trim((string)$answer);
    $raw = preg_replace('/^```[a-zA-Z]*\s*/', '', $raw);
    $raw = preg_replace('/```\s*$/', '', $raw);
    $raw = trim($raw);

    $data = json_decode($raw, true);
    if (!is_array($data)) {
        error_log('leadExtract: respons bukan JSON valid: ' . mb_substr($raw, 0, 200));
        return null;
    }
    return [
        'nama'      => mb_substr(trim((string)($data['nama']      ?? '')), 0, 100),
        'kebutuhan' => mb_substr(trim((string)($data['kebutuhan'] ?? '')), 0, 300),
        'waktu'     => mb_substr(trim((string)($data['waktu']     ?? '')), 0, 200),
        'anggaran'  => mb_substr(trim((string)($data['anggaran']  ?? '')), 0, 250),
        'ringkasan' => mb_substr(trim((string)($data['ringkasan'] ?? '')), 0, 300),
    ];
}

// Bangun transkrip percakapan satu nomor dari log (urut lama -> baru).
/* ============================================================================
 * v1.2.105: riwayat-wa-waha — riwayat chat sebelum nomor terhubung ke dashboard
 *
 * Seperti membuka WhatsApp Web: saat nomor di-scan (ditautkan sebagai perangkat), HP
 * mengirim riwayat chat ke WAHA (engine NOWEB dengan store aktif / GOWS / WEBJS).
 * Riwayat itu ditarik lewat API WAHA (/chats, /chats/{id}/messages) secara bertahap
 * oleh cron_tick (dan oleh panel Koneksi selagi terbuka), lalu disimpan TERPISAH dari
 * log live: data/wa-import/<nomor>.json + _index.json. Tidak terpangkas log_limit,
 * tidak masuk laporan/kuota/percakapan (conv), tidak membuka jendela 24 jam.
 * Batas waktu per nomor pelanggan = sebelum pesan live pertamanya di log (tidak dobel).
 * Job per nomor bisnis (ch): data/wa-import/_sync-<ch>.json.
 * Meta Cloud API tidak menyediakan riwayat -> hanya penyedia WAHA.
 * ========================================================================= */
if (!defined('WA_IMPORT_DIR')) define('WA_IMPORT_DIR', DATA_DIR . '/wa-import');
if (!defined('WA_IMPORT_MAX_MSGS')) define('WA_IMPORT_MAX_MSGS', 20000);   // per nomor pelanggan
if (!defined('WS_MAX_CHATS')) define('WS_MAX_CHATS', 1000);                // chat pribadi per tarikan
if (!defined('WS_MAX_PER_CHAT')) define('WS_MAX_PER_CHAT', 1000);          // pesan per chat per tarikan
if (!defined('WS_PAGE')) define('WS_PAGE', 100);

function wiFile($num) { return WA_IMPORT_DIR . '/' . preg_replace('/\D/', '', (string)$num) . '.json'; }
function wiIndexFile() { return WA_IMPORT_DIR . '/_index.json'; }
function wiIndexAll() {
    if (!is_file(wiIndexFile())) return [];
    $x = readJson(wiIndexFile(), []);
    return is_array($x) ? $x : [];
}
function wiLoad($num) {
    $f = wiFile($num);
    if (!is_file($f)) return null;
    $d = readJson($f, null);
    return (is_array($d) && is_array($d['msgs'] ?? null)) ? $d : null;
}
function wiKey($m) { return (string)($m['id'] ?? '') !== '' ? 'i:' . $m['id'] : 'h:' . md5($m['ts'] . '|' . $m['d'] . '|' . $m['t']); }
// Gabungkan pesan ke riwayat satu nomor (buang duplikat). [ditambah, total]
function wiSave($num, $msgs, $meta) {
    return deiWithLock('wa-import', function () use ($num, $msgs, $meta) {
        if (!is_dir(WA_IMPORT_DIR)) @mkdir(WA_IMPORT_DIR, 0755, true);
        $cur = wiLoad($num) ?: ['num' => $num, 'msgs' => []];
        $seen = [];
        foreach ($cur['msgs'] as $m) $seen[wiKey($m)] = true;
        $add = 0;
        foreach ($msgs as $m) {
            $k = wiKey($m);
            if (isset($seen[$k])) continue;
            $seen[$k] = true; $cur['msgs'][] = $m; $add++;
        }
        if ($add === 0 && is_file(wiFile($num))) return [0, count($cur['msgs'])];
        $i = 0; foreach ($cur['msgs'] as &$m) $m['_i'] = $i++; unset($m);
        usort($cur['msgs'], function ($a, $b) { return strcmp($a['ts'], $b['ts']) ?: ($a['_i'] <=> $b['_i']); });
        foreach ($cur['msgs'] as &$m) unset($m['_i']); unset($m);
        if (count($cur['msgs']) > WA_IMPORT_MAX_MSGS) $cur['msgs'] = array_slice($cur['msgs'], -WA_IMPORT_MAX_MSGS);
        $cur['at'] = $meta['at'] ?? date('Y-m-d H:i:s');
        $cur['ch'] = (string)($meta['ch'] ?? ($cur['ch'] ?? ''));
        writeJson(wiFile($num), $cur);
        $n = count($cur['msgs']);
        $ix = wiIndexAll();
        if ($n > 0) {
            $last = $cur['msgs'][$n - 1];
            $ix[$num] = ['count' => $n, 'first_ts' => $cur['msgs'][0]['ts'], 'last_ts' => $last['ts'],
                         'last_t' => mb_substr($last['t'], 0, 200), 'last_d' => $last['d'], 'at' => $cur['at'], 'ch' => $cur['ch']];
        }
        writeJson(wiIndexFile(), $ix);
        return [$add, $n];
    });
}
// Untuk wa_thread: riwayat terakhir (lama -> baru).
function wiThreadPublic($num, $all = false) {
    $d = wiLoad($num);
    if (!$d || !$d['msgs']) return null;
    $n = count($d['msgs']);
    $out = [];
    foreach (array_slice($d['msgs'], -($all ? 5000 : 300)) as $m) $out[] = ['ts' => $m['ts'], 'd' => $m['d'], 't' => $m['t']];
    return ['total' => $n, 'msgs' => $out, 'first_ts' => $d['msgs'][0]['ts'], 'last_ts' => $d['msgs'][$n - 1]['ts'], 'at' => (string)($d['at'] ?? '')];
}
// Untuk analisa lead bila log kosong (chat hanya ada di riwayat).
function wiTranscript($num, $max = 40) {
    $d = wiLoad($num);
    if (!$d || !$d['msgs']) return '';
    $out = '';
    foreach (array_slice($d['msgs'], -$max) as $m) $out .= ($m['d'] === 'in' ? 'Customer: ' : 'CS: ') . $m['t'] . "\n";
    return trim($out);
}

/* ---------- job tarik riwayat per nomor bisnis ---------- */
function wsFile($ch) { return WA_IMPORT_DIR . '/_sync-' . preg_replace('/[^A-Za-z0-9_]/', '', (string)$ch) . '.json'; }
function wsGet($ch) { $f = wsFile($ch); if (!is_file($f)) return null; $j = readJson($f, null); return is_array($j) ? $j : null; }
function wsPut($ch, $j) { if (!is_dir(WA_IMPORT_DIR)) @mkdir(WA_IMPORT_DIR, 0755, true); $j['upd'] = time(); writeJson(wsFile($ch), $j); }
// Jadwalkan tarikan. $reason 'scan' (baru ditautkan: 3 putaran, riwayat dari HP datang bertahap) | 'manual'.
function wsSchedule($wa, $reason, $by = '') {
    if (!whOn($wa)) return null;
    $ch = whCh($wa);
    return deiWithLock('wa-sync-' . $ch, function () use ($ch, $reason, $by) {
        $j = wsGet($ch);
        $now = time();
        if ($j && in_array(($j['st'] ?? ''), ['pending', 'running'], true) && $now - (int)($j['created'] ?? 0) < 1800) return $j;
        if ($j && $reason === 'scan' && $now - (int)($j['created'] ?? 0) < 600) return $j;   // webhook + panel = satu jadwal
        $j = ['ch' => $ch, 'st' => 'pending', 'reason' => $reason, 'by' => $by, 'created' => $now,
              'cutoff' => $now, 'due' => $now + ($reason === 'scan' ? 60 : 0),
              'pass' => 1, 'passes' => $reason === 'scan' ? 3 : 1,
              'phase' => 'chats', 'coff' => 0, 'chats' => [], 'ci' => 0, 'moff' => 0,
              'n_chats' => 0, 'n_msgs' => 0, 'n_new' => 0, 'n_nums' => 0, 'err' => '', 'tot' => ['msgs' => 0, 'new' => 0]];
        wsPut($ch, $j);
        return $j;
    });
}
// Pesan live pertama per nomor pelanggan (batas atas riwayat supaya tidak dobel dengan log).
function wsFirstLiveMap() {
    $out = [];
    if (deiStorageMysql()) {
        foreach (deiDb()->query("SELECT num, MIN(ts) AS t FROM dei_log WHERE channel = 'whatsapp' AND num <> '' GROUP BY num")->fetchAll() as $r) {
            $t = strtotime((string)$r['t']); if ($t) $out[(string)$r['num']] = $t;
        }
        return $out;
    }
    foreach (logReadAll() as $e) {
        if (($e['channel'] ?? '') !== 'whatsapp') continue;
        $n = waNormNum($e['ip'] ?? ''); $t = strtotime((string)($e['ts'] ?? ''));
        if ($n !== '' && $t && (!isset($out[$n]) || $t < $out[$n])) $out[$n] = $t;
    }
    return $out;
}
// Satu pesan WAHA -> bentuk riwayat. null = lewati (sistem, reaksi, protokol, di luar batas).
function wsMsg($m, $lte) {
    if (!is_array($m)) return null;
    $ts = (int)($m['timestamp'] ?? 0);
    if ($ts > 100000000000) $ts = (int)floor($ts / 1000);
    if ($ts <= 0 || $ts > $lte) return null;
    $body = trim((string)($m['body'] ?? ''));
    $t = $body;
    if (!empty($m['hasMedia'])) {
        $mt = strtolower((string)($m['media']['mimetype'] ?? ''));
        $lbl = strpos($mt, 'image/webp') === 0 ? '[Stiker]' : (strpos($mt, 'image/') === 0 ? '[Gambar]' : (strpos($mt, 'video/') === 0 ? '[Video]'
             : (strpos($mt, 'audio/') === 0 ? '[Pesan suara]' : ($mt !== '' ? '[Dokumen]' : '[Media]'))));
        $t = $lbl . ($body !== '' ? "\n" . $body : '');
    }
    if ($t === '') return null;
    return ['ts' => date('Y-m-d H:i:s', $ts), 'd' => !empty($m['fromMe']) ? 'out' : 'in', 't' => mb_substr($t, 0, 4000), 'id' => mb_substr(wahaMsgId($m), 0, 120)];
}
function wsPersonalChat($id) {
    $id = strtolower(trim((string)$id));
    if ($id === '' || strpos($id, '@') === false) return false;
    if (preg_match('/@(g\.us|newsletter|broadcast)$/', $id) || strpos($id, 'status@') === 0) return false;
    return (bool)preg_match('/@(c\.us|s\.whatsapp\.net|lid)$/', $id);
}
/* Kerjakan job yang jatuh tempo, sampai $budget detik. $only = satu ch saja (panel).
 * Mengembalikan ringkasan [ch => status] untuk yang dikerjakan, atau [] bila tak ada. */
function wsRun($s, $budget = 20, $only = '') {
    if (!is_dir(WA_IMPORT_DIR)) return [];
    $lk = @fopen(WA_IMPORT_DIR . '/.sync.lock', 'c');
    if (!$lk || !@flock($lk, LOCK_EX | LOCK_NB)) { if ($lk) @fclose($lk); return ['busy' => true]; }
    $t0 = microtime(true); $out = []; $live = null;
    try {
        foreach (whChannels($s) as $cx) {
            list($ch, $label, $wa) = $cx;
            if ($only !== '' && $ch !== $only) continue;
            $j = wsGet($ch);
            if (!$j) continue;
            $now = time();
            if (($j['st'] ?? '') === 'done' && (int)$j['pass'] < (int)$j['passes'] && (int)($j['due'] ?? 0) <= $now) {
                $j['pass']++; $j['st'] = 'running'; $j['phase'] = 'chats'; $j['coff'] = 0; $j['chats'] = []; $j['ci'] = 0; $j['moff'] = 0;
                $j['n_chats'] = 0; $j['n_msgs'] = 0; $j['n_new'] = 0; $j['n_nums'] = 0;
            }
            if (($j['st'] ?? '') === 'pending' && (int)($j['due'] ?? 0) <= $now) { $j['st'] = 'running'; $j['started'] = $now; }
            if (($j['st'] ?? '') !== 'running') continue;
            if ($live === null) $live = wsFirstLiveMap();
            $sp = rawurlencode(wahaSession($wa));
            $me = waNormNum($wa['waha_number'] ?? '');
            $fails = 0;
            while (microtime(true) - $t0 < $budget && $j['st'] === 'running') {
                if ($j['phase'] === 'chats') {
                    list($c, $d) = wahaApi($wa, 'GET', '/api/' . $sp . '/chats?limit=' . WS_PAGE . '&offset=' . (int)$j['coff'] . '&sortBy=conversationTimestamp&sortOrder=desc');
                    if ($c === 400 && (int)$j['coff'] === 0) list($c, $d) = wahaApi($wa, 'GET', '/api/' . $sp . '/chats?limit=' . WS_PAGE . '&offset=0');
                    if ($c < 200 || $c >= 300 || !is_array($d) || ($d && !isset($d[0]))) {
                        $j['cfail'] = (int)($j['cfail'] ?? 0) + 1;   // lintas tick: 5x gagal = berhenti
                        if ($j['cfail'] >= 5 || in_array($c, [400, 401, 404, 422, 501], true)) {
                            $j['st'] = 'error'; $j['err'] = wahaErr($c, $d, 'Daftar chat tidak bisa dibaca dari WAHA.');
                        }
                        break;
                    }
                    $j['cfail'] = 0;
                    foreach ($d as $chat) {
                        $cid = is_array($chat['id'] ?? null) ? (string)($chat['id']['_serialized'] ?? '') : (string)($chat['id'] ?? '');
                        if (!wsPersonalChat($cid) || count($j['chats']) >= WS_MAX_CHATS) continue;
                        $j['chats'][] = ['id' => $cid, 'name' => mb_substr(trim((string)($chat['name'] ?? '')), 0, 100)];
                    }
                    $j['coff'] += WS_PAGE;
                    if (count($d) < WS_PAGE || count($j['chats']) >= WS_MAX_CHATS || $j['coff'] >= WS_MAX_CHATS * 5) {
                        $j['phase'] = 'msgs'; $j['n_chats'] = count($j['chats']);
                    }
                    continue;
                }
                // phase msgs
                if ((int)$j['ci'] >= count($j['chats'])) {
                    $j['tot']['msgs'] += $j['n_msgs']; $j['tot']['new'] += $j['n_new'];
                    $j['chats'] = []; $j['finished'] = time();
                    $j['st'] = 'done';
                    if ((int)$j['pass'] < (int)$j['passes']) $j['due'] = time() + ((int)$j['pass'] === 1 ? 900 : 2700);
                    break;
                }
                $cur = &$j['chats'][$j['ci']];
                if (!isset($cur['num'])) {
                    $cur['num'] = wahaResolveNum($wa, $cur['id'], []);
                    if ($cur['num'] !== '' && $me !== '' && $cur['num'] === $me) $cur['num'] = '';
                }
                $num = (string)$cur['num'];
                if ($num === '') { unset($cur); $j['ci']++; $j['moff'] = 0; continue; }
                $lte = (int)$j['cutoff'];
                if (isset($live[$num]) && $live[$num] - 1 < $lte) $lte = $live[$num] - 1;
                list($c, $d) = wahaApi($wa, 'GET', '/api/' . $sp . '/chats/' . rawurlencode($cur['id']) . '/messages?limit=' . WS_PAGE
                    . '&offset=' . (int)$j['moff'] . '&downloadMedia=false&filter.timestamp.lte=' . $lte);
                if ($c < 200 || $c >= 300 || !is_array($d) || ($d && !isset($d[0]))) {
                    // chat ini dilewati; 3 gagal beruntun = WAHA bermasalah -> berhenti dengan pesan
                    $j['n_skip'] = (int)($j['n_skip'] ?? 0) + 1; $j['ci']++; $j['moff'] = 0; unset($cur);
                    if (++$fails >= 3) { $j['st'] = 'error'; $j['err'] = wahaErr($c, $d, 'Pesan tidak bisa dibaca dari WAHA.'); }
                    continue;
                }
                $fails = 0;
                if ((string)($cur['name'] ?? '') === '') {   // NOWEB: daftar chat tanpa nama -> pushName pesan masuk
                    foreach ($d as $m) {
                        if (!is_array($m) || !empty($m['fromMe'])) continue;
                        $pn = trim((string)($m['_data']['pushName'] ?? ($m['_data']['notifyName'] ?? ($m['_data']['Info']['PushName'] ?? ''))));
                        if ($pn !== '') { $cur['name'] = mb_substr($pn, 0, 100); break; }
                    }
                }
                $batch = [];
                foreach ($d as $m) { $x = wsMsg($m, $lte); if ($x) $batch[] = $x; }
                if ($batch) {
                    list($add) = wiSave($num, $batch, ['ch' => $ch, 'at' => date('Y-m-d H:i:s')]);
                    $j['n_msgs'] += count($batch); $j['n_new'] += $add;
                    if (empty($cur['saved'])) {
                        $cur['saved'] = 1; $j['n_nums']++;
                        $first = $batch[0]['ts']; $lastTs = $batch[0]['ts'];
                        foreach ($batch as $b) { if (strcmp($b['ts'], $first) < 0) $first = $b['ts']; if (strcmp($b['ts'], $lastTs) > 0) $lastTs = $b['ts']; }
                        $nm = $cur['name']; $multi = ($ch !== 'utama');
                        if (preg_match('/^\+?[\d\s\-().]+$/', $nm)) $nm = '';
                        waContactUpdate($num, function (&$ct, $isNew) use ($nm, $first, $lastTs, $ch, $multi) {
                            if ($nm !== '' && trim((string)($ct['name_wa'] ?? '')) === '') $ct['name_wa'] = $nm;
                            if ($isNew || strcmp($first, (string)($ct['first_seen'] ?? '9999')) < 0) $ct['first_seen'] = $first;
                            if ($isNew || (string)($ct['last_seen'] ?? '') === '') $ct['last_seen'] = $lastTs;   // v1.2.113
                            if ($multi && empty($ct['wa_ch'])) $ct['wa_ch'] = $ch;
                            $ct['hist'] = 1;
                        });
                    }
                }
                if (count($d) < WS_PAGE || (int)$j['moff'] + WS_PAGE >= WS_MAX_PER_CHAT) { $j['ci']++; $j['moff'] = 0; }
                else $j['moff'] += WS_PAGE;
                unset($cur);
                wsPut($ch, $j);   // progres tersimpan tiap halaman (bisa dilanjut tick berikutnya)
            }
            wsPut($ch, $j);
            $out[$ch] = wsPublic($j);
            if ($j['st'] === 'done' && (int)$j['pass'] === 1 && $j['reason'] === 'scan') {
                try { waAuditLog('history_sync', 'system', '', ['ch' => $ch, 'msgs' => $j['tot']['new']]); } catch (\Throwable $e) {}
            }
            if (microtime(true) - $t0 >= $budget) break;
        }
    } finally {
        @flock($lk, LOCK_UN); @fclose($lk);
    }
    return $out;
}
// Status untuk dashboard (tanpa daftar chat).
function wsPublic($j) {
    if (!$j) return null;
    $tot = count($j['chats'] ?? []) ?: (int)($j['n_chats'] ?? 0);
    $pct = 0;
    if (($j['st'] ?? '') === 'running') $pct = ($j['phase'] ?? '') === 'chats' ? 2 : max(3, min(99, (int)round(100 * (int)$j['ci'] / max(1, $tot))));
    elseif (($j['st'] ?? '') === 'done') $pct = 100;
    return ['st' => (string)($j['st'] ?? ''), 'reason' => (string)($j['reason'] ?? ''), 'pass' => (int)($j['pass'] ?? 1), 'passes' => (int)($j['passes'] ?? 1),
            'phase' => (string)($j['phase'] ?? ''), 'pct' => $pct, 'chats' => $tot, 'done_chats' => (int)($j['ci'] ?? 0),
            'msgs' => (int)($j['tot']['new'] ?? 0) + (($j['st'] ?? '') === 'running' ? (int)($j['n_new'] ?? 0) : 0),
            'nums' => (int)($j['n_nums'] ?? 0), 'err' => (string)($j['err'] ?? ''),
            'created' => (int)($j['created'] ?? 0), 'finished' => (int)($j['finished'] ?? 0), 'due' => (int)($j['due'] ?? 0)];
}

function leadBuildTranscript($number, $logs = null, $max = 40) {
    $number = preg_replace('/\D/', '', (string)$number);
    if ($logs === null) $logs = logReadAll();
    $rows = [];
    foreach ($logs as $e) {
        if (($e['channel'] ?? '') !== 'whatsapp') continue;
        if (preg_replace('/\D/', '', (string)($e['ip'] ?? '')) !== $number) continue;
        $rows[] = $e;
        if (count($rows) >= $max) break;
    }
    $rows = array_reverse($rows);   // log disimpan terbaru-dulu
    $out = '';
    foreach ($rows as $e) {
        $q = trim((string)($e['q'] ?? ''));
        $a = trim((string)($e['a'] ?? ''));
        if ($q !== '') $out .= "Customer: " . $q . "\n";
        if ($a !== '') $out .= "CS: " . $a . "\n";
    }
    if (trim($out) === '') { try { return wiTranscript($number, $max); } catch (\Throwable $e) {} }   // v1.2.105: riwayat-wa-waha
    return trim($out);
}

// Jalankan analisa untuk satu nomor lalu simpan kartunya.
// $force = true untuk analisa ulang manual (lewat action analyze_lead).
function leadAnalyzeNumber($settings, $number, $logs = null, $force = false) {
    $number = preg_replace('/\D/', '', (string)$number);
    if ($number === '') return false;
    $all = leadsGetAll();
    if (!$force && isset($all[$number])) return false;   // sudah punya kartu -> sekali saja

    $transcript = leadBuildTranscript($number, $logs);
    if ($transcript === '') return false;

    $ex = leadExtract($settings, $transcript);
    if ($ex === null) return false;

    $now = date('Y-m-d H:i:s');
    $lama = $all[$number] ?? [];
    $all[$number] = [
        'number'      => $number,
        'name'        => waContactName($number),
        'status'      => $lama['status'] ?? 'baru',
        'note'        => $lama['note'] ?? '',
        'extracted'   => $ex,
        'analyzed_at' => $now,
        'created_at'  => $lama['created_at'] ?? $now,
        'updated_at'  => $now,
    ];
    writeJson(LEADS_FILE, $all);
    return true;
}

/* ============================================================
 * v1.2.19: kontak WA — nama pengirim dari profil WhatsApp
 * ============================================================ */
function waGetContacts() {
    if (deiStorageMysql()) {   // v1.2.71
        $out = [];
        foreach (deiDb()->query('SELECT num, body FROM dei_contacts')->fetchAll() as $r) {
            $c = json_decode($r['body'], true);
            if (is_array($c)) $out[(string)$r['num']] = $c;
        }
        return $out;
    }
    $c = readJson(CONTACTS_FILE, []);
    return is_array($c) ? $c : [];
}
// Simpan/perbarui nama dari profil WhatsApp. TIDAK menimpa koreksi manual agent.
function waSaveContact($number, $nameWa, $ch = '') {   // v1.2.98: multi-nomor ($ch = nomor bisnis penerima)
    $number = preg_replace('/\D/', '', (string)$number);
    if ($number === '') return;
    $nameWa = trim((string)$nameWa);
    waContactUpdate($number, function (&$c) use ($nameWa, $ch) {   // v1.2.71: atomik, dua mode; v1.2.98: + $ch
        if ($nameWa !== '') $c['name_wa'] = mb_substr($nameWa, 0, 100);
        $c['last_seen'] = date('Y-m-d H:i:s');
        if ((string)$ch !== '') $c['wa_ch'] = (string)$ch;   // v1.2.98: multi-nomor
    });
}
// Nama tampil: koreksi manual menang atas nama profil WhatsApp.
function waContactName($number, $contacts = null) {
    $number = preg_replace('/\D/', '', (string)$number);
    $all = ($contacts === null) ? waContactsFor($number) : $contacts;   // v1.2.71
    $c = $all[$number] ?? null;
    if (!is_array($c)) return '';
    $manual = trim((string)($c['name_manual'] ?? ''));
    if ($manual !== '') return $manual;
    return trim((string)($c['name_wa'] ?? ''));
}

// v1.2.39: tag pipeline kontak (stage) + modifier VIP
function contactStageValid($s) {
    return in_array($s, ['new', 'warm', 'hot_prospect', 'cold', 'lost', 'active_customer', 'churned'], true);
}
function waContactStage($number, $contacts = null) {
    $number = preg_replace('/\D/', '', (string)$number);
    $all = ($contacts === null) ? waContactsFor($number) : $contacts;   // v1.2.71
    $c = $all[$number] ?? null;
    if (!is_array($c)) return 'new';
    $st = (string)($c['stage'] ?? 'new');
    return contactStageValid($st) ? $st : 'new';
}
function waContactVip($number, $contacts = null) {
    $number = preg_replace('/\D/', '', (string)$number);
    $all = ($contacts === null) ? waContactsFor($number) : $contacts;   // v1.2.71
    $c = $all[$number] ?? null;
    if (!is_array($c)) return false;
    // VIP hanya sah nempel di stage active_customer, walau data lama entah
    // bagaimana punya vip=true di stage lain (jaga-jaga, bukan cuma pas simpan).
    return !empty($c['vip']) && waContactStage($number, $all) === 'active_customer';
}
// Simpan stage + vip. VIP dipaksa false kalau stage bukan active_customer,
// supaya tidak ada kombinasi ganjil tersimpan (mis. "Baru" + VIP).
function waSetContactStage($number, $stage, $vip) {
    $number = preg_replace('/\D/', '', (string)$number);
    if ($number === '' || !contactStageValid($stage)) return false;
    waContactUpdate($number, function (&$c) use ($stage, $vip) {   // v1.2.71
        $c['stage']            = $stage;
        $c['vip']              = ($stage === 'active_customer') ? (bool)$vip : false;
        $c['stage_updated_at'] = date('Y-m-d H:i:s');
    });
    return true;
}
// v1.2.39 fase4: data pelanggan (nama + tanggal lahir), diisi manual saat
// kontak sudah jadi Active Customer. $custName / $custDob null = tidak
// diubah (partial update, sama pola dengan save_lead).
// v1.2.113: import-kontak — impor kontak dari file (XLS/XLSX/CSV) ke menu Kontak.
// Kunci kontak = nomor angka saja berawalan kode negara (sama persis dengan nomor
// dari WhatsApp), jadi saat nomor itu chat nanti datanya otomatis menyatu.
function contactImportNormNum($raw) {
    $d = preg_replace('/\D/', '', (string)$raw);
    if ($d === '') return '';
    if (strpos($d, '00') === 0) $d = substr($d, 2);                 // 0062… (format internasional)
    if (strpos($d, '620') === 0) $d = '62' . substr($d, 3);         // +62 0812… -> 62812…
    elseif ($d[0] === '0') $d = '62' . substr($d, 1);               // 0812… -> 62812…
    elseif ($d[0] === '8' && strlen($d) >= 9 && strlen($d) <= 13) $d = '62' . $d;   // 812… -> 62812…
    $n = strlen($d);
    if ($n < 10 || $n > 15) return '';
    if (strpos($d, '62') === 0 && ($d[2] ?? '') !== '8') return '';   // nomor HP Indonesia selalu 628…
    return $d;
}
function contactImportRank($s) {
    $r = ['active_customer' => 6, 'hot_prospect' => 5, 'warm' => 4, 'cold' => 3, 'churned' => 2, 'lost' => 1, 'new' => 0];
    return $r[$s] ?? 0;
}
// Terapkan satu baris impor ke kontak (dipanggil di dalam waContactUpdate).
// Kebijakan: Lead Rating hanya diisi bila kontak baru / masih Unrated, kecuali
// $overwrite; nama tidak menimpa nama yang sudah ada; last_seen dibiarkan kosong
// untuk kontak baru (belum pernah chat -> urut paling bawah).
function contactImportApply(array &$c, $isNew, array $r, $overwrite, $now, &$res) {
    if ($isNew) { $c['last_seen'] = ''; $res = 'created'; }
    $cur = contactStageValid($c['stage'] ?? '') ? $c['stage'] : 'new';
    $stage = $r['stage'];
    if ($stage !== '' && ($isNew || $cur === 'new' || $overwrite)) {
        if ($cur !== $stage || $isNew) {
            $c['stage'] = $stage;
            $c['vip'] = ($stage === 'active_customer') ? !empty($c['vip']) : false;
            $c['stage_updated_at'] = $now;
        }
        if (!$isNew) $res = 'updated';
    } elseif (!$isNew) {
        $res = ($stage !== '' && $cur !== $stage) ? 'kept' : 'updated';
    }
    if ($r['name'] !== '') {
        if (trim((string)($c['cust_name'] ?? '')) === '') $c['cust_name'] = $r['name'];
        if (trim((string)($c['name_manual'] ?? '')) === '' && trim((string)($c['name_wa'] ?? '')) === '') $c['name_manual'] = $r['name'];
    }
    $c['imp'] = ['at' => $now, 'src' => $r['src'], 'st' => $r['st'], 'n' => $r['cnt']];
}
function waSetContactInfo($number, $custName, $custDob) {
    $number = preg_replace('/\D/', '', (string)$number);
    if ($number === '') return false;
    waContactUpdate($number, function (&$c) use ($custName, $custDob) {   // v1.2.71
        if ($custName !== null) $c['cust_name'] = mb_substr(trim((string)$custName), 0, 100);
        if ($custDob  !== null) $c['cust_dob']  = $custDob;
    });
    return true;
}

/* ============================================================
 * v1.2.13: daftar kategori notif (6 fixed permanen + custom dari file)
 * ============================================================ */
function deiFixedCategories() {
    return ['Sales', 'Operation', 'Marketing', 'Engineering', 'Owner', 'IT'];
}
function deiCustomCategories() {
    $c = readJson(PUSH_CATEGORIES_FILE, []);
    if (!is_array($c)) return [];
    $out = [];
    foreach ($c as $x) {
        $x = trim((string)$x);
        if ($x !== '') $out[] = $x;
    }
    return array_values(array_unique($out));
}
function deiAllCategories() {
    return array_values(array_merge(deiFixedCategories(), deiCustomCategories()));
}
// Hitung pemakaian kategori di KB (topic) + users (categories) — untuk blokir hapus.
function deiCategoryUsage($cat) {
    $cat = trim((string)$cat);
    $kbCount = 0; $userCount = 0;
    foreach (readJson(KB_FILE, []) as $e) {
        if (trim((string)($e['topic'] ?? '')) === $cat) $kbCount++;
    }
    foreach (readJson(USERS_FILE, []) as $u) {
        $cats = $u['categories'] ?? [];
        if (is_array($cats) && in_array($cat, $cats, true)) $userCount++;
    }
    return ['kb' => $kbCount, 'users' => $userCount];
}

/* ============================================================
 * v1.2.12: auto-assign by topic — deteksi topik via KB retrieval + routing
 * ============================================================ */
// Deteksi topik dari pesan (hybrid: window + score threshold). Gratis (no AI call).
// Scoring sama persis dengan searchKB, tapi sekalian bawa score supaya bisa
// apply threshold — searchKB sendiri tidak diubah (dipakai tempat lain).
define('TOPIC_SCAN_MAX', 5);      // berapa kandidat teratas yang dicek topic-nya
define('TOPIC_MIN_RATIO', 0.5);   // kandidat diabaikan kalau score < ratio x score tertinggi
function detectTopicFromMessage($message) {
    $message = trim((string)$message);
    if ($message === '') return '';
    $kb = readJson(KB_FILE, []);
    if (!$kb) return '';

    $words = preg_split('/\s+/', mb_strtolower($message));
    $words = array_filter($words, function ($w) { return mb_strlen($w) >= 3; });
    if (empty($words)) return '';

    $scored = [];
    foreach ($kb as $entry) {
        $hay = mb_strtolower(($entry['title'] ?? '') . ' ' . ($entry['category'] ?? '') . ' ' . ($entry['content'] ?? ''));
        $score = 0;
        foreach ($words as $w) { $score += substr_count($hay, $w); }
        if ($score > 0) $scored[] = ['s' => $score, 'e' => $entry];
    }
    if (empty($scored)) return '';
    usort($scored, function ($a, $b) { return $b['s'] - $a['s']; });

    $topScore  = (int)$scored[0]['s'];
    $minScore  = $topScore * TOPIC_MIN_RATIO;
    $candidates = array_slice($scored, 0, TOPIC_SCAN_MAX);
    foreach ($candidates as $r) {
        if ($r['s'] < $minScore) break;   // sisanya pasti lebih kecil (sudah terurut)
        $topic = trim((string)($r['e']['topic'] ?? ''));
        if ($topic !== '') return $topic;
    }
    return '';
}

// Filter subscriber by topik: agent yang punya kategori match + SEMUA super_admin/admin.
// Kalau topic kosong -> return semua subscriber (broadcast fallback).
// $subscribers = array_keys(push-subs.json) = daftar username yang subscribe.
function getPushTargetsByTopic($topic, $subscribers) {
    $topic = trim((string)$topic);
    if ($topic === '' || empty($subscribers)) return $subscribers;   // fallback broadcast

    $users = readJson(USERS_FILE, []);
    $byName = [];
    foreach ($users as $u) {
        if (isset($u['username'])) $byName[$u['username']] = $u;
    }

    $targets = [];
    foreach ($subscribers as $sub) {
        $u = $byName[$sub] ?? null;
        if (!$u) { continue; }   // subscriber tidak ada di users -> skip (safety)
        $role = $u['role'] ?? '';
        // super_admin + admin selalu dapat semua notif
        if ($role === 'super_admin' || $role === 'admin' || $role === 'supervisor') {   // v1.2.58
            $targets[] = $sub;
            continue;
        }
        // agent lain: cek kategori match
        $cats = $u['categories'] ?? [];
        if (is_array($cats) && in_array($topic, $cats, true)) {
            $targets[] = $sub;
        }
    }
    // Safety: kalau hasil kosong (tidak ada agent match + tidak ada admin subscribe),
    // fallback broadcast supaya notif tidak hilang total.
    return empty($targets) ? $subscribers : $targets;
}

/*
 * v1.2.8: sendPushToUsers — kirim Web Push ke subscriber (generic, future-proof)
 * ============================================================ */
function sendPushToUsers($targetUsers, $title, $body, $url, $tag = 'dei-wa') {
    $vendorAutoload = __DIR__ . '/../vendor/autoload.php';
    $vapidFile = DATA_DIR . '/vapid-keys.json';
    $subsFile  = DATA_DIR . '/push-subs.json';
    if (!file_exists($vendorAutoload) || !file_exists($vapidFile) || !file_exists($subsFile)) return;

    require_once $vendorAutoload;
    $vapid = json_decode(file_get_contents($vapidFile), true);
    $allSubs = json_decode(file_get_contents($subsFile), true);
    if (!is_array($allSubs) || empty($allSubs)) return;
    if (empty($vapid['publicKey']) || empty($vapid['privateKey'])) return;

    try {
        $auth = ['VAPID' => [
            'subject'    => 'mailto:admin@deintegra.com',
            'publicKey'  => $vapid['publicKey'],
            'privateKey' => $vapid['privateKey'],
        ]];
        $webPush = new \Minishlink\WebPush\WebPush($auth);
        $payload = json_encode([
            'title' => $title,
            'body'  => $body,
            'url'   => $url,
            'icon'  => './icon-192.png',
            'tag'   => $tag,
        ], JSON_UNESCAPED_UNICODE);

        foreach ($targetUsers as $username) {
            $subs = $allSubs[$username] ?? [];
            foreach ($subs as $sub) {
                if (empty($sub['endpoint']) || empty($sub['keys'])) continue;
                $webPush->queueNotification(
                    \Minishlink\WebPush\Subscription::create([
                        'endpoint' => $sub['endpoint'],
                        'keys'     => $sub['keys'],
                    ]),
                    $payload
                );
            }
        }

        // Flush + cleanup expired (410 Gone / 404)
        $expired = [];
        foreach ($webPush->flush() as $report) {
            if (!$report->isSuccess() && $report->isSubscriptionExpired()) {
                $ep = method_exists($report, 'getEndpoint') ? $report->getEndpoint() : '';
                if ($ep !== '') $expired[$ep] = true;
            }
        }
        if (!empty($expired)) {
            $changed = false;
            foreach ($allSubs as $u => $subs) {
                $filtered = array_values(array_filter($subs, function ($s) use ($expired) {
                    return empty($expired[$s['endpoint'] ?? '']);
                }));
                if (count($filtered) !== count($subs)) { $allSubs[$u] = $filtered; $changed = true; }
            }
            if ($changed) @file_put_contents($subsFile, json_encode($allSubs, JSON_PRETTY_PRINT|JSON_UNESCAPED_UNICODE), LOCK_EX);
        }
    } catch (\Throwable $e) {
        error_log('sendPushToUsers error: ' . $e->getMessage());
    }
}
// === /v1.2.8 sendPushToUsers ===

/* v1.2.81: LINK redBus otomatis — hanya instalasi yang mengisi 'redbus' di data/server.php. */
function deiRedbusConf() {
    $c = deiServerConf()['redbus'] ?? null;
    if (!is_array($c) || empty($c['cities']) || !is_array($c['cities'])) return null;
    return $c;
}
// Nama kota (atau alias) -> [nama resmi, id]. null bila tidak dikenal.
function deiRedbusCity($name) {
    $c = deiRedbusConf(); if (!$c) return null;
    $norm = function ($x) { return trim(preg_replace('/\s+/u', ' ', mb_strtolower((string)$x))); };
    $map = [];
    foreach ($c['cities'] as $k => $v) $map[$norm($k)] = [$k, $v];
    $key = $norm($name);
    for ($i = 0; $i < 3 && isset($map[$key]); $i++) {
        list($nm, $v) = $map[$key];
        if (is_int($v) || ctype_digit((string)$v)) return [$nm, (string)$v];
        $key = $norm($v);   // alias -> kota lain
    }
    return null;
}
// v1.2.88: tabel rute (pasangan id kota) dari action=redbus_scan. null = belum ada -> semua pasangan boleh.
function deiRedbusRoutesFile() { return DATA_DIR . '/redbus-routes.json'; }
function deiRedbusRoutes() {
    static $r = false;
    if ($r !== false) return $r;
    $j = is_file(deiRedbusRoutesFile()) ? json_decode((string)@file_get_contents(deiRedbusRoutesFile()), true) : null;   // cek-storage: boleh (berkas konfigurasi hasil CLI, hanya dibaca)
    $r = (is_array($j) && !empty($j['pairs']) && is_array($j['pairs'])) ? array_fill_keys($j['pairs'], true) : null;
    return $r;
}
function deiRedbusPairKey($idA, $idB) { $a = (int)$idA; $b = (int)$idB; return min($a, $b) . '-' . max($a, $b); }
function deiRedbusRouteOk($from, $to) {
    $R = deiRedbusRoutes(); if ($R === null) return true;
    $f = deiRedbusCity($from); $t = deiRedbusCity($to);
    return $f && $t && isset($R[deiRedbusPairKey($f[1], $t[1])]);
}
// Tujuan yang tersedia dari satu kota (nama tampilan), maks $max.
function deiRedbusDestsFrom($from, $max = 8) {
    $R = deiRedbusRoutes(); $c = deiRedbusConf(); $f = deiRedbusCity($from);
    if ($R === null || !$c || !$f) return [];
    $out = [];
    foreach ($c['cities'] as $k => $v) {
        if (!(is_int($v) || ctype_digit((string)$v)) || (string)$v === $f[1]) continue;
        if (isset($R[deiRedbusPairKey($f[1], $v)])) $out[] = trim(preg_replace('/\s*\(.*?\)/', '', $k));
        if (count($out) >= $max) break;
    }
    return $out;
}
function deiRedbusSlug($s) { return trim(preg_replace('/[^a-z0-9]+/', '-', strtolower($s)), '-'); }
function deiRedbusUrl($from, $to, $date = '') {
    $c = deiRedbusConf(); $f = deiRedbusCity($from); $t = deiRedbusCity($to);
    if (!$c || !$f || !$t || $f[1] === $t[1]) return '';
    if (!deiRedbusRouteOk($from, $to)) return '';   // v1.2.88: pasangan tidak ada di tabel rute
    $today = wibDate('Y-m-d');
    // v1.2.87: tanpa tanggal -> hari ini sebelum jam batas, sesudahnya besok
    $cut = (int)($c['cutoff_hour'] ?? 15);
    $def = ((int)wibDate('G') >= $cut) ? date('Y-m-d', strtotime($today . ' +1 day')) : $today;
    $d = (preg_match('/^\d{4}-\d{2}-\d{2}$/', (string)$date) && $date >= $today) ? $date : $def;
    $q = ['fromCityName' => $f[0], 'fromCityId' => $f[1], 'srcCountry' => 'Indonesia', 'fromCityType' => 'CITY',
          'toCityName' => $t[0], 'toCityId' => $t[1], 'destCountry' => 'Indonesia', 'toCityType' => 'CITY',
          'onward' => date('d-M-Y', strtotime($d . ' 12:00:00'))];
    if (!empty($c['op_id'])) $q['opId'] = (string)$c['op_id'];
    return 'https://www.redbus.id/tiket-bus/' . deiRedbusSlug($f[0]) . '-ke-' . deiRedbusSlug($t[0]) . '?' . http_build_query($q, '', '&', PHP_QUERY_RFC3986);
}
function deiRedbusPromptBlock() {
    $c = deiRedbusConf(); if (!$c) return '';
    $names = implode(', ', array_keys($c['cities']));
    return "=== LINK PEMESANAN TIKET (redBus) ===\n"
        . "Bila pelanggan menanyakan harga, ketersediaan kursi, atau ingin memesan tiket untuk suatu rute, "
        . "tulis di baris terakhir jawaban tag persis seperti ini: [[REDBUS:<kota asal>|<kota tujuan>|<tanggal YYYY-MM-DD>]].\n"
        . "- Isi tanggal hanya bila pelanggan menyebut tanggal atau hari (hitung dari tanggal hari ini di atas); bila tidak, kosongkan: [[REDBUS:Jakarta|Purwokerto|]]. JANGAN menanyakan tanggal — begitu kota asal & tujuan jelas, langsung tulis tag (tanggal bisa diganti pelanggan di halaman redBus).\n"
        . "- Kota yang dikenal: " . $names . ".\n"
        . "- JANGAN PERNAH menulis URL/link redbus.id sendiri; sistem mengganti tag dengan link resmi.\n"
        . "- PENTING: aturan ini berlaku walaupun harga tidak ada di knowledge base. Untuk pertanyaan harga/tiket/kursi JANGAN menjawab 'tidak memiliki informasi' dan jangan menyuruh menghubungi tim; harga & kursi terbaru selalu ada di link redBus.\n"
        . "- Bila kota asal belum disebut (mis. 'harga ke Purwokerto'), tanyakan singkat: berangkat dari kota mana. Setelah pelanggan menjawab, tulis tagnya.\n"
        . "- Hanya kota di daftar yang dilayani. Bila kota asal/tujuan tidak ada di daftar, jawab singkat bahwa rute itu tidak tersedia (tanpa tag, tanpa link) lalu tawarkan kota tujuan dari daftar.";
}
// v1.2.86: "18 oktober" / "18 okt" / "18/10" / angka saja (hanya pesan sekarang) -> Y-m-d (tahun ini, atau tahun depan bila sudah lewat)
function deiRedbusDayMonth($t, $allowBare = false) {
    $bln = ['jan' => 1, 'feb' => 2, 'mar' => 3, 'apr' => 4, 'mei' => 5, 'may' => 5, 'jun' => 6, 'jul' => 7, 'agu' => 8, 'agt' => 8, 'aug' => 8,
            'sep' => 9, 'okt' => 10, 'oct' => 10, 'nov' => 11, 'des' => 12, 'dec' => 12];
    $today = wibDate('Y-m-d'); $d = 0; $mo = 0;
    if (preg_match('/\b(\d{1,2})\s*(jan|feb|mar|apr|mei|may|jun|jul|agu|agt|aug|sep|okt|oct|nov|des|dec)\p{L}*/u', $t, $m)) { $d = (int)$m[1]; $mo = $bln[$m[2]]; }
    elseif (preg_match('/\b(\d{1,2})[\/\-.](\d{1,2})\b/', $t, $m)) { $d = (int)$m[1]; $mo = (int)$m[2]; }
    elseif ($allowBare && preg_match('/^\s*(\d{1,2})\s*\??\s*$/', $t, $m)) {
        $d = (int)$m[1]; $mo = (int)substr($today, 5, 2);
        if (sprintf('%s-%02d', substr($today, 0, 7), $d) < $today) $mo = $mo % 12 + 1;
    }
    if ($d < 1 || $d > 31 || $mo < 1 || $mo > 12) return '';
    $y = (int)substr($today, 0, 4);
    if (sprintf('%04d-%02d-%02d', $y, $mo, $d) < $today) $y++;
    return checkdate($mo, $d, $y) ? sprintf('%04d-%02d-%02d', $y, $mo, $d) : '';
}
// v1.2.82: tebak rute dari pesan pelanggan (pesan sekarang + 2 pesan pelanggan sebelumnya).
// Hasil: ['from' => nama|null, 'to' => nama|null, 'date' => Y-m-d|'', 'intent' => bool]
function deiRedbusGuess($message, $history = []) {
    $c = deiRedbusConf(); if (!$c) return null;
    $texts = [mb_strtolower((string)$message)];
    $skip = true;   // v1.2.86: riwayat Tes Chatbot sudah memuat pesan sekarang di akhir
    for ($i = count($history) - 1; $i >= 0 && count($texts) < 4; $i--) {
        if (($history[$i]['role'] ?? '') === 'assistant') { $skip = false; continue; }
        $h = mb_strtolower((string)($history[$i]['content'] ?? ''));
        if ($skip && trim($h) === trim($texts[0])) { $skip = false; continue; }
        $skip = false; $texts[] = $h;
    }
    $names = array_keys($c['cities']);
    usort($names, function ($a, $b) { return mb_strlen($b) - mb_strlen($a); });
    $rx = '/(?<![\p{L}])(' . implode('|', array_map(function ($n) { return preg_quote(mb_strtolower($n), '/'); }, $names)) . ')(?![\p{L}])/u';
    $unknown = false; $intent = false; $to = null; $from = null; $date = ''; $seen = [];
    $today = wibDate('Y-m-d');
    // salah ketik ringan (purwekerto -> purwokerto): kata >=5 huruf, jarak edit <=1 (<=2 bila >=8 huruf)
    $single = array_values(array_filter(array_map('mb_strtolower', $names), function ($n) { return strpos($n, ' ') === false && strlen($n) >= 5; }));
    foreach ($texts as $k => $t) {
        $texts[$k] = preg_replace_callback('/\p{L}{5,}/u', function ($w) use ($single) {
            $x = $w[0]; if (in_array($x, $single, true)) return $x;
            // v1.2.83: salah ketik — huruf pertama sama, jarak 1 (2 hanya bila >=9 huruf); "malang" bukan "magelang"
            foreach ($single as $n) { if ($n[0] === $x[0] && abs(strlen($n) - strlen($x)) <= 1 && levenshtein($x, $n) <= (strlen($n) >= 9 ? 2 : 1)) return $n; }
            return $x;
        }, $t);
    }
    foreach ($texts as $ti => $t) {
        if (preg_match('/\b(harga|tiket|tarif|ongkos|biaya|berapa|pesan|booking|book|kursi|seat|jadwal|berangkat)\b/u', $t)) $intent = true;
        if ($date === '') {
            if (preg_match('/\b(\d{4}-\d{2}-\d{2})\b/', $t, $m)) $date = $m[1];
            elseif (preg_match('/\blusa\b/u', $t)) $date = date('Y-m-d', strtotime($today . ' +2 day'));
            elseif (preg_match('/\bbesok\b/u', $t)) $date = date('Y-m-d', strtotime($today . ' +1 day'));
            elseif (($dm = deiRedbusDayMonth($t, $ti === 0)) !== '') $date = $dm;   // v1.2.86
            elseif (preg_match('/\b(?:tanggal|tgl)\.?\s*(\d{1,2})\b/u', $t, $m) && (int)$m[1] >= 1 && (int)$m[1] <= 31) {
                $d = sprintf('%s-%02d', substr($today, 0, 7), (int)$m[1]);
                if ($d < $today) $d = date('Y-m', strtotime(substr($today, 0, 7) . '-01 +1 month')) . sprintf('-%02d', (int)$m[1]);
                if (checkdate((int)substr($d, 5, 2), (int)substr($d, 8, 2), (int)substr($d, 0, 4))) $date = $d;
            }
        }
        // v1.2.83: "ke <kota di luar tabel>" -> tujuan tidak dikenal, biarkan jawaban AI
        if (preg_match_all('/\b(?:ke|tujuan|menuju)\s+(\p{L}{3,})/u', $t, $km)) {
            foreach ($km[1] as $w) { if (!deiRedbusCity($w) && !in_array($w, ['mana', 'sana', 'sini', 'kota', 'arah', 'luar', 'dalam'], true)) $unknown = true; }
        }
        if (!preg_match_all($rx, $t, $mm, PREG_OFFSET_CAPTURE)) continue;
        foreach ($mm[1] as $hit) {
            $city = deiRedbusCity($hit[0]); if (!$city) continue;
            $before = substr($t, max(0, $hit[1] - 12), min(12, $hit[1]));
            if ($to === null && preg_match('/\b(ke|tujuan|menuju|to)\s*$/u', $before)) { $to = $city[0]; $intent = true; }   // v1.2.86: "ke <kota>" = niat cek rute
            elseif ($from === null && preg_match('/\b(dari|asal|from)\s*$/u', $before)) $from = $city[0];
            else $seen[] = [$city[0], $ti];
        }
    }
    foreach ($seen as $s) {   // kota tanpa kata "dari/ke": pesan sekarang lebih dulu
        if ($s[0] === $to || $s[0] === $from) continue;
        if ($to === null && $from !== null) $to = $s[0];
        elseif ($from === null && ($to !== null || $s[1] === 0)) $from = $s[0];
        elseif ($to === null) $to = $s[0];
    }
    if ($unknown && $to === null) return ['from' => $from, 'to' => null, 'date' => $date, 'intent' => $intent];   // v1.2.83
    if ($from !== null && $to === null && count($seen) <= 1) { $to = $from; $from = null; }   // satu kota saja = tujuan
    return ['from' => $from, 'to' => $to, 'date' => $date, 'intent' => $intent];
}

// Ganti tag di jawaban AI dengan link; tag yang tidak bisa dibuat linknya dibuang.
// v1.2.82: tanpa tag -> cadangan dari pesan pelanggan.
// v1.2.84: pembungkus — buang link redbus.id tulisan AI, lalu pastikan ada link resmi atau kabar "tidak tersedia".
function deiRedbusRouteNA($from = '', $to = '') {
    $c = deiRedbusConf() ?: []; $op = trim((string)($c['operator'] ?? ''));
    $nm = function ($x) { return trim(preg_replace('/\s*\(.*?\)/', '', (string)$x)); };
    $r = ($from !== '' && $to !== '') ? ' ' . $nm($from) . ' – ' . $nm($to) : ' tersebut';
    $msg = 'Mohon maaf, rute' . $r . ' belum tersedia' . ($op !== '' ? ' di ' . $op : '') . '.';
    $d = $from !== '' ? deiRedbusDestsFrom($from) : [];   // v1.2.88
    if ($d) $msg .= ' Dari ' . $nm(deiRedbusCity($from)[0]) . ' tersedia ke ' . implode(', ', $d) . '.';
    return $msg;
}
function deiRedbusExpand($answer, $message = '', $history = []) {
    if (!deiRedbusConf()) return $answer;
    $raw = false;
    if (preg_match('~redbus\.id~i', (string)$answer)) {
        $raw = true;   // baris yang memuat link tulisan AI dibuang seluruhnya
        $answer = trim(preg_replace("/\n{3,}/", "\n\n", preg_replace('~^.*(?:https?://)?(?:www\.)?redbus\.id\S*.*$\n?~imu', '', (string)$answer)));
    }
    // tag dengan kota di luar tabel -> seluruh jawaban jadi kabar "tidak tersedia" (tanpa kalimat "berikut linknya")
    if (preg_match_all('/\[\[REDBUS:([^|\]]*)\|([^|\]]*)(?:\|([^\]]*))?\]\]/u', (string)$answer, $tm, PREG_SET_ORDER)) {
        foreach ($tm as $m) if (deiRedbusUrl(trim($m[1]), trim($m[2]), trim($m[3] ?? '')) === '') {
            error_log('redbus: rute/kota tidak tersedia (' . $m[1] . ' -> ' . $m[2] . ')');
            return deiRedbusRouteNA(trim($m[1]), trim($m[2])) . (deiRedbusCity(trim($m[1])) && deiRedbusRoutes() !== null ? '' : ' Silakan sebutkan kota tujuan lain.');
        }
    }
    if ($raw && strpos((string)$answer, '[[REDBUS') === false) {
        // AI menulis link sendiri: ganti seluruhnya dengan link resmi, tanya kota asal, atau kabar tidak tersedia
        $g = $message !== '' ? deiRedbusGuess($message, $history) : null;
        $nm = function ($x) { return trim(preg_replace('/\s*\(.*?\)/', '', (string)$x)); };
        if ($g && $g['to'] !== null && $g['from'] !== null && ($u = deiRedbusUrl($g['from'], $g['to'], $g['date'])) !== '') {
            $c = deiRedbusConf();
            return 'Harga & kursi terbaru rute ' . $nm($g['from']) . ' – ' . $nm($g['to']) . ' bisa dicek langsung di redBus.' . "\n\n" . trim((string)($c['label'] ?? 'Cek harga & pesan tiket:') . ' ' . $u);
        }
        if ($g && $g['to'] !== null && $g['from'] === null) return 'Berangkat dari kota mana? Nanti saya kirimkan link cek harga & pesan tiket ke ' . $nm($g['to']) . '.';
        if ($g && $g['to'] !== null && $g['from'] !== null) return deiRedbusRouteNA($g['from'], $g['to']);   // v1.2.88
        return deiRedbusRouteNA() . ' Silakan sebutkan kota tujuan lain.';
    }
    // v1.2.85: penolakan AI soal harga/tiket ke kota di luar tabel -> kabar "belum tersedia" + contoh tujuan
    if (strpos((string)$answer, '[[REDBUS') === false
        && preg_match('/tidak (memiliki|punya|ada|tersedia)[^.\n]{0,20}informasi|belum (memiliki|punya|ada) informasi/iu', (string)$answer)
        && preg_match('/(?:harga|tiket|rute|tarif)[^.\n]{0,40}?\bke\s+(\p{Lu}[\p{L}]+(?:\s\p{Lu}[\p{L}]+)?)/u', (string)$answer, $km)
        && !deiRedbusCity($km[1])
        && !(($gg = deiRedbusGuess($message, $history)) && $gg['to'] !== null)) {   // pesan pelanggan sudah berisi rute dikenal -> cadangan biasa
        $c = deiRedbusConf(); $op = trim((string)($c['operator'] ?? ''));
        $ex = [];
        foreach ($c['cities'] as $k => $v) { if (is_int($v) || ctype_digit((string)$v)) $ex[] = trim(preg_replace('/\s*\(.*?\)/', '', $k)); if (count($ex) >= 8) break; }
        return 'Mohon maaf, rute ke ' . $km[1] . ' belum tersedia' . ($op !== '' ? ' di ' . $op : '') . '. '
            . 'Kota yang tersedia antara lain ' . implode(', ', $ex) . '. Mau cek rute yang mana?';
    }
    return deiRedbusExpandCore($answer, $message, $history);
}
function deiRedbusExpandCore($answer, $message = '', $history = []) {
    if (strpos((string)$answer, '[[REDBUS') === false) {
        $c = deiRedbusConf();
        if (!$c || $message === '' || stripos((string)$answer, 'redbus.id') !== false) return $answer;
        $g = deiRedbusGuess($message, $history);
        if (!$g || !$g['intent'] || $g['to'] === null) return $answer;
        $refuse = (bool)preg_match('/tidak (memiliki|punya|ada|tersedia)[^.\n]{0,20}informasi|belum (memiliki|punya|ada) informasi|hubungi (tim|admin|cs|customer)/iu', (string)$answer);
        $askDate = (bool)preg_match('/(tanggal|kapan|hari apa)[^?\n]{0,40}\?/iu', (string)$answer);   // v1.2.86
        if ($g['from'] === null) {
            return $refuse ? 'Berangkat dari kota mana? Nanti saya kirimkan link cek harga & pesan tiket ke ' . trim(preg_replace('/\s*\(.*?\)/', '', $g['to'])) . '.' : $answer;
        }
        // v1.2.83: AI sudah bilang rute tidak tersedia -> jangan tempel link
        if (preg_match('/(belum|tidak) (tersedia|bisa dicek|dapat dicek|melayani)|tidak ada di daftar/iu', (string)$answer)) return $answer;
        $u = deiRedbusUrl($g['from'], $g['to'], $g['date']);
        if ($u === '' && !deiRedbusRouteOk($g['from'], $g['to'])) return deiRedbusRouteNA($g['from'], $g['to']);   // v1.2.88
        if ($u === '') return $answer;
        $line = trim((string)($c['label'] ?? 'Cek harga & pesan tiket:') . ' ' . $u);
        $nm = function ($x) { return trim(preg_replace('/\s*\(.*?\)/', '', $x)); };   // "Yogyakarta (jogja)" -> "Yogyakarta"
        if ($refuse || ($askDate && $g['date'] === '')) return 'Harga & kursi terbaru rute ' . $nm($g['from']) . ' – ' . $nm($g['to']) . ' bisa dicek langsung di redBus' . ($g['date'] === '' ? ' (tanggal keberangkatan bisa diganti di halaman itu)' : '') . '.' . "\n\n" . $line;
        $onlyDate = mb_strlen(trim((string)$message)) <= 20 && deiRedbusDayMonth(mb_strtolower((string)$message), true) !== '';   // balasan berupa tanggal saja
        if ($askDate || $onlyDate) return 'Harga & kursi terbaru rute ' . $nm($g['from']) . ' – ' . $nm($g['to']) . ' bisa dicek langsung di redBus.' . "\n\n" . $line;
        $toNm = mb_strtolower(trim(preg_replace('/\s*\(.*?\)/', '', $g['to'])));
        if (mb_strpos(mb_strtolower((string)$answer), $toNm) === false) return $answer;   // v1.2.83: jawaban bukan soal rute ini
        return rtrim((string)$answer) . "\n\n" . $line;
    }
    $c = deiRedbusConf();
    $label = $c ? (string)($c['label'] ?? 'Cek harga & pesan tiket:') : '';
    $out = preg_replace_callback('/\[\[REDBUS:([^|\]]*)\|([^|\]]*)(?:\|([^\]]*))?\]\]/u', function ($m) use ($label) {
        $u = deiRedbusUrl(trim($m[1]), trim($m[2]), trim($m[3] ?? ''));
        if ($u === '') { error_log('redbus: kota tidak dikenal (' . $m[1] . ' -> ' . $m[2] . ')'); return deiRedbusRouteNA(trim($m[1]), trim($m[2])); }   // v1.2.84
        return trim($label . ' ' . $u);
    }, (string)$answer);
    if ($label !== '') $out = preg_replace('/(?:' . preg_quote($label, '/') . '\s*){2,}/u', $label . ' ', (string)$out);   // v1.2.87: label ganda
    return trim(preg_replace("/\n{3,}/", "\n\n", (string)$out));
}

function generateAnswer($s, $message, $history = [], $channel = '') {
    $persona     = trim((string)($s['bot']['system_prompt'] ?? ''));
    // v1.2.3: prepend structured prompt prefix (form-generated). Empty string if all fields blank.
    $structuredPrefix = buildStructuredPromptPrefix($s['bot'] ?? []);
    if ($structuredPrefix !== '') {
        $persona = $structuredPrefix . "\n\n=== INSTRUKSI TAMBAHAN ===\n" . $persona;
    }
    // v1.2.53: aturan bahasa ditempel PALING AKHIR supaya jadi instruksi terakhir
    // yang dibaca model — mengalahkan prefix terstruktur DAN persona tenant.
    $deiBahasaUser = deiDeteksiBahasa($message);   // v1.2.53: deterministik, tanpa panggilan AI
    $deiAturanBhs = deiAturanBahasa($s['bot'] ?? [], $deiBahasaUser);
    if ($deiAturanBhs !== '') {
        $persona .= "\n\n" . $deiAturanBhs;
    }
    $kbAll       = readJson(KB_FILE, []);
    $kbHitsUsed  = count($kbAll);
    $deiPriceBlk = pricelistPromptBlock();   // v1.2.22: '' kalau daftar harga kosong
    $deiRbBlk = deiRedbusPromptBlock();      // v1.2.81: hanya bila redbus aktif di server.php
    if ($deiRbBlk !== '') $deiPriceBlk = trim($deiPriceBlk . "\n\n" . $deiRbBlk);
    if ($channel === 'whatsapp' && deiHematConf($s)['prompt']) $deiPriceBlk = trim($deiPriceBlk . "\n\n" . deiHematPromptBlock());   // v1.2.89
    // v1.2.102: closing-sekali — cegah AI mengulang "ada lagi yang bisa dibantu?"
    $deiPriceBlk = trim($deiPriceBlk . "\n\n" . "=== PENUTUP PERCAKAPAN ===\n"
        . "Jika pelanggan berterima kasih, pamit, atau menyatakan tidak ada/belum ada pertanyaan lagi, balas SATU kalimat penutup singkat yang sopan TANPA pertanyaan apa pun. "
        . "Jangan pernah menanyakan 'apakah ada lagi yang bisa dibantu' atau sejenisnya (sistem sudah mengirimnya otomatis). "
        . "Jika pelanggan mengeluh ditanya berulang, minta maaf singkat dan JANGAN bertanya lagi.");
    $deiGcBlk = ''; try { $deiGcBlk = gcPromptBlock($channel); } catch (\Throwable $e) { error_log('gcPromptBlock: ' . $e->getMessage()); }
    if ($deiGcBlk !== '') $deiPriceBlk = trim($deiPriceBlk . "\n\n" . $deiGcBlk);   // v1.2.109: guest-comment
    $deiWaktuBlk = deiKonteksWaktu();        // v1.2.35: dipasang di SEMUA jalur di bawah
    $minCacheTok = 1024;   // Anthropic ignores cache on blocks below ~1024 tokens

    // Build the full-KB block (Strategy B: send everything, let Claude pick what's relevant).
    $kbText = '';
    $deiFotoOn = deiKbFotoAktif($s, $channel); $deiAdaFoto = false;   // v1.2.95: kb-foto
    foreach ($kbAll as $e) {
        $cat = trim((string)($e['category'] ?? ''));
        $tit = trim((string)($e['title']    ?? ''));
        $con = trim((string)($e['content']  ?? ''));
        // v1.2.24: entri tanpa ISI dilewati. Entri "judul saja" (mis. hasil
        // fitur Pertanyaan Belum Terjawab yang menunggu diisi) kalau dikirim
        // akan terbaca model sebagai pertanyaan tanpa jawaban.
        if ($con === '') continue;
        if ($tit === '' && $con === '') continue;
        $deiFoto = ($deiFotoOn && !empty($e['id'])) ? deiKbFotoClean($e['images'] ?? []) : [];   // v1.2.95: kb-foto
        if ($deiFoto) $deiAdaFoto = true;
        $kbText .= '[' . $cat . '] ' . $tit . "\n" . $con . ($deiFoto ? "\n(" . count($deiFoto) . ' foto tersedia — kode [[FOTO:' . $e['id'] . ']])' : '') . "\n\n";
    }
    $kbText = trim($kbText);
    if ($deiAdaFoto) $deiPriceBlk = trim($deiPriceBlk . "\n\n" . deiKbFotoPrompt());   // v1.2.95: kb-foto

    // Heuristic: 4 chars ≈ 1 token. Anthropic caches only blocks >=1024 tokens.
    $kbTokensEst = (int)(strlen($kbText) / 4);

    if ($kbText === '') {
        // No KB at all — single-string system (no caching needed).
        $sys = $deiWaktuBlk . "\n\n" . $persona . "\n\n(Tidak ada entri Knowledge Base. Arahkan pengunjung untuk menghubungi tim resmi.)";   // v1.2.35
        if ($deiPriceBlk !== '') $sys .= "\n\n" . $deiPriceBlk;   // v1.2.22
        $messages = buildMessages($message, $history);
        list($ok, $answer, $usage) = callClaude($s, $sys, $messages);
        return [$ok, $ok ? deiRedbusExpand($answer, $message, $history) : $answer, 0, $usage];   // v1.2.81
    }

    if ($kbTokensEst < $minCacheTok) {
        // KB too small to benefit from cache — fall back to inline string system (saves a request roundtrip on cache write).
        $sys = $deiWaktuBlk . "\n\n" . $persona . "\n\n=== KNOWLEDGE BASE ===\n" . $kbText;   // v1.2.35
        if ($deiPriceBlk !== '') $sys .= "\n\n" . $deiPriceBlk;   // v1.2.22
        $messages = buildMessages($message, $history);
        list($ok, $answer, $usage) = callClaude($s, $sys, $messages);
        return [$ok, $ok ? deiRedbusExpand($answer, $message, $history) : $answer, $kbHitsUsed, $usage];   // v1.2.81
    }

    // KB big enough to cache. System = array of blocks:
    //   [persona block, KB block with cache_control]
    // The KB block is identical across requests for the same tenant, so cache hit rate should be high.
    // v1.1.10 fix: inject KONTEKS WAKTU (dynamic date) di depan supaya AI tahu tahun sekarang
    // Bukan di-cache karena isinya berubah tiap hari. Persona + KB tetap di-cache.
    $konteksWaktu = $deiWaktuBlk;   // v1.2.35: memakai helper bersama


    $systemBlocks = [
        ['type' => 'text', 'text' => $konteksWaktu],
        ['type' => 'text', 'text' => $persona . "\n\n=== KNOWLEDGE BASE (gunakan HANYA informasi di bawah; jika tidak ada, arahkan ke kontak resmi) ==="],
        ['type' => 'text', 'text' => $kbText, 'cache_control' => ['type' => 'ephemeral']],
    ];
    // v1.2.22: blok harga ditaruh SETELAH titik cache — mengubah harga tidak
    // menghanguskan cache KB, jadi update sesering apa pun tetap murah.
    if ($deiPriceBlk !== '') {
        $systemBlocks[] = ['type' => 'text', 'text' => $deiPriceBlk];
    }
    $messages = buildMessages($message, $history);
    list($ok, $answer, $usage) = callClaude($s, $systemBlocks, $messages);
    return [$ok, $ok ? deiRedbusExpand($answer, $message, $history) : $answer, $kbHitsUsed, $usage];   // v1.2.81
}

/* ============================================================================
 * v1.2.95: kb-foto — FOTO di entri Knowledge Base (maks 6/entri, JPG/PNG) di
 * data/kb-media/. Untuk WhatsApp (Meta & WAHA) entri berfoto diberi kode
 * [[FOTO:<id>]] di prompt; bila pelanggan minta melihat foto, AI menulis kode
 * itu, sistem membuangnya dari teks lalu mengirim fotonya setelah balasan.
 * ========================================================================= */
define('KB_MEDIA_DIR', DATA_DIR . '/kb-media');
define('KB_FOTO_MAX', 6);
function deiKbFotoClean($imgs) {
    $out = []; $seen = [];
    foreach ((array)$imgs as $im) {
        $f = is_array($im) ? (string)($im['file'] ?? '') : (string)$im;
        if (!preg_match('/^[a-f0-9]{20}\.(jpg|png)$/', $f) || isset($seen[$f]) || !is_file(KB_MEDIA_DIR . '/' . $f)) continue;
        $seen[$f] = true;
        $out[] = ['file' => $f];
        if (count($out) >= KB_FOTO_MAX) break;
    }
    return $out;
}
function deiKbFotoAktif($s, $channel) {
    return $channel === 'whatsapp' && in_array((string)($s['whatsapp_api']['provider'] ?? 'meta'), ['meta', 'waha'], true);
}
function deiKbFotoPrompt() {
    return "=== FOTO (WhatsApp) ===\n"
        . "Beberapa entri Knowledge Base punya foto, ditandai '(N foto tersedia — kode [[FOTO:...]])'. "
        . "Jika pelanggan meminta melihat foto/gambar/katalog/menu/kamar/produk/QR pembayaran yang sesuai dengan entri bertanda itu, "
        . "jawab singkat lalu tulis kode entri itu PERSIS di baris terakhir jawaban (maksimal 2 kode); fotonya dikirim otomatis setelah teks. "
        . "Jangan mengarang kode, jangan menulis kode bila pelanggan tidak meminta melihat foto, dan jangan menjelaskan kode itu kepada pelanggan. "
        . "Jika foto yang diminta tidak ada di Knowledge Base, katakan fotonya belum tersedia.";
}
/* Buang kode foto dari jawaban AI. Hasil: [teks bersih, daftar id entri]. */
function deiKbFotoExtract($answer) {
    $ids = [];
    $answer = preg_replace_callback('/\[{1,2}\s*FOTO\s*:\s*([A-Za-z0-9_\-]+)\s*\]{1,2}/i', function ($m) use (&$ids) { $ids[] = $m[1]; return ''; }, (string)$answer);
    $answer = preg_replace("/[ \t]+\n/", "\n", $answer);
    $answer = trim(preg_replace("/\n{3,}/", "\n\n", $answer));
    return [$answer, array_values(array_unique($ids))];
}
/* Kirim foto entri KB (maks 2 entri, 8 foto). Hasil: [meta media salinan untuk log, judul entri terkirim, id terkirim]. */
function deiKbFotoSend($wa, $to, $ids) {
    if (!$ids) return [[], [], []];
    $byId = [];
    foreach ((array)readJson(KB_FILE, []) as $e) { if (!empty($e['id'])) $byId[(string)$e['id']] = $e; }
    $num = preg_replace('/\D/', '', (string)$to);
    $sent = []; $titles = []; $okIds = []; $n = 0;
    foreach (array_slice($ids, 0, 2) as $id) {
        $e = $byId[$id] ?? null;
        if (!$e) { error_log('kb-foto: kode tidak dikenal ' . $id); continue; }
        $imgs = deiKbFotoClean($e['images'] ?? []);
        if (!$imgs) continue;
        $kirim = 0;
        foreach ($imgs as $im) {
            if ($n >= 8) break 2;
            $p = KB_MEDIA_DIR . '/' . $im['file'];
            if (!waSendImage($wa, $to, $p)) { error_log('kb-foto: gagal kirim ' . $im['file'] . ' — ' . ($GLOBALS['wa_last_error'] ?? '')); continue; }
            $n++; $kirim++;
            $meta = ['type' => 'image', 'kb' => (string)$id];   // salinan untuk thread dashboard (ikut masa simpan media)
            $dir = WA_MEDIA_DIR . '/' . $num;
            if (!is_dir($dir)) @mkdir($dir, 0755, true);
            $fn = substr(sha1($im['file'] . '|' . microtime(true) . '|' . mt_rand()), 0, 20) . '.' . pathinfo($p, PATHINFO_EXTENSION);
            if ($num !== '' && @copy($p, $dir . '/' . $fn)) { $meta['file'] = $num . '/' . $fn; $meta['size'] = (int)filesize($p); }
            else $meta['error'] = 'unavailable';
            $sent[] = $meta;
        }
        if ($kirim) { $titles[] = trim((string)($e['title'] ?? '')); $okIds[] = (string)$id; }
    }
    return [$sent, $titles, $okIds];
}
function waSendImage($wa, $to, $path, $caption = '') {
    $wa = waChanFor($wa, $to); $GLOBALS['wa_out_ch'] = (string)($wa['_ch'] ?? '');   // v1.2.98: multi-nomor
    $GLOBALS['wa_last_error'] = '';
    if (!is_file($path)) { $GLOBALS['wa_last_error'] = 'File foto tidak ada.'; return false; }
    $mime = (strtolower(pathinfo($path, PATHINFO_EXTENSION)) === 'png') ? 'image/png' : 'image/jpeg';
    $prov = (string)($wa['provider'] ?? 'meta');
    if ($prov === 'waha') {
        $to = waNormNum($to);
        list($c, $d) = wahaApi($wa, 'POST', '/api/sendImage', ['session' => wahaSession($wa), 'chatId' => $to . '@c.us',
            'file' => ['mimetype' => $mime, 'filename' => basename($path), 'data' => base64_encode((string)file_get_contents($path))],
            'caption' => (string)$caption]);
        if ($c >= 200 && $c < 300) { $id = is_array($d) ? wahaMsgId($d) : ''; if ($id !== '') wahaRememberSent($to, $id, ''); whOut($wa, $to, (string)($GLOBALS['dei_out_src'] ?? 'bot'), true, $id, ''); return true; }   // v1.2.104
        whOut($wa, $to, (string)($GLOBALS['dei_out_src'] ?? 'bot'), false);
        $GLOBALS['wa_last_error'] = wahaErr($c, $d, 'Kirim foto lewat WAHA gagal.');
        return false;
    }
    if ($prov !== 'meta') { $GLOBALS['wa_last_error'] = 'Penyedia ini tidak mendukung kirim foto.'; return false; }
    $token = (string)($wa['access_token'] ?? ''); $pnid = (string)($wa['phone_number_id'] ?? '');
    if ($token === '' || $pnid === '') { $GLOBALS['wa_last_error'] = 'Access Token / Phone Number ID kosong.'; return false; }
    $mid = deiMetaMediaId($wa, $path, $mime);
    if ($mid === '') return false;
    $img = ['id' => $mid]; if ((string)$caption !== '') $img['caption'] = (string)$caption;
    $payload = ['messaging_product' => 'whatsapp', 'recipient_type' => 'individual', 'to' => $to, 'type' => 'image', 'image' => $img];
    $ch = curl_init('https://graph.facebook.com/v21.0/' . rawurlencode($pnid) . '/messages');
    curl_setopt_array($ch, [CURLOPT_RETURNTRANSFER => true, CURLOPT_POST => true, CURLOPT_TIMEOUT => 20,
        CURLOPT_HTTPHEADER => ['Content-Type: application/json', 'Authorization: Bearer ' . $token],
        CURLOPT_POSTFIELDS => json_encode($payload, JSON_UNESCAPED_UNICODE)]);
    $resp = curl_exec($ch); $code = (int)curl_getinfo($ch, CURLINFO_HTTP_CODE); curl_close($ch);
    if ($code >= 200 && $code < 300) { waOutCount('service'); return true; }
    $d = json_decode((string)$resp, true);
    $GLOBALS['wa_last_error'] = (is_array($d) && isset($d['error']['message'])) ? (string)$d['error']['message'] : ('HTTP ' . $code);
    deiMetaMediaIdForget($wa, $path);   // id bisa kedaluwarsa -> unggah ulang lain kali
    return false;
}
/* Foto KB diunggah ke Meta sekali; id disimpan 25 hari (id media Meta berlaku 30 hari). */
function deiMetaMediaKey($wa, $path) { return (string)($wa['phone_number_id'] ?? '') . '|' . basename($path) . '|' . (int)@filemtime($path); }
function deiMetaMediaId($wa, $path, $mime) {
    $cf = KB_MEDIA_DIR . '/.meta-ids.json';
    $k = deiMetaMediaKey($wa, $path);
    $all = readJson($cf, []); if (!is_array($all)) $all = [];
    if (!empty($all[$k]['id']) && time() - (int)($all[$k]['t'] ?? 0) < 25 * 86400) return (string)$all[$k]['id'];
    $ch = curl_init('https://graph.facebook.com/v21.0/' . rawurlencode((string)($wa['phone_number_id'] ?? '')) . '/media');
    curl_setopt_array($ch, [CURLOPT_RETURNTRANSFER => true, CURLOPT_POST => true, CURLOPT_TIMEOUT => 45,
        CURLOPT_HTTPHEADER => ['Authorization: Bearer ' . (string)($wa['access_token'] ?? '')],
        CURLOPT_POSTFIELDS => ['messaging_product' => 'whatsapp', 'type' => $mime, 'file' => new CURLFile($path, $mime, basename($path))]]);
    $resp = curl_exec($ch); $code = (int)curl_getinfo($ch, CURLINFO_HTTP_CODE); curl_close($ch);
    $d = json_decode((string)$resp, true);
    if ($code < 200 || $code >= 300 || !is_array($d) || empty($d['id'])) {
        $GLOBALS['wa_last_error'] = 'Unggah foto ke Meta gagal: ' . ((is_array($d) && isset($d['error']['message'])) ? $d['error']['message'] : ('HTTP ' . $code));
        return '';
    }
    foreach ($all as $kk => $v) { if (time() - (int)($v['t'] ?? 0) > 25 * 86400) unset($all[$kk]); }
    $all[$k] = ['id' => (string)$d['id'], 't' => time()];
    writeJson($cf, $all);
    return (string)$d['id'];
}
function deiMetaMediaIdForget($wa, $path) {
    $cf = KB_MEDIA_DIR . '/.meta-ids.json';
    $all = readJson($cf, []); if (!is_array($all)) return;
    $k = deiMetaMediaKey($wa, $path);
    if (isset($all[$k])) { unset($all[$k]); writeJson($cf, $all); }
}

function buildMessages($message, $history) {
    $messages = [];
    foreach (array_slice($history, -8) as $h) {
        $role = ($h['role'] ?? '') === 'assistant' ? 'assistant' : 'user';
        $content = trim($h['content'] ?? '');
        if ($content === '') continue;
        // v1.2.102: closing-sekali — riwayat tidak boleh diawali assistant & peran berurutan digabung
        // (closing otomatis / balasan dari HP menambah assistant ekstra -> urutan pecah -> AI error)
        if (!$messages && $role === 'assistant') continue;
        $n = count($messages);
        if ($n && $messages[$n - 1]['role'] === $role) { $messages[$n - 1]['content'] .= "\n\n" . $content; continue; }
        $messages[] = ['role' => $role, 'content' => $content];
    }
    $n = count($messages);
    if ($n && $messages[$n - 1]['role'] === 'user') $messages[$n - 1]['content'] .= "\n\n" . $message;
    else $messages[] = ['role' => 'user', 'content' => $message];
    return $messages;
}

/* ----------------------------------------------------------------------------
 *  WhatsApp Cloud API helpers
 * ------------------------------------------------------------------------- */
function waConf($s) {
    return is_array($s['whatsapp_api'] ?? null) ? $s['whatsapp_api'] : [];
}

/* v1.2.98: multi-nomor — beberapa nomor WhatsApp dalam satu tenant.
 * settings.wa_numbers = [{id, label, phone_number_id, display_number, verified_name, access_token, waba_id,
 *                         waha_session, waha_url, waha_api_key, waha_number, created_at}]
 * Nomor utama = whatsapp_api (id 'utama'). Nomor tambahan memakai penyedia yang sama (Meta / WAHA);
 * kolom kosong (token, WABA, URL & API key WAHA) mewarisi nomor utama.
 * Percakapan tetap per nomor pelanggan. Kontak menyimpan wa_ch = nomor bisnis terakhir yang dipakai
 * pelanggan; semua kiriman ke pelanggan itu keluar dari nomor yang sama (waChanFor). */
if (!defined('WA_NUMBERS_MAX')) define('WA_NUMBERS_MAX', 20);   // v1.2.99: lisensi-nomor (batas teknis; batas paket dari pusat)
if (!defined('DEI_DEFAULT_MAX_WA_NUMBERS')) define('DEI_DEFAULT_MAX_WA_NUMBERS', 0);
// v1.2.99: lisensi-nomor — jumlah nomor tambahan yang diizinkan paket (fitur pusat max_wa_numbers).
function waNumbersLimit() {
    $f = [];
    try { $f = deiFeatures(); } catch (\Throwable $e) { error_log('waNumbersLimit: ' . $e->getMessage()); }
    return max(0, min(WA_NUMBERS_MAX, (int)($f['max_wa_numbers'] ?? DEI_DEFAULT_MAX_WA_NUMBERS)));
}
// $all = false: hanya nomor yang masuk paket (urutan penambahan; yang terakhir terkunci lebih dulu).
function waNumbersRaw($s = null, $all = false) {
    if ($s === null) $s = getSettings();
    $l = $s['wa_numbers'] ?? [];
    if (!is_array($l)) return [];
    $out = [];
    foreach ($l as $x) { if (is_array($x) && !empty($x['id'])) $out[] = $x; }
    if (!$all && $out) $out = array_slice($out, 0, waNumbersLimit());
    return $out;
}
function waMultiProv($wa) { return in_array((string)($wa['provider'] ?? 'meta'), ['meta', 'waha'], true); }
function waMultiOn($wa, $s = null) { return waMultiProv($wa) && count(waNumbersRaw($s)) > 0; }
function waChanNumOf($x, $prov) {
    return waNormNum($prov === 'waha' ? ($x['waha_number'] ?? '') : ($x['display_number'] ?? ''));
}
function waChanLabelOf($x, $prov, $fallback) {
    $l = trim((string)($x['label'] ?? ''));
    if ($l !== '') return $l;
    $n = waChanNumOf($x, $prov);
    return $n !== '' ? '+' . $n : $fallback;
}
// Daftar nomor (utama dulu) untuk label di dashboard. Tanpa rahasia.
function waChannels($s = null) {
    if ($s === null) $s = getSettings();
    $wa = waConf($s); $prov = (string)($wa['provider'] ?? 'meta');
    $out = [['id' => 'utama', 'label' => waChanLabelOf($wa, $prov, 'Nomor utama'), 'number' => waChanNumOf($wa, $prov), 'primary' => true]];
    if (!waMultiProv($wa)) return $out;
    $i = 1;
    foreach (waNumbersRaw($s) as $x) {
        $i++;
        $out[] = ['id' => (string)$x['id'], 'label' => waChanLabelOf($x, $prov, 'Nomor ' . $i), 'number' => waChanNumOf($x, $prov), 'primary' => false];
    }
    return $out;
}
// Konfigurasi kirim untuk satu nomor. $wa = whatsapp_api (nomor utama). Id tak dikenal -> nomor utama.
function waChanConf($wa, $id, $s = null) {
    $id = (string)$id;
    if ($id !== '' && $id !== 'utama' && waMultiProv($wa)) {
        $prov = (string)($wa['provider'] ?? 'meta');
        foreach (waNumbersRaw($s) as $x) {
            if ((string)$x['id'] !== $id) continue;
            $c = $wa;
            if ($prov === 'waha') {
                $c['waha_session'] = (string)($x['waha_session'] ?? '');
                if (trim((string)($x['waha_url'] ?? '')) !== '') $c['waha_url'] = (string)$x['waha_url'];
                if ((string)($x['waha_api_key'] ?? '') !== '') $c['waha_api_key'] = (string)$x['waha_api_key'];
                $c['waha_number'] = (string)($x['waha_number'] ?? '');
            } else {
                $c['phone_number_id'] = (string)($x['phone_number_id'] ?? '');
                $c['display_number'] = (string)($x['display_number'] ?? '');
                if ((string)($x['access_token'] ?? '') !== '') $c['access_token'] = (string)$x['access_token'];
                if ((string)($x['waba_id'] ?? '') !== '') $c['waba_id'] = (string)$x['waba_id'];
            }
            $c['_ch'] = $id;
            return $c;
        }
    }
    $wa['_ch'] = 'utama';
    return $wa;
}
// Nomor pengirim untuk pelanggan $to: yang sudah ditetapkan (_ch) dipakai apa adanya,
// selain itu nomor bisnis terakhir yang dipakai pelanggan (kontak.wa_ch).
function waChanFor($wa, $to) {
    if (!empty($wa['_ch']) || !waMultiOn($wa)) return $wa;
    $c = null;
    try { $c = waContactGet($to); } catch (\Throwable $e) { error_log('waChanFor: ' . $e->getMessage()); }
    return waChanConf($wa, (string)(is_array($c) ? ($c['wa_ch'] ?? '') : ''));
}
// Nomor penerima kiriman webhook (value.metadata). Tanpa nomor tambahan: $wa apa adanya (perilaku lama).
// v1.2.99: lisensi-nomor — null = nomor tambahan di luar paket (pesan diabaikan, tidak dibalas dari nomor lain).
function waChanFromMeta($wa, $meta) {
    $meta = is_array($meta) ? $meta : [];
    $pid = (string)($meta['phone_number_id'] ?? '');
    if ($pid !== '' && ($wa['provider'] ?? 'meta') === 'meta' && $pid !== (string)($wa['phone_number_id'] ?? '')) {
        $act = [];
        foreach (waNumbersRaw() as $x) $act[(string)$x['id']] = true;
        foreach (waNumbersRaw(null, true) as $x) {
            if ((string)($x['phone_number_id'] ?? '') !== $pid) continue;
            return isset($act[(string)$x['id']]) ? waChanConf($wa, (string)$x['id']) : null;
        }
    }
    if (!waMultiOn($wa)) return $wa;
    if (!empty($meta['_dei_ch'])) return waChanConf($wa, (string)$meta['_dei_ch']);
    return waChanConf($wa, 'utama');
}
// WAHA: cari nomor dari nama sesi event. null = sesi bukan milik tenant ini.
function waWahaChanBySession($wa, $sess) {
    $sess = (string)$sess;
    if ($sess === wahaSession($wa)) return waMultiOn($wa) ? waChanConf($wa, 'utama') : $wa;
    if (($wa['provider'] ?? 'meta') !== 'waha') return null;
    foreach (waNumbersRaw() as $x) {
        $c = waChanConf($wa, (string)$x['id']);
        if (trim((string)($x['waha_session'] ?? '')) !== '' && wahaSession($c) === $sess) return $c;
    }
    return null;
}
// v1.2.116: pindah-nomor — nomor bisnis aktif sebuah chat ('' = akun satu nomor).
function waCurCh($num, $s = null) {
    if ($s === null) $s = getSettings();
    if (!waMultiOn(waConf($s), $s)) return '';
    $c = null;
    try { $c = waContactGet(waNormNum($num)); } catch (\Throwable $e) { error_log('waCurCh: ' . $e->getMessage()); }
    $ch = (string)(is_array($c) ? ($c['wa_ch'] ?? '') : '');
    foreach (waChannels($s) as $x) { if ($x['id'] === $ch) return $ch; }
    return 'utama';
}
// Meta: jendela 24 jam milik pasangan (pelanggan, nomor bisnis). '' = semua pesan masuk dihitung.
function waWinCh($num, $s = null) {
    if ($s === null) $s = getSettings();
    if ((string)(waConf($s)['provider'] ?? 'meta') !== 'meta') return '';
    return waCurCh($num, $s);
}
function waInboundOnCh($e, $ch) {
    if ($ch === '') return true;
    $x = (string)($e['wa_ch'] ?? '');
    return ($x === '' ? 'utama' : $x) === $ch;
}
function waContactSetCh($num, $ch) {
    $num = waNormNum($num); $ch = (string)$ch;
    if ($num === '' || $ch === '') return;
    try {
        $c = waContactGet($num);
        if (is_array($c) && (string)($c['wa_ch'] ?? '') === $ch) return;
        waContactUpdate($num, function (&$r) use ($ch) { $r['wa_ch'] = $ch; });
    } catch (\Throwable $e) { error_log('waContactSetCh: ' . $e->getMessage()); }
}
// Nomor WAHA yang terbaca dari sesi -> simpan ke nomor yang sesuai.
function waChanSetWahaNumber($wa, $dev) {
    $s2 = getSettings();
    $id = (string)($wa['_ch'] ?? '');
    if ($id === '' || $id === 'utama') {
        $s2['whatsapp_api']['waha_number'] = $dev;
    } else {
        $l = is_array($s2['wa_numbers'] ?? null) ? $s2['wa_numbers'] : [];
        foreach ($l as $i => $x) { if (is_array($x) && (string)($x['id'] ?? '') === $id) $l[$i]['waha_number'] = $dev; }
        $s2['wa_numbers'] = $l;
    }
    writeJson(SETTINGS_FILE, $s2);
}
// Info nomor Meta (display_phone_number, verified_name). [ok, data|pesan]
function waMetaPhoneInfo($token, $pnid) {
    if ($token === '' || $pnid === '') return [false, 'Token / Phone Number ID kosong.'];
    list($c, $j, , $e) = deiHttpGetCapped('https://graph.facebook.com/v21.0/' . rawurlencode($pnid) . '?fields=display_phone_number,verified_name',
        ['Authorization: Bearer ' . $token], 65536);
    $d = json_decode((string)$j, true);
    if ($c >= 200 && $c < 300 && is_array($d)) return [true, $d];
    return [false, 'Meta menolak Phone Number ID ini (' . ($e !== '' ? $e : 'HTTP ' . $c) . ') — cek ID & izin token.'];
}

// v1.2.36: batas 24 jam adalah aturan Meta, bukan WhatsApp secara umum.
// Untuk penyedia lain jendela selalu terbuka. Hasilnya disimpan sementara
// karena dipakai berulang di dalam perulangan daftar percakapan.
function waWindowSelaluTerbuka() {
    static $cache = null;
    if ($cache === null) {
        $wa = waConf(getSettings());
        $cache = (($wa['provider'] ?? 'meta') !== 'meta');
    }
    return $cache;
}

// Validate Meta's X-Hub-Signature-256 (skipped only if app_secret not set).
function waVerifySignature($rawBody, $appSecret) {
    if ($appSecret === '' || $appSecret === null) return true;
    $hdr = $_SERVER['HTTP_X_HUB_SIGNATURE_256'] ?? '';
    if (strpos($hdr, 'sha256=') !== 0) return false;
    $expected = 'sha256=' . hash_hmac('sha256', $rawBody, $appSecret);
    return hash_equals($expected, $hdr);
}

// Send a plain-text WhatsApp message via the Cloud API. Returns true on 2xx.
// v1.2.36: kirim lewat Fonnte (gateway tidak resmi, memakai nomor yang sudah ada).
// Fonnte membalas HTTP 200 walau gagal, jadi status di badan balasan ikut diperiksa.
function waSendFonnte($wa, $to, $text) {
    $token = $wa['fonnte_token'] ?? '';
    if ($token === '') return false;
    $ch = curl_init('https://api.fonnte.com/send');
    curl_setopt_array($ch, [
        CURLOPT_RETURNTRANSFER => true,
        CURLOPT_POST           => true,
        CURLOPT_TIMEOUT        => 20,
        CURLOPT_HTTPHEADER     => ['Authorization: ' . $token],
        CURLOPT_POSTFIELDS     => http_build_query([
            'target'      => $to,
            'message'     => $text,
            'countryCode' => '62',
        ]),
    ]);
    $resp = curl_exec($ch);
    $code = curl_getinfo($ch, CURLINFO_HTTP_CODE);
    curl_close($ch);
    if ($code < 200 || $code >= 300) {
        error_log('waSendFonnte HTTP ' . $code);
        return false;
    }
    $d = json_decode((string)$resp, true);
    if (is_array($d) && array_key_exists('status', $d) && $d['status'] === false) {
        error_log('waSendFonnte ditolak: ' . mb_substr((string)$resp, 0, 200));
        return false;
    }
    return true;
}

// v1.2.75: koneksi perangkat Fonnte — panggil API perangkat (qr / device / disconnect / update-device).
// Fonnte membalas HTTP 200 walau gagal; status ada di badan balasan.
function fonnteApi($token, $path, $fields = []) {
    $ch = curl_init('https://api.fonnte.com/' . $path);
    curl_setopt_array($ch, [
        CURLOPT_RETURNTRANSFER => true,
        CURLOPT_POST           => true,
        CURLOPT_TIMEOUT        => 20,
        CURLOPT_CONNECTTIMEOUT => 8,
        CURLOPT_HTTPHEADER     => ['Authorization: ' . $token],
        CURLOPT_POSTFIELDS     => http_build_query($fields),
    ]);
    $resp = curl_exec($ch);
    $code = curl_getinfo($ch, CURLINFO_HTTP_CODE);
    $err  = curl_error($ch);
    curl_close($ch);
    if ($resp === false || $code < 200 || $code >= 300) {
        error_log('fonnteApi ' . $path . ' HTTP ' . $code . ' ' . $err);
        return ['status' => false, 'reason' => 'Server Fonnte tidak dapat dihubungi (HTTP ' . $code . ').'];
    }
    $d = json_decode((string)$resp, true);
    return is_array($d) ? $d : ['status' => false, 'reason' => 'Balasan Fonnte tidak dikenali.'];
}
function fonnteReason($d, $fallback) {
    $r = trim((string)($d['reason'] ?? ($d['detail'] ?? '')));
    return $r !== '' ? $r : $fallback;
}

/* ============================================================
 * v1.2.76: WAHA — gateway WhatsApp Web sendiri (Docker di VPS)
 * ============================================================
 * Berbeda dengan Fonnte, WAHA meneruskan pesan yang diketik dari HP
 * (event message.any, fromMe=true) sehingga balasan CS dari HP ikut
 * tercatat di dashboard dan bot otomatis mundur — sama seperti echo
 * Coexistence Meta. Kiriman WAHA diterjemahkan ke bentuk payload Meta
 * supaya seluruh alur yang sudah teruji (antrean, debounce, anti-dobel,
 * mode manusia) dipakai ulang tanpa disalin. */
function wahaSession($wa) {
    $n = preg_replace('/[^A-Za-z0-9_-]/', '', (string)($wa['waha_session'] ?? ''));
    return $n !== '' ? $n : 'default';
}
function wahaApi($wa, $method, $path, $body = null) {
    $base = rtrim(trim((string)($wa['waha_url'] ?? '')), '/');
    if ($base === '') return [0, ['message' => 'URL WAHA belum diisi.']];
    $ch = curl_init($base . $path);
    $hdr = ['Accept: application/json', 'X-Api-Key: ' . (string)($wa['waha_api_key'] ?? '')];
    $opt = [CURLOPT_RETURNTRANSFER => true, CURLOPT_TIMEOUT => 20, CURLOPT_CONNECTTIMEOUT => 8, CURLOPT_CUSTOMREQUEST => $method];
    if ($body !== null) {
        $hdr[] = 'Content-Type: application/json';
        $opt[CURLOPT_POSTFIELDS] = json_encode($body, JSON_UNESCAPED_UNICODE | JSON_UNESCAPED_SLASHES);
    }
    $opt[CURLOPT_HTTPHEADER] = $hdr;
    curl_setopt_array($ch, $opt);
    $resp = curl_exec($ch);
    $code = (int)curl_getinfo($ch, CURLINFO_HTTP_CODE);
    $err  = curl_error($ch);
    curl_close($ch);
    if ($resp === false) return [0, ['message' => 'Server WAHA tidak dapat dihubungi: ' . $err]];
    $d = json_decode((string)$resp, true);
    return [$code, is_array($d) ? $d : ['message' => mb_substr(trim((string)$resp), 0, 200)]];
}
function wahaErr($code, $d, $fallback = 'Permintaan ke WAHA gagal.') {
    $m = '';
    if (is_array($d)) {
        $m = $d['message'] ?? ($d['error'] ?? '');
        if (is_array($m)) $m = implode('; ', array_map(function ($x) { return is_scalar($x) ? (string)$x : json_encode($x); }, $m));
    }
    $m = trim((string)$m);
    if ($code === 401) $m = 'API Key WAHA ditolak (401).';
    return $m !== '' ? $m : ($fallback . ($code ? ' (HTTP ' . $code . ')' : ''));
}
function wahaWebhookUrl($wa) {
    $base = deiSelfApiUrl();
    if ($base === '') $base = deiRememberedApiUrl();
    return $base . '?action=wa_webhook_waha&key=' . rawurlencode((string)($wa['waha_webhook_key'] ?? ''));
}
function wahaSessionConfig($wa) {
    return [
        'webhooks' => [[
            'url'     => wahaWebhookUrl($wa),
            'events'  => ['message.any', 'session.status', 'message.ack', 'call.received'],   // v1.2.104: skor-risiko-wa (centang); v1.2.108: tolak-telepon
            'hmac'    => ['key' => (string)($wa['waha_webhook_key'] ?? '')],
            'retries' => ['policy' => 'exponential', 'delaySeconds' => 2, 'attempts' => 5],
        ]],
        // NOWEB butuh store aktif supaya pemetaan @lid -> nomor tersedia.
        'noweb' => ['store' => ['enabled' => true, 'fullSync' => false]],
    ];
}
// Pastikan sesi ada & berjalan. Hasil: [ok, data sesi | pesan error].
function wahaEnsureSession($wa) {
    $n = wahaSession($wa);
    list($c, $d) = wahaApi($wa, 'GET', '/api/sessions/' . rawurlencode($n));
    if ($c === 404) {
        list($c, $d) = wahaApi($wa, 'POST', '/api/sessions', ['name' => $n, 'start' => true, 'config' => wahaSessionConfig($wa)]);
        if ($c < 200 || $c >= 300) return [false, wahaErr($c, $d, 'Gagal membuat sesi WAHA.')];
        if (empty($d['status'])) $d['status'] = 'STARTING';
        whMark($wa, 'cfg_at');   // v1.2.104: config sudah berlangganan message.ack
        return [true, $d];
    }
    if ($c < 200 || $c >= 300) return [false, wahaErr($c, $d)];
    $st = (string)($d['status'] ?? '');
    if ($st === 'STOPPED') { wahaApi($wa, 'POST', '/api/sessions/' . rawurlencode($n) . '/start'); $d['status'] = 'STARTING'; }
    elseif ($st === 'FAILED') {
        // v1.2.77: restart sekali. FAILED lagi dalam 2 menit = login tersimpan rusak/ditolak WhatsApp
        // -> logout (hapus login) lalu start, supaya QR baru muncul (dulu restart tiap 3 dtk tanpa henti).
        $f = DATA_DIR . '/waha-failed.json';
        $last = (int)(readJson($f, [])[$n] ?? 0);
        if ($last > 0 && time() - $last < 120) {
            wahaApi($wa, 'POST', '/api/sessions/' . rawurlencode($n) . '/logout');
            wahaApi($wa, 'POST', '/api/sessions/' . rawurlencode($n) . '/start');
            writeJson($f, [$n => 0]);
            error_log('waha: sesi ' . $n . ' gagal berulang -> logout + start (QR baru)');
        } else {
            wahaApi($wa, 'POST', '/api/sessions/' . rawurlencode($n) . '/restart');
            writeJson($f, [$n => time()]);
        }
        $d['status'] = 'STARTING';
    }
    return [true, $d];
}
function wahaJidNum($jid) {
    $jid = strtolower(trim((string)$jid));
    if (preg_match('/^(\d{6,20})(?::\d+)?@(c\.us|s\.whatsapp\.net)$/', $jid, $m)) return $m[1];
    return '';
}
// Nomor lawan bicara. @lid (pengenal privasi WA) dipetakan ke nomor HP:
// medan alternatif dari engine dulu, lalu API /lids WAHA (hasil disimpan).
function wahaResolveNum($wa, $jid, $p) {
    $num = wahaJidNum($jid);
    if ($num !== '') return $num;
    $jid = strtolower(trim((string)$jid));
    if (substr($jid, -4) !== '@lid') return '';
    $k = (is_array($p['_data']['key'] ?? null)) ? $p['_data']['key'] : [];
    $lid = preg_replace('/\D/', '', substr($jid, 0, -4));
    $f = DATA_DIR . '/waha-lids.json';
    foreach (['remoteJidAlt', 'senderPn', 'participantPn', 'remoteJidPn'] as $kf) {   // v1.2.102: hp-lid (+ simpan peta)
        $alt = wahaJidNum($k[$kf] ?? '');
        if ($alt === '') $alt = wahaJidNum($p['_data'][$kf] ?? '');
        if ($alt !== '') {
            if ($lid !== '') { try { deiWithLock('waha-lids', function () use ($f, $lid, $alt) {
                $all = readJson($f, []); if (!is_array($all)) $all = [];
                if (($all[$lid] ?? '') !== $alt) { $all[$lid] = $alt; if (count($all) > 5000) $all = array_slice($all, -5000, null, true); writeJson($f, $all); }
            }); } catch (\Throwable $e) {} }
            return $alt;
        }
    }
    if ($lid === '') return '';
    $cache = readJson($f, []);
    if (!empty($cache[$lid])) return (string)$cache[$lid];
    list($c, $d) = wahaApi($wa, 'GET', '/api/' . rawurlencode(wahaSession($wa)) . '/lids/' . rawurlencode($lid));
    $pn = ($c >= 200 && $c < 300 && is_array($d)) ? wahaJidNum($d['pn'] ?? '') : '';
    if ($pn !== '') {
        deiWithLock('waha-lids', function () use ($f, $lid, $pn) {
            $all = readJson($f, []);
            if (!is_array($all)) $all = [];
            $all[$lid] = $pn;
            if (count($all) > 5000) $all = array_slice($all, -5000, null, true);
            writeJson($f, $all);
        });
    }
    return $pn;
}
// Jejak pesan yang DIKIRIM sistem ini (bot / dashboard), supaya pantulannya
// (fromMe) tidak dianggap balasan CS dari HP. Dicatat SEBELUM kirim karena
// webhook pantulan bisa tiba sebelum respons sendText kembali.
function wahaSentFile() { return DATA_DIR . '/waha-sent.json'; }
function wahaRememberSent($num, $id, $text) {
    deiWithLock('waha-sent', function () use ($num, $id, $text) {
        $now = time();
        $all = readJson(wahaSentFile(), []);
        if (!is_array($all)) $all = [];
        $all = array_values(array_filter($all, function ($r) use ($now) { return ($r['t'] ?? 0) > $now - 900; }));
        $all[] = ['t' => $now, 'id' => (string)$id, 'h' => $text !== '' ? md5(waNormNum($num) . '|' . trim((string)$text)) : ''];
        if (count($all) > 500) $all = array_slice($all, -500);
        writeJson(wahaSentFile(), $all);
    });
}
function wahaSentByUs($num, $id, $text) {
    $all = readJson(wahaSentFile(), []);
    if (!is_array($all)) return false;
    $h = md5(waNormNum($num) . '|' . trim((string)$text));
    $now = time();
    foreach ($all as $r) {
        if (($r['t'] ?? 0) <= $now - 900) continue;
        if ($id !== '' && ($r['id'] ?? '') === $id) return true;
        if (($r['h'] ?? '') === $h) return true;
    }
    return false;
}
function wahaMsgId($p) {
    $id = $p['id'] ?? '';
    if (is_array($id)) $id = $id['_serialized'] ?? ($id['id'] ?? '');
    return (string)$id;
}
// Terjemahkan event WAHA (message / message.any) ke payload bentuk Meta.
// null = abaikan (grup, status, chat ke diri sendiri, pantulan kiriman sendiri).
// v1.2.77: kandidat JID chat lawan bicara, urut dari yang paling bisa dipercaya.
function wahaChatCandidates($p, $fromMe) {
    $d = is_array($p['_data'] ?? null) ? $p['_data'] : [];
    $c = [
        (string)($d['key']['remoteJid'] ?? ''),          // NOWEB
        (string)($d['Info']['Chat'] ?? ''),              // GOWS
        (string)($d['id']['remote'] ?? ''),              // WEBJS
    ];
    if ($fromMe) { $c[] = (string)($p['to'] ?? ''); $c[] = (string)($p['from'] ?? ''); }
    else         { $c[] = (string)($p['from'] ?? ''); $c[] = (string)($p['to'] ?? ''); }
    $out = [];
    foreach ($c as $j) { $j = trim($j); if ($j !== '' && strpos($j, '@') !== false && !in_array($j, $out, true)) $out[] = $j; }
    return $out;
}
function wahaToMetaPayload($wa, $evt) {
    $p = is_array($evt['payload'] ?? null) ? $evt['payload'] : [];
    $id = wahaMsgId($p);
    $fromMe = !empty($p['fromMe']);
    // v1.2.77: lawan bicara = chat-nya (remoteJid), bukan selalu `to` — NOWEB mengisi `from`
    // dengan chat lawan bicara juga untuk pesan fromMe. Nomor sendiri dilewati.
    $me = wahaJidNum(preg_replace('/:\d+@/', '@', (string)($evt['me']['id'] ?? '')));
    $meLid = strtolower((string)($evt['me']['lid'] ?? ''));
    $num = ''; $chat = '';
    foreach (wahaChatCandidates($p, $fromMe) as $cj) {
        if (preg_match('/@(g\.us|newsletter|broadcast)$/i', $cj)) return null;
        if ($meLid !== '' && strtolower(preg_replace('/:\d+@/', '@', $cj)) === $meLid) continue;
        $n = wahaResolveNum($wa, $cj, $p);
        if ($n === '' || ($me !== '' && $n === $me)) { if ($chat === '') $chat = $cj; continue; }
        $num = $n; $chat = $cj; break;
    }
    if ($num === '') {
        if ($chat !== '') error_log('waha: lawan bicara tidak terbaca (' . $chat . ')');
        // v1.2.102: hp-lid — jejak pesan yang terbuang (diagnosa balasan HP yang tidak muncul)
        try { $df = DATA_DIR . '/waha-dropped.json'; $dl = readJson($df, []); if (!is_array($dl)) $dl = [];
            $dl[] = ['t' => date('Y-m-d H:i:s'), 'fromMe' => $fromMe ? 1 : 0, 'chat' => $chat, 'from' => (string)($p['from'] ?? ''), 'to' => (string)($p['to'] ?? ''), 'body' => mb_substr((string)($p['body'] ?? ''), 0, 60)];
            writeJson($df, array_slice($dl, -200)); } catch (\Throwable $e) {}
        return null;
    }

    $body = trim((string)($p['body'] ?? ''));
    $type = 'text';
    if (!empty($p['hasMedia'])) {
        $mt = strtolower((string)($p['media']['mimetype'] ?? ''));
        $type = strpos($mt, 'image/') === 0 ? 'image' : (strpos($mt, 'video/') === 0 ? 'video'
              : (strpos($mt, 'audio/') === 0 ? 'audio' : ($mt !== '' ? 'document' : 'media')));
    } elseif ($body === '') {
        $type = 'unsupported';
    }

    if ($fromMe) {
        if (($p['source'] ?? '') === 'api' || wahaSentByUs($num, $id, $body)) return null;
        whOut($wa, $num, 'hp', true, $id, $body);   // v1.2.104: skor-risiko-wa — diketik dari HP
        if (in_array($type, deiWaMediaTypes(), true)) {   // v1.2.94: wa-media
            return ['entry' => [['changes' => [['value' => [
                'message_echoes' => [['id' => $id, 'to' => $num, 'type' => $type, $type => wahaMediaObj($p, $body)]],
            ]]]]]];
        }
        $etext = ($type === 'text') ? $body : ($body !== '' ? $body . "\n" . deiNonTextLabel($type) : deiNonTextLabel($type));
        return ['entry' => [['changes' => [['value' => [
            'message_echoes' => [['id' => $id, 'to' => $num, 'type' => 'text', 'text' => ['body' => $etext]]],
        ]]]]]];
    }

    whIn($wa, $num);   // v1.2.104: skor-risiko-wa
    $msg = ['from' => $num, 'id' => $id, 'type' => $type];
    if ($type === 'text') $msg['text'] = ['body' => $body];
    elseif (in_array($type, deiWaMediaTypes(), true)) $msg[$type] = wahaMediaObj($p, $body);   // v1.2.94: wa-media
    $nama = '';
    $dd = is_array($p['_data'] ?? null) ? $p['_data'] : [];
    foreach ([$dd['notifyName'] ?? '', $dd['pushName'] ?? '', $dd['Info']['PushName'] ?? '', $p['notifyName'] ?? ''] as $cand) {
        if (is_string($cand) && trim($cand) !== '') { $nama = trim($cand); break; }
    }
    $val = ['messages' => [$msg]];
    if ($nama !== '') $val['contacts'] = [['wa_id' => $num, 'profile' => ['name' => $nama]]];
    return ['entry' => [['changes' => [['value' => $val]]]]];
}
/* v1.2.94: wa-media: objek media WAHA dalam bentuk Meta (url diunduh lewat deiWaMediaFetch) */
function wahaMediaObj($p, $caption) {
    $md = is_array($p['media'] ?? null) ? $p['media'] : [];
    return ['_waha_url' => (string)($md['url'] ?? ''), 'mime_type' => (string)($md['mimetype'] ?? ''),
            'filename' => (string)($md['filename'] ?? ''), 'caption' => (string)$caption];
}
/* v1.2.104: skor-risiko-wa — pemantauan kesehatan nomor WhatsApp (WAHA).
 * WhatsApp tidak memberi skor risiko untuk WhatsApp Web; skor ini HEURISTIK dari perilaku nomor:
 * chat duluan ke nomor baru, balasan atas chat duluan, volume, teks kembar, centang (message.ack),
 * gagal kirim, sesi putus/logout paksa (session.status), umur nomor.
 * Data mentah per nomor: data/wa-health/<ch>.json (ember per jam WIB, simpan 14 hari).
 * Skor: data/wa-health/score.json — dihitung cron_tick tiap 15 menit (atau saat panel dibuka).
 * Ambang & bobot = tebakan awal; setel ulang setelah ada data nomor sungguhan. */
if (!defined('WA_HEALTH_DIR')) define('WA_HEALTH_DIR', DATA_DIR . '/wa-health');
if (!defined('WA_HEALTH_CFG_V')) define('WA_HEALTH_CFG_V', 3);   // 2 = webhook berlangganan message.ack; 3 = + call.received (v1.2.108: tolak-telepon)
function whOn($wa) { return (string)($wa['provider'] ?? 'meta') === 'waha'; }
function whCh($wa) { $c = preg_replace('/[^A-Za-z0-9_]/', '', (string)($wa['_ch'] ?? '')); return $c !== '' ? $c : 'utama'; }
function whFile($ch) { return WA_HEALTH_DIR . '/' . preg_replace('/[^A-Za-z0-9_]/', '', (string)$ch) . '.json'; }
function whBlank() { return ['v' => 1, 'h' => [], 'li' => [], 'init' => [], 'dup' => [], 'm' => [], 'ev' => [], 'mk' => []]; }
function whRead($ch) {
    $d = readJson(whFile($ch), null);
    if (!is_array($d)) return whBlank();
    foreach (whBlank() as $k => $v) { if (!isset($d[$k]) || !is_array($d[$k]) && is_array($v)) $d[$k] = $v; }
    return $d;
}
// $fn(&$d) mengubah data; kembalikan false untuk batal menulis.
function whUpdate($ch, $fn) {
    try {
        if (!is_dir(WA_HEALTH_DIR)) @mkdir(WA_HEALTH_DIR, 0755, true);
        deiWithLock('wa-health-' . $ch, function () use ($ch, $fn) {
            $d = whRead($ch);
            if ($fn($d) === false) return;
            whPrune($d);
            writeJson(whFile($ch), $d);
        });
    } catch (\Throwable $e) { error_log('wa-health: ' . $e->getMessage()); }
}
function whPrune(&$d) {
    $now = time();
    if ((int)($d['pr'] ?? 0) > $now - 600) return;   // rapikan maks 10 menit sekali
    $d['pr'] = $now;
    $hk = gmdate('YmdH', $now + 7 * 3600 - 14 * 86400);
    foreach (array_keys($d['h']) as $k) if ((string)$k < $hk) unset($d['h'][$k]);
    foreach ($d['li'] as $n => $t) if ((int)$t < $now - 7 * 86400) unset($d['li'][$n]);
    foreach ($d['init'] as $n => $r) if ((int)($r[0] ?? 0) < $now - 7 * 86400) unset($d['init'][$n]);
    foreach ($d['dup'] as $k => $r) if ((int)($r['t'] ?? 0) < $now - 86400) unset($d['dup'][$k]);
    foreach ($d['m'] as $k => $r) if ((int)($r[0] ?? 0) < $now - 3 * 86400) unset($d['m'][$k]);
    if (count($d['m']) > 4000) $d['m'] = array_slice($d['m'], -4000, null, true);
    if (count($d['li']) > 20000) { arsort($d['li']); $d['li'] = array_slice($d['li'], 0, 20000, true); }
    $ev = [];
    foreach ($d['ev'] as $e) if ((int)($e[0] ?? 0) >= $now - 7 * 86400) $ev[] = $e;
    $d['ev'] = array_slice($ev, -80);
}
function whInc(&$d, $f, $n = 1) {
    $k = gmdate('YmdH', time() + 7 * 3600);
    if (!isset($d['h'][$k]) || !is_array($d['h'][$k])) $d['h'][$k] = [];
    $d['h'][$k][$f] = (int)($d['h'][$k][$f] ?? 0) + $n;
}
// Id pesan WAHA beda bentuk antar engine/endpoint ("true_628..@c.us_3EB0..", {_serialized}, {id}).
// Inti id (segmen terakhir) dipakai sebagai kunci.
function whMid($id) {
    $id = (string)$id;
    if ($id === '') return '';
    $p = strrpos($id, '_');
    return substr($p === false ? $id : substr($id, $p + 1), 0, 64);
}
function whIn($wa, $num) {
    $num = waNormNum($num);
    if (!whOn($wa) || $num === '') return;
    whUpdate(whCh($wa), function (&$d) use ($num) {
        $now = time();
        whInc($d, 'in');
        $d['li'][$num] = $now;
        if (isset($d['init'][$num]) && empty($d['init'][$num][1]) && $now - (int)$d['init'][$num][0] <= 86400) $d['init'][$num][1] = 1;
    });
}
// $src: bot | agent | hp (diketik dari HP, terbaca dari echo WAHA)
function whOut($wa, $to, $src, $ok, $id = '', $text = '') {
    $to = waNormNum($to);
    if (!whOn($wa) || $to === '') return;
    whUpdate(whCh($wa), function (&$d) use ($to, $src, $ok, $id, $text) {
        $now = time();
        if (!$ok) { whInc($d, 'of'); return; }
        whInc($d, $src === 'hp' ? 'oh' : ($src === 'agent' ? 'oa' : 'ob'));
        $li = (int)($d['li'][$to] ?? 0);
        if ($src === 'bot' && $li > 0 && $now - $li <= 2) whInc($d, 'fa');
        if ($li < $now - 86400) {   // chat duluan: nomor ini tidak mengirim pesan 24 jam terakhir
            whInc($d, 'on');
            if (!isset($d['init'][$to]) || (int)$d['init'][$to][0] < $now - 86400) $d['init'][$to] = [$now, 0];
            $t = trim(preg_replace('/\s+/u', ' ', mb_strtolower((string)$text)));
            if (mb_strlen($t) >= 12) {
                $hk = 'h' . substr(md5($t), 0, 12);
                $r = is_array($d['dup'][$hk] ?? null) ? $d['dup'][$hk] : ['t' => $now, 'n' => []];
                if (!in_array($to, $r['n'], true) && count($r['n']) < 30) $r['n'][] = $to;
                $r['t'] = $now;
                $d['dup'][$hk] = $r;
            }
        }
        $mid = whMid($id);
        if ($mid !== '') $d['m']['m' . $mid] = [$now, 0];
    });
}
function whAck($wa, $p) {
    if (!whOn($wa)) return;
    $mid = whMid(wahaMsgId(is_array($p) ? $p : []));
    if ($mid === '') return;
    $ack = (int)($p['ack'] ?? 0);
    whUpdate(whCh($wa), function (&$d) use ($mid, $ack) {
        $first = empty($d['ack_on']);
        if ($first) $d['ack_on'] = time();   // langganan message.ack terbukti aktif mulai sekarang
        $k = 'm' . $mid;
        if (!isset($d['m'][$k])) return $first ? null : false;
        $cur = (int)$d['m'][$k][1];
        if ($ack < 0) $d['m'][$k][1] = -1;
        elseif ($cur >= 0 && $ack > $cur) $d['m'][$k][1] = min(4, $ack);
        else return $first ? null : false;
    });
}
// Penanda aksi dari dashboard (logout manual, pasang webhook) -> perubahan status sesuai itu bukan sinyal risiko.
function whMark($wa, $key) {
    if (!whOn($wa)) return;
    whUpdate(whCh($wa), function (&$d) use ($key) {
        $d['mk'][$key] = time();
        if ($key === 'cfg_at') $d['cfg_v'] = WA_HEALTH_CFG_V;
    });
}
function whStatus($wa, $evt) {
    if (!whOn($wa)) return;
    $st = strtoupper(trim((string)($evt['payload']['status'] ?? '')));
    if ($st === '') return;
    $meId = (string)($evt['me']['id'] ?? ($evt['payload']['me']['id'] ?? ''));
    $me = $meId !== '' ? wahaJidNum(preg_replace('/:\d+@/', '@', $meId)) : '';
    $known = waNormNum($wa['waha_number'] ?? '');
    $ch = whCh($wa);
    $flagOut = ''; $pairedOut = false;   // v1.2.105
    whUpdate($ch, function (&$d) use ($st, $me, $known, &$flagOut, &$pairedOut) {
        $now = time();
        $prev = (string)($d['st'] ?? '');
        $dirty = false;
        if ($st === 'SCAN_QR_CODE' && $prev !== $st) { $d['qr_at'] = $now; $dirty = true; }
        if ($st === 'WORKING' && $me !== '' && (string)($d['num'] ?? '') !== $me) {
            $last = (string)($d['num'] ?? '');
            if ($last === '' && $known !== '' && $known !== $me) $last = $known;
            // nomor berbeda dari yang terakhir terlihat -> nomor baru dipasang; umur dihitung dari sekarang
            if ($last !== '' && $last !== $me) { $d['paired_at'] = $now; $d['paired_src'] = 'scan'; $d['m'] = []; $d['init'] = []; }
            elseif ($last === '' && $known === '' && (int)($d['qr_at'] ?? 0) > $now - 3600 && empty($d['paired_at'])) { $d['paired_at'] = $now; $d['paired_src'] = 'scan'; }
            $d['num'] = $me; $dirty = true;
        }
        if ($st === 'WORKING' && $prev !== 'WORKING' && (int)($d['qr_at'] ?? 0) > $now - 3600) $pairedOut = true;   // v1.2.105: baru ditautkan
        if ($prev === $st) return $dirty ? null : false;
        $quiet = max((int)($d['mk']['manual_at'] ?? 0), (int)($d['mk']['cfg_at'] ?? 0)) > $now - 180;
        $flag = '';
        if ($prev === 'WORKING' && !$quiet) $flag = $st === 'SCAN_QR_CODE' ? 'logout' : ($st === 'FAILED' ? 'failed' : 'drop');
        $d['ev'][] = [$now, $st, $flag];
        $d['st'] = $st; $d['st_at'] = $now;
        $flagOut = $flag;
    });
    if ($flagOut === 'logout') whAlert($wa, $ch, 'logout', null);
    if ($pairedOut) { try { wsSchedule($wa, 'scan', 'system'); } catch (\Throwable $e) { error_log('wsSchedule: ' . $e->getMessage()); } }   // v1.2.105: riwayat-wa-waha
}

/* ---------- skor ---------- */
function whLevel($score) { return $score >= 60 ? 'bahaya' : ($score >= 30 ? 'waspada' : 'aman'); }
function whScore($ch, $d = null) {
    if ($d === null) $d = whRead($ch);
    $now = time();
    $f = [];
    $add = function ($p, $t) use (&$f) { $f[] = ['p' => (int)$p, 't' => $t]; };
    $keys = ['in', 'ob', 'oa', 'oh', 'on', 'of', 'fa'];
    $a = array_fill_keys($keys, 0); $peak = 0; $firstH = '';
    $h24 = gmdate('YmdH', $now + 7 * 3600 - 23 * 3600);
    $days = [];
    for ($i = 6; $i >= 0; $i--) $days[gmdate('Y-m-d', $now + 7 * 3600 - $i * 86400)] = ['in' => 0, 'out' => 0, 'new' => 0];
    foreach ($d['h'] as $k => $b) {
        $k = (string)$k;
        if (!is_array($b)) continue;
        if ($firstH === '' || $k < $firstH) $firstH = $k;
        $o = (int)($b['ob'] ?? 0) + (int)($b['oa'] ?? 0) + (int)($b['oh'] ?? 0);
        $dk = substr($k, 0, 4) . '-' . substr($k, 4, 2) . '-' . substr($k, 6, 2);
        if (isset($days[$dk])) { $days[$dk]['in'] += (int)($b['in'] ?? 0); $days[$dk]['out'] += $o; $days[$dk]['new'] += (int)($b['on'] ?? 0); }
        if ($k < $h24) continue;
        foreach ($keys as $x) $a[$x] += (int)($b[$x] ?? 0);
        if ($o > $peak) $peak = $o;
    }
    $out = $a['ob'] + $a['oa'] + $a['oh'];

    // 1. umur nomor
    $since = (int)($d['paired_at'] ?? 0);
    $age = $since > 0 ? (int)floor(($now - $since) / 86400) : null;
    if ($age !== null) {
        if ($age < 7) $add($out >= 50 ? 20 : 8, 'Nomor baru (' . $age . ' hari)' . ($out >= 50 ? ' sudah mengirim ' . $out . ' pesan/24 jam' : '') . ' — nomor baru paling rawan; naikkan volume bertahap.');
        elseif ($age < 30 && $out >= 50) $add(10, 'Nomor masih muda (' . $age . ' hari) dengan ' . $out . ' pesan keluar/24 jam.');
    }
    // 2. chat duluan ke nomor yang tidak mengirim pesan 24 jam terakhir
    $on = $a['on'];
    if ($on > 50) $add(25, $on . ' chat duluan ke nomor yang belum menghubungi (24 jam) — pola paling sering berujung banned.');
    elseif ($on > 20) $add(15, $on . ' chat duluan ke nomor yang belum menghubungi (24 jam).');
    elseif ($on > 5) $add(8, $on . ' chat duluan ke nomor yang belum menghubungi (24 jam).');
    // 3. balasan atas chat duluan (7 hari; yang belum 24 jam & belum dibalas tidak dihitung)
    $ni = 0; $nr = 0;
    foreach ($d['init'] as $r) {
        if (!is_array($r)) continue;
        if (!empty($r[1])) { $ni++; $nr++; }
        elseif ((int)$r[0] < $now - 86400) $ni++;
    }
    $reply = $ni > 0 ? $nr / $ni : null;
    if ($ni >= 10 && $reply < 0.2) $add(15, 'Hanya ' . round($reply * 100) . '% dari ' . $ni . ' chat duluan yang dibalas (7 hari) — penerima tidak merespons/bisa melaporkan.');
    elseif ($ni >= 10 && $reply < 0.4) $add(8, round($reply * 100) . '% dari ' . $ni . ' chat duluan yang dibalas (7 hari).');
    // 4. volume
    if ($peak > 100) $add(10, 'Puncak ' . $peak . ' pesan keluar dalam 1 jam.');
    if ($out > 800) $add(10, $out . ' pesan keluar dalam 24 jam.');
    // 5. teks kembar ke banyak nomor baru
    $dupMax = 0;
    foreach ($d['dup'] as $r) if (is_array($r) && (int)($r['t'] ?? 0) >= $now - 86400) $dupMax = max($dupMax, count((array)($r['n'] ?? [])));
    if ($dupMax >= 10) $add(15, 'Teks yang sama dikirim duluan ke ' . $dupMax . ' nomor berbeda (24 jam) — terlihat seperti broadcast.');
    // 6–7. centang (hanya pesan setelah langganan message.ack aktif, umur 6–72 jam)
    $ackOn = (int)($d['ack_on'] ?? 0);
    $na = 0; $stuck = 0; $read = 0;
    if ($ackOn > 0) {
        foreach ($d['m'] as $r) {
            if (!is_array($r)) continue;
            $t = (int)$r[0];
            if ($t < $ackOn || $t > $now - 6 * 3600) continue;
            $na++;
            if ((int)$r[1] <= 1) $stuck++;
            if ((int)$r[1] >= 3) $read++;
        }
    }
    $stuckP = $na > 0 ? $stuck / $na : null; $readP = $na > 0 ? $read / $na : null;
    if ($na >= 20 && $stuckP > 0.15) $add(15, round($stuckP * 100) . '% pesan tertahan di centang satu > 6 jam — tanda diblokir penerima atau pengiriman dibatasi.');
    elseif ($na >= 20 && $stuckP > 0.05) $add(7, round($stuckP * 100) . '% pesan tertahan di centang satu > 6 jam.');
    if ($na >= 30 && $readP < 0.3) $add(5, 'Hanya ' . round($readP * 100) . '% pesan yang dibaca (centang biru).');
    // 8. gagal kirim
    $att = $out + $a['of'];
    if ($att >= 10 && $a['of'] / $att > 0.05) $add(10, $a['of'] . ' dari ' . $att . ' kiriman gagal (24 jam).');
    // 9–10. sesi
    $lo7 = 0; $fa7 = 0; $dr24 = 0;
    foreach ($d['ev'] as $e) {
        if (!is_array($e) || (string)($e[2] ?? '') === '') continue;
        if ($e[2] === 'logout') $lo7++;
        if ($e[2] === 'failed') $fa7++;
        if ((int)$e[0] >= $now - 86400) $dr24++;
    }
    if ($lo7 > 0) $add(25, 'WhatsApp memutus sesi (logout paksa) ' . $lo7 . 'x dalam 7 hari — sinyal pembatasan paling kuat.');
    if ($fa7 > 0) $add(10, 'Sesi gagal (FAILED) ' . $fa7 . 'x dalam 7 hari.');
    if ($dr24 >= 3) $add(10, 'Sesi putus-sambung ' . $dr24 . 'x dalam 24 jam.');
    // 11. balasan instan
    if ($a['ob'] >= 20 && $a['fa'] / $a['ob'] > 0.8) $add(5, 'Hampir semua balasan bot terkirim < 2 detik — aktifkan jeda balasan.');

    usort($f, function ($x, $y) { return $y['p'] - $x['p']; });
    $score = min(100, array_sum(array_column($f, 'p')));
    $hoursData = $firstH !== '' ? (int)floor(($now + 7 * 3600 - gmmktime((int)substr($firstH, 8, 2), 0, 0, (int)substr($firstH, 4, 2), (int)substr($firstH, 6, 2), (int)substr($firstH, 0, 4))) / 3600) : 0;
    $series = [];
    foreach ($days as $dk => $v) $series[] = ['d' => $dk] + $v;
    return [
        'ch' => (string)$ch, 'score' => $score, 'level' => whLevel($score), 'factors' => $f, 'at' => $now,
        'partial' => $hoursData < 24,
        'm' => ['in' => $a['in'], 'out' => $out, 'out_bot' => $a['ob'], 'out_agent' => $a['oa'], 'out_hp' => $a['oh'],
                'out_new' => $on, 'fail' => $a['of'], 'peak_hour' => $peak, 'age_days' => $age, 'age_src' => (string)($d['paired_src'] ?? ''),
                'init_n' => $ni, 'reply_pct' => $reply === null ? null : round($reply * 100),
                'ack_on' => $ackOn > 0, 'ack_n' => $na, 'stuck_pct' => $stuckP === null ? null : round($stuckP * 100), 'read_pct' => $readP === null ? null : round($readP * 100),
                'logout_7d' => $lo7, 'failed_7d' => $fa7, 'drops_24h' => $dr24, 'status' => (string)($d['st'] ?? ''), 'number' => (string)($d['num'] ?? '')],
        'series' => $series, 'since' => $since,
        'events' => array_slice(array_reverse(array_values(array_filter($d['ev'], 'is_array'))), 0, 12),
        'cfg_ok' => (int)($d['cfg_v'] ?? 0) >= WA_HEALTH_CFG_V || $ackOn > 0,
    ];
}
// Nomor WAHA yang dipantau: [[ch, label, conf], ...]
function whChannels($s = null) {
    if ($s === null) $s = getSettings();
    $wa = waConf($s);
    if (!whOn($wa)) return [];
    $out = [];
    foreach (waChannels($s) as $c) {
        $conf = $c['id'] === 'utama' ? $wa : waChanConf($wa, $c['id'], $s);
        if ($c['id'] !== 'utama' && ($conf['_ch'] ?? '') !== $c['id']) continue;
        $out[] = [$c['id'], (string)$c['label'], $conf];
    }
    return $out;
}
if (!defined('WA_HEALTH_SCORE_FILE')) define('WA_HEALTH_SCORE_FILE', WA_HEALTH_DIR . '/score.json');
// Hitung ulang semua nomor (cron_tick tiap 15 menit, $force = sekarang). Kirim push saat masuk zona Bahaya.
function whScoreAll($s = null, $force = false) {
    if ($s === null) $s = getSettings();
    $chs = whChannels($s);
    if (!$chs) return null;
    $prev = readJson(WA_HEALTH_SCORE_FILE, []);
    if (!is_array($prev)) $prev = [];
    if (!$force && (int)($prev['at'] ?? 0) > time() - 900) return $prev;
    $res = ['at' => time(), 'nums' => [], 'alerted' => is_array($prev['alerted'] ?? null) ? $prev['alerted'] : []];
    foreach ($chs as $c) {
        list($ch, $label, $conf) = $c;
        $sc = whScore($ch);
        $row = whRow($ch, $label, $conf, $sc);
        $res['nums'][$ch] = $row;
        $was = (string)($prev['nums'][$ch]['level'] ?? 'aman');
        $lastA = (int)($res['alerted'][$ch] ?? 0);
        if ($sc['level'] === 'bahaya' && ($was !== 'bahaya' || $lastA < time() - 86400) && $lastA < time() - 12 * 3600 && empty($GLOBALS['dei_dry'])) {
            whAlert($conf, $ch, 'bahaya', $row);
            $res['alerted'][$ch] = time();
        }
    }
    deiWithLock('wa-health-score', function () use ($res) { writeJson(WA_HEALTH_SCORE_FILE, $res); });
    return $res;
}
function whRow($ch, $label, $conf, $sc) {
    return ['ch' => $ch, 'label' => $label, 'number' => $sc['m']['number'] !== '' ? $sc['m']['number'] : waNormNum($conf['waha_number'] ?? ''),
            'score' => $sc['score'], 'level' => $sc['level'], 'partial' => $sc['partial'],
            'top' => array_slice(array_map(function ($x) { return '+' . $x['p'] . ': ' . $x['t']; }, $sc['factors']), 0, 3)];
}
// Panel dibuka -> skor segar satu nomor ikut disimpan (lencana sama dengan panel). Push tetap lewat cron.
function whStoreRow($ch, $label, $conf, $sc) {
    try {
        deiWithLock('wa-health-score', function () use ($ch, $label, $conf, $sc) {
            $all = readJson(WA_HEALTH_SCORE_FILE, []);
            if (!is_array($all) || empty($all['at'])) return;
            $all['nums'][$ch] = whRow($ch, $label, $conf, $sc);
            writeJson(WA_HEALTH_SCORE_FILE, $all);
        });
    } catch (\Throwable $e) { error_log('wa-health store: ' . $e->getMessage()); }
}
function whAlert($wa, $ch, $kind, $row) {
    try {
        if (!empty($GLOBALS['dei_dry'])) return;
        $label = '';
        foreach (waChannels() as $c) if ($c['id'] === $ch) $label = (string)$c['label'];
        if ($label === '') $label = $ch === 'utama' ? 'Nomor utama' : $ch;
        if ($kind === 'logout') { $title = 'Nomor WA terputus: ' . $label; $body = 'WhatsApp memutus sesi nomor ini (logout paksa). Scan ulang di Widget & API dan kurangi chat duluan — bisa jadi tanda pembatasan.'; }
        else { $title = 'Nomor WA berisiko: ' . $label . ' (' . (int)$row['score'] . '/100)'; $body = preg_replace('/^\+\d+: /', '', (string)($row['top'][0] ?? 'Cek panel Kesehatan nomor.')); }
        $subs = array_keys(readJson(DATA_DIR . '/push-subs.json', []));
        $targets = [];
        foreach (readJson(USERS_FILE, []) as $u) {
            $un = (string)($u['username'] ?? '');
            if ($un !== '' && in_array(($u['role'] ?? ''), ['super_admin', 'admin'], true) && in_array($un, $subs, true)) $targets[] = $un;
        }
        if ($targets) sendPushToUsers($targets, $title, $body, deiDashboardUrl(), 'dei-wa-health');
        error_log('[wa-health] ' . $title . ' — ' . $body);
    } catch (\Throwable $e) { error_log('wa-health alert: ' . $e->getMessage()); }
}
// Pasang ulang konfigurasi sesi (webhook + message.ack). PUT me-restart sesi WAHA beberapa detik.
function whApplyCfg($conf) {
    $n = wahaSession($conf);
    if ((string)($conf['waha_webhook_key'] ?? '') === '') return [false, 'Kunci webhook belum ada.'];
    list($c, $d) = wahaApi($conf, 'GET', '/api/sessions/' . rawurlencode($n));
    if ($c === 404) return [false, 'Sesi WAHA belum dibuat — hubungkan nomor dulu.'];
    if ($c < 200 || $c >= 300) return [false, wahaErr($c, $d)];
    whMark($conf, 'cfg_at');
    list($c, $d) = wahaApi($conf, 'PUT', '/api/sessions/' . rawurlencode($n), ['name' => $n, 'config' => wahaSessionConfig($conf)]);
    if ($c < 200 || $c >= 300) { whUpdate(whCh($conf), function (&$d) { $d['cfg_v'] = 0; }); return [false, wahaErr($c, $d, 'Gagal memasang webhook.')]; }
    return [true, ''];
}
// cron: sesi lama (dibuat sebelum v1.2.104) dipasang ulang otomatis sekali, hanya jam 01–04 WIB.
function whEnsureCfgCron($s) {
    $done = [];
    $h = (int)wibDate('G');
    if ($h < 1 || $h > 4 || !empty($GLOBALS['dei_dry'])) return $done;
    foreach (whChannels($s) as $c) {
        list($ch, , $conf) = $c;
        $d = whRead($ch);
        if ((int)($d['cfg_v'] ?? 0) >= WA_HEALTH_CFG_V || !empty($d['call_on'])) continue;   // v1.2.108: tolak-telepon (sesi v2 dipasang ulang sekali)
        if ((int)($d['mk']['cfg_try'] ?? 0) > time() - 6 * 3600) continue;
        whUpdate($ch, function (&$x) { $x['mk']['cfg_try'] = time(); });
        list($ok, $err) = whApplyCfg($conf);
        $done[$ch] = $ok ? 'ok' : $err;
    }
    return $done;
}
// Ringkas untuk statistik pusat (tanpa isi chat).
function whStatsSummary() {
    $sc = readJson(WA_HEALTH_SCORE_FILE, []);
    if (!is_array($sc) || empty($sc['nums'])) return null;
    $out = [];
    foreach ($sc['nums'] as $r) {
        $out[] = ['ch' => (string)$r['ch'], 'label' => mb_substr((string)$r['label'], 0, 40), 'number' => (string)$r['number'],
                  'score' => (int)$r['score'], 'level' => (string)$r['level'], 'partial' => !empty($r['partial']),
                  'top' => array_map(function ($t) { return mb_substr((string)$t, 0, 140); }, array_slice((array)($r['top'] ?? []), 0, 3))];
    }
    return ['at' => (int)$sc['at'], 'nums' => array_slice($out, 0, 21)];
}

/* v1.2.108: tolak-telepon — telepon WhatsApp masuk (WAHA event call.received).
 * WAHA (WhatsApp Web) tidak bisa mengangkat telepon; HP tetap berdering sebentar.
 * Per nomor bisnis (ch) bisa diatur: tolak otomatis (selalu / hanya di luar jam operasional WIB)
 * + pesan balasan. Semua telepon masuk dicatat di log (dir=call) -> Percakapan WA & Log.
 * Pengaturan: data/wa-calls.json {ch: {...}}. Anti-dobel & jeda balasan: data/wa-calls-seen.json.
 * Sesi lama perlu webhook baru (WA_HEALTH_CFG_V 3): dipasang otomatis jam 01–04 WIB / tombol di panel. */
if (!defined('WA_CALLS_FILE')) define('WA_CALLS_FILE', DATA_DIR . '/wa-calls.json');
if (!defined('WA_CALLS_SEEN_FILE')) define('WA_CALLS_SEEN_FILE', DATA_DIR . '/wa-calls-seen.json');
if (!defined('WA_CALL_REPLY_GAP')) define('WA_CALL_REPLY_GAP', 600);   // telepon beruntun: pesan balasan maks 1x / 10 menit / nomor
function wcDefaults() {
    return ['on' => false, 'when' => 'always', 'days' => [1, 2, 3, 4, 5, 6], 'start' => '08:00', 'end' => '17:00',
            'reply_on' => true,
            'msg' => "Mohon maaf, nomor ini hanya melayani chat dan tidak dapat menerima telepon. Silakan ketik pertanyaan Anda di sini, kami bantu segera \xF0\x9F\x99\x8F"];
}
function wcClean($in) {
    $d = wcDefaults();
    $o = ['on' => !empty($in['on']), 'when' => (($in['when'] ?? '') === 'hours') ? 'hours' : 'always'];
    $days = [];
    foreach ((array)($in['days'] ?? []) as $x) { $x = (int)$x; if ($x >= 1 && $x <= 7) $days[$x] = $x; }
    ksort($days);
    $o['days'] = array_values($days);
    foreach (['start', 'end'] as $k) {
        $v = trim((string)($in[$k] ?? $d[$k]));
        $o[$k] = preg_match('/^([01]\d|2[0-3]):[0-5]\d$/', $v) ? $v : $d[$k];
    }
    $o['reply_on'] = !empty($in['reply_on']);
    $o['msg'] = mb_substr(trim(str_replace("\r", '', (string)($in['msg'] ?? ''))), 0, 1000);
    return $o;
}
function wcConf($ch) {
    $all = readJson(WA_CALLS_FILE, []);
    $c = (is_array($all) && is_array($all[$ch] ?? null)) ? $all[$ch] : [];
    return array_replace(wcDefaults(), $c);
}
function wcSave($ch, $conf) {
    deiWithLock('wa-calls', function () use ($ch, $conf) {
        $all = readJson(WA_CALLS_FILE, []);
        if (!is_array($all)) $all = [];
        $all[$ch] = $conf;
        writeJson(WA_CALLS_FILE, $all);
    });
}
// Di dalam jam operasional (WIB)? Mulai = selesai -> 24 jam di hari terpilih.
// Rentang lewat tengah malam (mis. 22:00–06:00) ikut hari mulainya.
function wcInHours($c, $ts = null) {
    $ts = $ts ?? time();
    $days = array_map('intval', (array)($c['days'] ?? []));
    $now = wibDate('H:i', $ts); $st = (string)($c['start'] ?? '08:00'); $en = (string)($c['end'] ?? '17:00');
    $today = in_array((int)wibDate('N', $ts), $days, true);
    if ($st === $en) return $today;
    if ($st < $en) return $today && $now >= $st && $now < $en;
    if ($now >= $st) return $today;
    if ($now < $en) return in_array((int)wibDate('N', $ts - 86400), $days, true);
    return false;
}
// [tolak?, alasan: off | always | in_hours | outside_hours]
function wcDecide($c, $ts = null) {
    if (empty($c['on'])) return [false, 'off'];
    if (($c['when'] ?? 'always') !== 'hours') return [true, 'always'];
    return wcInHours($c, $ts) ? [false, 'in_hours'] : [true, 'outside_hours'];
}
// Teks tampilan entri log telepon ('' bila bukan telepon).
function wcLabel($e) {
    if ((string)($e['dir'] ?? '') !== 'call' || !is_array($e['call'] ?? null)) return '';
    $k = $e['call'];
    $t = "\xF0\x9F\x93\x9E Telepon " . (!empty($k['video']) ? 'video' : 'suara') . ' masuk';
    $act = (string)($k['act'] ?? '');
    if ($act === 'rejected') $t .= " \xE2\x80\x94 ditolak otomatis" . (($k['why'] ?? '') === 'outside_hours' ? ' (di luar jam operasional)' : '');
    elseif ($act === 'reject_failed') $t .= " \xE2\x80\x94 gagal ditolak otomatis";
    elseif (($k['why'] ?? '') === 'in_hours') $t .= " \xE2\x80\x94 jam operasional, tidak ditolak";
    return $t;
}
// Jejak kecil berkunci: $fn(&$all) mengubah isi, nilai kembali diteruskan. Entri > 24 jam dibuang.
function wcSeen($fn) {
    return deiWithLock('wa-calls-seen', function () use ($fn) {
        $all = readJson(WA_CALLS_SEEN_FILE, []);
        if (!is_array($all)) $all = [];
        $now = time();
        foreach ($all as $k => $t) { if ((int)$t < $now - 86400) unset($all[$k]); }
        $r = $fn($all);
        if (count($all) > 3000) $all = array_slice($all, -3000, null, true);
        writeJson(WA_CALLS_SEEN_FILE, $all);
        return $r;
    });
}
function wcHandle($wa, $evt) {
    $p = is_array($evt['payload'] ?? null) ? $evt['payload'] : [];
    if (!empty($p['isGroup'])) return 'group';
    $id = trim((string)($p['id'] ?? '')); $from = trim((string)($p['from'] ?? ''));
    if ($id === '' || $from === '') return 'bad';
    $ch = whCh($wa);
    $first = wcSeen(function (&$all) use ($ch, $id) {
        $k = 'c' . $ch . ':' . $id;
        if (isset($all[$k])) return false;
        $all[$k] = time();
        return true;
    });
    if (!$first) return 'dup';
    whUpdate($ch, function (&$d) { if (!empty($d['call_on'])) return false; $d['call_on'] = time(); });   // langganan call.received terbukti aktif
    $num = wahaResolveNum($wa, $from, $p);
    $c = wcConf($ch);
    list($reject, $why) = wcDecide($c);
    $act = 'none'; $sent = '';
    if ($reject) {
        list($code, $d) = wahaApi($wa, 'POST', '/api/' . rawurlencode(wahaSession($wa)) . '/calls/reject', ['from' => $from, 'id' => $id]);
        $act = ($code >= 200 && $code < 300) ? 'rejected' : 'reject_failed';
        if ($act !== 'rejected') error_log('waha: tolak telepon gagal HTTP ' . $code . ': ' . wahaErr($code, $d));
        $msg = trim((string)($c['msg'] ?? ''));
        if (!empty($c['reply_on']) && $msg !== '' && $num !== '' && empty($GLOBALS['dei_dry'])) {
            $go = wcSeen(function (&$all) use ($ch, $num) {
                $k = 'r' . $ch . ':' . $num;
                if ((int)($all[$k] ?? 0) > time() - WA_CALL_REPLY_GAP) return false;
                $all[$k] = time();
                return true;
            });
            if ($go) {
                $GLOBALS['dei_out_src'] = 'bot';
                if (waSendWaha($wa, $num, $msg)) $sent = $msg;
            }
        }
    }
    if ($num === '') { error_log('waha: telepon masuk, nomor tidak terbaca (' . mb_substr($from, 0, 40) . ')'); return $act; }
    $row = ['ts' => date('Y-m-d H:i:s'), 'q' => '', 'a' => $sent, 'ip' => $num, 'channel' => 'whatsapp', 'dir' => 'call',
            'call' => ['video' => !empty($p['isVideo']), 'act' => $act, 'why' => $why],
            'utm_source' => 'whatsapp', 'utm_medium' => 'call', 'utm_campaign' => '', 'page' => '', 'referrer' => ''];
    if (!empty($wa['_ch'])) $row['wa_ch'] = (string)$wa['_ch'];
    try { $s = getSettings(); logPrepend($row, (int)($s['api']['log_limit'] ?? 500)); }
    catch (\Throwable $e) { error_log('log telepon: ' . $e->getMessage()); }
    return $act;
}
/* ====== /v1.2.108: tolak-telepon ====== */

function waSendWaha($wa, $to, $text) {
    $GLOBALS['wa_last_error'] = '';
    $to = waNormNum($to);
    if ($to === '') { $GLOBALS['wa_last_error'] = 'Nomor tujuan kosong.'; return false; }
    if (trim((string)($wa['waha_url'] ?? '')) === '') { $GLOBALS['wa_last_error'] = 'URL WAHA belum diisi.'; return false; }
    wahaRememberSent($to, '', $text);
    list($c, $d) = wahaApi($wa, 'POST', '/api/sendText', ['session' => wahaSession($wa), 'chatId' => $to . '@c.us', 'text' => $text]);
    if ($c >= 200 && $c < 300) {
        $id = is_array($d) ? wahaMsgId($d) : '';
        if ($id !== '') wahaRememberSent($to, $id, '');
        whOut($wa, $to, (string)($GLOBALS['dei_out_src'] ?? 'bot'), true, $id, $text);   // v1.2.104: skor-risiko-wa
        return true;
    }
    whOut($wa, $to, (string)($GLOBALS['dei_out_src'] ?? 'bot'), false);   // v1.2.104
    $GLOBALS['wa_last_error'] = wahaErr($c, $d, 'Kirim lewat WAHA gagal.');
    error_log('waSendWaha HTTP ' . $c . ': ' . $GLOBALS['wa_last_error']);
    return false;
}

function waSend($wa, $to, $text) {
    $wa = waChanFor($wa, $to); $GLOBALS['wa_out_ch'] = (string)($wa['_ch'] ?? '');   // v1.2.98: multi-nomor
    // v1.2.36: pilih penyedia. Bawaan 'meta' supaya tenant lama tidak berubah.
    if (($wa['provider'] ?? 'meta') === 'fonnte') return waSendFonnte($wa, $to, $text);
    if (($wa['provider'] ?? 'meta') === 'waha') return waSendWaha($wa, $to, $text);   // v1.2.76: WAHA
    $GLOBALS['wa_last_error'] = '';
    $token = $wa['access_token'] ?? '';
    $pnid  = $wa['phone_number_id'] ?? '';
    if ($token === '') { $GLOBALS['wa_last_error'] = 'Access Token WhatsApp kosong — belum diisi atau terhapus. Hubungkan ulang di Pengaturan.'; return false; }
    if ($pnid === '')  { $GLOBALS['wa_last_error'] = 'Phone Number ID kosong.'; return false; }
    $url = 'https://graph.facebook.com/v21.0/' . rawurlencode($pnid) . '/messages';
    $payload = [
        'messaging_product' => 'whatsapp',
        'recipient_type'    => 'individual',
        'to'                => $to,
        'type'              => 'text',
        'text'              => ['preview_url' => false, 'body' => $text],
    ];
    $ch = curl_init($url);
    curl_setopt_array($ch, [
        CURLOPT_RETURNTRANSFER => true,
        CURLOPT_POST           => true,
        CURLOPT_TIMEOUT        => 20,
        CURLOPT_HTTPHEADER     => ['Content-Type: application/json', 'Authorization: Bearer ' . $token],
        CURLOPT_POSTFIELDS     => json_encode($payload, JSON_UNESCAPED_UNICODE),
    ]);
    $resp = curl_exec($ch);
    $cerr = curl_error($ch);
    $code = curl_getinfo($ch, CURLINFO_HTTP_CODE);
    curl_close($ch);
    if ($code >= 200 && $code < 300) { waOutCount('service'); return true; }   // v1.2.57
    $msg = '';
    $d = json_decode((string)$resp, true);
    if (is_array($d) && isset($d['error'])) {
        $e = $d['error'];
        $msg = trim(($e['message'] ?? '') . (isset($e['code']) ? ' (code ' . $e['code'] . ')' : ''));
    }
    if ($msg === '') $msg = $cerr !== '' ? $cerr : ('HTTP ' . $code);
    $GLOBALS['wa_last_error'] = $msg;
    error_log('waSend Meta HTTP ' . $code . ': ' . mb_substr((string)$resp, 0, 300));
    return false;
}

/* ============================================================
 * v1.2.47: Blast WA — template message via WhatsApp Cloud API resmi
 * ============================================================ */
if (!defined('WA_BLASTS_FILE')) define('WA_BLASTS_FILE', DATA_DIR . '/wa-blasts.json');

// Ambil daftar template dari Meta (butuh waba_id + access_token).
function waFetchTemplates($wa) {
    $token = $wa['access_token'] ?? '';
    $waba  = $wa['waba_id'] ?? '';
    if ($token === '' || $waba === '') {
        return ['ok' => false, 'error' => 'WABA ID atau Access Token belum diisi di menu Widget & API.'];
    }
    $url = 'https://graph.facebook.com/v21.0/' . rawurlencode($waba) . '/message_templates?fields=name,status,language,category,components&limit=250';
    $ch = curl_init($url);
    curl_setopt_array($ch, [CURLOPT_RETURNTRANSFER => true, CURLOPT_TIMEOUT => 25,
        CURLOPT_HTTPHEADER => ['Authorization: Bearer ' . $token]]);
    $raw = curl_exec($ch); $code = curl_getinfo($ch, CURLINFO_HTTP_CODE); curl_close($ch);
    if ($code < 200 || $code >= 300) {
        $err = json_decode($raw, true);
        return ['ok' => false, 'error' => 'Gagal ambil template (HTTP ' . $code . '): ' . ($err['error']['message'] ?? 'unknown')];
    }
    $d = json_decode($raw, true);
    return ['ok' => true, 'templates' => $d['data'] ?? []];
}

// Hitung jumlah variabel {{n}} pada BODY template.
function waTemplateVarCount($tmpl) {
    foreach (($tmpl['components'] ?? []) as $comp) {
        if (strtoupper($comp['type'] ?? '') === 'BODY') {
            preg_match_all('/\{\{\s*(\d+)\s*\}\}/', $comp['text'] ?? '', $m);
            return !empty($m[1]) ? max(array_map('intval', $m[1])) : 0;
        }
    }
    return 0;
}

// Kirim satu template message. $vars index 0 => {{1}}.
function waSendTemplate($wa, $to, $name, $lang, $vars = []) {
    $wa = waChanFor($wa, $to); $GLOBALS['wa_out_ch'] = (string)($wa['_ch'] ?? '');   // v1.2.98: multi-nomor
    $token = $wa['access_token'] ?? '';
    $pnid  = $wa['phone_number_id'] ?? '';
    if ($token === '' || $pnid === '') return ['ok' => false, 'error' => 'token/phone_number_id kosong'];
    $payload = [
        'messaging_product' => 'whatsapp',
        'to'                => $to,
        'type'              => 'template',
        'template'          => ['name' => $name, 'language' => ['code' => $lang ?: 'id']],
    ];
    if (!empty($vars)) {
        $params = [];
        foreach ($vars as $v) $params[] = ['type' => 'text', 'text' => (string)$v];
        $payload['template']['components'] = [['type' => 'body', 'parameters' => $params]];
    }
    $url = 'https://graph.facebook.com/v21.0/' . rawurlencode($pnid) . '/messages';
    $ch = curl_init($url);
    curl_setopt_array($ch, [CURLOPT_RETURNTRANSFER => true, CURLOPT_POST => true, CURLOPT_TIMEOUT => 20,
        CURLOPT_HTTPHEADER => ['Content-Type: application/json', 'Authorization: Bearer ' . $token],
        CURLOPT_POSTFIELDS => json_encode($payload, JSON_UNESCAPED_UNICODE)]);
    $raw = curl_exec($ch); $code = curl_getinfo($ch, CURLINFO_HTTP_CODE); curl_close($ch);
    if ($code >= 200 && $code < 300) { waOutCount('template'); return ['ok' => true]; }   // v1.2.57
    $err = json_decode($raw, true);
    return ['ok' => false, 'error' => ($err['error']['message'] ?? ('HTTP ' . $code))];
}

function waBlastReadAll() { $b = readJson(WA_BLASTS_FILE, []); return is_array($b) ? $b : []; }
function waBlastWrite($b) { writeJson(WA_BLASTS_FILE, $b); }
function waBlastGenId() { return 'blast_' . date('Ymd_His') . '_' . bin2hex(random_bytes(3)); }
function waBlastFind($all, $id) {
    foreach ($all as $i => $b) { if (($b['id'] ?? '') === $id) return $i; }
    return -1;
}
// Ganti token {nama}/{name} di nilai variabel dengan nama kontak.
function waBlastFillVar($v, $name) {
    $name = $name !== '' ? $name : 'Kak';
    return str_ireplace(['{nama}', '{name}'], $name, (string)$v);
}

/* ============================================================
 * v1.2.36: alur pemrosesan pesan WA masuk — dipakai SEMUA penyedia
 * ============================================================ */
// Dipisahkan supaya penyedia kedua (Fonnte) tidak perlu menyalin alur ini.
// Yang khas per-penyedia tinggal di webhook masing-masing: cara memverifikasi
// kiriman, membaca strukturnya, dan mengirim balasan. Begitu nomor dan teks
// didapat, penanganannya identik.
//
// $metaInfo  : value.metadata dari Meta (untuk tracker WA-to-Ads). Kosongkan
//              untuk penyedia lain — tracker otomatis tidak aktif.
// $senderName: nama profil pengirim kalau tersedia.
/* v1.2.109: guest-comment — survei kepuasan pelanggan. v1.2.110: customer-feedback (nama umum lintas industri,
 *  label nomor referensi bisa diatur, preset aspek per industri). Mulai paket Business.
 *  - WhatsApp: pelanggan mengetik kata kunci (mis. "CUSTOMER FEEDBACK", bisa dari QR wa.me) -> bot memandu
 *    nama, nomor kamar, rating 1–5 per aspek, komentar. Alur terpandu TANPA AI (tidak memakai kuota AI).
 *  - Web: form publik ?action=gc_form (QR di kamar/front desk, atau tautan dari bot widget).
 *  - Rating rendah (<= ambang) -> notifikasi push/Telegram + WA ke nomor staf (opsional).
 *  - Tautan ulasan Google ditawarkan ke SEMUA tamu (tanpa menyaring rating — kebijakan Google).
 * Data: data/guest-comment.json (pengaturan), data/guest-comments.json (entri, terbaru di depan),
 *       data/gc-sessions.json (sesi WA berjalan, kedaluwarsa GC_SESSION_TTL). */
if (!defined('GC_CONF_FILE')) define('GC_CONF_FILE', DATA_DIR . '/guest-comment.json');
if (!defined('GC_FILE')) define('GC_FILE', DATA_DIR . '/guest-comments.json');
if (!defined('GC_SESS_FILE')) define('GC_SESS_FILE', DATA_DIR . '/gc-sessions.json');
if (!defined('GC_MAX')) define('GC_MAX', 5000);
if (!defined('GC_SESSION_TTL')) define('GC_SESSION_TTL', 1800);
if (!defined('GC_TIERS')) define('GC_TIERS', 'business,pro,custom,enterprise');   // paket yang mendapat fitur ini

function gcDefaults() {
    return [
        'enabled'  => false,
        'aspects'  => [
            ['id' => 'overall', 'label' => 'Kesan keseluruhan',          'label_en' => 'Overall experience'],
            ['id' => 'quality', 'label' => 'Kualitas produk / layanan',  'label_en' => 'Product / service quality'],
            ['id' => 'staff',   'label' => 'Keramahan & bantuan staf',   'label_en' => 'Staff friendliness & help'],
            ['id' => 'speed',   'label' => 'Kecepatan pelayanan',        'label_en' => 'Speed of service'],
            ['id' => 'value',   'label' => 'Harga sesuai kualitas',      'label_en' => 'Value for money'],
        ],
        'ask_name' => true,
        'ask_room' => false,
        'ref_label'    => 'Nomor pesanan',
        'ref_label_en' => 'Order number',
        'ask_phone_web' => true,
        'intro'    => "Terima kasih sudah memilih kami \xF0\x9F\x99\x8F Mohon luangkan 1 menit untuk memberi penilaian & masukan.",
        'intro_en' => "Thank you for choosing us \xF0\x9F\x99\x8F Please spare a minute to rate us and share your feedback.",
        'thanks'   => 'Terima kasih atas masukan Anda! Setiap komentar kami baca untuk terus memperbaiki layanan.',
        'thanks_en'=> 'Thank you for your feedback! We read every comment to keep improving our service.',
        'review_url'     => '',
        'review_text'    => 'Bila berkenan, bagikan juga pengalaman Anda di Google: {link}',
        'review_text_en' => 'If you have a moment, please share your experience on Google too: {link}',
        'low'      => 2,
        'alert_wa' => '',
        'keywords' => ['customer feedback', 'feedback', 'survei', 'isi survei', 'kesan pesan', 'kesan dan pesan', 'beri ulasan', 'guest comment'],
        'ai_hint'  => true,
    ];
}
function gcSlug($t) {
    $t = strtolower(preg_replace('/[^A-Za-z0-9]+/', '_', (string)$t));
    return substr(trim($t, '_'), 0, 24);
}
function gcClean($in) {
    $d = gcDefaults();
    $in = is_array($in) ? $in : [];
    $o = ['enabled' => !empty($in['enabled'])];
    foreach (['ask_name', 'ask_room', 'ask_phone_web', 'ai_hint'] as $k) $o[$k] = array_key_exists($k, $in) ? !empty($in[$k]) : $d[$k];
    $asp = []; $seen = [];
    foreach ((array)($in['aspects'] ?? $d['aspects']) as $a) {
        if (!is_array($a)) continue;
        $l = mb_substr(trim((string)($a['label'] ?? '')), 0, 60);
        $le = mb_substr(trim((string)($a['label_en'] ?? '')), 0, 60);
        if ($l === '' && $le === '') continue;
        if ($l === '') $l = $le;
        $id = gcSlug($a['id'] ?? '');
        if ($id === '') $id = gcSlug($le !== '' ? $le : $l);
        if ($id === '') $id = 'a' . (count($asp) + 1);
        $base = $id; $n = 2;
        while (isset($seen[$id])) $id = substr($base, 0, 20) . '_' . $n++;
        $seen[$id] = 1;
        $asp[] = ['id' => $id, 'label' => $l, 'label_en' => $le];
        if (count($asp) >= 8) break;
    }
    $o['aspects'] = $asp ?: $d['aspects'];
    foreach (['ref_label', 'ref_label_en'] as $k) {
        $v = array_key_exists($k, $in) ? mb_substr(trim((string)$in[$k]), 0, 40) : $d[$k];
        $o[$k] = $v !== '' ? $v : $d[$k];
    }
    foreach (['intro', 'intro_en', 'thanks', 'thanks_en', 'review_text', 'review_text_en'] as $k) {
        $v = array_key_exists($k, $in) ? trim(str_replace("\r", '', (string)$in[$k])) : $d[$k];
        $o[$k] = mb_substr($v, 0, 600);
    }
    $u = trim((string)($in['review_url'] ?? ''));
    $o['review_url'] = preg_match('~^https?://[^\s<>"]{3,500}$~i', $u) ? $u : '';
    $o['low'] = max(1, min(4, (int)($in['low'] ?? $d['low'])));
    $nums = [];
    foreach (preg_split('/[,;\n]+/', (string)($in['alert_wa'] ?? '')) as $x) {
        $x = preg_replace('/\D/', '', $x);
        if ($x === '') continue;
        if ($x[0] === '0') $x = '62' . substr($x, 1);
        if (strlen($x) >= 9 && strlen($x) <= 15) $nums[$x] = $x;
        if (count($nums) >= 5) break;
    }
    $o['alert_wa'] = implode(', ', array_values($nums));
    $kw = [];
    $kwIn = $in['keywords'] ?? $d['keywords'];
    if (is_string($kwIn)) $kwIn = preg_split('/[,\n]+/', $kwIn);
    foreach ((array)$kwIn as $k) {
        $k = trim(preg_replace('/\s+/', ' ', mb_strtolower((string)$k, 'UTF-8')));
        if (mb_strlen($k) >= 3 && mb_strlen($k) <= 40) $kw[$k] = $k;
        if (count($kw) >= 15) break;
    }
    $o['keywords'] = $kw ? array_values($kw) : $d['keywords'];
    return $o;
}
function gcConf() {
    if (isset($GLOBALS['dei_gc_conf'])) return $GLOBALS['dei_gc_conf'];
    $raw = readJson(GC_CONF_FILE, []);
    $raw = is_array($raw) ? gcMigrate($raw) : [];
    return $GLOBALS['dei_gc_conf'] = gcClean(array_replace(gcDefaults(), $raw));
}
// v1.2.110: customer-feedback — nilai bawaan lama (khas hotel) yang belum diubah admin diganti bawaan umum.
// Hotel yang memang memakai aspek kamar tetap: aspek hanya diganti bila persis sama dengan bawaan lama DAN
// teks pembuka juga masih bawaan lama (tanda pengaturan belum pernah disesuaikan).
function gcMigrate($raw) {
    $old = ['intro' => "Terima kasih sudah menginap bersama kami \xF0\x9F\x99\x8F Mohon luangkan 1 menit untuk mengisi guest comment.",
            'intro_en' => "Thank you for staying with us \xF0\x9F\x99\x8F Please spare a minute to share your guest comment."];
    $d = gcDefaults();
    $untouched = (string)($raw['intro'] ?? '') === $old['intro'];
    foreach ($old as $k => $v) { if ((string)($raw[$k] ?? '') === $v) $raw[$k] = $d[$k]; }
    if (($raw['keywords'] ?? null) === ['guest comment', 'guest feedback', 'kesan pesan', 'kesan dan pesan', 'survei tamu', 'isi survei']) $raw['keywords'] = $d['keywords'];
    $oldIds = array_map(function ($a) { return is_array($a) ? (string)($a['id'] ?? '') : ''; }, (array)($raw['aspects'] ?? []));
    if ($untouched && $oldIds === ['overall', 'room', 'clean', 'staff', 'fnb'] && ($raw['aspects'][1]['label'] ?? '') === 'Kamar') {
        $raw['aspects'] = $d['aspects'];
        if (!isset($raw['ref_label'])) $raw['ask_room'] = false;
    }
    if (!isset($raw['ref_label']) && !empty($raw['ask_room'])) { $raw['ref_label'] = 'Nomor kamar'; $raw['ref_label_en'] = 'Room number'; }
    return $raw;
}
// Paket: tanpa server pusat (instalasi sendiri) = boleh. Trial & Starter/Growth = belum.
function gcPlan() {
    if (isset($GLOBALS['dei_gc_plan'])) return $GLOBALS['dei_gc_plan'];
    $s = getSettings();
    $cs = $s['central_server'] ?? [];
    if (empty($cs['url']) || empty($cs['tenant_id']) || empty($cs['license_key'])) return $GLOBALS['dei_gc_plan'] = ['ok' => true, 'tier' => '', 'trial' => false];
    $cap = [];
    try { $cap = getCapStatus($s); } catch (\Throwable $e) { error_log('gcPlan: ' . $e->getMessage()); }
    $tier = strtolower(trim((string)($cap['tier'] ?? '')));
    $trial = !empty($cap['trial']) || $tier === 'trial';
    $ok = !$trial && in_array($tier, explode(',', GC_TIERS), true);
    return $GLOBALS['dei_gc_plan'] = ['ok' => $ok, 'tier' => $trial ? 'trial' : $tier, 'trial' => $trial];
}
function gcActive() { return gcPlan()['ok'] && gcConf()['enabled']; }
function gcLockedMsg() { return 'Customer Feedback tersedia mulai paket Business. Hubungi ' . deiBrandVendor() . ' untuk upgrade paket.'; }
function gcApiBase() {
    $u = deiSelfApiUrl();
    if ($u === '' || strpos($u, '://localhost') !== false) { $r = deiRememberedApiUrl(); if ($r !== '') $u = $r; }
    return $u;
}
function gcFormUrl($room = '') {
    $b = gcApiBase();
    if ($b === '') return '';
    return $b . '?action=gc_form' . ($room !== '' ? '&room=' . rawurlencode($room) : '');
}
function gcAspLabel($a, $lang) { return ($lang === 'en' && trim((string)($a['label_en'] ?? '')) !== '') ? $a['label_en'] : $a['label']; }
function gcTxt($k, $lang) {
    $T = [
        'ask_name'    => ['Boleh kami tahu nama Anda?', 'May we have your name?'],
        'ask_room'    => ['{ref} Anda? (ketik *-* bila tidak ada)', 'Your {ref}? (type *-* if none)'],
        'ask_rate'    => ["*{n}/{t}* Bagaimana penilaian Anda untuk *{a}*?\nBalas angka *1–5* (1 = sangat buruk, 5 = sangat baik).",
                          "*{n}/{t}* How would you rate *{a}*?\nReply with *1–5* (1 = very poor, 5 = excellent)."],
        'bad_rate'    => ['Mohon balas dengan angka *1* sampai *5* ya. Ketik *batal* untuk berhenti.', 'Please reply with a number from *1* to *5*. Type *cancel* to stop.'],
        'ask_comment' => ['Terakhir, ada komentar, saran, atau hal yang perlu kami perbaiki? Ketik *-* bila tidak ada.',
                          'Lastly, any comments, suggestions, or things we should improve? Type *-* if none.'],
        'stop_hint'   => ['(ketik *batal* untuk berhenti)', '(type *cancel* to stop)'],
        'cancelled'   => ['Baik, pengisian feedback dibatalkan. Silakan kirim pesan bila ada yang bisa kami bantu.', 'Okay, the feedback has been cancelled. Feel free to message us if you need anything.'],
    ];
    return $T[$k][$lang === 'en' ? 1 : 0] ?? '';
}
function gcNorm($t) { return str_replace(['survey', 'feed back'], ['survei', 'feedback'], trim(preg_replace('/\s+/u', ' ', mb_strtolower(preg_replace('/[^\p{L}\p{N}\s#-]/u', ' ', (string)$t), 'UTF-8')))); }   // v1.2.110: survey = survei
function gcMatchKeyword($text, $conf) {
    $n = ' ' . gcNorm($text) . ' ';
    if (mb_strlen($n) > 120) return false;   // pesan panjang = pertanyaan biasa, bukan perintah
    foreach ($conf['keywords'] as $k) {
        if (mb_strpos($n, ' ' . gcNorm($k) . ' ') !== false) return true;
    }
    return false;
}
function gcLangOf($text) {
    $l = deiDeteksiBahasa($text);
    if ($l === 'en' || $l === 'id') return $l;
    $n = ' ' . gcNorm($text) . ' ';
    if (preg_match('/ (i|my|give|would|like|leave|please|want) /', $n) && !preg_match('/ (saya|ingin|mau|isi|kesan|survei) /', $n)) return 'en';
    return 'id';
}
function gcIsSkip($t) { return in_array(gcNorm($t), ['', '-', 'skip', 'lewati', 'tidak ada', 'tidak', 'ga ada', 'gak ada', 'nggak ada', 'enggak', 'no', 'none', 'nothing', 'n a', 'na', 'tdk ada'], true) || trim((string)$t) === '-'; }
function gcIsCancel($t) { return in_array(gcNorm($t), ['batal', 'cancel', 'stop', 'berhenti', 'keluar', 'batalkan', 'quit', 'exit'], true); }
function gcParseRating($t) {
    $t = trim((string)$t);
    if (preg_match('/^\D{0,3}([1-5])(?!\d)/u', $t, $m)) return (int)$m[1];
    $st = preg_match_all('/\x{2B50}|\x{1F31F}|\x{2605}/u', $t);
    if ($st >= 1 && $st <= 5) return $st;
    $w = ['satu' => 1, 'dua' => 2, 'tiga' => 3, 'empat' => 4, 'lima' => 5, 'one' => 1, 'two' => 2, 'three' => 3, 'four' => 4, 'five' => 5];
    $n = gcNorm($t);
    return $w[$n] ?? 0;
}
function gcRatingStats($ratings, $low) {
    $v = array_values(array_filter(array_map('intval', (array)$ratings), function ($x) { return $x >= 1 && $x <= 5; }));
    $avg = $v ? round(array_sum($v) / count($v), 2) : 0;
    $isLow = false;
    foreach ($v as $x) if ($x <= $low) $isLow = true;
    return [$avg, $isLow];
}

/* --- entri --- */
function gcAll() { $d = readJson(GC_FILE, []); return is_array($d) ? $d : []; }
function gcStore($e) {
    $conf = gcConf();
    list($avg, $low) = gcRatingStats($e['ratings'] ?? [], $conf['low']);
    $labels = [];
    foreach ($conf['aspects'] as $a) if (isset($e['ratings'][$a['id']])) $labels[$a['id']] = $a['label'];
    $e = array_merge([
        'id' => 'g' . wibDate('ymdHis') . bin2hex(random_bytes(2)),
        'ts' => wibDate('Y-m-d H:i:s'), 'channel' => 'web', 'num' => '', 'name' => '', 'room' => '', 'phone' => '',
        'lang' => 'id', 'ratings' => [], 'comment' => '', 'wa_ch' => '', 'status' => 'baru', 'note' => '',
    ], $e, ['labels' => $labels, 'avg' => $avg, 'low' => $low]);
    deiWithLock('gc', function () use ($e) {
        $all = gcAll();
        array_unshift($all, $e);
        if (count($all) > GC_MAX) $all = array_slice($all, 0, GC_MAX);
        writeJson(GC_FILE, $all);
    });
    if ($low) { try { gcAlert($e); } catch (\Throwable $ex) { error_log('gcAlert: ' . $ex->getMessage()); } }
    return $e;
}
function gcAlert($e) {
    $s = getSettings();
    $conf = gcConf();
    $who = trim(($e['name'] !== '' ? $e['name'] : 'Pelanggan') . ($e['room'] !== '' ? ' (' . mb_strtolower(gcRefLabel($conf, 'id'), 'UTF-8') . ' ' . $e['room'] . ')' : ''));
    $det = [];
    foreach ($conf['aspects'] as $a) if (isset($e['ratings'][$a['id']])) $det[] = $a['label'] . ' ' . (int)$e['ratings'][$a['id']];
    $title = 'Feedback rendah: ' . $who;
    $body = 'Rata-rata ' . $e['avg'] . '/5 · ' . implode(', ', $det) . ($e['comment'] !== '' ? ' — "' . mb_substr($e['comment'], 0, 120) . '"' : '');
    $subs = array_keys((array)readJson(DATA_DIR . '/push-subs.json', []));
    $targets = [];
    foreach ((array)readJson(USERS_FILE, []) as $u) {
        $un = (string)($u['username'] ?? '');
        if ($un !== '' && in_array(($u['role'] ?? ''), ['super_admin', 'admin', 'supervisor'], true) && in_array($un, $subs, true)) $targets[] = $un;
    }
    if ($targets) sendPushToUsers($targets, $title, mb_substr($body, 0, 180), deiDashboardUrl() . '#gc', 'dei-gc');
    tgNotify($s, "\xE2\x9A\xA0\xEF\xB8\x8F " . $title . "\n" . $body . ($e['num'] !== '' ? "\nWA: +" . $e['num'] : ($e['phone'] !== '' ? "\nHP: " . $e['phone'] : '')));
    if ($conf['alert_wa'] !== '') {
        $wa = waConf($s);
        {
            $txt = "\xE2\x9A\xA0\xEF\xB8\x8F *Customer feedback rendah*\n" . $who . "\nRata-rata *" . $e['avg'] . "/5*\n" . implode("\n", $det)
                 . ($e['comment'] !== '' ? "\n\nKomentar: " . mb_substr($e['comment'], 0, 500) : '')
                 . ($e['num'] !== '' ? "\n\nWA pelanggan: +" . $e['num'] : ($e['phone'] !== '' ? "\n\nHP pelanggan: " . $e['phone'] : ''));
            foreach (explode(', ', $conf['alert_wa']) as $n) {
                if ($n === '' || $n === $e['num']) continue;
                if (!waSend($wa, $n, $txt)) error_log('gcAlert WA ' . $n . ': ' . (string)($GLOBALS['wa_last_error'] ?? ''));
            }
        }
    }
}

/* --- sesi WA --- */
function gcSessMutate($fn) {
    return deiWithLock('gcsess', function () use ($fn) {
        $all = readJson(GC_SESS_FILE, []);
        if (!is_array($all)) $all = [];
        $now = time();
        foreach ($all as $k => $v) { if ((int)($v['at'] ?? 0) < $now - GC_SESSION_TTL) unset($all[$k]); }
        $r = $fn($all);
        writeJson(GC_SESS_FILE, $all);
        return $r;
    });
}
function gcSessGet($num) { return gcSessMutate(function (&$all) use ($num) { return $all[$num] ?? null; }); }
function gcSessPut($num, $st) { gcSessMutate(function (&$all) use ($num, $st) { if ($st === null) unset($all[$num]); else $all[$num] = $st + ['at' => time()]; return true; }); }
function gcQuestion($st, $conf) {
    $step = $st['steps'][$st['i']] ?? '';
    $lang = $st['lang'];
    if ($step === 'name') return gcTxt('ask_name', $lang);
    if ($step === 'room') return str_replace('{ref}', $lang === 'en' ? mb_strtolower(gcRefLabel($conf, 'en'), 'UTF-8') : gcRefLabel($conf, 'id'), gcTxt('ask_room', $lang));
    if ($step === 'comment') return gcTxt('ask_comment', $lang);
    $asp = array_values(array_filter($st['steps'], function ($x) { return strpos($x, 'r:') === 0; }));
    $n = array_search($step, $asp, true);
    foreach ($conf['aspects'] as $a) {
        if ('r:' . $a['id'] === $step) return strtr(gcTxt('ask_rate', $lang), ['{n}' => (string)($n + 1), '{t}' => (string)count($asp), '{a}' => gcAspLabel($a, $lang)]);
    }
    return '';
}
function gcThanks($conf, $lang) {
    $t = trim((string)($lang === 'en' ? ($conf['thanks_en'] ?: $conf['thanks']) : $conf['thanks']));
    if ($conf['review_url'] !== '') {
        $r = trim((string)($lang === 'en' ? ($conf['review_text_en'] ?: $conf['review_text']) : $conf['review_text']));
        if ($r === '') $r = '{link}';
        if (strpos($r, '{link}') === false) $r .= ' {link}';
        $t .= "\n\n" . str_replace('{link}', $conf['review_url'], $r);
    }
    return $t;
}
// Dipanggil dari waProcessIncoming sebelum handoff/AI. true = pesan sudah ditangani alur survei.
function gcWaHandle($s, $wa, $from, $text, $senderName, $metaInfo) {
    if (!empty($metaInfo['_no_reply']) || !empty($metaInfo['_media'])) {
        // stiker/media: biarkan alur biasa, sesi survei tetap menunggu
        return false;
    }
    $num = waNormNum($from);
    if ($num === '' || !gcActive()) return false;
    $conf = gcConf();
    $st = gcSessGet($num);
    if (!$st && !gcMatchKeyword($text, $conf)) return false;
    $lic = getLicenseStatus($s);
    if (deiLicOff($lic['status'] ?? '')) return false;   // v1.2.111

    $reply = '';
    if (!$st) {
        $lang = gcLangOf($text);
        $room = preg_match('/#\s*([A-Za-z0-9][A-Za-z0-9-]{0,9})/u', (string)$text, $m) ? $m[1] : '';
        $steps = [];
        if ($conf['ask_name']) $steps[] = 'name';
        if ($conf['ask_room'] && $room === '') $steps[] = 'room';
        foreach ($conf['aspects'] as $a) $steps[] = 'r:' . $a['id'];
        $steps[] = 'comment';
        $st = ['lang' => $lang, 'steps' => $steps, 'i' => 0, 'name' => $conf['ask_name'] ? '' : mb_substr(trim((string)$senderName), 0, 60),
               'room' => $room, 'ratings' => [], 'comment' => '', 'bad' => 0, 'ch' => (string)($wa['_ch'] ?? ''), 'started' => time()];
        $intro = trim((string)($lang === 'en' ? ($conf['intro_en'] ?: $conf['intro']) : $conf['intro']));
        $reply = ($intro !== '' ? $intro . "\n\n" : '') . gcQuestion($st, $conf) . "\n" . gcTxt('stop_hint', $lang);
        gcSessPut($num, $st);
    } elseif (gcIsCancel($text)) {
        gcSessPut($num, null);
        $reply = gcTxt('cancelled', $st['lang']);
    } else {
        $step = $st['steps'][$st['i']] ?? 'comment';
        $t = trim((string)$text);
        $advance = true;
        if ($step === 'name') {
            $st['name'] = gcIsSkip($t) ? mb_substr(trim((string)$senderName), 0, 60) : mb_substr($t, 0, 60);
        } elseif ($step === 'room') {
            $st['room'] = gcIsSkip($t) ? '' : mb_substr(preg_replace('/^(kamar|room|meja|table|no\.?|nomor|kode|order|pesanan|booking)\s*/iu', '', $t), 0, 20);
        } elseif ($step === 'comment') {
            $st['comment'] = gcIsSkip($t) ? '' : mb_substr($t, 0, 2000);
        } else {
            $r = gcParseRating($t);
            if ($r > 0) { $st['ratings'][substr($step, 2)] = $r; $st['bad'] = 0; }
            elseif (gcIsSkip($t) && $st['bad'] >= 1) { $st['bad'] = 0; }   // tamu memang tidak mau menilai aspek ini
            else { $advance = false; $st['bad']++; }
        }
        if (!$advance) {
            $reply = gcTxt('bad_rate', $st['lang']) . "\n\n" . gcQuestion($st, $conf);
            if ($st['bad'] >= 3) {   // jelas bukan menjawab survei -> hentikan, lanjut ke bot biasa
                gcSessPut($num, null);
                return false;
            }
            gcSessPut($num, $st);
        } else {
            $st['i']++;
            if ($st['i'] >= count($st['steps'])) {
                gcSessPut($num, null);
                $entry = gcStore(['channel' => 'whatsapp', 'num' => $num, 'name' => $st['name'], 'room' => $st['room'],
                                  'lang' => $st['lang'], 'ratings' => $st['ratings'], 'comment' => $st['comment'], 'wa_ch' => $st['ch']]);
                $reply = gcThanks($conf, $st['lang']);
            } else {
                gcSessPut($num, $st);
                $reply = gcQuestion($st, $conf);
            }
        }
    }
    // kirim + catat (dihitung sebagai pesan sistem: tidak menambah hitungan Batas Balasan AI)
    $reply = stripMarkdownIfEnabled($reply, $s);
    if (waSend($wa, $from, $reply)) convReply($from, 'system');
    if ($wa['keep_context'] ?? true) {
        $h = waLoadHistory($from);
        $h[] = ['role' => 'user', 'content' => $text];
        $h[] = ['role' => 'assistant', 'content' => $reply];
        waSaveHistory($from, $h);
    }
    $log = ['ts' => date('Y-m-d H:i:s'), 'q' => $text, 'a' => $reply, 'ip' => $from, 'channel' => 'whatsapp', 'utm_source' => 'whatsapp',
            'utm_medium' => 'chat', 'utm_campaign' => '', 'page' => '', 'referrer' => '', 'gc' => 1];
    if (!empty($wa['_ch'])) $log['wa_ch'] = (string)$wa['_ch'];
    logPrepend($log, (int)($s['api']['log_limit'] ?? 500));
    return true;
}
function gcRefLabel($c, $lang) { return ($lang === 'en' && trim((string)($c['ref_label_en'] ?? '')) !== '') ? $c['ref_label_en'] : (string)($c['ref_label'] ?? 'Nomor pesanan'); }
// Instruksi tambahan ke AI supaya pelanggan yang ingin memberi masukan diarahkan ke survei.
function gcPromptBlock($channel) {
    if (!gcActive()) return '';
    $c = gcConf();
    if (!$c['ai_hint']) return '';
    if ($channel === 'whatsapp') {
        return "=== CUSTOMER FEEDBACK ===\nJika pelanggan ingin memberi kesan, komentar, saran, keluhan, atau penilaian tentang produk/layanan, minta pelanggan mengetik persis: "
             . mb_strtoupper($c['keywords'][0], 'UTF-8') . " (sistem akan memandu survei singkat 1 menit). Jangan mengumpulkan penilaian sendiri.";
    }
    $u = gcFormUrl();
    if ($u === '') return '';
    return "=== CUSTOMER FEEDBACK ===\nJika pelanggan ingin memberi kesan, komentar, saran, keluhan, atau penilaian tentang produk/layanan, arahkan ke form feedback singkat ini: " . $u;
}
function gcPublicConf($lang) {
    $c = gcConf();
    $asp = [];
    foreach ($c['aspects'] as $a) $asp[] = ['id' => $a['id'], 'label' => $a['label'], 'label_en' => $a['label_en']];
    return ['aspects' => $asp, 'ask_name' => $c['ask_name'], 'ask_room' => $c['ask_room'], 'ask_phone' => $c['ask_phone_web'],
            'ref' => gcRefLabel($c, 'id'), 'ref_en' => gcRefLabel($c, 'en'),
            'intro' => $c['intro'], 'intro_en' => $c['intro_en'], 'thanks' => $c['thanks'], 'thanks_en' => $c['thanks_en'],
            'review_url' => $c['review_url'], 'review_text' => $c['review_text'], 'review_text_en' => $c['review_text_en']];
}
function gcFormHtml($s, $active, $room) {
    $J = JSON_UNESCAPED_UNICODE | JSON_UNESCAPED_SLASHES | JSON_HEX_TAG | JSON_HEX_AMP | JSON_HEX_APOS | JSON_HEX_QUOT;
    $name = deiTenantName($s);
    $color = (string)($s['appearance']['primary_color'] ?? '#140383');
    if (!preg_match('/^#[0-9a-fA-F]{3,8}$/', $color)) $color = '#140383';
    $logo = (string)($s['appearance']['avatar_image'] ?? '');
    if ($logo !== '' && !preg_match('~^(https?://|/|data:image/)~', $logo)) $logo = '';
    $data = ['active' => $active, 'room' => $room, 'name' => $name, 'logo' => $logo,
             'conf' => $active ? gcPublicConf('id') : null, 'api' => '?action=gc_submit',
             'langs' => (array)($s['bot']['languages'] ?? ['id'])];
    $h = function ($x) { return htmlspecialchars((string)$x, ENT_QUOTES, 'UTF-8'); };
    ob_start(); ?>
<!doctype html>
<html lang="id"><head><meta charset="utf-8"><meta name="viewport" content="width=device-width,initial-scale=1">
<title>Customer Feedback · <?= $h($name) ?></title><meta name="robots" content="noindex">
<style>
:root{--c:<?= $h($color) ?>;--ink:#1d1d2b;--mut:#6b6b80;--line:#e5e5ee;--bg:#f5f5f9}
*{box-sizing:border-box}body{margin:0;font:16px/1.5 system-ui,-apple-system,"Segoe UI",Roboto,sans-serif;color:var(--ink);background:var(--bg)}
.w{max-width:560px;margin:0 auto;padding:20px 16px 40px}
.hd{display:flex;align-items:center;gap:12px;margin-bottom:14px}.hd img{width:44px;height:44px;border-radius:12px;object-fit:cover}
.hd b{font-size:17px;display:block}.hd small{color:var(--mut)}
.lg{margin-left:auto;display:flex;border:1px solid var(--line);border-radius:999px;overflow:hidden;background:#fff}
.lg button{border:0;background:none;padding:6px 12px;font:600 13px system-ui;cursor:pointer;color:var(--mut)}.lg button.on{background:var(--c);color:#fff}
.card{background:#fff;border:1px solid var(--line);border-radius:16px;padding:18px;margin-bottom:14px}
.intro{margin:0;color:#3a3a4c}
label.f{display:block;font-weight:600;font-size:14px;margin:0 0 6px}
input[type=text],input[type=tel],textarea{width:100%;border:1px solid var(--line);border-radius:10px;padding:11px 12px;font:inherit;background:#fff}
input:focus,textarea:focus{outline:2px solid color-mix(in srgb,var(--c) 35%,transparent);border-color:var(--c)}
.row{margin-bottom:14px}.row:last-child{margin-bottom:0}.g2{display:grid;grid-template-columns:1fr 1fr;gap:12px}
.asp{padding:12px 0;border-top:1px solid var(--line)}.asp:first-child{border-top:0;padding-top:0}
.asp .t{font-weight:600;margin-bottom:8px}
.stars{display:flex;gap:6px}.stars button{flex:1;min-width:0;height:46px;border:1px solid var(--line);border-radius:10px;background:#fff;font:600 16px system-ui;color:var(--mut);cursor:pointer}
.stars button.on{background:var(--c);border-color:var(--c);color:#fff}
.scale{display:flex;justify-content:space-between;font-size:12px;color:var(--mut);margin-top:4px}
.btn{width:100%;border:0;border-radius:12px;background:var(--c);color:#fff;font:600 16px system-ui;padding:14px;cursor:pointer}
.btn[disabled]{opacity:.6}.err{color:#b42318;font-size:14px;margin:10px 0 0;display:none}
.done{text-align:center;padding:32px 18px}.done .ic{font-size:44px}.done a.btn{display:inline-block;text-decoration:none;width:auto;padding:12px 22px;margin-top:10px}
.hp{position:absolute;left:-9999px}.ft{text-align:center;color:var(--mut);font-size:12px;margin-top:18px}
@media (max-width:380px){.g2{grid-template-columns:1fr}.stars button{height:42px}}
</style></head><body><div class="w" id="app"></div>
<script>
(function(){
var D=<?= json_encode($data, $J) ?>;
var L=(navigator.language||'id').slice(0,2)==='en'&&D.langs.indexOf('en')>=0?'en':'id';
try{var q=new URLSearchParams(location.search).get('lang');if(q==='en'||q==='id')L=q;}catch(e){}
var R={};var st={sent:false};
var T={id:{t:'Customer Feedback',name:'Nama',phone:'No. HP / WhatsApp (opsional)',cm:'Komentar & saran',cmp:'Ceritakan pengalaman Anda, atau hal yang perlu kami perbaiki…',
 lo:'Sangat buruk',hi:'Sangat baik',send:'Kirim',sending:'Mengirim…',need:'Mohon beri nilai untuk semua aspek.',fail:'Gagal mengirim. Coba lagi.',off:'Form feedback belum tersedia.',again:'Isi lagi'},
 en:{t:'Customer Feedback',name:'Name',phone:'Phone / WhatsApp (optional)',cm:'Comments & suggestions',cmp:'Tell us about your experience, or anything we should improve…',
 lo:'Very poor',hi:'Excellent',send:'Submit',sending:'Sending…',need:'Please rate every aspect.',fail:'Could not submit. Please try again.',off:'The feedback form is not available.',again:'Submit another'}};
function e(s){return String(s==null?'':s).replace(/[&<>"']/g,function(c){return{'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'}[c];});}
function x(k){return T[L][k];}
function pick(a,b){return L==='en'&&b?b:a;}
function head(){return '<div class="hd">'+(D.logo?'<img src="'+e(D.logo)+'" alt="">':'')+'<div><b>'+e(D.name)+'</b><small>'+x('t')+'</small></div>'+
 ('<div class="lg"><button type="button" data-l="id" class="'+(L==='id'?'on':'')+'">ID</button><button type="button" data-l="en" class="'+(L==='en'?'on':'')+'">EN</button></div>')+'</div>';}
function draw(){
 var a=document.getElementById('app'),C=D.conf,h=head();
 if(!D.active){a.innerHTML=h+'<div class="card done"><div class="ic">🛎️</div><p>'+x('off')+'</p></div>';wire();return;}
 if(st.sent){var rv=C.review_url?pick(C.review_text,C.review_text_en)||'{link}':'';
  var rb='';if(C.review_url){var parts=rv.split('{link}');rb='<p>'+e(parts[0]).replace(/\n/g,'<br>')+'</p><a class="btn" href="'+e(C.review_url)+'" target="_blank" rel="noopener">Google Review ★</a>'+(parts[1]?'<p>'+e(parts[1])+'</p>':'');}
  a.innerHTML=h+'<div class="card done"><div class="ic">🙏</div><p>'+e(pick(C.thanks,C.thanks_en)).replace(/\n/g,'<br>')+'</p>'+rb+'</div>';wire();return;}
 var f='<form id="f" novalidate><div class="card"><p class="intro">'+e(pick(C.intro,C.intro_en)).replace(/\n/g,'<br>')+'</p></div><div class="card">';
 if(C.ask_name||C.ask_room){f+='<div class="'+(C.ask_name&&C.ask_room?'g2 ':'')+'row">';
  if(C.ask_name)f+='<div><label class="f" for="nm">'+x('name')+'</label><input type="text" id="nm" maxlength="60" autocomplete="name" value="'+e(st.nm||'')+'"></div>';
  if(C.ask_room)f+='<div><label class="f" for="rm">'+e(pick(C.ref,C.ref_en))+'</label><input type="text" id="rm" maxlength="20" value="'+e(st.rm!=null?st.rm:D.room)+'"></div>';
  f+='</div>';}
 if(C.ask_phone)f+='<div class="row"><label class="f" for="ph">'+x('phone')+'</label><input type="tel" id="ph" maxlength="20" autocomplete="tel" value="'+e(st.ph||'')+'"></div>';
 f+='</div><div class="card">';
 C.aspects.forEach(function(s){f+='<div class="asp"><div class="t">'+e(pick(s.label,s.label_en))+'</div><div class="stars" data-a="'+e(s.id)+'">';
  for(var i=1;i<=5;i++)f+='<button type="button" data-v="'+i+'" class="'+(R[s.id]>=i?'on':'')+'" aria-label="'+i+'">'+i+'</button>';
  f+='</div><div class="scale"><span>'+x('lo')+'</span><span>'+x('hi')+'</span></div></div>';});
 f+='</div><div class="card"><label class="f" for="cm">'+x('cm')+'</label><textarea id="cm" rows="4" maxlength="2000" placeholder="'+x('cmp')+'">'+e(st.cm||'')+'</textarea>'+
  '<input class="hp" type="text" id="hp" tabindex="-1" autocomplete="off"></div><button class="btn" id="sb" type="submit">'+x('send')+'</button><p class="err" id="er"></p></form>';
 a.innerHTML=h+f;wire();
}
function keep(){var g=function(i){var el=document.getElementById(i);return el?el.value:undefined;};st.nm=g('nm');st.rm=g('rm');st.ph=g('ph');st.cm=g('cm');}
function wire(){
 Array.prototype.forEach.call(document.querySelectorAll('.lg button'),function(b){b.onclick=function(){keep();L=b.dataset.l;draw();};});
 Array.prototype.forEach.call(document.querySelectorAll('.stars button'),function(b){b.onclick=function(){var p=b.parentNode;R[p.dataset.a]=+b.dataset.v;
  Array.prototype.forEach.call(p.children,function(c){c.classList.toggle('on',+c.dataset.v<=+b.dataset.v);});};});
 var f=document.getElementById('f');if(!f)return;
 f.onsubmit=function(ev){ev.preventDefault();keep();var er=document.getElementById('er');er.style.display='none';
  for(var i=0;i<D.conf.aspects.length;i++){if(!R[D.conf.aspects[i].id]){er.textContent=x('need');er.style.display='block';return;}}
  var sb=document.getElementById('sb');sb.disabled=true;sb.textContent=x('sending');
  fetch(D.api,{method:'POST',headers:{'Content-Type':'application/json'},body:JSON.stringify({name:st.nm||'',room:st.rm||'',phone:st.ph||'',comment:st.cm||'',ratings:R,lang:L,hp:document.getElementById('hp').value})})
  .then(function(r){return r.json();}).then(function(j){if(j&&j.ok){st.sent=true;draw();window.scrollTo(0,0);}else{throw new Error(j&&j.error||'');}})
  .catch(function(err){sb.disabled=false;sb.textContent=x('send');er.textContent=err.message||x('fail');er.style.display='block';});};
}
draw();
})();
</script></body></html>
<?php
    return ob_get_clean();
}

function waProcessIncoming($s, $wa, $from, $text, $senderName = '', $metaInfo = []) {
    $logLimit = (int)($s['api']['log_limit'] ?? 500);
    $keepCtx  = ($wa['keep_context'] ?? true);

    // v1.2.8 Fase 3: push notif ke semua subscriber saat WA text masuk
    $deiPushSubsFile = DATA_DIR . '/push-subs.json';
    if (file_exists($deiPushSubsFile)) {
        $deiPushSubs = json_decode(file_get_contents($deiPushSubsFile), true);
        if (is_array($deiPushSubs) && !empty($deiPushSubs)) {
            $deiPushPreview = mb_substr($text, 0, 80);
            $deiWaTopic = detectTopicFromMessage($text);  // v1.2.12: auto-assign by topic
            $deiWaTargets = getPushTargetsByTopic($deiWaTopic, array_keys($deiPushSubs));
            sendPushToUsers($deiWaTargets, 'Pesan WA: +' . $from, $deiPushPreview, deiDashboardUrl());
        }
    }

    // === WA-to-Ads tracker (deintegra lead) — fire & forget ===
    $wtMeta = $metaInfo;
    $wtPn  = preg_replace('/\D/','', $wtMeta['display_phone_number'] ?? '');
    $wtPid = (string)($wtMeta['phone_number_id'] ?? '');
    if ($wtPid === '1247385528447121' || $wtPn === '6285111230487') {
        $wtPayload = json_encode(['phone'=>$from, 'message'=>$text, 'name'=>$senderName, 'token'=>'a72243cc6cec300146cbaef6a0b14490']);  // v1.2.19: nama kini terisi
        if (function_exists('curl_init')) {
            $wtCh = curl_init('https://deintegra.com/wa-tracker/fn-hook.php');
            curl_setopt_array($wtCh, [CURLOPT_POST=>true, CURLOPT_HTTPHEADER=>['Content-Type: application/json'], CURLOPT_POSTFIELDS=>$wtPayload, CURLOPT_RETURNTRANSFER=>true, CURLOPT_TIMEOUT=>3, CURLOPT_SSL_VERIFYPEER=>false]);
            @curl_exec($wtCh); @curl_close($wtCh);
        }
    }
    if (mb_strlen($text) > 2000) $text = mb_substr($text, 0, 2000);

    $limit = (int)($wa['rate_limit_per_number'] ?? ($s['api']['rate_limit'] ?? 20));
    // v1.2.58: mode Manual tidak memakai AI (tidak ada biaya), jangan buang pesan
    // pelanggan & jangan kirim balasan otomatis "terlalu banyak pesan".
    if (!deiIsManual($s) && !checkRateLimit('wa:' . $from, $limit)) {
        if (deiSysOnce($from, 'ratelimit', 600)) waSend($wa, $from, 'Anda mengirim terlalu banyak pesan. Mohon tunggu sebentar ya.');
        else waOutCount('saved');   // v1.2.89
        return;
    }

    // v1.2.37: bereskan claim & mode kedaluwarsa SEBELUM memutuskan siapa yang
    // menjawab. Sebelumnya keduanya hanya diproses saat dashboard dibuka —
    // agent yang pulang tanpa melepas percakapan membuat bot diam semalaman.
    try {
        waClaimAutoProcess();
        waModeSweepIdle();
    } catch (\Throwable $e) { error_log('sapu mode/claim: ' . $e->getMessage()); }
    convGuestMsg($from, $text, (string)($wa['_ch'] ?? ''));   // v1.2.56 + v1.2.101: jejak untuk auto-closing & eskalasi

    // --- Handoff logic ---
    $ho = is_array($s['handoff'] ?? null) ? $s['handoff'] : [];
    $mode = waGetMode($from);
    // v1.2.109: guest-comment — survei terpandu (sebelum handoff kata kunci & batas AI; tanpa panggilan AI)
    if ($mode === 'bot' && !deiIsManual($s)) {
        try { if (gcWaHandle($s, $wa, $from, $text, $senderName, $metaInfo)) return; }
        catch (\Throwable $e) { error_log('guest-comment: ' . $e->getMessage()); }
    }
    // Auto-handoff: a keyword flips this number to human mode.
    if ($mode === 'bot' && !empty($ho['enabled']) && waMatchHandoff($text, $ho['keywords'] ?? [])) {
        waSetMode($from, 'human', 'keyword');
        $mode = 'human';
    }
    // v1.2.97: batas-ai — AI sudah membalas N kali: serahkan ke agent (ucapan penutup & stiker tidak memicu)
    $deiAiLim = deiAiLimitConf($s); $deiAiLimitHit = false;
    if ($mode === 'bot' && $deiAiLim['max'] > 0 && !deiIsManual($s) && empty($metaInfo['_no_reply'])
        && !deiIsClosingPhrase($text) && convBotCount($from) >= $deiAiLim['max']) {
        waSetMode($from, 'human', 'ai_limit');
        $mode = 'human';
        $deiAiLimitHit = true;
    }

    $logBase = [
        'ts'           => date('Y-m-d H:i:s'),
        'q'            => $text,
        'ip'           => $from,
        'channel'      => 'whatsapp',
        'utm_source'   => 'whatsapp',
        'utm_medium'   => 'chat',
        'utm_campaign' => '',
        'page'         => '',
        'referrer'     => '',
    ];
    if (isset($metaInfo['_q_show'])) $logBase['q'] = (string)$metaInfo['_q_show'];   // v1.2.94: wa-media
    if (!empty($metaInfo['_media'])) $logBase['media'] = $metaInfo['_media'];
    if (!empty($wa['_ch'])) $logBase['wa_ch'] = (string)$wa['_ch'];   // v1.2.98: multi-nomor

    if ($mode === 'human') {
        // Admin is handling this number — record, notify, do NOT auto-reply.
        deiRouteAssign($from, (string)($wa['_ch'] ?? ''), $s);   // v1.2.100: routing (lewati bila sudah diklaim / routing mati)
        $deiAiLimA = '';   // v1.2.97: batas-ai — pesan serah terima (sekali, saat batas tercapai)
        if ($deiAiLimitHit && $deiAiLim['text'] !== '' && waSend($wa, $from, $deiAiLim['text'])) $deiAiLimA = $deiAiLim['text'];
        if ($keepCtx) {
            $history = waLoadHistory($from);
            $history[] = ['role' => 'user', 'content' => $text];
            if ($deiAiLimA !== '') $history[] = ['role' => 'assistant', 'content' => $deiAiLimA];
            waSaveHistory($from, $history);
        }
        logPrepend(array_merge($logBase, ['a' => $deiAiLimA, 'awaiting' => true], $deiAiLimitHit ? ['ai_limit' => true] : []), $logLimit);
        tgNotify($s, "\xF0\x9F\x93\xA9 [WhatsApp] " . $from . ":\n\"" . $text . "\"\n\xF0\x9F\x99\x8B "
            . ($deiAiLimitHit ? 'batas ' . $deiAiLim['max'] . ' balasan AI tercapai — menunggu admin' : 'menunggu admin'));
        try { agentEvent('in', '', $from); } catch (\Throwable $e) {}   // v1.2.58: volume masuk untuk laporan
        return;
    }

    // v1.2.94: wa-media: stiker tanpa caption = seperti ucapan penutup, dicatat tanpa dibalas
    if (!empty($metaInfo['_no_reply'])) {
        if ($keepCtx) { $hSt = waLoadHistory($from); $hSt[] = ['role' => 'user', 'content' => $text]; waSaveHistory($from, $hSt); }
        logPrepend(array_merge($logBase, ['a' => '', 'hemat' => 'ack']), $logLimit);
        waOutCount('saved');
        return;
    }
    // v1.2.89: ucapan penutup ("ok makasih", 👍) setelah jawaban bot yang bukan pertanyaan -> tidak dibalas
    $hemat = deiHematConf($s);
    if ($hemat['skip_ack'] && $keepCtx && trim($text) !== '' && deiIsClosingPhrase($text)) {
        $hAck = waLoadHistory($from);
        $lastT = end($hAck);
        $lastA = (is_array($lastT) && ($lastT['role'] ?? '') === 'assistant') ? rtrim((string)($lastT['content'] ?? '')) : '';
        if ($lastA !== '' && mb_strpos(mb_substr($lastA, -25), '?') === false) {
            $hAck[] = ['role' => 'user', 'content' => $text];
            waSaveHistory($from, $hAck);
            logPrepend(array_merge($logBase, ['a' => '', 'hemat' => 'ack']), $logLimit);
            waOutCount('saved');
            return;
        }
    }

    // Bot mode — generate and send an automatic answer.
    // v1.1.3: license enforcement
    $lic = getLicenseStatus($s);
    if (deiLicOff($lic['status'])) {   // v1.2.111
        $answer = $lic['message'] ?: LIC_DEFAULT_SUSPEND_MSG;
        if (!deiSysOnce($from, 'suspended', 21600)) { waOutCount('saved'); logPrepend(array_merge($logBase, ['a' => '', 'suspended' => true]), $logLimit); return; }   // v1.2.89
        if (waSend($wa, $from, $answer)) convReply($from, 'system');   // v1.2.56
        logPrepend(array_merge($logBase, ['a' => $answer, 'suspended' => true]), $logLimit);
        return;
    }
    // v1.1.4: cap enforcement (graceful at 90%+, no Claude call)
    $cap = getCapStatus($s);
    if ($cap['reached'] || $cap['warning']) {
        $answer = $cap['message'] ?: CAP_DEFAULT_MSG;
        if (!deiSysOnce($from, 'cap', 21600)) { waOutCount('saved'); logPrepend(array_merge($logBase, ['a' => '', 'cap_reached' => true]), $logLimit); return; }   // v1.2.89
        if (waSend($wa, $from, $answer)) convReply($from, 'system');   // v1.2.56
        logPrepend(array_merge($logBase, ['a' => $answer, 'cap_reached' => true]), $logLimit);
        return;
    }
    $history = $keepCtx ? waLoadHistory($from) : [];
    $deiT0 = microtime(true);   // v1.2.96: jeda-balasan
    deiTypingStart($s, $wa, $from);   // v1.2.96: mengetik
    list($ok, $answer, $_kbUsed, $usage) = generateAnswer($s, $text, $history, 'whatsapp');   // v1.2.89
    $answer0 = $answer;   // v1.2.102
    $deiFotoIds = [];   // v1.2.95: kb-foto
    if ($ok) list($answer, $deiFotoIds) = deiKbFotoExtract($answer);
    // v1.2.5: strip markdown kalau rule no_asterisk aktif (WA channel)
    $answer = stripMarkdownIfEnabled($answer, $s);
    $deiAiError = false;   // v1.2.17
    if (!$ok || (trim($answer) === '' && !$deiFotoIds)) {   // v1.2.95: kb-foto: jawaban boleh hanya foto
        $answer = 'Maaf, saya sedang mengalami gangguan. Silakan coba lagi sebentar lagi.';
        $deiAiError = true;
        if (empty($GLOBALS['dei_ai_last_err'])) $GLOBALS['dei_ai_last_err'] = $ok ? 'jawaban AI kosong' : mb_substr((string)$answer0, 0, 200);   // v1.2.102
        error_log('[ai_fail] wa ' . $from . ': ' . (string)$GLOBALS['dei_ai_last_err']);
        // v1.2.72 (server sendiri): 'ai_fail_handoff' => true -> agent yang lanjut, pelanggan tidak disuruh mencoba lagi
        if (!empty(deiServerConf()['ai_fail_handoff'])) {
            $answer = (string)(deiServerConf()['ai_fail_text'] ?? 'Terima kasih, pesan Anda sudah kami terima. Tim kami akan segera membalas.');
            try { waSetMode($from, 'human', 'ai_fail'); } catch (\Throwable $e) { error_log('ai_fail_handoff: ' . $e->getMessage()); }
            tgNotify($s, "\xE2\x9A\xA0\xEF\xB8\x8F [WhatsApp] AI gagal menjawab +" . $from . " \xE2\x80\x94 dialihkan ke agent:\n\"" . $text . "\"");
        }
    } else {
        recordUsage($usage);
    }
    if (!$deiAiError) deiReplyDelayWait($s, $text, $answer, $deiT0);   // v1.2.96: jeda-balasan
    deiTypingStop($wa, $from);   // v1.2.96: mengetik
    $deiSent = (trim($answer) !== '') ? waSend($wa, $from, $answer) : true;   // v1.2.95: kb-foto
    $deiFotoOut = []; $deiFotoJudul = []; $deiFotoKirim = [];
    if (!$deiAiError && $deiFotoIds) {
        try { list($deiFotoOut, $deiFotoJudul, $deiFotoKirim) = deiKbFotoSend($wa, $from, $deiFotoIds); }
        catch (\Throwable $e) { error_log('kb-foto: ' . $e->getMessage()); }
        if (trim($answer) === '' && !$deiFotoOut) {   // AI hanya menulis kode tapi foto gagal terkirim
            $answer = 'Mohon maaf, fotonya belum bisa kami kirim saat ini. Admin kami akan membantu mengirimkannya.';
            $deiSent = waSend($wa, $from, $answer);
        }
    }
    if ($deiSent && !$deiAiError) convReply($from, 'bot');   // v1.2.56

    if ($keepCtx) {
        $history[] = ['role' => 'user', 'content' => $text];
        $history[] = ['role' => 'assistant', 'content' => trim($answer . ($deiFotoKirim ? "\n[[FOTO:" . implode(']] [[FOTO:', $deiFotoKirim) . ']]' : ''))];   // v1.2.95: kb-foto
        waSaveHistory($from, $history);
    }

    $deiLogA = (trim($answer) !== '') ? $answer : ('[Foto: ' . implode(', ', array_filter($deiFotoJudul)) . ']');   // v1.2.95: kb-foto
    $logs = logPrepend(array_merge($logBase, ['a' => $deiLogA], $deiAiError ? ['ai_error' => true, 'ai_err' => (string)($GLOBALS['dei_ai_last_err'] ?? '')] : [], $deiFotoOut ? ['media_out' => $deiFotoOut] : []), $logLimit);  // v1.2.17 + v1.2.58 kunci
    if (deiStorageMysql()) $logs = logReadByNumber($from, 400);   // v1.2.71

    // v1.2.20: kalau percakapan sudah mencapai ambang pesan dan belum
    // punya kartu lead, jalankan analisa SEKALI. Non-blocking —
    // kegagalan analisa tidak boleh mengganggu balasan ke customer.
    if (!$deiAiError) {
        try {
            $deiLeadNum = preg_replace('/\D/', '', (string)$from);
            $deiLeadCount = 0;
            foreach ($logs as $deiLogRow) {
                if (($deiLogRow['channel'] ?? '') !== 'whatsapp') continue;
                if (preg_replace('/\D/', '', (string)($deiLogRow['ip'] ?? '')) === $deiLeadNum) $deiLeadCount++;
            }
            if ($deiLeadCount >= LEAD_TRIGGER_MSGS) {
                leadAnalyzeNumber($s, $from, $logs, false);
            }
        } catch (\Throwable $e) { error_log('lead analyze: ' . $e->getMessage()); }
    }
    tgNotify($s, "\xF0\x9F\x93\xA9 [WhatsApp] " . $from . ":\n\"" . $text . "\"\n\xE2\x9C\x85 dijawab bot");
}

/* v1.2.71: isi kiriman webhook Meta — dipakai webhook (mode sync) dan worker (mode redis). */
function waHandleMetaPayload($s, $wa, $payload) {
    if (!is_array($payload)) return;
    // v1.2.93: wa-bot-off: tetap diproses walau bot mati (AI diam lewat deiReplyMode)
    // v1.2.76: WAHA memakai alur ini juga (payload-nya diterjemahkan ke bentuk Meta)
    if (!in_array(($wa['provider'] ?? 'meta'), ['meta', 'waha'], true)) return;
    $logLimit = (int)($s['api']['log_limit'] ?? 500);
    $keepCtx  = ($wa['keep_context'] ?? true);

    $waBase = $wa;   // v1.2.98: multi-nomor
    foreach (($payload['entry'] ?? []) as $entry) {
        foreach (($entry['changes'] ?? []) as $change) {
            $wa = waChanFromMeta($waBase, $change['value']['metadata'] ?? []);   // v1.2.98: multi-nomor
            if ($wa === null) {   // v1.2.99: lisensi-nomor
                error_log('wa: pesan ke nomor tambahan di luar paket diabaikan (' . mb_substr((string)($change['value']['metadata']['phone_number_id'] ?? ''), 0, 30) . ')');
                $wa = $waBase; continue;
            }
            $messages = $change['value']['messages'] ?? [];
            // v1.2.19: nama profil WhatsApp ada di value.contacts (sejajar messages),
            // bukan di dalam tiap pesan. Petakan wa_id -> nama dulu.
            $waProfileNames = [];
            foreach (($change['value']['contacts'] ?? []) as $wc) {
                $wcId = preg_replace('/\D/', '', (string)($wc['wa_id'] ?? ''));
                $wcNm = trim((string)($wc['profile']['name'] ?? ''));
                if ($wcId !== '' && $wcNm !== '') $waProfileNames[$wcId] = $wcNm;
            }
            foreach ($messages as $msg) {
                $from = $msg['from'] ?? '';
                if ($from === '') continue;
                // v1.2.71: satu nomor diproses berurutan (mode antrean); nomor lain paralel
                $meta = $change['value']['metadata'] ?? [];
                deiNumLock($from, function () use ($s, $wa, $msg, $waProfileNames, $meta) {
                    waHandleMetaMessage($s, $wa, $msg, $waProfileNames, $meta);
                });
            }

            /* v1.2.48: COEXISTENCE — pesan yang dikirim AGENT dari app HP (echo).
             * Tujuan: tampil di thread dashboard + bot otomatis mundur. */
            foreach (($change['value']['message_echoes'] ?? []) as $echo) {
                $eto = waNormNum($echo['to'] ?? ($echo['recipient_id'] ?? ''));
                if ($eto === '') continue;
                $etext = (($echo['type'] ?? '') === 'text') ? trim($echo['text']['body'] ?? '') : '';
                $emedia = null;   // v1.2.94: wa-media
                if (in_array((string)($echo['type'] ?? ''), deiWaMediaTypes(), true)) {
                    list($emedia, $etext) = deiWaMediaFromMsg($wa, $eto, $echo);
                }
                if ($etext === '') continue;
                try {
                    $eid = (string)($echo['id'] ?? '');
                    $dup = false;
                    // v1.2.58: cek duplikat + tulis di bawah satu kunci
                    logMutate(function (&$elogs) use ($eid, $etext, $eto, &$dup, $emedia) {
                        if ($eid !== '') { foreach ($elogs as $el) { if (($el['echo_id'] ?? '') === $eid) { $dup = true; return false; } } }
                        array_unshift($elogs, array_merge([
                            'ts' => date('Y-m-d H:i:s'), 'q' => '', 'a' => $etext, 'ip' => $eto,
                            'channel' => 'whatsapp', 'dir' => 'manual', 'src' => 'hp', 'echo_id' => $eid,
                            'utm_source' => 'whatsapp', 'utm_medium' => 'hp', 'utm_campaign' => '', 'page' => '', 'referrer' => '',
                        ], $emedia ? ['media' => $emedia] : []));   // v1.2.94: wa-media
                    }, $logLimit);
                    if ($dup && !empty($emedia['file'])) @unlink(WA_MEDIA_DIR . '/' . $emedia['file']);   // v1.2.94: wa-media: kiriman ulang
                    if (!$dup) {
                        if (!empty($wa['_ch'])) waContactSetCh($eto, $wa['_ch']);   // v1.2.98: multi-nomor
                        waSetMode($eto, 'human', 'agent_reply'); // agent balas dari HP = ambil alih -> bot mundur
                        $ecl = waClaimGet($eto);   // v1.2.58: atribusikan ke pemegang claim bila ada
                        deiRecordAgentReply($eto, $ecl ? ($ecl['agent_username'] ?? '(HP)') : '(HP)', 'hp');
                        convReply($eto, 'agent');   // v1.2.56
                        if ($keepCtx) { $eh = waLoadHistory($eto); $eh[] = ['role' => 'assistant', 'content' => $etext]; waSaveHistory($eto, $eh); }
                    }
                } catch (\Throwable $e) { error_log('wa echo: ' . $e->getMessage()); }
            }

            /* v1.2.48: COEXISTENCE — sinkronisasi kontak dari app HP. */
            $syncList = array_merge(
                (array)($change['value']['smb_app_state_sync'] ?? []),
                (array)($change['value']['state_sync'] ?? [])
            );
            foreach ($syncList as $sync) {
                $cn  = waNormNum($sync['contact']['phone_number'] ?? ($sync['wa_id'] ?? ($sync['phone_number'] ?? '')));
                $cnm = trim((string)($sync['contact']['full_name'] ?? ($sync['full_name'] ?? ($sync['name'] ?? ''))));
                if ($cn !== '') { try { waSaveContact($cn, $cnm); } catch (\Throwable $e) {} }
            }

            /* v1.2.48: COEXISTENCE — riwayat chat lama (best-effort, sekali saat onboarding).
             * Skema history bisa bervariasi; tulis apa yang bisa dibaca tanpa mengasumsikan terlalu dalam. */
            foreach (($change['value']['history'] ?? []) as $hist) {
                foreach (($hist['threads'] ?? []) as $thread) {
                    $hnum = waNormNum($thread['id'] ?? ($thread['contact_id'] ?? ''));
                    if ($hnum === '') continue;
                    $hrows = [];   // v1.2.58: dikumpulkan dulu, ditulis sekali di bawah kunci
                    foreach (($thread['messages'] ?? []) as $hm) {
                        if (($hm['type'] ?? '') !== 'text') continue;
                        $htext = trim($hm['text']['body'] ?? '');
                        if ($htext === '') continue;
                        $hfrom = waNormNum($hm['from'] ?? '');
                        $hts   = !empty($hm['timestamp']) ? date('Y-m-d H:i:s', (int)$hm['timestamp']) : date('Y-m-d H:i:s');
                        $outbound = ($hfrom !== '' && $hfrom !== $hnum); // dari nomor bisnis -> balasan
                        array_unshift($hrows, [
                            'ts' => $hts,
                            'q' => $outbound ? '' : $htext,
                            'a' => $outbound ? $htext : '',
                            'ip' => $hnum, 'channel' => 'whatsapp',
                            'dir' => $outbound ? 'manual' : 'in', 'src' => 'history',
                            'utm_source' => 'whatsapp', 'utm_medium' => 'history', 'utm_campaign' => '', 'page' => '', 'referrer' => '',
                        ]);
                    }
                    if ($hrows) logMutate(function (&$hlogs) use ($hrows) { $hlogs = array_merge($hrows, $hlogs); }, max($logLimit, 2000));
                }
            }
        }
    }
}

/* v1.2.72: DEBOUNCE (server sendiri, data/server.php 'debounce_sec' => 2).
 * Webhook mencatat teks tiap pesan ke buf:wa:<nomor> + waktu pesan terakhir.
 * Worker yang memegang kunci nomor menunggu sampai nomor itu diam debounce_sec
 * (maks 8 dtk), lalu menguras buffer: semua bubble jadi SATU panggilan AI.
 * Job pesan lain yang ikut tergabung nanti dilewati karena wamid-nya sudah ditandai. */
function deiDebounceSec() {
    if (!deiQueueRedis()) return 0.0;
    // v1.2.89: server.php 'debounce_sec' menang; kalau tidak diisi pakai pengaturan Hemat Pesan
    $sc = deiServerConf();
    return max(0.0, min(5.0, array_key_exists('debounce_sec', $sc) ? (float)$sc['debounce_sec'] : deiHematConf()['debounce_sec']));
}
/* v1.2.89: DEBOUNCE MODE FILE (shared hosting, tanpa Redis). Tiap webhook mencatat pesannya
 * di data/.debounce/<nomor>.json lalu menunggu sampai nomor itu diam N detik (maks 8).
 * Hanya proses yang pesannya PALING AKHIR yang menjawab — semua teks digabung jadi satu.
 * Proses lain berhenti tanpa membalas: [null, []]. Butuh webhook yang sudah ack ke Meta. */
function deiDebounceFileCollect($s, $num, $wamid, $text) {
    if (deiQueueRedis() || $wamid === '') return [$text, []];
    $sec = deiHematConf($s)['debounce_sec'];
    if ($sec <= 0) return [$text, []];
    if (PHP_SAPI !== 'cli' && !function_exists('fastcgi_finish_request') && !function_exists('litespeed_finish_request')) return [$text, []];
    $k = preg_replace('/\D/', '', (string)$num);
    if ($k === '') return [$text, []];
    $dir = DATA_DIR . '/.debounce';
    if (!is_dir($dir)) @mkdir($dir, 0755, true);
    $f = $dir . '/' . $k . '.json';
    $rw = function ($fn) use ($f, $k) {
        return deiWithLock('deb_' . $k, function () use ($f, $fn) {
            $items = is_file($f) ? json_decode((string)@file_get_contents($f), true) : [];
            if (!is_array($items)) $items = [];
            $batas = microtime(true) - 600;
            $items = array_values(array_filter($items, function ($it) use ($batas) { return is_array($it) && (float)($it['t'] ?? 0) > $batas; }));
            $res = $fn($items);
            if ($items) @file_put_contents($f, json_encode($items, JSON_UNESCAPED_UNICODE), LOCK_EX); else @unlink($f);
            return $res;
        });
    };
    try {
        $rw(function (&$items) use ($wamid, $text) { $items[] = ['id' => (string)$wamid, 'text' => $text, 't' => microtime(true)]; });
        $stop = microtime(true) + 8;
        while (microtime(true) < $stop) {
            $last = $rw(function (&$items) { $e = end($items); return $e ? (float)$e['t'] : 0.0; });
            $wait = $last + $sec - microtime(true);
            if ($wait <= 0) break;
            usleep((int)(min($wait, 0.5) * 1e6));
        }
        return $rw(function (&$items) use ($wamid) {
            $e = end($items);
            if (!$e || (string)$e['id'] !== (string)$wamid) return [null, []];   // ada pesan lebih baru -> dia yang menjawab
            $texts = []; $ids = [];
            foreach ($items as $it) {
                $id = (string)($it['id'] ?? '');
                if ($id === '' || isset($ids[$id])) continue;
                $ids[$id] = true;
                $t = trim((string)($it['text'] ?? ''));
                if ($t !== '') $texts[] = $t;
            }
            $items = [];
            return [implode("\n", $texts), array_keys($ids)];
        });
    } catch (\Throwable $e) {
        error_log('debounce file: ' . $e->getMessage());
        return [$text, []];
    }
}
function deiDebounceBuffer($payload) {
    if (deiDebounceSec() <= 0 || !is_array($payload)) return;
    try {
        $r = deiRedis();
        foreach (($payload['entry'] ?? []) as $en) foreach (($en['changes'] ?? []) as $ch) foreach (($ch['value']['messages'] ?? []) as $m) {
            if (($m['type'] ?? '') !== 'text') continue;
            $num = preg_replace('/\D/', '', (string)($m['from'] ?? ''));
            $txt = trim((string)($m['text']['body'] ?? ''));
            if ($num === '' || $txt === '') continue;
            $r->rPush('buf:wa:' . $num, json_encode(['id' => (string)($m['id'] ?? ''), 'text' => $txt], JSON_UNESCAPED_UNICODE));
            $r->expire('buf:wa:' . $num, 600);
            $r->set('last:wa:' . $num, (string)microtime(true), ['ex' => 600]);
        }
    } catch (\Throwable $e) { error_log('debounce buffer: ' . $e->getMessage()); }
}
// Kembalikan [teks gabungan, wamid yang ikut digabung]. Tanpa debounce: [teks sendiri, []].
function deiDebounceCollect($num, $wamid, $text) {
    $sec = deiDebounceSec();
    if ($sec <= 0) return [$text, []];
    try {
        $r = deiRedis();
        $k = preg_replace('/\D/', '', (string)$num);
        $stop = microtime(true) + 8;
        while (true) {
            $wait = (float)$r->get('last:wa:' . $k) + $sec - microtime(true);
            if ($wait <= 0 || microtime(true) > $stop) break;
            usleep((int)(min($wait, 0.5) * 1e6));
        }
        $res = $r->multi()->lRange('buf:wa:' . $k, 0, -1)->del('buf:wa:' . $k)->exec();
        $texts = []; $ids = [];
        foreach ((array)($res[0] ?? []) as $it) {
            $j = json_decode((string)$it, true);
            $id = (string)($j['id'] ?? '');
            if ($id === '' || isset($ids[$id])) continue;
            if ($id !== $wamid && waMsgSeen($id)) continue;          // sudah diproses sendiri sebelumnya
            $ids[$id] = true;
            $texts[] = trim((string)($j['text'] ?? ''));
        }
        if (!isset($ids[(string)$wamid])) { array_unshift($texts, $text); $ids[(string)$wamid] = true; }
        $texts = array_values(array_filter($texts, 'strlen'));
        return [implode("\n", $texts), array_keys($ids)];
    } catch (\Throwable $e) {
        error_log('debounce: ' . $e->getMessage());
        return [$text, []];
    }
}

/* v1.2.71: satu pesan masuk dari Meta. Kiriman ulang Meta (wamid sama) diabaikan. */
/* ============================================================================
 * v1.2.94: wa-media — MEDIA WhatsApp (gambar/video/audio/dokumen/stiker).
 * Diunduh saat pesan masuk (Meta: lewat media id; WAHA: media.url, file di WAHA
 * hanya bertahan ~3 menit) ke data/wa-media/<nomor>/, disajikan lewat action
 * wa_media (wajib login), dihapus otomatis setelah media_days hari (bawaan 7; pilihan 14/30).
 * Salinan asli tetap ada di HP / aplikasi WhatsApp Business.
 * ========================================================================= */
define('WA_MEDIA_DIR', DATA_DIR . '/wa-media');
define('WA_MEDIA_MAX_BYTES', 16 * 1024 * 1024);
function deiWaMediaTypes() { return ['image', 'video', 'audio', 'document', 'sticker', 'media']; }   // 'media' = WAHA tanpa mimetype
function deiWaMediaDays($s = null) {
    if ($s === null) $s = getSettings();
    $d = (int)($s['whatsapp_api']['media_days'] ?? 7);   // v1.2.94: media-days: bawaan 7, pilihan 7/14/30
    return in_array($d, [7, 14, 30], true) ? $d : 7;
}
function deiWaMediaLabel($type) {
    $m = ['image' => 'Gambar', 'video' => 'Video', 'audio' => 'Pesan suara', 'document' => 'Dokumen', 'sticker' => 'Stiker'];
    return $m[$type] ?? 'Media';
}
function deiWaMediaExt($mime, $fname = '') {
    $e = strtolower(pathinfo((string)$fname, PATHINFO_EXTENSION));
    if ($e !== '' && preg_match('/^[a-z0-9]{1,5}$/', $e) && !in_array($e, ['php', 'phtml', 'phar', 'html', 'htm', 'shtml', 'svg', 'js', 'cgi', 'pl', 'py'], true)) return $e;
    $mime = strtolower(trim(explode(';', (string)$mime)[0]));
    $map = ['image/jpeg' => 'jpg', 'image/png' => 'png', 'image/webp' => 'webp', 'image/gif' => 'gif',
            'video/mp4' => 'mp4', 'video/3gpp' => '3gp', 'video/webm' => 'webm', 'video/quicktime' => 'mov',
            'audio/ogg' => 'ogg', 'audio/mpeg' => 'mp3', 'audio/mp4' => 'm4a', 'audio/aac' => 'aac', 'audio/amr' => 'amr', 'audio/webm' => 'weba',
            'application/pdf' => 'pdf', 'text/plain' => 'txt', 'text/csv' => 'csv',
            'application/msword' => 'doc', 'application/vnd.openxmlformats-officedocument.wordprocessingml.document' => 'docx',
            'application/vnd.ms-excel' => 'xls', 'application/vnd.openxmlformats-officedocument.spreadsheetml.sheet' => 'xlsx',
            'application/vnd.ms-powerpoint' => 'ppt', 'application/vnd.openxmlformats-officedocument.presentationml.presentation' => 'pptx',
            'application/zip' => 'zip'];
    return $map[$mime] ?? 'bin';
}
/* GET dengan batas ukuran. Hasil: [kode HTTP, isi|null, content-type, pesan galat]. */
function deiHttpGetCapped($url, $headers, $max) {
    if (!function_exists('curl_init')) return [0, null, '', 'curl tidak ada'];
    $buf = ''; $over = false;
    $ch = curl_init($url);
    curl_setopt_array($ch, [
        CURLOPT_HTTPHEADER => $headers, CURLOPT_FOLLOWLOCATION => true, CURLOPT_MAXREDIRS => 3,
        CURLOPT_CONNECTTIMEOUT => 8, CURLOPT_TIMEOUT => 45, CURLOPT_USERAGENT => 'DEI-Chatbot/1.0',
        CURLOPT_WRITEFUNCTION => function ($c, $d) use (&$buf, &$over, $max) {
            if (strlen($buf) + strlen($d) > $max) { $over = true; return 0; }
            $buf .= $d; return strlen($d);
        },
    ]);
    curl_exec($ch);
    $code = (int)curl_getinfo($ch, CURLINFO_HTTP_CODE);
    $ct   = (string)curl_getinfo($ch, CURLINFO_CONTENT_TYPE);
    $err  = curl_error($ch);
    curl_close($ch);
    if ($over) return [$code, null, $ct, 'too_big'];
    if ($code < 200 || $code >= 300 || $buf === '') return [$code, null, $ct, $err !== '' ? $err : ('HTTP ' . $code)];
    return [$code, $buf, $ct, ''];
}
/* Ambil isi media. $m = objek media dari pesan (Meta: id/mime_type; WAHA: _waha_url). Hasil: [isi|null, mime, galat]. */
function deiWaMediaFetch($wa, $m) {
    $m = is_array($m) ? $m : [];
    if (array_key_exists('_waha_url', $m)) {
        $base = rtrim(trim((string)($wa['waha_url'] ?? '')), '/');
        $u = parse_url((string)$m['_waha_url']);
        $path = (string)($u['path'] ?? '') . (isset($u['query']) ? '?' . $u['query'] : '');
        if ($base === '' || $path === '') return [null, '', 'url media WAHA kosong (WAHA_DOWNLOAD_MEDIA mati?)'];
        list(, $b, $ct, $e) = deiHttpGetCapped($base . $path, ['X-Api-Key: ' . (string)($wa['waha_api_key'] ?? '')], WA_MEDIA_MAX_BYTES);
        return [$b, (string)($m['mime_type'] ?? '') ?: $ct, $e];
    }
    $id = (string)($m['id'] ?? '');
    $tok = (string)($wa['access_token'] ?? '');
    if ($id === '' || $tok === '') return [null, '', 'media id kosong'];
    list(, $j, , $e) = deiHttpGetCapped('https://graph.facebook.com/v21.0/' . rawurlencode($id), ['Authorization: Bearer ' . $tok], 65536);
    $d = json_decode((string)$j, true);
    if (!is_array($d) || empty($d['url'])) return [null, '', 'info media: ' . ($e ?: 'kosong')];
    if ((int)($d['file_size'] ?? 0) > WA_MEDIA_MAX_BYTES) return [null, '', 'too_big'];
    list(, $b, $ct, $e) = deiHttpGetCapped((string)$d['url'], ['Authorization: Bearer ' . $tok], WA_MEDIA_MAX_BYTES);
    return [$b, (string)($d['mime_type'] ?? '') ?: $ct, $e];
}
/* Unduh & simpan. Hasil meta: {type, file, mime, name, size} atau {type, error}. */
function deiWaMediaStore($wa, $num, $msgId, $type, $m) {
    $num = preg_replace('/\D/', '', (string)$num);
    $name = trim((string)($m['filename'] ?? ''));
    $meta = ['type' => $type];
    if ($name !== '') $meta['name'] = mb_substr($name, 0, 120);
    try { deiWaMediaSweep(); } catch (\Throwable $e) {}
    if ($num === '') { $meta['error'] = 'unavailable'; return $meta; }
    list($bytes, $mime, $err) = deiWaMediaFetch($wa, $m);
    if ($bytes === null) {
        $meta['error'] = ($err === 'too_big') ? 'too_big' : 'unavailable';
        if ($err !== 'too_big') error_log('wa-media: gagal unduh ' . $type . ' dari ' . $num . ' — ' . mb_substr((string)$err, 0, 160));
        return $meta;
    }
    $dir = WA_MEDIA_DIR . '/' . $num;
    if (!is_dir($dir)) @mkdir($dir, 0755, true);
    $fn = substr(sha1($msgId . '|' . microtime(true) . '|' . mt_rand()), 0, 20) . '.' . deiWaMediaExt($mime, $name);
    if (@file_put_contents($dir . '/' . $fn, $bytes) === false) { $meta['error'] = 'unavailable'; error_log('wa-media: gagal tulis ' . $dir); return $meta; }
    $meta['file'] = $num . '/' . $fn;
    $meta['mime'] = strtolower(trim(explode(';', (string)$mime)[0]));
    $meta['size'] = strlen($bytes);
    return $meta;
}
/* Pesan media (format Meta) -> [meta media, teks tampil di log, teks untuk AI]. */
function deiWaMediaFromMsg($wa, $num, $msg) {
    $type = (string)($msg['type'] ?? '');
    $m = is_array($msg[$type] ?? null) ? $msg[$type] : [];
    $cap = trim((string)($m['caption'] ?? ''));
    $meta = deiWaMediaStore($wa, $num, (string)($msg['id'] ?? ''), $type, $m);
    $lbl = deiWaMediaLabel($type);
    $show = '[' . $lbl . (!empty($meta['name']) ? ': ' . $meta['name'] : '') . ']' . ($cap !== '' ? "\n" . $cap : '');
    $ai = '[Pelanggan mengirim ' . mb_strtolower($lbl) . (!empty($meta['name']) ? ' "' . $meta['name'] . '"' : '')
        . '. Bot tidak bisa melihat isinya; bila perlu, sampaikan bahwa admin akan mengeceknya.]' . ($cap !== '' ? "\n" . $cap : '');
    return [$meta, $show, $ai];
}
/* Hapus media lebih tua dari media_days. Paling sering sekali per jam. */
function deiWaMediaSweep($force = false) {
    if (!is_dir(WA_MEDIA_DIR)) return 0;
    $mark = WA_MEDIA_DIR . '/.sweep';
    if (!$force && is_file($mark) && time() - (int)@filemtime($mark) < 3600) return 0;
    @touch($mark);
    $batas = time() - deiWaMediaDays() * 86400;
    $n = 0;
    foreach ((array)glob(WA_MEDIA_DIR . '/*', GLOB_ONLYDIR) as $d) {
        foreach ((array)glob($d . '/*') as $f) {
            if (is_file($f) && (int)@filemtime($f) < $batas && @unlink($f)) $n++;
        }
        if (!glob($d . '/*')) @rmdir($d);
    }
    return $n;
}
/* Kirim file ke browser: tipe aman tampil inline, lainnya diunduh. Mendukung Range (video di Safari). */
function deiWaMediaOutput($path, $download = false) {
    $ext = strtolower(pathinfo($path, PATHINFO_EXTENSION));
    $inline = ['jpg' => 'image/jpeg', 'png' => 'image/png', 'webp' => 'image/webp', 'gif' => 'image/gif',
               'mp4' => 'video/mp4', '3gp' => 'video/3gpp', 'webm' => 'video/webm', 'mov' => 'video/quicktime',
               'ogg' => 'audio/ogg', 'mp3' => 'audio/mpeg', 'm4a' => 'audio/mp4', 'aac' => 'audio/aac', 'amr' => 'audio/amr', 'weba' => 'audio/webm',
               'pdf' => 'application/pdf'];
    $ct = $inline[$ext] ?? 'application/octet-stream';
    $size = (int)filesize($path);
    $start = 0; $end = $size - 1;
    if (!empty($_SERVER['HTTP_RANGE']) && preg_match('/bytes=(\d*)-(\d*)/', $_SERVER['HTTP_RANGE'], $r)) {
        if ($r[1] !== '') { $start = (int)$r[1]; if ($r[2] !== '') $end = min((int)$r[2], $size - 1); }
        elseif ($r[2] !== '') { $start = max(0, $size - (int)$r[2]); }
        if ($start > $end || $start >= $size) { http_response_code(416); header('Content-Range: bytes */' . $size); exit; }
        http_response_code(206);
        header('Content-Range: bytes ' . $start . '-' . $end . '/' . $size);
    }
    header('Content-Type: ' . $ct);
    header('X-Content-Type-Options: nosniff');
    header("Content-Security-Policy: default-src 'none'; img-src 'self'; media-src 'self'; sandbox");
    header('Cache-Control: private, max-age=86400');
    header('Accept-Ranges: bytes');
    header('Content-Length: ' . ($end - $start + 1));
    $dl = $download || !isset($inline[$ext]);
    header('Content-Disposition: ' . ($dl ? 'attachment' : 'inline') . '; filename="' . basename($path) . '"');
    $fh = fopen($path, 'rb');
    fseek($fh, $start);
    $left = $end - $start + 1;
    while ($left > 0 && !feof($fh)) { $chunk = fread($fh, min(65536, $left)); echo $chunk; $left -= strlen($chunk); }
    fclose($fh);
}

function waHandleMetaMessage($s, $wa, $msg, $waProfileNames, $metadata) {
    $from = $msg['from'] ?? '';
    if ($from === '') return;
    $wamid = (string)($msg['id'] ?? '');
    if ($wamid !== '' && waMsgSeen($wamid)) return;
    $GLOBALS['dei_in_wamid'] = $wamid;   // v1.2.96: mengetik
    try {
        // v1.2.19: simpan nama kontak (tidak menimpa koreksi manual)
        $deiFromKey = preg_replace('/\D/', '', (string)$from);
        $deiWaName  = $waProfileNames[$deiFromKey] ?? '';
        try { waSaveContact($from, $deiWaName, (string)($wa['_ch'] ?? '')); }   // v1.2.98: multi-nomor
        catch (\Throwable $e) { error_log('waSaveContact: ' . $e->getMessage()); }

        if (($msg['type'] ?? '') !== 'text') {
            // v1.2.94: wa-media: media diunduh & dicatat; AI menjawab caption-nya (stiker tanpa caption tidak dibalas)
            if (in_array((string)($msg['type'] ?? ''), deiWaMediaTypes(), true)) {
                list($wmMeta, $wmShow, $wmAi) = deiWaMediaFromMsg($wa, $from, $msg);
                $wmCap = trim((string)($msg[$msg['type']]['caption'] ?? ''));
                waProcessIncoming($s, $wa, $from, $wmAi, $deiWaName, array_merge((array)$metadata,
                    ['_media' => $wmMeta, '_q_show' => $wmShow, '_no_reply' => ($msg['type'] === 'sticker' && $wmCap === '')]));
                return;
            }
            // v1.2.58: mode Manual tidak membalas otomatis; tandai saja supaya agent tahu
            if (deiIsManual($s)) {
                waProcessIncoming($s, $wa, $from, deiNonTextLabel($msg['type'] ?? ''), $deiWaName, $metadata);
                return;
            }
            if (deiSysOnce($from, 'nontext', 1800)) waSend($wa, $from, 'Maaf, untuk saat ini saya hanya bisa membalas pesan teks.');
            else waOutCount('saved');   // v1.2.89
            return;
        }
        $text = trim($msg['text']['body'] ?? '');
        if ($text === '') return;
        // v1.2.72: bubble beruntun dari nomor ini digabung (mode antrean + debounce_sec)
        if (!deiIsManual($s) && waGetMode($from) === 'bot') {
            if (deiQueueRedis()) {
                list($text, $mergedIds) = deiDebounceCollect($from, $wamid, $text);
            } else {
                list($text, $mergedIds) = deiDebounceFileCollect($s, $from, $wamid, $text);   // v1.2.89
                if ($text === null) { waOutCount('saved'); return; }   // digabung ke pesan berikutnya
            }
            if (count($mergedIds ?? []) > 1 && deiQueueRedis()) { for ($i = 1; $i < count($mergedIds); $i++) waOutCount('saved'); }
            if ($text === '') return;
        }
        // v1.2.36: alur pemrosesan dipindah ke fungsi bersama
        waProcessIncoming($s, $wa, $from, $text, $deiWaName, $metadata);
    } finally {
        // Ditandai juga saat gagal di tengah jalan: lebih baik tidak dibalas ganda.
        if ($wamid !== '') waMsgMarkSeen($wamid);
        foreach (($mergedIds ?? []) as $mid) { if ($mid !== $wamid) waMsgMarkSeen($mid); }   // v1.2.72
    }
}

// Per-number short conversation memory (flat-file, expires after 6h idle).
function waSessionFile($from) {
    return WA_SESSIONS_DIR . '/' . preg_replace('/[^0-9]/', '', (string)$from) . '.json';
}
function waLoadHistory($from) {
    if (deiStorageMysql()) {   // v1.2.71
        $st = deiDb()->prepare('SELECT ts, turns FROM dei_wa_sessions WHERE num = ?');
        $st->execute([preg_replace('/[^0-9]/', '', (string)$from)]);
        $r = $st->fetch();
        if (!$r || (int)$r['ts'] < time() - 6 * 3600) return [];
        $t = json_decode($r['turns'], true);
        return is_array($t) ? $t : [];
    }
    $f = waSessionFile($from);
    if (!is_file($f)) return [];
    $d = json_decode(@file_get_contents($f), true);
    if (!is_array($d) || empty($d['turns'])) return [];
    if (($d['ts'] ?? 0) < time() - 6 * 3600) return [];
    return $d['turns'];
}
function waSaveHistory($from, $turns) {
    if (deiStorageMysql()) {   // v1.2.71
        deiDb()->prepare('INSERT INTO dei_wa_sessions (num, ts, turns) VALUES (?, ?, ?) ON DUPLICATE KEY UPDATE ts = VALUES(ts), turns = VALUES(turns)')
            ->execute([preg_replace('/[^0-9]/', '', (string)$from), time(), logEncode(array_values(array_slice($turns, -16)))]);
        return;
    }
    if (!is_dir(WA_SESSIONS_DIR)) @mkdir(WA_SESSIONS_DIR, 0755, true);
    @file_put_contents(waSessionFile($from), json_encode(['ts' => time(), 'turns' => array_slice($turns, -16)], JSON_UNESCAPED_UNICODE), LOCK_EX);
}

// Send a 200 to Meta immediately and detach, so the webhook never times out
// while we call the AI. Only used when fastcgi_finish_request() is available
// (PHP-FPM). Otherwise the caller processes synchronously and replies at the end.
function respondAndContinue($body = 'EVENT_RECEIVED') {
    @ignore_user_abort(true);
    http_response_code(200);
    header('Content-Type: text/plain; charset=utf-8');
    header('Content-Length: ' . strlen($body));
    header('Connection: close');
    echo $body;
    if (function_exists('fastcgi_finish_request')) fastcgi_finish_request();
    elseif (function_exists('litespeed_finish_request')) litespeed_finish_request();   // v1.2.71: LiteSpeed (Niagahoster)
}

/* ----------------------------------------------------------------------------
 *  Handoff (per-number bot/human mode) + Telegram notifications
 * ------------------------------------------------------------------------- */
function waNormNum($n) { return preg_replace('/[^0-9]/', '', (string)$n); }

function waGetMode($from) {
    if (deiIsManual()) return 'human';   // v1.2.58: mode Manual = semua nomor dipegang manusia
    $modes = readJson(WA_MODES_FILE, []);
    $k = waNormNum($from);
    return (isset($modes[$k]['mode']) && $modes[$k]['mode'] === 'human') ? 'human' : 'bot';
}
// v1.2.71: dibungkus kunci 'wa-modes' supaya worker paralel tidak saling menimpa.
function waSetMode($from, $mode, $reason = '') {   // v1.2.101: + alasan serah ke agent
    $r = deiWithLock('wa-modes', function () use ($from, $mode) { return waSetMode_nolock($from, $mode); });
    if ($mode === 'human') convBotReset($from);   // v1.2.97: batas-ai — kembali ke bot nanti mulai dari nol
    if ($mode === 'human') convTrack($from, 'handover', ['reason' => $reason !== '' ? $reason : 'mode_human']);   // v1.2.101: percakapan
    return $r;
}
function waSetMode_nolock($from, $mode) {
    $modes = readJson(WA_MODES_FILE, []);
    $k = waNormNum($from);
    if ($mode === 'human') {
        $modes[$k] = ['mode' => 'human', 'ts' => time()];
    } else {
        unset($modes[$k]); // bot is the default → remove entry
    }
    writeJson(WA_MODES_FILE, $modes);
}

// v1.2.37: berapa lama mode manusia bertahan tanpa aktivitas agent.
// Dihitung dari waktu waSetMode('human') terakhir — yaitu saat handoff terjadi
// atau saat agent membalas manual. Pesan dari tamu TIDAK memperpanjangnya:
// kalau tamu terus mengirim pesan tapi tidak ada yang menjawab, justru itulah
// saat bot paling perlu mengambil alih.
define('WA_MODE_IDLE_SEC', 3600);   // 1 jam

// Kembalikan ke mode bot untuk nomor yang sudah lama diam di mode manusia.
// Nomor yang masih dipegang agent (ada claim) DILEWATI — percakapan itu punya
// aturannya sendiri lewat waClaimAutoProcess (lepas otomatis 30 menit), dan bot
// tidak boleh menyela pekerjaan yang sedang berjalan.
// v1.2.71: dibungkus kunci 'wa-modes' supaya worker paralel tidak saling menimpa.
function waModeSweepIdle() {
    return deiWithLock('wa-modes', function () { return waModeSweepIdle_nolock(); });
}
function waModeSweepIdle_nolock() {
    if (deiIsManual()) return 0;          // v1.2.58: tidak ada bot untuk dikembalikan
    $modes = readJson(WA_MODES_FILE, []);
    if (empty($modes) || !is_array($modes)) return 0;
    $claims = readJson(waClaimFile(), []);
    if (!is_array($claims)) $claims = [];
    $now = time();
    $n = 0;
    foreach ($modes as $k => $m) {
        if (!is_array($m) || ($m['mode'] ?? '') !== 'human') continue;
        if (!empty($claims[$k])) continue;                     // masih dipegang agent
        $ts = (int)($m['ts'] ?? 0);
        if ($ts > 0 && ($now - $ts) < WA_MODE_IDLE_SEC) continue;
        unset($modes[$k]);                                     // bot = bawaan
        $n++;
    }
    if ($n > 0) {
        writeJson(WA_MODES_FILE, $modes);
        error_log('wa: ' . $n . ' nomor kembali ke mode bot (manual idle > '
                  . (int)(WA_MODE_IDLE_SEC / 60) . ' menit)');
    }
    return $n;
}

/* ============================================================================
 *  v1.2.58: MODE BALASAN (AI / Manual) + TIM AGENT + FITUR DARI PUSAT
 *
 *  reply.mode = 'manual' -> AI tidak dipanggil untuk WhatsApp, tidak ada
 *  balasan otomatis, semua nomor dianggap mode manusia (waGetMode), sapu
 *  idle & auto-closing mati, claim tidak lepas otomatis. Widget web tetap AI.
 *
 *  Fitur per tenant (max_agents, max_supervisors, white_label) dikirim pusat
 *  lewat cap_info pada check_update dan ikut disimpan di cap-cache.json —
 *  jadi mengedit users.json/settings.json di tenant tidak bisa menembus batas.
 * ========================================================================= */
define('DEI_DEFAULT_MAX_AGENTS', 10);
define('DEI_DEFAULT_MAX_SUPERVISORS', 1);
define('DEI_DEFAULT_TOPIC_SCANS', 10);   // v1.2.68: kuota scan topik / bulan (0 = tanpa batas)
define('WA_AGENT_REPLIED_FILE', DATA_DIR . '/wa-agent-replied.json');   // nomor -> ts balasan agent terakhir
define('AGENT_EV_DIR', DATA_DIR . '/agent-events');                       // log event agent per bulan (.jsonl)

function deiReplyMode($s = null) {
    if ($s === null) {
        if (!isset($GLOBALS['dei_reply_mode_cache'])) {
            $GLOBALS['dei_reply_mode_cache'] = deiReplyMode(getSettings());
        }
        return $GLOBALS['dei_reply_mode_cache'];
    }
    // v1.2.93: wa-bot-off — toggle "Aktifkan Bot WhatsApp" mati = AI tidak membalas (perilaku Mode Manual);
    // pesan masuk & balasan dari HP tetap tercatat di dashboard.
    if (empty($s['whatsapp_api']['enabled'])) return 'manual';
    return deiReplyModeSetting($s);
}
/* v1.2.93: wa-bot-off: pilihan Mode Balasan di menu Tim apa adanya (tanpa memperhitungkan toggle bot) */
function deiReplyModeSetting($s) { return ((($s['reply']['mode'] ?? 'ai') === 'manual') ? 'manual' : 'ai'); }
/* v1.2.93: wa-bot-off: nomor WhatsApp tersambung (kredensial ada), lepas dari status bot AI */
function deiWaConnected($wa) {
    $wa = is_array($wa) ? $wa : [];
    $p = (string)($wa['provider'] ?? 'meta');
    if ($p === 'waha')   return trim((string)($wa['waha_url'] ?? '')) !== '';
    if ($p === 'fonnte') return !empty($wa['fonnte_token']);
    return !empty($wa['access_token']) && !empty($wa['phone_number_id']);
}
function deiIsManual($s = null) { return deiReplyMode($s) === 'manual'; }
function deiNonTextLabel($type) {
    $t = trim((string)$type);
    return '[Pesan ' . ($t !== '' ? $t : 'non-teks') . ' — buka WhatsApp di HP untuk melihat isinya]';
}

function deiTeamConf($s) {
    $t = is_array($s['team'] ?? null) ? $s['team'] : [];
    return [
        // Agent hanya melihat chat yang belum diklaim + miliknya sendiri.
        'agent_private' => !empty($t['agent_private']),   // bawaan MATI; nyalakan di Tim & Agent
    ];
}

function deiFeaturesFromCap($cap) {
    if (!is_array($cap)) return null;
    if (!array_key_exists('max_agents', $cap) && !array_key_exists('white_label', $cap)) return null;   // pusat lama
    return [
        'max_agents'      => max(0, (int)($cap['max_agents'] ?? DEI_DEFAULT_MAX_AGENTS)),
        'max_supervisors' => max(0, (int)($cap['max_supervisors'] ?? DEI_DEFAULT_MAX_SUPERVISORS)),
        'white_label'     => !empty($cap['white_label']),
        'topic_scan_quota' => max(0, (int)($cap['topic_scan_quota'] ?? DEI_DEFAULT_TOPIC_SCANS)),   // v1.2.68
        'max_wa_numbers'  => max(0, (int)($cap['max_wa_numbers'] ?? DEI_DEFAULT_MAX_WA_NUMBERS)),   // v1.2.99: lisensi-nomor
        'trial'           => deiTrialNorm($cap['trial'] ?? null),   // v1.2.90
    ];
}

// 0 = tanpa batas (sama seperti monthly_chat_cap di pusat).
function deiFeatures($s = null) {
    if (isset($GLOBALS['dei_features_cache'])) return $GLOBALS['dei_features_cache'];
    if ($s === null) $s = getSettings();
    $f = ['max_agents' => DEI_DEFAULT_MAX_AGENTS, 'max_supervisors' => DEI_DEFAULT_MAX_SUPERVISORS,
          'white_label' => false, 'topic_scan_quota' => DEI_DEFAULT_TOPIC_SCANS, 'source' => 'default',
          'max_wa_numbers' => DEI_DEFAULT_MAX_WA_NUMBERS];   // v1.2.99: lisensi-nomor
    $cs = $s['central_server'] ?? [];
    if (!empty($cs['url']) && !empty($cs['tenant_id']) && !empty($cs['license_key'])) {
        try {
            $cap = getCapStatus($s);
            // v1.2.60: cache lama (sebelum v1.2.58) tidak membawa fitur -> segarkan, maks 1x / 10 menit
            if (!is_array($cap['features'] ?? null) && (time() - (int)(readJson(CAP_CACHE_FILE, [])['cached_at'] ?? 0)) > 600) {
                $cap = getCapStatus($s, true);
            }
            if (is_array($cap['features'] ?? null)) $f = $cap['features'] + ['source' => 'pusat'];
        } catch (\Throwable $e) { error_log('deiFeatures: ' . $e->getMessage()); }
    }
    $GLOBALS['dei_features_cache'] = $f;
    return $f;
}

// Kursi agent/supervisor: urutan di users.json menentukan siapa yang masuk
// batas. Kalau paket diturunkan, akun TERAKHIR yang ditambahkan yang terkunci.
function deiSeatRank($username, $role, $users) {
    $n = 0;
    foreach ((array)$users as $u) {
        if (($u['role'] ?? '') !== $role) continue;
        $n++;
        if (($u['username'] ?? '') === $username) return $n;
    }
    return 0;
}
function deiSeatAllowed($username, $role, $users) {
    if (!in_array($role, ['wa_agent', 'supervisor'], true)) return true;
    $f = deiFeatures();
    $max = ($role === 'wa_agent') ? (int)$f['max_agents'] : (int)$f['max_supervisors'];
    if ($max <= 0) return true;
    $rank = deiSeatRank($username, $role, $users);
    return $rank > 0 && $rank <= $max;
}
function deiSeatInfo($users) {
    $f = deiFeatures();
    $ag = 0; $sp = 0;
    foreach ((array)$users as $u) {
        if (($u['role'] ?? '') === 'wa_agent') $ag++;
        if (($u['role'] ?? '') === 'supervisor') $sp++;
    }
    return ['max_agents' => (int)$f['max_agents'], 'used_agents' => $ag,
            'max_supervisors' => (int)$f['max_supervisors'], 'used_supervisors' => $sp,
            'source' => $f['source'] ?? 'default'];
}
// v1.2.60: jumlah akun per peran tim (dikirim ke pusat lewat stats)
function deiSeatCounts() {
    // Sengaja TIDAK memanggil deiFeatures(): fungsi ini dipakai deiCollectStats(), yang dipanggil
    // getCapStatus() saat refresh -> bisa rekursi. Baca cache saja.
    $cf = readJson(CAP_CACHE_FILE, [])['features'] ?? null;
    $f = is_array($cf) ? $cf + ['source' => 'pusat']
                       : ['max_agents' => DEI_DEFAULT_MAX_AGENTS, 'max_supervisors' => DEI_DEFAULT_MAX_SUPERVISORS, 'source' => 'default'];
    $ag = 0; $sp = 0;
    foreach ((array)readJson(USERS_FILE, []) as $u) {
        if (($u['role'] ?? '') === 'wa_agent') $ag++;
        if (($u['role'] ?? '') === 'supervisor') $sp++;
    }
    $wn = 0;   // v1.2.99: lisensi-nomor
    try { $wn = count(waNumbersRaw(getSettings(), true)); } catch (\Throwable $e) {}
    return ['agents' => $ag, 'supervisors' => $sp,
            'wa_numbers' => $wn, 'max_wa_numbers' => (int)($f['max_wa_numbers'] ?? DEI_DEFAULT_MAX_WA_NUMBERS),   // v1.2.99
            'max_agents' => (int)$f['max_agents'], 'max_supervisors' => (int)$f['max_supervisors'],
            'source' => $f['source'] ?? 'default'];
}
// v1.2.60: pusat mengirim fitur paket di header cron_tick (sudah terverifikasi license key)
// -> batas kursi baru berlaku <= 1 menit tanpa menunggu cache 24 jam.
/* ======================================================================
 * v1.2.65: Catatan rilis — halaman "Pembaruan" (khusus super_admin/admin)
 * Sumber: pusat ?action=release_notes (tenant_id + license_key), di-cache
 * 30 menit. Push ke admin dipicu cron_tick lewat header X-Dei-Latest.
 * ==================================================================== */
define('RELNOTES_CACHE_FILE', DATA_DIR . '/release-notes-cache.json');
define('RELNOTIFY_FILE',      DATA_DIR . '/release-notify.json');
define('RELNOTES_TTL', 1800);

function deiVerOk($v) { return is_string($v) && preg_match('/^v\d+\.\d+\.\d+$/', $v) === 1; }
function deiVerCmp($a, $b) { return version_compare(ltrim((string)$a, 'v'), ltrim((string)$b, 'v')); }

function deiFetchReleaseNotes($force = false) {
    $cache = readJson(RELNOTES_CACHE_FILE, []);
    $has = !empty($cache['releases']) && is_array($cache['releases']);
    if (!$force && $has && (time() - (int)($cache['fetched_at'] ?? 0)) < RELNOTES_TTL) return $cache + ['stale' => false];
    $s = getSettings();
    $cs = $s['central_server'] ?? [];
    if (empty($cs['url']) || empty($cs['tenant_id']) || empty($cs['license_key'])) {
        $err = 'Server pusat belum dikonfigurasi.';
        return $has ? $cache + ['stale' => true, 'error' => $err] : ['releases' => [], 'latest' => null, 'stale' => true, 'error' => $err];
    }
    $ch = curl_init(rtrim($cs['url'], '/') . '/backend/index.php?action=release_notes');
    curl_setopt_array($ch, [CURLOPT_RETURNTRANSFER => true, CURLOPT_TIMEOUT => 10, CURLOPT_CONNECTTIMEOUT => 5,
        CURLOPT_POST => true, CURLOPT_HTTPHEADER => ['Content-Type: application/json'],
        CURLOPT_POSTFIELDS => json_encode(['tenant_id' => $cs['tenant_id'], 'license_key' => $cs['license_key'], 'limit' => 60])]);
    $resp = curl_exec($ch);
    $code = (int)curl_getinfo($ch, CURLINFO_HTTP_CODE);
    curl_close($ch);
    $j = json_decode((string)$resp, true);
    if ($code === 200 && is_array($j) && !empty($j['ok']) && is_array($j['releases'] ?? null)) {
        $rel = [];
        foreach ($j['releases'] as $r) {
            if (!is_array($r) || !deiVerOk($r['version'] ?? '')) continue;
            $hl = [];
            foreach (array_slice((array)($r['highlights'] ?? []), 0, 12) as $h) { if (is_string($h) && trim($h) !== '') $hl[] = mb_substr(trim($h), 0, 300); }
            $rel[] = [
                'version'     => $r['version'],
                'released_at' => mb_substr((string)($r['released_at'] ?? ''), 0, 19),
                'title'       => mb_substr(trim((string)($r['title'] ?? '')), 0, 120),
                'type'        => in_array(($r['type'] ?? ''), ['fitur', 'peningkatan', 'perbaikan'], true) ? $r['type'] : 'peningkatan',
                'changelog'   => mb_substr(trim((string)($r['changelog'] ?? '')), 0, 3000),
                'highlights'  => $hl,
            ];
        }
        usort($rel, function ($a, $b) { return deiVerCmp($b['version'], $a['version']); });
        $cache = ['fetched_at' => time(), 'fetched_at_wib' => wibDate('Y-m-d H:i:s'), 'latest' => $rel[0]['version'] ?? null, 'releases' => $rel];
        writeJson(RELNOTES_CACHE_FILE, $cache);
        return $cache + ['stale' => false];
    }
    $err = (is_array($j) && !empty($j['error'])) ? (string)$j['error'] : ('Gagal menghubungi server pusat (HTTP ' . $code . ').');
    return $has ? $cache + ['stale' => true, 'error' => $err] : ['releases' => [], 'latest' => null, 'stale' => true, 'error' => $err];
}

// Dipanggil dari cron_tick. Rilis pertama yang terlihat hanya dicatat (tanpa push)
// supaya tenant yang baru dipasang tidak dibanjiri notifikasi rilis lama.
/* v1.2.74: rilis bertipe "perbaikan" hanya ditampilkan ke Super Admin */
function deiRelVisible($r, $role) {
    return $role === 'super_admin' || (($r['type'] ?? '') !== 'perbaikan');
}

function deiReleaseNotify($latest) {
    if (!deiVerOk($latest)) return null;
    $st = readJson(RELNOTIFY_FILE, []);
    $last = (string)($st['last_notified'] ?? '');
    if ($last === '') {
        writeJson(RELNOTIFY_FILE, ['last_notified' => $latest, 'at_wib' => wibDate('Y-m-d H:i:s'), 'pushed' => 0, 'init' => true]);
        return ['init' => $latest];
    }
    if (deiVerCmp($latest, $last) <= 0) return null;
    if (!empty($GLOBALS['dei_dry'])) return ['would_notify' => $latest];
    $notes = deiFetchReleaseNotes(true);
    $title = '';
    $relType = '';
    foreach (($notes['releases'] ?? []) as $r) {
        if ($r['version'] === $latest) { $title = $r['title'] !== '' ? $r['title'] : mb_substr($r['changelog'], 0, 110); $relType = (string)($r['type'] ?? ''); break; }
    }
    $pushRoles = $relType === 'perbaikan' ? ['super_admin'] : ['super_admin', 'admin'];   // v1.2.74
    $subs = array_keys(readJson(DATA_DIR . '/push-subs.json', []));
    $targets = [];
    foreach (readJson(USERS_FILE, []) as $u) {
        $un = (string)($u['username'] ?? '');
        if ($un !== '' && in_array(($u['role'] ?? ''), $pushRoles, true) && in_array($un, $subs, true)) $targets[] = $un;
    }
    if ($targets) sendPushToUsers($targets, 'Pembaruan baru: ' . $latest, $title !== '' ? $title : 'Lihat apa yang baru di ' . deiBrandProduct() . '.', deiDashboardUrl() . '#pembaruan', 'dei-release');
    writeJson(RELNOTIFY_FILE, ['last_notified' => $latest, 'at_wib' => wibDate('Y-m-d H:i:s'), 'pushed' => count($targets)]);
    return ['notified' => $latest, 'pushed' => count($targets)];
}
/* ====== /v1.2.65 ====== */

/* ======================================================================
 * v1.2.66: Log Percakapan terstruktur — filter, facet, paginasi (server-side)
 * ==================================================================== */
function deiLogStatus($e) {
    $d = (string)($e['dir'] ?? '');
    if ($d === 'manual')  return 'manual';
    if ($d === 'closing') return 'closing';
    if ($d === 'call')    return 'call';   // v1.2.108: tolak-telepon
    if (!empty($e['ai_error']) || !empty($e['suspended']) || !empty($e['cap_reached'])) return 'error';
    if (!empty($e['awaiting'])) return 'awaiting';
    return 'ai';
}
function deiLogDim($e, $k) {
    $v = trim((string)($e['utm_' . $k] ?? ''));
    if ($v !== '') return $v;
    return $k === 'source' ? '(direct)' : '(none)';
}
function deiLogParams($g) {
    $d = function ($v) { $v = substr((string)$v, 0, 10); return preg_match('/^\d{4}-\d{2}-\d{2}$/', $v) ? $v : ''; };
    $ch = (string)($g['channel'] ?? '');
    $st = (string)($g['status'] ?? '');
    return [
        'from'     => $d($g['from'] ?? ''),
        'to'       => $d($g['to'] ?? ''),
        'channel'  => in_array($ch, ['web', 'whatsapp'], true) ? $ch : '',
        'source'   => mb_substr(trim((string)($g['source'] ?? '')), 0, 120),
        'medium'   => mb_substr(trim((string)($g['medium'] ?? '')), 0, 120),
        'campaign' => mb_substr(trim((string)($g['campaign'] ?? '')), 0, 120),
        'status'   => in_array($st, ['ai', 'awaiting', 'manual', 'closing', 'error', 'call'], true) ? $st : '',   // v1.2.108: tolak-telepon
        'q'        => mb_strtolower(mb_substr(trim((string)($g['q'] ?? '')), 0, 100)),
    ];
}
// $skip = nama dimensi yang diabaikan (untuk menghitung facet dimensi itu sendiri)
function deiLogMatch($e, $f, $skip = '') {
    $day = substr((string)($e['ts'] ?? ''), 0, 10);
    if ($f['from'] !== '' && $day < $f['from']) return false;
    if ($f['to'] !== ''   && $day > $f['to'])   return false;
    if ($skip !== 'channel'  && $f['channel']  !== '' && ($e['channel'] ?? 'web') !== $f['channel']) return false;
    if ($skip !== 'source'   && $f['source']   !== '' && deiLogDim($e, 'source')   !== $f['source'])   return false;
    if ($skip !== 'medium'   && $f['medium']   !== '' && deiLogDim($e, 'medium')   !== $f['medium'])   return false;
    if ($skip !== 'campaign' && $f['campaign'] !== '' && deiLogDim($e, 'campaign') !== $f['campaign']) return false;
    if ($skip !== 'status'   && $f['status']   !== '' && deiLogStatus($e) !== $f['status']) return false;
    if ($f['q'] !== '') {
        $hay = mb_strtolower(($e['q'] ?? '') . "\n" . ($e['a'] ?? '') . "\n" . ($e['ip'] ?? '') . "\n" . ($e['page'] ?? '') . "\n" . ($e['_name'] ?? ''));
        if (mb_strpos($hay, $f['q']) === false) return false;
    }
    return true;
}
// Nama kontak WA (manual > profil WA) ditempel sebagai _name supaya bisa dicari & ditampilkan
function deiLogWithNames($logs) {
    $c = waGetContacts();   // v1.2.71
    if (!is_array($c) || !$c) return $logs;
    foreach ($logs as &$e) {
        if (($e['channel'] ?? 'web') !== 'whatsapp') continue;
        $k = (string)($e['ip'] ?? '');
        if ($k !== '' && isset($c[$k]) && is_array($c[$k])) {
            $n = trim((string)($c[$k]['name_manual'] ?? '')) ?: trim((string)($c[$k]['name_wa'] ?? ''));
            if ($n !== '') $e['_name'] = $n;
        }
    }
    unset($e);
    return $logs;
}
function deiLogStatusLabel($st) {
    return ['ai' => 'Dijawab AI', 'awaiting' => 'Menunggu balasan', 'manual' => 'Balasan agent', 'closing' => 'Closing otomatis', 'error' => 'Gagal / error', 'call' => 'Telepon masuk'][$st] ?? $st;   // v1.2.108: tolak-telepon
}
/* ====== /v1.2.66 ====== */

/* ======================================================================
 * v1.2.67: Scan Topik Percakapan per periode (AI) — hasil disimpan di
 * data/topic-scans.json per (periode, channel) supaya tidak scan ulang tiap buka.
 * Unit = satu percakapan: pesan pengunjung dari kontak yang sama di hari yang sama.
 * ==================================================================== */
define('TOPIC_SCANS_FILE', DATA_DIR . '/topic-scans.json');
define('TOPIC_SAMPLE_MAX', 300);
function deiTopicPeriods() { return [7, 14, 30, 60, 90, 180, 365]; }

// Kumpulkan unit percakapan dalam periode. Kembalikan [units, meta].
function deiTopicUnits($days, $channel) {
    $from = wibDate('Y-m-d', time() - ($days - 1) * 86400);
    $to   = wibDate('Y-m-d');
    $logs = logReadAll();
    $oldest = '';
    $units = [];
    foreach ($logs as $e) {
        $ts = (string)($e['ts'] ?? '');
        $day = substr($ts, 0, 10);
        if ($day !== '' && ($oldest === '' || $day < $oldest)) $oldest = $day;
        if ($day === '' || $day < $from || $day > $to) continue;
        if (in_array(($e['dir'] ?? ''), ['manual', 'closing'], true)) continue;          // balasan agent
        if (($e['utm_source'] ?? '') === 'dashboard' && ($e['utm_medium'] ?? '') === 'test') continue;   // Tes Chatbot
        $ch = (string)($e['channel'] ?? 'web');
        if ($channel !== '' && $ch !== $channel) continue;
        $q = trim(preg_replace('/\s+/u', ' ', (string)($e['q'] ?? '')));
        if ($q === '') continue;
        $k = $ch . '|' . (string)($e['ip'] ?? '') . '|' . $day;
        if (!isset($units[$k])) $units[$k] = ['ch' => $ch, 'day' => $day, 'msgs' => [], 'ts' => $ts];
        $units[$k]['msgs'][] = ['ts' => $ts, 'q' => $q];
    }
    $out = [];
    foreach ($units as $u) {
        usort($u['msgs'], function ($a, $b) { return strcmp($a['ts'], $b['ts']); });
        $t = '';
        foreach ($u['msgs'] as $m) {
            if (mb_strlen($t) >= 280) break;
            $t .= ($t === '' ? '' : ' / ') . $m['q'];
        }
        $t = mb_substr($t, 0, 300);
        if (mb_strlen(preg_replace('/[^\p{L}\p{N}]/u', '', $t)) < 2) continue;   // "1", "👍" saja
        $out[] = ['ch' => $u['ch'], 'day' => $u['day'], 'text' => $t, 'n' => count($u['msgs'])];
    }
    usort($out, function ($a, $b) { return strcmp($b['day'], $a['day']); });
    return [$out, ['from' => $from, 'to' => $to, 'oldest' => $oldest, 'log_entries' => count($logs)]];
}
// Ambil sampel merata (bukan hanya yang terbaru) supaya periode panjang terwakili.
function deiTopicSample($units, $max) {
    $n = count($units);
    if ($n <= $max) return $units;
    $o = [];
    for ($i = 0; $i < $max; $i++) $o[] = $units[(int)floor($i * $n / $max)];
    return $o;
}
function deiTopicKey($days, $channel) { return $days . '|' . ($channel === '' ? 'all' : $channel); }
// v1.2.68: kuota scan topik per bulan (WIB). Hanya scan yang benar-benar memanggil AI yang dihitung.
define('TOPIC_USAGE_FILE', DATA_DIR . '/topic-scan-usage.json');
function deiTopicQuota($noFetch = false) {
    // $noFetch: dipakai deiCollectStats() — JANGAN memanggil deiFeatures() di sana
    // (getCapStatus mengirim statistik -> rekursi tanpa akhir).
    $f = $noFetch ? ((array)(readJson(CAP_CACHE_FILE, [])['features'] ?? [])) : deiFeatures();
    $limit = max(0, (int)($f['topic_scan_quota'] ?? DEI_DEFAULT_TOPIC_SCANS));
    $month = wibDate('Y-m');
    $u = readJson(TOPIC_USAGE_FILE, []);
    $used = (int)($u[$month]['count'] ?? 0);
    $y = (int)substr($month, 0, 4); $m = (int)substr($month, 5, 2) + 1;
    if ($m > 12) { $m = 1; $y++; }
    return ['limit' => $limit, 'used' => $used, 'left' => $limit > 0 ? max(0, $limit - $used) : null,
            'month' => $month, 'reset' => sprintf('%04d-%02d-01', $y, $m)];
}
function deiTopicQuotaUse($user, $days, $channel, $usage) {
    $lock = @fopen(DATA_DIR . '/topic-scan-usage.lock', 'c');
    if ($lock) @flock($lock, LOCK_EX);
    $month = wibDate('Y-m');
    $u = readJson(TOPIC_USAGE_FILE, []);
    if (!is_array($u)) $u = [];
    if (!isset($u[$month])) $u[$month] = ['count' => 0, 'runs' => []];
    $u[$month]['count']++;
    $u[$month]['runs'][] = ['at' => wibDate('Y-m-d H:i:s'), 'user' => $user, 'days' => $days, 'channel' => $channel,
                            'in' => (int)($usage['input_tokens'] ?? 0), 'out' => (int)($usage['output_tokens'] ?? 0)];
    $u[$month]['runs'] = array_slice($u[$month]['runs'], -200);
    ksort($u);
    $u = array_slice($u, -12, null, true);   // simpan 12 bulan
    writeJson(TOPIC_USAGE_FILE, $u);
    if ($lock) { @flock($lock, LOCK_UN); @fclose($lock); }
}
/* ====== /v1.2.67 ====== */

function deiApplyPushedFeatures($raw) {
    $j = json_decode((string)$raw, true);
    $f = deiFeaturesFromCap(is_array($j) ? $j : null);
    if (!$f) return false;
    $cache = readJson(CAP_CACHE_FILE, []);
    $tierP = (is_array($j) && isset($j['tier'])) ? strtolower(trim((string)$j['tier'])) : '';   // v1.2.109: guest-comment: tier ikut didorong pusat
    if (($cache['features'] ?? null) == $f && ($tierP === '' || (string)($cache['tier'] ?? '') === $tierP)) return false;
    $cache['features'] = $f;
    if ($tierP !== '') $cache['tier'] = $tierP;
    unset($GLOBALS['dei_gc_plan']);
    if (empty($cache['cached_at'])) $cache['cached_at'] = 1;   // tanpa cap info: biar check_update tetap jalan
    writeJson(CAP_CACHE_FILE, $cache);
    unset($GLOBALS['dei_features_cache']);
    return true;
}

function deiSeatMsg($role, $f) {
    $max = ($role === 'wa_agent') ? (int)$f['max_agents'] : (int)$f['max_supervisors'];
    $lbl = ($role === 'wa_agent') ? 'agent' : 'supervisor';
    return 'Batas paket: maksimal ' . $max . ' ' . $lbl . '. Hubungi ' . deiBrandVendor() . ' untuk menambah kursi.';
}

// Agent (mode privat) tidak boleh membuka chat yang dipegang agent lain.
function deiGuardAgentPrivate($u, $num) {
    deiGuardSpvScope($u, $num);   // v1.2.59
    if (($u['role'] ?? '') !== 'wa_agent') return;
    if (!deiTeamConf(getSettings())['agent_private']) return;
    $cl = waClaimGet($num);
    if (!$cl) return;
    if (($cl['agent_username'] ?? '') === ($u['username'] ?? '')) return;
    if (($cl['takeover_request']['requester'] ?? '') === ($u['username'] ?? '')) return;
    jsonOut(['ok' => false, 'error' => 'Chat ini dipegang agent lain.'], 403);
}
// v1.2.58: teks & logo kepala widget. Kustomisasi hanya berlaku bila paket
// tenant punya hak white-label dari pusat; selain itu tampilan bawaan.
define('DEI_WIDGET_SUBTITLE', 'Online • Powered by AI');
function deiBranding($s) {
    $wl = is_array($s['white_label'] ?? null) ? $s['white_label'] : [];
    $f = deiFeatures($s);
    $on = !empty($f['white_label']);
    $sub = DEI_WIDGET_SUBTITLE; $logo = '';
    if ($on) {
        $c = trim((string)($wl['subtitle'] ?? ''));
        if ($c !== '') $sub = $c;
        elseif (!empty($wl['hide_branding'])) $sub = 'Online';
        $logo = trim((string)($wl['header_logo'] ?? ''));
    }
    return ['subtitle' => $sub, 'header_logo' => $logo, 'white_label' => $on];
}
function deiIsLead($role) { return in_array($role, ['super_admin', 'admin', 'supervisor'], true); }   // boleh lihat semua & assign

/* ---------- v1.2.59: tim supervisor (WA Agent -> Supervisor atasan) ---------- */
// Supervisor efektif seorang agent: dihitung hanya bila akun supervisor itu masih ada.
function deiAgentSpv($agentUser, $users) {
    $sv = trim((string)($agentUser['supervisor'] ?? ''));
    if ($sv === '') return '';
    foreach ((array)$users as $x) {
        if (($x['username'] ?? '') === $sv && ($x['role'] ?? '') === 'supervisor') return $sv;
    }
    return '';
}
// Lingkup supervisor = dirinya + WA Agent di bawahnya + WA Agent yang belum punya supervisor.
// null = tanpa batas (bukan supervisor).
function deiSpvScope($u, $users = null) {
    if (($u['role'] ?? '') !== 'supervisor') return null;
    if ($users === null) $users = readJson(USERS_FILE, []);
    $me = (string)($u['username'] ?? '');
    $out = [$me => true];
    foreach ((array)$users as $x) {
        if (($x['role'] ?? '') !== 'wa_agent') continue;
        $sp = deiAgentSpv($x, $users);
        if ($sp === '' || $sp === $me) $out[(string)($x['username'] ?? '')] = true;
    }
    return $out;
}
// Chat belum diklaim selalu terlihat; chat diklaim hanya bila pemegangnya masuk lingkup.
function deiSpvSeesOwner($scope, $owner) { return $scope === null || $owner === '' || isset($scope[$owner]); }
function deiGuardSpvScope($u, $num) {
    if (($u['role'] ?? '') !== 'supervisor') return;
    $cl = waClaimGet($num);
    $owner = (string)($cl['agent_username'] ?? '');
    if (deiSpvSeesOwner(deiSpvScope($u), $owner)) return;
    jsonOut(['ok' => false, 'error' => 'Chat ini dipegang ' . $owner . ' (di luar tim Anda).'], 403);
}

/* ---------- log event agent (append-only, per bulan) ---------- */
function agentEvent($ev, $agent, $num, $extra = []) {
    try {
        if (!is_dir(AGENT_EV_DIR)) @mkdir(AGENT_EV_DIR, 0755, true);
        $row = array_merge(['t' => time(), 'ev' => (string)$ev, 'agent' => (string)$agent, 'num' => waNormNum($num)], $extra);
        @file_put_contents(AGENT_EV_DIR . '/' . wibDate('Y-m') . '.jsonl',
            json_encode($row, JSON_UNESCAPED_UNICODE | JSON_UNESCAPED_SLASHES) . "\n", FILE_APPEND | LOCK_EX);
    } catch (\Throwable $e) { error_log('agentEvent: ' . $e->getMessage()); }
}
function agentEventsRead($fromTs, $toTs) {
    $out = [];
    $y = (int)wibDate('Y', $fromTs); $mo = (int)wibDate('n', $fromTs);
    $endKey = wibDate('Y-m', $toTs);
    for ($i = 0; $i < 14; $i++) {
        $key = sprintf('%04d-%02d', $y, $mo);
        $mo++; if ($mo > 12) { $mo = 1; $y++; }
        $f = AGENT_EV_DIR . '/' . $key . '.jsonl';
        if (is_file($f)) {
            $fh = @fopen($f, 'r');
            if ($fh) {
                while (($line = fgets($fh)) !== false) {
                    $r = json_decode($line, true);
                    if (!is_array($r)) continue;
                    $t = (int)($r['t'] ?? 0);
                    if ($t >= $fromTs && $t <= $toTs) $out[] = $r;
                }
                fclose($fh);
            }
        }
        if ($key >= $endKey) break;
    }
    return $out;
}
// WIB 'Y-m-d' -> ts awal hari (UTC epoch)
function wibDayStart($ymd) {
    if (!preg_match('/^\d{4}-\d{2}-\d{2}$/', (string)$ymd)) return null;
    $t = strtotime($ymd . ' 00:00:00 UTC');
    return $t === false ? null : $t - 7 * 3600;
}
// Akun yang bisa menerima assign chat (agent & supervisor dalam batas kursi).
function deiAssignableUsers($me = null) {
    $users = readJson(USERS_FILE, []);
    $scope = $me ? deiSpvScope($me, $users) : null;   // v1.2.59: supervisor hanya ke timnya
    $out = [];
    foreach ((array)$users as $u) {
        $r = $u['role'] ?? '';
        if (!in_array($r, ['wa_agent', 'supervisor', 'admin', 'super_admin'], true)) continue;
        if ($scope !== null && !isset($scope[$u['username'] ?? ''])) continue;
        if (!deiSeatAllowed($u['username'] ?? '', $r, $users)) continue;
        $out[] = ['username' => $u['username'] ?? '', 'name' => $u['name'] ?? ($u['username'] ?? ''), 'role' => $r];
    }
    return $out;
}

/* ---------- jejak balasan agent per nomor (untuk flag "Full bot" & FRT) ---------- */
function waAgentRepliedAll() { $a = readJson(WA_AGENT_REPLIED_FILE, []); return is_array($a) ? $a : []; }
// Catat balasan agent; kembalikan ts balasan agent SEBELUMNYA (0 = belum pernah).
function waAgentRepliedTouch($num) {
    $num = waNormNum($num);
    if ($num === '') return 0;
    $lock = @fopen(DATA_DIR . '/wa-agent-replied.lock', 'c');
    if ($lock) @flock($lock, LOCK_EX);
    $prev = 0;
    try {
        $all = waAgentRepliedAll();
        $prev = (int)($all[$num] ?? 0);
        $all[$num] = time();
        writeJson(WA_AGENT_REPLIED_FILE, $all);
    } finally {
        if ($lock) { @flock($lock, LOCK_UN); @fclose($lock); }
    }
    return $prev;
}

// Satu pintu untuk semua balasan agent (dashboard / HP): jejak + event laporan.
function deiRecordAgentReply($num, $agent, $src = 'dashboard') {
    try {
        $cs = convStateReadAll();
        $since = (int)($cs[waNormNum($num)]['guest_waiting_since'] ?? 0);   // dibaca SEBELUM convReply mengosongkannya
        $prev = waAgentRepliedTouch($num);
        $first = ($prev === 0 || (time() - $prev) > 86400);                  // balasan pertama sesi (jeda > 24 jam)
        $ex = ['first' => $first ? 1 : 0, 'src' => $src];
        if ($since > 0) $ex['wait'] = max(0, time() - $since);
        agentEvent('reply', $agent, $num, $ex);
        convTrack($num, 'agent', ['agent' => (string)$agent]);   // v1.2.101: percakapan
    } catch (\Throwable $e) { error_log('deiRecordAgentReply: ' . $e->getMessage()); }
}

/* ---------- flag status chat ----------
 * unreplied : pesan terakhir dari customer (bukan sekadar "ok makasih"), belum dibalas. Tidak pernah kedaluwarsa.
 * done      : pesan terakhir dari kita & customer diam >= 24 jam (atau customer pamit lalu diam >= 24 jam).
 * active    : selain itu.
 * full_bot  : belum pernah ada balasan agent sama sekali (mode AI). */
function deiChatFlag($num, $meta, $cs, $agentReplied, $now = null) {
    $now = $now ?? time();
    $st = is_array($cs[$num] ?? null) ? $cs[$num] : null;
    if ($st && !empty($st['last_from'])) {
        $from = (string)$st['last_from'];
        $at = (int)($st['last_at'] ?? 0);
        $bye = !empty($st['guest_bye']);
        $since = (int)($st['guest_waiting_since'] ?? 0);
    } else {
        // conv-state dipangkas setelah 3 hari diam -> tebak dari entri log terakhir
        $dir = (string)($meta['last_dir'] ?? '');
        $q = (string)($meta['last_q'] ?? ''); $a = (string)($meta['last_a'] ?? '');
        if ($dir === 'manual') $from = 'agent';
        elseif ($a === '' && $q !== '') $from = 'guest';
        else $from = 'bot';
        $at = strtotime((string)($meta['last_ts'] ?? '')) ?: 0;
        $bye = ($from === 'guest') && deiIsClosingPhrase($q);
        $since = ($from === 'guest' && !$bye) ? $at : 0;
    }
    if (!empty($meta['bot_failed']) && $from !== 'agent') { $from = 'guest'; $bye = false; if (!$since) $since = $at; }
    $flag = 'active'; $note = '';
    if ($from === 'guest' && !$bye) {
        $flag = 'unreplied';
    } elseif ($at > 0 && ($now - $at) >= 86400) {
        $flag = 'done';
        $note = ($from === 'guest') ? 'Customer menutup percakapan' : 'Tidak ada balasan customer dalam 24 jam';
    }
    // v1.2.101: percakapan — ditandai selesai (tombol Selesai) dan belum ada pesan baru sesudahnya
    if ($st && !empty($st['res_at']) && (int)$st['res_at'] >= (int)$at) {
        $flag = 'done'; $note = 'Ditandai selesai' . (!empty($st['res_by']) ? ' oleh ' . $st['res_by'] : '');
    }
    $hasAgent = isset($agentReplied[$num]) || !empty($meta['has_manual']);
    return [
        'flag'        => $flag,
        'flag_note'   => $note,
        'waiting_sec' => ($flag === 'unreplied' && $since > 0) ? max(0, $now - $since) : 0,
        'last_from'   => $from,
        'full_bot'    => !$hasAgent,
    ];
}

// ============================================================================
// === v1.2.0 WA Claim System — Helper Functions ==============================
// ============================================================================

/** Path ke file audit log WA claim. */
function waAuditLogFile() {
    return DATA_DIR . '/wa-audit-log.json';
}

/** Path ke file claim state (per nomor). Reuse pattern WA_MODES_FILE style. */
function waClaimFile() {
    return DATA_DIR . '/wa-claims.json';
}

/** Get claim state untuk 1 nomor. Return null kalau tidak claimed. */
function waClaimGet($number) {
    $number = waNormNum($number);
    if ($number === '') return null;
    $claims = readJson(waClaimFile(), []);
    return $claims[$number] ?? null;
}

/** Get semua claim state. Return array [number => claim_data]. */
function waClaimGetAll() {
    return readJson(waClaimFile(), []);
}

/** Set claim state untuk 1 nomor. Pass null untuk release (hapus entry). */
// v1.2.71: dibungkus kunci 'wa-claims' supaya worker paralel tidak saling menimpa.
function waClaimSet($number, $claim) {
    $prev = '';   // v1.2.101: percakapan — catat assign / lepas bila pemegang berubah
    $r = deiWithLock('wa-claims', function () use ($number, $claim, &$prev) {
        $cs = readJson(waClaimFile(), []);
        $prev = (string)($cs[waNormNum($number)]['agent_username'] ?? '');
        return waClaimSet_nolock($number, $claim);
    });
    $new = is_array($claim) ? (string)($claim['agent_username'] ?? '') : '';
    if ($r && $new !== '' && $new !== $prev) convTrack($number, 'assign', ['agent' => $new]);
    elseif ($r && $claim === null && $prev !== '') convTrack($number, 'release');
    return $r;
}
function waClaimSet_nolock($number, $claim) {
    $number = waNormNum($number);
    if ($number === '') return false;
    $claims = readJson(waClaimFile(), []);
    if ($claim === null) {
        unset($claims[$number]);
        // Sinkronkan mode ke bot supaya konsisten
        waSetMode($number, 'bot');
    } else {
        $claims[$number] = $claim;
        // Sinkronkan mode ke human supaya bot tidak balas
        waSetMode($number, 'human', 'assign');   // v1.2.101
    }
    writeJson(waClaimFile(), $claims);
    return true;
}

/** Update last_agent_activity untuk 1 nomor (dipanggil saat agent kirim manual reply). */
// v1.2.71: dibungkus kunci 'wa-claims' supaya worker paralel tidak saling menimpa.
function waClaimTouchActivity($number, $agent) {
    return deiWithLock('wa-claims', function () use ($number, $agent) { return waClaimTouchActivity_nolock($number, $agent); });
}
function waClaimTouchActivity_nolock($number, $agent) {
    $number = waNormNum($number);
    if ($number === '') return;
    $claims = readJson(waClaimFile(), []);
    if (!isset($claims[$number])) return;
    if (($claims[$number]['agent_username'] ?? '') !== $agent) return;
    $claims[$number]['last_agent_activity'] = time();
    writeJson(waClaimFile(), $claims);
}

/** Write audit log entry. Keep last 500 entries. */
// v1.2.71: dibungkus kunci 'wa-audit' supaya worker paralel tidak saling menimpa.
function waAuditLog($action, $agent, $number, $extra = []) {
    return deiWithLock('wa-audit', function () use ($action, $agent, $number, $extra) { return waAuditLog_nolock($action, $agent, $number, $extra); });
}
function waAuditLog_nolock($action, $agent, $number, $extra = []) {
    $entries = readJson(waAuditLogFile(), []);
    $entry = [
        'ts' => date('Y-m-d H:i:s'),
        'action' => $action,
        'agent' => $agent,
        'number' => waNormNum($number),
    ];
    if (!empty($extra)) $entry['extra'] = $extra;
    array_unshift($entries, $entry);
    $entries = array_slice($entries, 0, 500);
    writeJson(waAuditLogFile(), $entries);
}

/**
 * Auto-process expired claims + takeover requests.
 * - mode=human AND last_agent_activity > 30 menit → auto release
 * - takeover_request pending > 5 menit → auto approve
 * Return: [released_count, approved_count]
 */
// v1.2.71: dibungkus kunci 'wa-claims' supaya worker paralel tidak saling menimpa.
function waClaimAutoProcess() {
    return deiWithLock('wa-claims', function () { return waClaimAutoProcess_nolock(); });
}
function waClaimAutoProcess_nolock() {
    $claims = readJson(waClaimFile(), []);
    if (empty($claims)) return [0, 0];

    $now = time();
    $INACTIVITY_TIMEOUT = 30 * 60;  // 30 menit
    $TAKEOVER_TIMEOUT = 5 * 60;     // 5 menit
    $released = 0;
    $approved = 0;
    $changed = false;

    foreach ($claims as $num => $claim) {
        // 1. Auto-approve takeover request
        if (!empty($claim['takeover_request'])) {
            $req = $claim['takeover_request'];
            if ($now - ($req['requested_at'] ?? 0) > $TAKEOVER_TIMEOUT) {
                $oldAgent = $claim['agent_username'] ?? 'unknown';
                $claim['agent_username'] = $req['requester'];
                $claim['claimed_at'] = $now;
                $claim['last_agent_activity'] = $now;
                unset($claim['takeover_request']);
                waAuditLog('takeover_auto_approve', $req['requester'], $num, [
                    'from_agent' => $oldAgent,
                    'reason' => $req['reason'] ?? '',
                ]);
                $claims[$num] = $claim;
                $changed = true;
                $approved++;
            }
        }

        // 2. Auto-release kalau inactivity
        // v1.2.58: mode Manual -> claim tidak lepas otomatis (tidak ada bot
        // yang mengambil alih); SPV yang memindahkan chat bila perlu.
        if (deiIsManual()) continue;
        $lastActivity = $claim['last_agent_activity'] ?? $claim['claimed_at'] ?? 0;
        if ($now - $lastActivity > $INACTIVITY_TIMEOUT) {
            waAuditLog('auto_release', $claim['agent_username'] ?? 'unknown', $num, [
                'inactivity_seconds' => $now - $lastActivity,
            ]);
            unset($claims[$num]);
            waSetMode($num, 'bot');
            $changed = true;
            $released++;
        }
    }

    if ($changed) writeJson(waClaimFile(), $claims);
    return [$released, $approved];
}


/* v1.2.100: routing — bagi chat otomatis ke agent (lihat docstring patch v1.2.100). */
if (!defined('AGENT_PRESENCE_FILE')) define('AGENT_PRESENCE_FILE', DATA_DIR . '/agent-presence.json');
if (!defined('ROUTING_STATE_FILE')) define('ROUTING_STATE_FILE', DATA_DIR . '/routing-state.json');
if (!defined('PRESENCE_ONLINE_SEC')) define('PRESENCE_ONLINE_SEC', 120);
function deiRoutingConf($s = null) {
    if ($s === null) $s = getSettings();
    $r = is_array($s['routing'] ?? null) ? $s['routing'] : [];
    return [
        'enabled'     => !empty($r['enabled']),
        'method'      => (($r['method'] ?? 'load') === 'rr') ? 'rr' : 'load',
        'by_number'   => !empty($r['by_number']),
        'online_only' => !array_key_exists('online_only', $r) || !empty($r['online_only']),
        'max_active'  => max(0, min(500, (int)($r['max_active'] ?? 0))),
    ];
}
function deiPresenceAll() { $p = readJson(AGENT_PRESENCE_FILE, []); return is_array($p) ? $p : []; }
function deiPresenceOnline($row) {
    return is_array($row) && ($row['status'] ?? 'available') !== 'away' && (time() - (int)($row['seen'] ?? 0)) <= PRESENCE_ONLINE_SEC;
}
// Catat heartbeat (+ ubah status). Hasil: [online sebelum, online sesudah].
function deiPresenceTouch($username, $status = null) {
    return deiWithLock('agent-presence', function () use ($username, $status) {
        $all = deiPresenceAll();
        $row = is_array($all[$username] ?? null) ? $all[$username] : ['status' => 'available'];
        $was = deiPresenceOnline($row);
        $row['seen'] = time();
        if ($status !== null) $row['status'] = ($status === 'away') ? 'away' : 'available';
        $all[$username] = $row;
        writeJson(AGENT_PRESENCE_FILE, $all);
        return [$was, deiPresenceOnline($row)];
    });
}
// Daftar tim = supervisor yang ada.
function deiTeamsList($users = null) {
    if ($users === null) $users = readJson(USERS_FILE, []);
    $out = [];
    foreach ((array)$users as $u) {
        if (($u['role'] ?? '') === 'supervisor') $out[] = ['username' => (string)($u['username'] ?? ''), 'name' => (string)($u['name'] ?? ($u['username'] ?? ''))];
    }
    return $out;
}
// Tim yang menangani nomor bisnis $ch ('' = semua agent).
function deiChanTeam($ch, $s = null) {
    if ($s === null) $s = getSettings();
    $ch = (string)$ch;
    if ($ch !== '' && $ch !== 'utama') {
        foreach (waNumbersRaw($s) as $x) { if ((string)$x['id'] === $ch) return trim((string)($x['team'] ?? '')); }
    }
    return trim((string)($s['whatsapp_api']['team'] ?? ''));
}
function deiRouteCandidates($conf, $team, $users, $claims, $pres, $role) {
    $active = [];
    foreach ((array)$claims as $c) { $a = (string)($c['agent_username'] ?? ''); if ($a !== '') $active[$a] = ($active[$a] ?? 0) + 1; }
    $out = [];
    foreach ((array)$users as $u) {
        $un = (string)($u['username'] ?? ''); $r = (string)($u['role'] ?? '');
        if ($un === '' || $r !== $role) continue;
        if (!deiSeatAllowed($un, $r, $users)) continue;
        if ($team !== '' && ($r === 'supervisor' ? $un !== $team : deiAgentSpv($u, $users) !== $team)) continue;
        $p = $pres[$un] ?? null;
        if (is_array($p) && ($p['status'] ?? '') === 'away') continue;      // Istirahat: selalu dilewati
        if ($conf['online_only'] && !deiPresenceOnline($p)) continue;
        $n = $active[$un] ?? 0;
        if ($conf['max_active'] > 0 && $n >= $conf['max_active']) continue;
        $out[$un] = $n;
    }
    return $out;
}
// Serahkan chat $num ke agent secara otomatis. Hasil: username, atau '' bila tidak dibagikan.
// $ch = nomor bisnis yang dihubungi (null = dari kontak).
function deiRouteAssign($num, $ch = null, $s = null) {
    try {
        if ($s === null) $s = getSettings();
        $conf = deiRoutingConf($s);
        if (!$conf['enabled']) return '';
        $num = waNormNum($num);
        if ($num === '') return '';
        if ($ch === null || $ch === '') { $c = waContactGet($num); $ch = (string)(is_array($c) ? ($c['wa_ch'] ?? '') : ''); }
        $team = $conf['by_number'] ? deiChanTeam($ch, $s) : '';
        $pick = (string)deiWithLock('wa-routing', function () use ($num, $conf, $team) {
            $claims = waClaimGetAll();
            if (!empty($claims[$num])) return '';
            $users = readJson(USERS_FILE, []);
            $pres = deiPresenceAll();
            $cand = deiRouteCandidates($conf, $team, $users, $claims, $pres, 'wa_agent');
            if (!$cand) $cand = deiRouteCandidates($conf, $team, $users, $claims, $pres, 'supervisor');   // cadangan
            if (!$cand) return '';
            $st = readJson(ROUTING_STATE_FILE, []);
            $last = is_array($st['last'] ?? null) ? $st['last'] : [];
            $best = null; $bestKey = null;
            foreach ($cand as $un => $n) {
                $k = [$conf['method'] === 'load' ? $n : 0, (int)($last[$un] ?? 0), $un];
                if ($bestKey === null || $k < $bestKey) { $bestKey = $k; $best = $un; }
            }
            $now = time();
            $seq = (int)($st['seq'] ?? 0) + 1;   // urutan, bukan detik: beberapa chat bisa dibagikan di detik yang sama
            $st['seq'] = $seq;
            $last[$best] = $seq;
            $st['last'] = $last;
            writeJson(ROUTING_STATE_FILE, $st);
            waClaimSet($num, ['agent_username' => $best, 'claimed_at' => $now, 'last_agent_activity' => $now,
                              'assigned_by' => '(otomatis)', 'auto' => true]);
            return $best;
        });
        if ($pick === '') return '';
        try { waAuditLog('auto_assign', '(otomatis)', $num, ['to_agent' => $pick, 'team' => $team, 'method' => $conf['method']]); } catch (\Throwable $e) {}
        agentEvent('assign', $pick, $num, ['by' => '(otomatis)', 'from' => '']);
        try {
            $nm = waContactName($num);
            sendPushToUsers([$pick], 'Chat baru untuk Anda', '+' . $num . ($nm ? ' (' . $nm . ')' : '') . ' — dibagikan otomatis', deiDashboardUrl());
        } catch (\Throwable $e) { error_log('routing push: ' . $e->getMessage()); }
        return $pick;
    } catch (\Throwable $e) { error_log('deiRouteAssign: ' . $e->getMessage()); return ''; }
}
// Bagikan chat yang menunggu agent (belum diklaim, <= 24 jam, mode manusia). Hasil: jumlah dibagikan.
function deiRouteDrain($max = 10, $s = null) {
    try {
        if ($s === null) $s = getSettings();
        if (!deiRoutingConf($s)['enabled']) return 0;
        $cs = convStateReadAll();
        if (!is_array($cs) || !$cs) return 0;
        $claims = waClaimGetAll();
        $manual = deiIsManual($s);
        $now = time();
        $wait = [];
        foreach ($cs as $num => $st) {
            $since = (int)(is_array($st) ? ($st['guest_waiting_since'] ?? 0) : 0);
            $num = (string)$num;
            if ($since <= 0 || $now - $since > 86400 || !empty($claims[$num])) continue;
            if (!$manual && waGetMode($num) !== 'human') continue;
            $wait[$num] = $since;
        }
        asort($wait);
        $n = 0; $tries = 0;
        foreach (array_keys($wait) as $num) {
            if ($n >= $max || ++$tries > 40) break;
            if (deiRouteAssign($num, null, $s) !== '') $n++;
        }
        return $n;
    } catch (\Throwable $e) { error_log('deiRouteDrain: ' . $e->getMessage()); return 0; }
}

// === /v1.2.0 WA Claim System Helpers ========================================

// Does the message contain a handoff keyword? Single words match on word
// boundaries; multi-word phrases match as substring.
function waMatchHandoff($text, $keywords) {
    $t = ' ' . mb_strtolower(trim($text)) . ' ';
    $t = preg_replace('/[^\p{L}\p{N}]+/u', ' ', $t);
    foreach ($keywords as $kw) {
        $kw = mb_strtolower(trim($kw));
        if ($kw === '') continue;
        if (strpos($kw, ' ') !== false) {
            if (mb_strpos($t, $kw) !== false) return true;       // phrase
        } else {
            if (mb_strpos($t, ' ' . $kw . ' ') !== false) return true; // whole word
        }
    }
    return false;
}

// Send a Telegram notification (best-effort, never blocks the flow).
function tgNotify($s, $text) {
    $tg = is_array($s['telegram'] ?? null) ? $s['telegram'] : [];
    if (empty($tg['enabled']) || empty($tg['bot_token']) || empty($tg['chat_id'])) return false;
    $url = 'https://api.telegram.org/bot' . $tg['bot_token'] . '/sendMessage';
    $ch = curl_init($url);
    curl_setopt_array($ch, [
        CURLOPT_RETURNTRANSFER => true,
        CURLOPT_POST           => true,
        CURLOPT_TIMEOUT        => 8,
        CURLOPT_POSTFIELDS     => http_build_query([
            'chat_id' => $tg['chat_id'],
            'text'    => $text,
            'disable_web_page_preview' => 'true',
        ]),
    ]);
    curl_exec($ch);
    $code = curl_getinfo($ch, CURLINFO_HTTP_CODE);
    curl_close($ch);
    return $code >= 200 && $code < 300;
}

/* ============================================================================
 *  v1.2.56: AUTO-CLOSING + SOP ESKALASI (Emergency Response)
 *
 *  conv-state.json  : jejak pesan terakhir per nomor WA — siapa (guest/bot/
 *                     agent/system/closing) dan kapan. Terpisah dari
 *                     wa-sessions karena sesi itu kedaluwarsa 6 jam & tidak
 *                     ada sama sekali kalau keep_context dimatikan.
 *  escalations.json : insiden eskalasi + token "Saya tangani" + rate limit.
 *  cron_tick        : dipanggil dei-pusat tiap menit (atau CLI) dan
 *                     menjalankan sweep di bawah. Tanpa ini tidak ada yang
 *                     "bangun" saat tamu/bot diam.
 * ========================================================================= */
define('CONV_STATE_FILE', DATA_DIR . '/conv-state.json');
define('ESC_FILE', DATA_DIR . '/escalations.json');
define('DEI_AC_TEXT_ID', "Apakah ada lagi yang bisa kami bantu? Jika ada, silakan sampaikan di sini, atau hubungi Call Center kami di {telepon} untuk respon lebih cepat. Terima kasih \xF0\x9F\x99\x8F");
define('DEI_AC_TEXT_EN', "Is there anything else we can help you with? Feel free to reply here, or call our Call Center at {telepon} for a faster response. Thank you \xF0\x9F\x99\x8F");

if (!defined('DEI_AC_GAP_SEC')) define('DEI_AC_GAP_SEC', 12 * 3600);   // v1.2.102: closing-sekali — jeda minimal antar closing per nomor
function deiAcConf($s) {
    $c = is_array($s['auto_closing'] ?? null) ? $s['auto_closing'] : [];
    $tid = trim((string)($c['text_id'] ?? ''));
    $ten = trim((string)($c['text_en'] ?? ''));
    return [
        'enabled' => !empty($c['enabled']),
        'minutes' => max(1, (int)($c['minutes'] ?? 10)),
        'phone'   => trim((string)($c['phone'] ?? '')),
        'text_id' => $tid !== '' ? $tid : DEI_AC_TEXT_ID,
        'text_en' => $ten !== '' ? $ten : DEI_AC_TEXT_EN,
        'hours'   => trim((string)($c['hours'] ?? '')),
    ];
}
function deiAcText($ac, $lang) {
    $t = ($lang === 'en') ? $ac['text_en'] : $ac['text_id'];
    $tel = $ac['phone'] !== '' ? $ac['phone'] : '-';
    return str_replace(['{telepon}', '{phone}'], $tel, $t);
}

function deiEscContact($x) {
    if (!is_array($x)) return null;
    $c = [
        'name'     => trim((string)($x['name'] ?? '')),
        'wa'       => deiNormalizePhone($x['wa'] ?? '') ?: waNormNum($x['wa'] ?? ''),   // 0812.. -> 62812..
        'pushover' => trim((string)($x['pushover'] ?? '')),
        'ntfy'     => trim((string)($x['ntfy'] ?? '')),
    ];
    if ($c['wa'] === '' && $c['pushover'] === '' && $c['ntfy'] === '') return null;
    if ($c['name'] === '') $c['name'] = $c['wa'] !== '' ? ('+' . $c['wa']) : 'Kontak';
    return $c;
}
function deiEscConf($s) {
    $c = is_array($s['escalation'] ?? null) ? $s['escalation'] : [];
    $l1 = []; $l2 = [];
    foreach ((array)($c['l1_contacts'] ?? []) as $x) { $k = deiEscContact($x); if ($k) $l1[] = $k; }
    foreach ((array)($c['l2_contacts'] ?? []) as $x) { $k = deiEscContact($x); if ($k) $l2[] = $k; }
    $m1 = max(1, (int)($c['l1_minutes'] ?? 5));
    $m2 = max($m1 + 1, (int)($c['l2_minutes'] ?? 10));
    $srv = trim((string)($c['ntfy_server'] ?? ''));
    $tl  = trim((string)($c['wa_template_lang'] ?? ''));
    return [
        'enabled'          => !empty($c['enabled']),
        'hours'            => trim((string)($c['hours'] ?? '')),
        'l1_minutes'       => $m1,
        'l2_minutes'       => $m2,
        'l1'               => $l1,
        'l2'               => $l2,
        'pushover_token'   => trim((string)($c['pushover_app_token'] ?? '')),
        'ntfy_server'      => rtrim($srv !== '' ? $srv : 'https://ntfy.sh', '/'),
        'wa_template'      => trim((string)($c['wa_template'] ?? '')),
        'wa_template_lang' => $tl !== '' ? $tl : 'id',
    ];
}

// "08:00-22:00" (WIB). Kosong = 24 jam. Mendukung rentang lewat tengah malam.
function deiInHours($range, $ts = null) {
    $range = trim((string)$range);
    if ($range === '') return true;
    if (!preg_match('/^(\d{1,2})[:.](\d{2})\s*-\s*(\d{1,2})[:.](\d{2})$/', $range, $m)) return true;
    $a = (int)$m[1] * 60 + (int)$m[2];
    $b = (int)$m[3] * 60 + (int)$m[4];
    $now = (int)wibDate('G', $ts) * 60 + (int)wibDate('i', $ts);
    if ($a === $b) return true;
    return ($a < $b) ? ($now >= $a && $now < $b) : ($now >= $a || $now < $b);
}

// Ucapan penutup dari tamu ("ok makasih", "thanks", 👍). Dipakai untuk:
// (1) tidak mengirim closing ke tamu yang sudah pamit, (2) tidak membuka
// insiden eskalasi hanya karena tamu bilang "ok".
function deiIsClosingPhrase($t) {
    $t = mb_strtolower(trim((string)$t), 'UTF-8');
    $asli = $t;   // v1.2.102
    if ($t === '') return true;
    if (!preg_match('/[\p{L}\p{N}]/u', $t)) return true;            // hanya emoji / tanda baca
    $t = trim(preg_replace('/\s+/u', ' ', preg_replace('/[^\p{L}\s]/u', ' ', $t)));
    $inti = '(ok|oke|okey|okay|okeh|okee+|okok|sip|siap|baik|baiklah|noted|mantap|mantab|thanks?|thank you|thankyou|thx|tq|ty|tks|tengkyu|makasih|makasi|maksih|makasii+|trims|trimakasih|trimakasi|terimakasih|terima ?kasih|terima ?kasi|sama ?sama|suwun|nuhun|hatur nuhun)';
    $ekor = '( (ya|yah|yaa+|kak|ka|kk|kakak|min|mas|mbak|mba|pak|bu|bang|banyak|sekali|so much|a lot|very much|' . $inti . '))*';
    if (preg_match('/^' . $inti . $ekor . '$/u', $t)) return true;
    // v1.2.102: closing-sekali — jawaban "tidak ada / belum" (biasanya atas pertanyaan "ada lagi?")
    $tidak = '(sementara|smntara|smtr|sementara ini|untuk sementara|utk sementara|udah|sudah|sdh|udh|itu|itu aja|itu saja|cukup|cukup itu)? ?(belum|blm|blom|belom|tidak|tdk|gak|ga|gk|nggak|ngga|enggak|engga|no|nope|nothing|cukup|sudah|udah|sdh|udh|aman|enough)( (ada|ad|dulu|dl|lagi|lg|itu|aja|saja|kok|sih|cukup|jelas|paham|tau|tahu|thanks|' . $inti . '|ya|yah|kak|ka|kk|kakak|min|mas|mbak|mba|pak|bu|bang))*';
    if (preg_match('/^' . $tidak . '$/u', $t)) return true;
    // pesan pendek yang DIAKHIRI terima kasih ("maaf kejauhan, trimakasih ya kak") tanpa tanda tanya
    if (mb_strpos($asli, '?') === false && count(explode(' ', $t)) <= 8
        && !preg_match('/(^| )(berapa|brp|apa|apakah|ada|ad|bisa|bs|gimana|gmn|bagaimana|kapan|dimana|mana|mau|minta|tolong|info|harga|booking|book|pesan|reservasi|kamar|cek|check|how|what|when|where|can|could|please|pls)( |$)/u', $t)
        && preg_match('/(^| )' . $inti . '( (ya|yah|yaa+|kak|ka|kk|kakak|min|mas|mbak|mba|pak|bu|bang|banyak|sekali))*$/u', $t)) return true;
    return false;
}

/* ---------- conv-state: baca-ubah-tulis di bawah satu kunci ---------- */
function convStateMutate($fn, $num = null) {
    // v1.2.71: mode mysql mengunci satu baris; $num wajib (semua pemanggil mengubah satu nomor)
    if (deiStorageMysql()) {
        if ($num === null || waNormNum($num) === '') throw new \RuntimeException('convStateMutate: $num wajib di mode mysql');
        return convStateDbMutateOne($fn, $num);
    }
    $lock = @fopen(DATA_DIR . '/conv-state.lock', 'c');
    if ($lock) @flock($lock, LOCK_EX);
    $res = null;
    try {
        $all = readJson(CONV_STATE_FILE, []);
        if (!is_array($all)) $all = [];
        $res = $fn($all);
        $batas = time() - 3 * 86400;                                 // pangkas yang diam > 3 hari
        foreach ($all as $k => $v) { if ((int)($v['last_at'] ?? 0) < $batas) unset($all[$k]); }
        writeJson(CONV_STATE_FILE, $all);
    } finally {
        if ($lock) { @flock($lock, LOCK_UN); @fclose($lock); }
    }
    return $res;
}

// Pesan masuk dari tamu (WA).
function convGuestMsg($num, $text, $ch = '') {   // v1.2.101: + nomor bisnis
    $num = waNormNum($num);
    if ($num === '') return;
    $lang = deiDeteksiBahasa($text);
    $bye  = deiIsClosingPhrase($text);
    try {
        convStateMutate(function (&$all) use ($num, $text, $lang, $bye) {
            $now = time();
            $st = is_array($all[$num] ?? null) ? $all[$num] : [];
            if ((int)($st['last_at'] ?? 0) < $now - 86400) $st['bot_n'] = 0;   // v1.2.97: batas-ai
            $wasWaiting = !empty($st['guest_waiting_since']);
            $st['last_from'] = 'guest';
            $st['last_at']   = $now;
            // Ucapan penutup tidak MEMULAI masa tunggu; tapi kalau tamu memang
            // sudah menunggu, masa tunggunya tetap berjalan.
            if (!$wasWaiting) {
                $st['guest_waiting_since'] = $bye ? 0 : $now;
                $st['esc_level'] = 0; $st['esc_inc'] = ''; $st['esc_acked'] = 0;
            }
            $st['guest_bye'] = $bye ? 1 : 0;
            if ($lang === 'id' || $lang === 'en') $st['lang'] = $lang;
            $st['closing_sent_at'] = 0;
            $st['last_guest_text'] = mb_substr((string)$text, 0, 160);
            $all[$num] = $st;
        }, $num);
    } catch (\Throwable $e) { error_log('convGuestMsg: ' . $e->getMessage()); }
    convTrack($num, 'guest', ['ch' => (string)$ch, 'bye' => $bye]);   // v1.2.101: percakapan
}

// Balasan keluar. $who: bot | agent | system (pesan lisensi/kuota)
function convReply($num, $who) {
    $num = waNormNum($num);
    if ($num === '') return;
    try {
        $inc = convStateMutate(function (&$all) use ($num, $who) {
            $st = is_array($all[$num] ?? null) ? $all[$num] : [];
            $inc = (string)($st['esc_inc'] ?? '');
            $st['last_from'] = $who;
            $st['last_at']   = time();
            $st['guest_waiting_since'] = 0;
            $st['esc_level'] = 0; $st['esc_inc'] = ''; $st['esc_acked'] = 0;
            $st['closing_sent_at'] = 0;
            if ($who === 'bot') $st['bot_n'] = (int)($st['bot_n'] ?? 0) + 1;   // v1.2.97: batas-ai
            elseif ($who === 'agent') $st['bot_n'] = 0;
            $all[$num] = $st;
            return $inc;
        }, $num);
        if ($inc !== '' && $inc !== null) escResolve($inc, $who);
    } catch (\Throwable $e) { error_log('convReply: ' . $e->getMessage()); }
    if ($who === 'bot' || $who === 'system') convTrack($num, $who);   // v1.2.101: percakapan (agent lewat deiRecordAgentReply)
}

/* v1.2.101: percakapan — mesin status & statistik */
/* ======================================================================
 * v1.2.101: percakapan — siklus hidup per percakapan WA (laporan layanan)
 *  Dibuka   : pesan pelanggan masuk & tidak ada percakapan terbuka
 *             (agent mengirim duluan -> dibuka dengan origin 'outbound').
 *  Selesai  : agent menekan Selesai | pelanggan pamit setelah dibalas |
 *             pesan terakhir dari kita & pelanggan diam >= 24 jam (resolved_at = balasan terakhir).
 *  Dibuka lagi: pesan pelanggan <= 30 menit setelah selesai.
 *  Kedaluwarsa: tanpa aktivitas 7 hari tanpa memenuhi syarat selesai (tidak dihitung selesai).
 *  Status   : open (bot) | handover (menunggu agent) | assigned | resolved | expired
 * ==================================================================== */
if (!defined('CONV_TIMEOUT_SEC')) define('CONV_TIMEOUT_SEC', 86400);
if (!defined('CONV_REOPEN_SEC')) define('CONV_REOPEN_SEC', 1800);
if (!defined('CONV_EXPIRE_SEC')) define('CONV_EXPIRE_SEC', 7 * 86400);

function convNew($num, $now, $origin, $ch) {
    return [
        'id' => 'c' . wibDate('ymdHis', $now) . '-' . $num . '-' . bin2hex(random_bytes(2)),
        'num' => $num, 'ch' => (string)$ch, 'channel' => 'whatsapp', 'origin' => $origin,
        'status' => 'open', 'opened_at' => $now, 'last_at' => $now, 'last_from' => '',
        'guest_msgs' => 0, 'bot_msgs' => 0, 'agent_msgs' => 0, 'system_msgs' => 0,
        'first_reply_at' => 0, 'first_bot_at' => 0, 'handover_at' => 0, 'handover_reason' => '',
        'assigned_at' => 0, 'agent' => '', 'agents' => [], 'assign_n' => 0, 'first_agent_at' => 0,
        'wait_since' => 0, 'resp_sum' => 0, 'resp_n' => 0, 'aresp_sum' => 0, 'aresp_n' => 0,
        'closing_at' => 0, 'resolved_at' => 0, 'resolved_by' => '', 'resolver' => '', 'ended_at' => 0, 'reopen_n' => 0,
    ];
}
// Selesaikan otomatis bila sudah waktunya. Hasil: '' | 'timeout' | 'expired'.
function convAutoEnd(&$c, $now) {
    if (!is_array($c) || convIsFinal($c)) return '';
    $last = (int)($c['last_at'] ?? 0);
    if (in_array((string)($c['last_from'] ?? ''), ['bot', 'agent'], true) && $now - $last >= CONV_TIMEOUT_SEC) {
        $c['status'] = 'resolved'; $c['resolved_at'] = $last; $c['resolved_by'] = 'timeout';
        $c['ended_at'] = $now; $c['wait_since'] = 0;
        return 'timeout';
    }
    if ($now - $last >= CONV_EXPIRE_SEC) {
        $c['status'] = 'expired'; $c['ended_at'] = $now; $c['wait_since'] = 0;
        return 'expired';
    }
    return '';
}
function convResolve(&$c, $now, $by, $who = '') {
    $c['status'] = 'resolved'; $c['resolved_at'] = $now; $c['resolved_by'] = $by; $c['resolver'] = (string)$who;
    $c['ended_at'] = $now; $c['wait_since'] = 0;
}
function convOpenStatus($c) {
    if ((int)($c['assigned_at'] ?? 0) > 0 && (string)($c['agent'] ?? '') !== '') return 'assigned';
    return ((int)($c['handover_at'] ?? 0) > 0) ? 'handover' : 'open';
}
// Inti mesin status (murni; diuji terpisah). Mengubah $c / $flush. Hasil: true bila ada perubahan berarti.
function convApply(&$c, &$flush, $num, $ev, $x, $now) {
    // percakapan terbuka yang sebenarnya sudah lewat waktunya (cron belum sempat menyapu)
    if (is_array($c) && !convIsFinal($c) && convAutoEnd($c, $now) !== '') { $flush[] = $c; $c = null; }

    if ($ev === 'guest') {
        $bye = !empty($x['bye']);
        if (is_array($c) && convIsFinal($c)) {
            $since = $now - (int)($c['ended_at'] ?? 0);
            if ($c['status'] === 'resolved' && $since <= CONV_REOPEN_SEC) {
                $c['guest_msgs']++;
                if ($bye) return true;                                   // "ok makasih" susulan: tetap selesai
                $c['status'] = 'open'; $c['status'] = convOpenStatus($c);
                $c['resolved_at'] = 0; $c['resolved_by'] = ''; $c['resolver'] = ''; $c['ended_at'] = 0;
                $c['reopen_n'] = (int)($c['reopen_n'] ?? 0) + 1;
                $c['last_from'] = 'guest'; $c['last_at'] = $now; $c['wait_since'] = $now;
                if (!empty($x['ch'])) $c['ch'] = (string)$x['ch'];
                return true;
            }
            if ($bye) { $c['guest_msgs']++; return true; }               // pamit ke percakapan yang sudah selesai
            $c = null;
        }
        if ($c === null) {
            if ($bye) return false;                                      // "ok"/stiker tanpa percakapan aktif: bukan percakapan baru
            $c = convNew($num, $now, 'inbound', (string)($x['ch'] ?? ''));
            if (!empty($x['human'])) {
                $c['handover_at'] = $now;
                $c['handover_reason'] = !empty($x['manual']) ? 'manual_mode' : 'mode_human';
                $c['status'] = 'handover';
            }
            if (!empty($x['agent'])) {                                   // nomor masih dipegang agent (claim)
                $c['handover_at'] = $now; if ($c['handover_reason'] === '') $c['handover_reason'] = 'claimed';
                $c['assigned_at'] = $now; $c['agent'] = (string)$x['agent']; $c['assign_n'] = 1; $c['status'] = 'assigned';
            }
        }
        $c['guest_msgs']++;
        if (!empty($x['ch'])) $c['ch'] = (string)$x['ch'];
        $c['last_from'] = 'guest'; $c['last_at'] = $now;
        if ($bye) {
            if (((int)$c['bot_msgs'] + (int)$c['agent_msgs']) > 0) convResolve($c, $now, 'guest_bye');
        } elseif (empty($c['wait_since'])) {
            $c['wait_since'] = $now;
        }
        return true;
    }

    if ($ev === 'bot' || $ev === 'agent' || $ev === 'system') {
        $agent = (string)($x['agent'] ?? '');
        if ($c === null) {
            if ($ev !== 'agent') return false;
            $c = convNew($num, $now, 'outbound', (string)($x['ch'] ?? ''));
            $c['handover_at'] = $now; $c['handover_reason'] = 'outbound';
        }
        $c[$ev . '_msgs'] = (int)($c[$ev . '_msgs'] ?? 0) + 1;
        if (convIsFinal($c)) return true;                                // balasan susulan setelah selesai: hanya dihitung
        if ($ev === 'system') return true;                               // pesan lisensi/kuota bukan jawaban
        if (!$c['first_reply_at']) $c['first_reply_at'] = $now;
        $ws = (int)($c['wait_since'] ?? 0);
        if ($ws > 0) {
            $c['resp_sum'] += max(0, $now - $ws); $c['resp_n']++;
            if ($ev === 'agent') { $c['aresp_sum'] += max(0, $now - $ws); $c['aresp_n']++; }
            $c['wait_since'] = 0;
        }
        if ($ev === 'bot') {
            if (!$c['first_bot_at']) $c['first_bot_at'] = $now;
        } else {
            if (!$c['first_agent_at']) $c['first_agent_at'] = $now;
            if ($agent !== '' && !in_array($agent, (array)$c['agents'], true)) $c['agents'][] = $agent;
            if (!$c['handover_at']) { $c['handover_at'] = $now; $c['handover_reason'] = 'agent_reply'; }
            if (!$c['assigned_at']) { $c['assigned_at'] = $now; $c['assign_n'] = max(1, (int)$c['assign_n']); }
            if ($agent !== '' && ($c['agent'] === '' || $c['agent'] === '(HP)')) $c['agent'] = $agent;
            elseif ($c['agent'] === '') $c['agent'] = '(HP)';
            $c['status'] = 'assigned';
        }
        $c['last_from'] = $ev; $c['last_at'] = $now;
        return true;
    }

    if (!is_array($c) || convIsFinal($c)) return false;                  // event berikut hanya untuk percakapan terbuka

    if ($ev === 'handover') {
        if ($c['handover_at']) return false;
        $c['handover_at'] = $now; $c['handover_reason'] = (string)($x['reason'] ?? 'mode_human');
        $c['status'] = convOpenStatus($c);
        return true;
    }
    if ($ev === 'assign') {
        $agent = (string)($x['agent'] ?? '');
        if ($agent === '') return false;
        if (!$c['handover_at']) { $c['handover_at'] = $now; $c['handover_reason'] = 'assign'; }
        if (!$c['assigned_at']) $c['assigned_at'] = $now;
        if ($c['agent'] !== $agent) { $c['agent'] = $agent; $c['assign_n'] = (int)$c['assign_n'] + 1; }
        $c['status'] = 'assigned';
        return true;
    }
    if ($ev === 'release') {
        if ($c['status'] !== 'assigned') return false;
        // agent terakhir tetap tercatat (atribusi); Mode Manual -> kembali ke antrean, Mode AI -> bot
        $c['status'] = !empty($x['manual']) ? 'handover' : 'open';
        return true;
    }
    if ($ev === 'closing') { $c['closing_at'] = $now; return true; }
    if ($ev === 'resolve') { convResolve($c, $now, 'agent', (string)($x['agent'] ?? '')); return true; }
    return false;
}
// Satu pintu pencatatan. Tidak pernah melempar — gagal mencatat tidak boleh mengganggu balasan.
function convTrack($num, $ev, $x = []) {
    $num = waNormNum($num);
    if ($num === '') return false;
    try {
        if ($ev === 'guest') {
            $x['human'] = (waGetMode($num) === 'human');
            $x['manual'] = deiIsManual();
            $cl = waClaimGet($num);
            if ($cl && !empty($cl['agent_username'])) $x['agent'] = (string)$cl['agent_username'];
        }
        if ($ev === 'release') $x['manual'] = deiIsManual();
        return (bool)convStoreMutate($num, function (&$c, &$flush) use ($num, $ev, $x) {
            return convApply($c, $flush, $num, $ev, $x, time());
        });
    } catch (\Throwable $e) { error_log('convTrack(' . $ev . '): ' . $e->getMessage()); return false; }
}
// cron_tick: selesaikan percakapan yang sudah waktunya + rapikan berkas terbuka.
function convSweep($now = null) {
    $now = $now ?? time();
    $out = ['timeout' => 0, 'expired' => 0, 'evicted' => 0];
    foreach (convStoreOpen() as $c0) {
        $tmp = $c0;
        if (convAutoEnd($tmp, $now) === '') continue;                    // pra-saring tanpa kunci
        convStoreMutate((string)$c0['num'], function (&$c, &$flush) use ($now, &$out, $c0) {
            if (!is_array($c) || ($c['id'] ?? '') !== $c0['id']) return;
            $r = convAutoEnd($c, $now);
            if ($r !== '') $out[$r]++;
        });
    }
    $out['evicted'] = convStoreEvict($now);
    return $out;
}

/* ---------- v1.2.101: statistik layanan dari record percakapan ---------- */
function convAvg($sum, $n) { return $n > 0 ? (int)round($sum / $n) : null; }
function convStats($recs, $fromTs, $toTs, $chLabels = []) {
    $z = function () { return ['n' => 0, 'sum' => 0]; };
    $T = ['total' => 0, 'inbound' => 0, 'outbound' => 0, 'customers' => 0,
          'open_now' => 0, 'unassigned' => 0, 'assigned' => 0, 'resolved' => 0, 'expired' => 0, 'in_progress' => 0,
          'bot_handled' => 0, 'bot_resolved' => 0, 'to_agent' => 0, 'reopened' => 0,
          'resolved_agent' => 0, 'resolved_bye' => 0, 'resolved_timeout' => 0,
          'guest_msgs' => 0, 'bot_msgs' => 0, 'agent_msgs' => 0];
    $A = ['frt' => $z(), 'frt_agent' => $z(), 'wait' => $z(), 'resp' => $z(), 'resp_agent' => $z(), 'resolution' => $z(), 'bot_resolution' => $z()];
    $nums = []; $daily = []; $hourly = array_fill(0, 24, 0); $wday = array_fill(1, 7, 0);
    $reasons = []; $agents = []; $chans = [];
    for ($d = $fromTs; $d <= $toTs; $d += 86400) $daily[wibDate('Y-m-d', $d)] = ['date' => wibDate('Y-m-d', $d), 'total' => 0, 'bot_resolved' => 0, 'to_agent' => 0, 'resolved' => 0];
    $add = function (&$a, $v) { if ($v !== null && $v >= 0) { $a['n']++; $a['sum'] += $v; } };
    foreach ($recs as $c) {
        $o = (int)$c['opened_at'];
        $in = (($c['origin'] ?? 'inbound') === 'inbound');
        $st = (string)($c['status'] ?? 'open');
        $res = ($st === 'resolved');
        $hand = (int)($c['handover_at'] ?? 0); $asg = (int)($c['assigned_at'] ?? 0);
        $bot = (int)($c['bot_msgs'] ?? 0) > 0;
        $botRes = $res && $bot && !$hand && (int)($c['agent_msgs'] ?? 0) === 0;
        $T['total']++; $T[$in ? 'inbound' : 'outbound']++;
        $nums[$c['num']] = 1;
        if ($st === 'open') $T['open_now']++;
        if ($st === 'handover') $T['unassigned']++;
        if (in_array($st, ['open', 'handover', 'assigned'], true)) $T['in_progress']++;
        if ($asg) $T['assigned']++;
        if ($res) { $T['resolved']++; $rb = (string)($c['resolved_by'] ?? ''); if ($rb === 'agent') $T['resolved_agent']++; elseif ($rb === 'guest_bye') $T['resolved_bye']++; else $T['resolved_timeout']++; }
        if ($st === 'expired') $T['expired']++;
        if ($bot) $T['bot_handled']++;
        if ($botRes) $T['bot_resolved']++;
        if ($bot && $hand) $T['to_agent']++;
        if ((int)($c['reopen_n'] ?? 0) > 0) $T['reopened']++;
        foreach (['guest_msgs', 'bot_msgs', 'agent_msgs'] as $k) $T[$k] += (int)($c[$k] ?? 0);
        if ($hand) { $r = (string)($c['handover_reason'] ?? '') ?: 'lainnya'; $reasons[$r] = ($reasons[$r] ?? 0) + 1; }

        $frt = $frtA = $wait = $resol = null;
        if ($in) {
            if ((int)$c['first_reply_at']) $frt = (int)$c['first_reply_at'] - $o;
            if ((int)$c['first_agent_at']) $frtA = (int)$c['first_agent_at'] - max($hand, $o);
            if ($asg && $hand) $wait = max(0, $asg - $hand);
            if ($res) $resol = max(0, (int)$c['resolved_at'] - $o);
            $add($A['frt'], $frt); $add($A['frt_agent'], $frtA); $add($A['wait'], $wait); $add($A['resolution'], $resol);
            if ($botRes) $add($A['bot_resolution'], $resol);
        }
        $A['resp']['n'] += (int)$c['resp_n']; $A['resp']['sum'] += (int)$c['resp_sum'];
        $A['resp_agent']['n'] += (int)$c['aresp_n']; $A['resp_agent']['sum'] += (int)$c['aresp_sum'];

        $dk = wibDate('Y-m-d', $o);
        if (isset($daily[$dk])) {
            $daily[$dk]['total']++;
            if ($botRes) $daily[$dk]['bot_resolved']++;
            if ($bot && $hand) $daily[$dk]['to_agent']++;
            if ($res) $daily[$dk]['resolved']++;
        }
        if ($in) { $hourly[(int)wibDate('G', $o)]++; $wday[(int)wibDate('N', $o)]++; }

        $ag = (string)($c['agent'] ?? '');
        if ($ag !== '' && $asg) {
            if (!isset($agents[$ag])) $agents[$ag] = ['agent' => $ag, 'assigned' => 0, 'resolved' => 0, 'in_progress' => 0, 'msgs' => 0,
                'frt' => $z(), 'resp' => $z(), 'resolution' => $z()];
            $R = &$agents[$ag];
            $R['assigned']++; if ($res) $R['resolved']++; if (!convIsFinal($c)) $R['in_progress']++;
            $R['msgs'] += (int)($c['agent_msgs'] ?? 0);
            $add($R['frt'], $frtA); $add($R['resolution'], $resol);
            $R['resp']['n'] += (int)$c['aresp_n']; $R['resp']['sum'] += (int)$c['aresp_sum'];
            unset($R);
        }
        $ch = (string)($c['ch'] ?? '') ?: 'utama';
        if (!isset($chans[$ch])) $chans[$ch] = ['ch' => $ch, 'label' => $chLabels[$ch] ?? $ch, 'total' => 0, 'bot_resolved' => 0, 'to_agent' => 0, 'resolved' => 0, 'unassigned' => 0,
            'frt' => $z(), 'frt_agent' => $z(), 'resolution' => $z()];
        $C = &$chans[$ch];
        $C['total']++; if ($botRes) $C['bot_resolved']++; if ($bot && $hand) $C['to_agent']++; if ($res) $C['resolved']++; if ($st === 'handover') $C['unassigned']++;
        $add($C['frt'], $frt); $add($C['frt_agent'], $frtA); $add($C['resolution'], $resol);
        unset($C);
    }
    $T['customers'] = count($nums);
    $avg = [];
    foreach ($A as $k => $a) $avg[$k] = convAvg($a['sum'], $a['n']);
    $avg['bot_rate'] = $T['bot_handled'] > 0 ? round($T['bot_resolved'] * 100 / $T['bot_handled'], 1) : null;
    $avg['resolved_rate'] = $T['total'] > 0 ? round($T['resolved'] * 100 / $T['total'], 1) : null;
    $avg['handover_rate'] = $T['bot_handled'] > 0 ? round($T['to_agent'] * 100 / $T['bot_handled'], 1) : null;
    $fin = function ($rows, $keys) {
        $o = [];
        foreach ($rows as $r) { foreach ($keys as $k) $r[$k] = convAvg($r[$k]['sum'], $r[$k]['n']); $o[] = $r; }
        usort($o, function ($a, $b) { return ($b['assigned'] ?? $b['total']) <=> ($a['assigned'] ?? $a['total']); });
        return $o;
    };
    // rata-rata per hari dalam seminggu = jumlah / banyaknya hari itu dalam rentang
    $wdN = array_fill(1, 7, 0);
    for ($d = $fromTs; $d <= $toTs; $d += 86400) $wdN[(int)wibDate('N', $d)]++;
    $wdOut = [];
    foreach ($wday as $k => $v) $wdOut[] = ['day' => $k, 'total' => $v, 'avg' => $wdN[$k] ? round($v / $wdN[$k], 1) : 0];
    arsort($reasons);
    return [
        'totals' => $T, 'avg' => $avg,
        'daily' => array_values($daily), 'hourly' => $hourly, 'weekday' => $wdOut,
        'handover_reasons' => $reasons,
        'agents' => $fin($agents, ['frt', 'resp', 'resolution']),
        'channels' => $fin($chans, ['frt', 'frt_agent', 'resolution']),
    ];
}
// Nama kontak untuk sekumpulan record (mode file: satu kali baca; mysql: per nomor).
function convContactNames($recs) {
    $out = [];
    try {
        $nums = array_unique(array_map(function ($c) { return (string)$c['num']; }, $recs));
        if (!deiStorageMysql()) {
            $all = waGetContacts();
            foreach ($nums as $n) if (isset($all[$n])) $out[$n] = (string)($all[$n]['name'] ?? '');
        } else {
            foreach ($nums as $n) { $ct = waContactGet($n); if ($ct) $out[$n] = (string)($ct['name'] ?? ''); }
        }
    } catch (\Throwable $e) {}
    return $out;
}
// Ringkas untuk UI (thread & daftar).
function convPublic($c) {
    if (!is_array($c)) return null;
    $k = ['id', 'num', 'ch', 'origin', 'status', 'opened_at', 'last_at', 'last_from', 'guest_msgs', 'bot_msgs', 'agent_msgs',
          'first_reply_at', 'handover_at', 'handover_reason', 'assigned_at', 'agent', 'first_agent_at', 'resolved_at', 'resolved_by', 'resolver', 'reopen_n'];
    $o = [];
    foreach ($k as $x) $o[$x] = $c[$x] ?? null;
    return $o;
}
// Sejak kapan percakapan tercatat (ts) — null bila belum ada.
function convTrackingSince() {
    try {
        if (deiStorageMysql()) {
            return convDbRun(function () { $v = deiDb()->query('SELECT MIN(opened_at) FROM dei_conversations')->fetchColumn(); return $v ? (int)$v : null; });
        }
        $min = null;
        $files = glob(CONV_DIR . '/*.jsonl') ?: [];
        sort($files);
        if ($files) { $fh = @fopen($files[0], 'r'); if ($fh) { $c = json_decode((string)fgets($fh), true); fclose($fh); if (is_array($c)) $min = (int)$c['opened_at']; } }
        $f = CONV_OPEN_FILE;
        foreach ((array)readJson($f, []) as $c) if (is_array($c) && ($min === null || (int)$c['opened_at'] < $min)) $min = (int)$c['opened_at'];
        return $min;
    } catch (\Throwable $e) { return null; }
}

/* ---------- escalations.json ---------- */
function escMutate($fn) {
    $lock = @fopen(DATA_DIR . '/escalations.lock', 'c');
    if ($lock) @flock($lock, LOCK_EX);
    $res = null;
    try {
        $db = readJson(ESC_FILE, []);
        if (!is_array($db)) $db = [];
        foreach (['incidents', 'tokens', 'rate'] as $k) if (!is_array($db[$k] ?? null)) $db[$k] = [];
        $res = $fn($db);
        $batas = time() - 90 * 86400;                                // insiden disimpan 90 hari
        foreach ($db['incidents'] as $id => $inc) {
            if ((int)($inc['opened_at'] ?? 0) < $batas) unset($db['incidents'][$id]);
        }
        foreach ($db['tokens'] as $t => $v) {
            if ((int)($v['exp'] ?? 0) < time() - 86400) unset($db['tokens'][$t]);
        }
        writeJson(ESC_FILE, $db);
    } finally {
        if ($lock) { @flock($lock, LOCK_UN); @fclose($lock); }
    }
    return $res;
}
function escResolve($incId, $by) {
    escMutate(function (&$db) use ($incId, $by) {
        if (!isset($db['incidents'][$incId])) return;
        if (!empty($db['incidents'][$incId]['resolved_at'])) return;
        $db['incidents'][$incId]['resolved_at'] = time();
        $db['incidents'][$incId]['resolved_by'] = $by;
    });
}

/* ---------- pengirim notifikasi ---------- */
function escDry() { return !empty($GLOBALS['dei_dry']); }
function escDryLog($row) { $GLOBALS['esc_dry_log'][] = $row; }

function escSendPushover($token, $user, $title, $msg, $url) {
    if ($token === '' || $user === '') return ['ok' => false, 'error' => 'Pushover app token / user key kosong'];
    if (escDry()) { escDryLog(['via' => 'pushover', 'to' => $user, 'title' => $title, 'msg' => $msg, 'url' => $url]); return ['ok' => true, 'dry' => true]; }
    $f = ['token' => $token, 'user' => $user, 'title' => $title, 'message' => $msg,
          'priority' => 2, 'retry' => 60, 'expire' => 1800, 'sound' => 'siren'];
    if ($url !== '') { $f['url'] = $url; $f['url_title'] = 'Saya tangani'; }
    $ch = curl_init('https://api.pushover.net/1/messages.json');
    curl_setopt_array($ch, [CURLOPT_RETURNTRANSFER => true, CURLOPT_POST => true, CURLOPT_TIMEOUT => 10,
        CURLOPT_POSTFIELDS => http_build_query($f)]);
    $r = curl_exec($ch); $code = curl_getinfo($ch, CURLINFO_HTTP_CODE); curl_close($ch);
    if ($code >= 200 && $code < 300) return ['ok' => true];
    return ['ok' => false, 'error' => 'Pushover HTTP ' . $code . ' ' . mb_substr((string)$r, 0, 150)];
}
function escSendNtfy($server, $topic, $title, $msg, $url) {
    if ($topic === '') return ['ok' => false, 'error' => 'topic ntfy kosong'];
    if (escDry()) { escDryLog(['via' => 'ntfy', 'to' => $topic, 'title' => $title, 'msg' => $msg, 'url' => $url]); return ['ok' => true, 'dry' => true]; }
    $h = ['Title: ' . preg_replace('/[^\x20-\x7E]/', '', $title), 'Priority: urgent', 'Tags: rotating_light'];
    if ($url !== '') $h[] = 'Click: ' . $url;
    $ch = curl_init($server . '/' . rawurlencode($topic));
    curl_setopt_array($ch, [CURLOPT_RETURNTRANSFER => true, CURLOPT_POST => true, CURLOPT_TIMEOUT => 10,
        CURLOPT_HTTPHEADER => $h, CURLOPT_POSTFIELDS => $msg]);
    $r = curl_exec($ch); $code = curl_getinfo($ch, CURLINFO_HTTP_CODE); curl_close($ch);
    if ($code >= 200 && $code < 300) return ['ok' => true];
    return ['ok' => false, 'error' => 'ntfy HTTP ' . $code . ' ' . mb_substr((string)$r, 0, 150)];
}
// WA ke Supervisor/Manager. Cloud API (Meta) di luar jendela 24 jam WAJIB
// template; kalau template diisi, dipakai. Fonnte = teks bebas.
function escSendWa($s, $ec, $to, $text, $vars) {
    if ($to === '') return ['ok' => false, 'error' => 'nomor kosong'];
    if (escDry()) { escDryLog(['via' => 'wa', 'to' => $to, 'msg' => $text]); return ['ok' => true, 'dry' => true]; }
    $wa = waConf($s);
    if (($wa['provider'] ?? 'meta') === 'meta' && $ec['wa_template'] !== '') {
        return waSendTemplate($wa, $to, $ec['wa_template'], $ec['wa_template_lang'], $vars);
    }
    $GLOBALS['wa_last_error'] = '';
    if (waSend($wa, $to, $text)) return ['ok' => true];
    $e = trim((string)($GLOBALS['wa_last_error'] ?? ''));
    return ['ok' => false, 'error' => $e !== '' ? $e : 'gagal kirim WA'];
}

function deiSelfApiUrl() {
    $host = $_SERVER['HTTP_HOST'] ?? '';
    if ($host === '') return '';
    $scheme = (!empty($_SERVER['HTTPS']) && $_SERVER['HTTPS'] !== 'off') ? 'https' : 'http';
    if (($_SERVER['HTTP_X_FORWARDED_PROTO'] ?? '') === 'https') $scheme = 'https';
    $uri = $_SERVER['REQUEST_URI'] ?? '';
    $base = (($p = strpos($uri, '/api/')) !== false) ? substr($uri, 0, $p) : '';
    return $scheme . '://' . $host . $base . '/api/index.php';
}
// URL API tenant diingat dari request HTTP (dashboard / cron pusat) supaya
// cron CLI pun bisa membuat link "Saya tangani".
function deiRememberApiUrl() {
    $u = deiSelfApiUrl();
    if ($u === '') return;
    $f = DATA_DIR . '/self-url.txt';
    if (@file_get_contents($f) !== $u) @file_put_contents($f, $u, LOCK_EX);
}
function deiRememberedApiUrl() {
    return trim((string)@file_get_contents(DATA_DIR . '/self-url.txt'));
}
function deiTenantName($s) {
    $n = trim((string)($s['bot']['persona_company'] ?? ''));
    if ($n === '') $n = trim((string)($s['central_server']['tenant_id'] ?? ''));
    return $n !== '' ? $n : deiBrandProduct();   // v1.2.73
}

// Kirim ke semua kontak satu level, dengan rate limit per kontak
// (maks 10 alarm / 10 menit — mencegah badai notifikasi).
function escNotifyContacts($s, $ec, $contacts, $title, $text, $vars, $incId, $infoOnly = false) {
    $hasil = [];
    foreach ($contacts as $c) {
        $key = $c['wa'] . '|' . $c['pushover'] . '|' . $c['ntfy'];
        $boleh = escMutate(function (&$db) use ($key) {
            $now = time();
            $list = array_values(array_filter((array)($db['rate'][$key] ?? []), function ($t) use ($now) { return $t > $now - 600; }));
            if (count($list) >= 10) { $db['rate'][$key] = $list; return false; }
            $list[] = $now; $db['rate'][$key] = $list; return true;
        });
        if (!$boleh) { $hasil[] = ['name' => $c['name'], 'suppressed' => true]; continue; }

        $url = '';
        if ($incId !== '' && !$infoOnly) {
            $base = deiSelfApiUrl();
            if ($base === '') $base = deiRememberedApiUrl();             // CLI: pakai URL yang pernah tercatat
            if ($base !== '') {
                $tok = bin2hex(random_bytes(12));
                escMutate(function (&$db) use ($tok, $incId, $c) {
                    $db['tokens'][$tok] = ['inc' => $incId, 'name' => $c['name'], 'exp' => time() + 6 * 3600];
                });
                $url = $base . '?action=esc_ack&t=' . $tok;
            }
        }
        $msg = $text . ($url !== '' ? "\n\n\xF0\x9F\x91\x89 Saya tangani: " . $url : '');
        $r = ['name' => $c['name']];
        if ($c['wa'] !== '') {
            $v = $vars; $v[] = ($url !== '' ? $url : '-');
            $r['wa'] = escSendWa($s, $ec, $c['wa'], $msg, $v);
        }
        if (!$infoOnly) {
            if ($c['pushover'] !== '') $r['pushover'] = escSendPushover($ec['pushover_token'], $c['pushover'], $title, $text, $url);
            if ($c['ntfy'] !== '')     $r['ntfy']     = escSendNtfy($ec['ntfy_server'], $c['ntfy'], $title, $text, $url);
        }
        $hasil[] = $r;
    }
    return $hasil;
}

/* ---------- SWEEP 1: Auto-Closing WA ---------- */
function autoClosingSweep($s) {
    if (deiIsManual($s)) return [];      // v1.2.58: mode Manual tanpa pesan otomatis
    $ac = deiAcConf($s);
    if (!$ac['enabled'] || !deiInHours($ac['hours'])) return [];
    $wa = waConf($s);
    if (!($wa['enabled'] ?? false)) return [];
    $all = convStateReadAll();
    if (!is_array($all) || empty($all)) return [];
    $now = time();
    $batas = $ac['minutes'] * 60;
    $keepCtx = ($wa['keep_context'] ?? true);
    $out = [];
    foreach ($all as $num => $st) {
        $num = (string)$num;
        if (($st['last_from'] ?? '') !== 'bot') continue;
        if (!empty($st['closing_sent_at']) || !empty($st['guest_bye'])) continue;
        if ($now - (int)($st['closing_once_at'] ?? 0) < DEI_AC_GAP_SEC) continue;   // v1.2.102: closing-sekali
        $lastAt = (int)($st['last_at'] ?? 0);
        $age = $now - $lastAt;
        if ($age < $batas || $age > 20 * 3600) continue;             // > 20 jam: basi / dekat batas 24 jam Meta
        if (waGetMode($num) === 'human' || waClaimGet($num)) continue; // agent sedang pegang

        // tandai dulu, baru kirim -> tick yang tumpang-tindih tidak mengirim dua kali
        $klaim = convStateMutate(function (&$a) use ($num, $lastAt) {
            if (($a[$num]['last_from'] ?? '') !== 'bot' || (int)($a[$num]['last_at'] ?? 0) !== $lastAt || !empty($a[$num]['closing_sent_at'])) return false;
            if (time() - (int)($a[$num]['closing_once_at'] ?? 0) < DEI_AC_GAP_SEC) return false;   // v1.2.102
            $a[$num]['closing_sent_at'] = time();
            $a[$num]['closing_once_at'] = time();   // v1.2.102: TIDAK di-reset oleh pesan tamu/bot
            return true;
        }, $num);
        if (!$klaim) continue;

        $text = deiAcText($ac, (string)($st['lang'] ?? 'id'));
        if (escDry()) { escDryLog(['via' => 'closing', 'to' => $num, 'msg' => $text]); $ok = true; }
        else { $ok = waSend($wa, $num, $text); }
        $out[] = ['number' => $num, 'ok' => (bool)$ok];
        if (!$ok) continue;
        convTrack($num, 'closing');   // v1.2.101: percakapan

        if ($keepCtx) { $h = waLoadHistory($num); $h[] = ['role' => 'assistant', 'content' => $text]; waSaveHistory($num, $h); }
        logPrepend([
            'ts' => date('Y-m-d H:i:s'), 'q' => '', 'a' => $text, 'ip' => $num,
            'channel' => 'whatsapp', 'dir' => 'closing',
            'utm_source' => 'whatsapp', 'utm_medium' => 'auto_closing', 'utm_campaign' => '', 'page' => '', 'referrer' => '',
        ], (int)($s['api']['log_limit'] ?? 500));
    }
    return $out;
}

/* ---------- SWEEP 2: Eskalasi ---------- */
function escReasonLabel($r) {
    $m = ['claimed_unanswered' => 'sudah di-claim agent, belum dibalas',
          'human_unanswered'   => 'mode manusia (handoff), belum ada agent membalas',
          'bot_failed'         => 'bot/AI gagal membalas',
          'manual_unanswered'  => 'mode manual, belum ada agent membalas'];   // v1.2.58
    return $m[$r] ?? $r;
}
function escBuildText($tenant, $menit, $kontak, $pesan, $reason, $L) {
    $label = ($L === 1) ? 'Supervisor' : 'Manager';
    return "\xF0\x9F\x9A\xA8 EMERGENCY \xE2\x80\x94 " . $tenant . "\n"
         . "Tamu menunggu " . $menit . " menit tanpa balasan.\n"
         . "Kontak: " . $kontak . "\n"
         . ($pesan !== '' ? "Pesan: \"" . $pesan . "\"\n" : '')
         . "Sebab: " . escReasonLabel($reason) . "\n"
         . "Level " . $L . " \xE2\x86\x92 " . $label;
}
function escalationSweep($s) {
    $ec = deiEscConf($s);
    if (!$ec['enabled'] || !deiInHours($ec['hours'])) return [];
    $all = convStateReadAll();
    if (!is_array($all) || empty($all)) return [];
    $now = time();
    $out = [];
    foreach ($all as $num => $st) {
        $num = (string)$num;
        $since = (int)($st['guest_waiting_since'] ?? 0);
        if ($since <= 0 || !empty($st['esc_acked'])) continue;
        $wait = $now - $since;
        if ($wait > 12 * 3600) continue;                            // basi — jangan bangunkan orang untuk ini
        $lvl = (int)($st['esc_level'] ?? 0);
        $target = ($wait >= $ec['l2_minutes'] * 60) ? 2 : (($wait >= $ec['l1_minutes'] * 60) ? 1 : 0);
        if ($target <= $lvl) continue;

        $claim = waClaimGet($num);
        $reason = $claim ? 'claimed_unanswered' : (deiIsManual($s) ? 'manual_unanswered' : (waGetMode($num) === 'human' ? 'human_unanswered' : 'bot_failed'));
        $incId = (string)($st['esc_inc'] ?? '');
        $baru = ($incId === '');
        if ($baru) $incId = 'inc_' . wibDate('Ymd_His') . '_' . bin2hex(random_bytes(2));

        $ok = convStateMutate(function (&$a) use ($num, $since, $target, $incId) {
            if ((int)($a[$num]['guest_waiting_since'] ?? 0) !== $since) return false;   // sudah dibalas
            if (!empty($a[$num]['esc_acked']) || (int)($a[$num]['esc_level'] ?? 0) >= $target) return false;
            $a[$num]['esc_level'] = $target;
            $a[$num]['esc_inc'] = $incId;
            return true;
        }, $num);
        if (!$ok) continue;

        $menit = (int)floor($wait / 60);
        $nama = waContactName($num);
        $kontak = '+' . $num . ($nama ? ' (' . $nama . ')' : '');
        $pesan = (string)($st['last_guest_text'] ?? '');
        $tenant = deiTenantName($s);
        if ($baru) {
            escMutate(function (&$db) use ($incId, $num, $since, $reason, $pesan) {
                $db['incidents'][$incId] = ['channel' => 'wa', 'contact' => $num, 'opened_at' => $since,
                    'reason' => $reason, 'message' => $pesan, 'level' => 0, 'notified' => [],
                    'ack_by' => '', 'ack_at' => 0, 'resolved_at' => 0, 'resolved_by' => ''];
            });
        }
        $notif = [];
        $title = 'EMERGENCY - ' . $tenant;
        $vars = [$tenant, (string)$menit, $kontak, $pesan !== '' ? $pesan : '-'];
        for ($L = $lvl + 1; $L <= $target; $L++) {
            $text = escBuildText($tenant, $menit, $kontak, $pesan, $reason, $L);
            $contacts = ($L === 1) ? $ec['l1'] : $ec['l2'];
            $notif['L' . $L] = escNotifyContacts($s, $ec, $contacts, $title, $text, $vars, $incId);
            // naik ke Manager: Supervisor diberi kabar lewat WA (bukan alarm)
            if ($L === 2 && !empty($ec['l1'])) {
                $info = "\xE2\x9A\xA0\xEF\xB8\x8F Eskalasi naik ke Manager \xE2\x80\x94 " . $tenant . "\nKontak " . $kontak . " sudah menunggu " . $menit . " menit.";
                $notif['L2_info_spv'] = escNotifyContacts($s, $ec, $ec['l1'], $title, $info, $vars, $incId, true);
            }
            if (!escDry()) tgNotify($s, $text);
        }
        escMutate(function (&$db) use ($incId, $target, $notif) {
            if (!isset($db['incidents'][$incId])) return;
            $db['incidents'][$incId]['level'] = $target;
            $db['incidents'][$incId]['notified'][] = ['at' => time(), 'level' => $target, 'result' => $notif];
        });
        try { waAuditLog('escalation_L' . $target, 'system', $num, ['incident' => $incId, 'reason' => $reason, 'wait_min' => $menit]); } catch (\Throwable $e) {}
        $out[] = ['number' => $num, 'incident' => $incId, 'level' => $target, 'reason' => $reason, 'notify' => $notif];
    }
    return $out;
}

/* ============================================================================
 *  ROUTER
 * ========================================================================= */

/* ============================================================================
 *  v1.2.45: Web Conversations — percakapan per-sesi (mirip WA threads)
 * ============================================================================ */
function webConvGenId() {
    return 'wc_' . bin2hex(random_bytes(8));
}
function webConvGenVisitor() {
    return 'wv_' . bin2hex(random_bytes(8));
}
function webConvReadAll() {
    return readJson(WEB_CONV_FILE, []);
}
function webConvWrite($convs) {
    writeJson(WEB_CONV_FILE, $convs);
}
function webConvFind($convs, $convId) {
    foreach ($convs as $i => $c) {
        if (($c['id'] ?? '') === $convId) return $i;
    }
    return -1;
}
function webConvSessionFile($convId) {
    // sanitize: hanya alfanumerik + underscore
    $safe = preg_replace('/[^a-zA-Z0-9_]/', '', (string)$convId);
    return WEB_SESSIONS_DIR . '/' . $safe . '.json';
}
function webConvLoadMessages($convId) {
    $f = webConvSessionFile($convId);
    if (!is_file($f)) return [];
    $d = json_decode(@file_get_contents($f), true);
    return is_array($d) ? $d : [];
}
function webConvSaveMessages($convId, $msgs) {
    if (!is_dir(WEB_SESSIONS_DIR)) @mkdir(WEB_SESSIONS_DIR, 0755, true);
    @file_put_contents(webConvSessionFile($convId), json_encode($msgs, JSON_UNESCAPED_UNICODE), LOCK_EX);
}
// Limit jumlah percakapan per visitor (hapus yang paling lama)
define('WEB_CONV_LIMIT_PER_VISITOR', 50);
// Limit total percakapan di file (auto-prune yang paling lama)
define('WEB_CONV_LIMIT_TOTAL', 2000);

/* ============================================================
 * v1.2.53: Form Data Pengunjung (lead capture sebelum chat)
 * ============================================================ */

/* Normalisasi no HP -> digit saja, nomor Indonesia dijadikan format 62xxx.
 * Nomor luar negeri dibiarkan apa adanya asal panjangnya masuk akal.
 * Mengembalikan '' kalau tidak valid. */
function deiNormalizePhone($raw) {
    $d = preg_replace('/\D/', '', (string)$raw);
    if ($d === '') return '';
    if (strpos($d, '620') === 0)      $d = '62' . substr($d, 3);   // 62 0812... (salah ketik umum)
    elseif (strpos($d, '0') === 0)    $d = '62' . substr($d, 1);   // 0812...
    elseif (strpos($d, '8') === 0)    $d = '62' . $d;              // 812...
    $len = strlen($d);
    if ($len < 9 || $len > 15) return '';
    return $d;
}

/* Label percakapan web dari data lead: "Nama - +62xxx". */
function deiWebLeadLabel($name, $phone) {
    $name  = trim((string)$name);
    $phone = trim((string)$phone);
    if ($name === '' && $phone === '') return '';
    if ($name === '')  return '+' . $phone;
    if ($phone === '') return $name;
    return $name . " \xC2\xB7 +" . $phone;   // \xC2\xB7 = titik tengah (butuh kutip ganda)
}

function webVisitorReadAll() {
    $d = readJson(WEB_VISITORS_FILE, []);
    return is_array($d) ? $d : [];
}
function webVisitorGetLead($visitorId) {
    $visitorId = trim((string)$visitorId);
    if ($visitorId === '') return null;
    $all = webVisitorReadAll();
    $v = $all[$visitorId] ?? null;
    return (is_array($v) && !empty($v['phone'])) ? $v : null;
}
function webVisitorSaveLead($visitorId, $lead) {
    $visitorId = trim((string)$visitorId);
    if ($visitorId === '') return false;
    $all = webVisitorReadAll();
    // auto-prune supaya file flat tidak membengkak tanpa batas
    if (!isset($all[$visitorId]) && count($all) >= WEB_VISITOR_LIMIT) {
        uasort($all, function ($a, $b) { return strcmp((string)($a['ts'] ?? ''), (string)($b['ts'] ?? '')); });
        $all = array_slice($all, (int)(WEB_VISITOR_LIMIT / 4), null, true);
    }
    $all[$visitorId] = $lead;
    writeJson(WEB_VISITORS_FILE, $all);
    return true;
}

/* Konfigurasi form (dengan nilai bawaan) — dipakai bootstrap & validasi. */
function deiLeadFormConfig($s) {
    $lf = (isset($s['widget']['lead_form']) && is_array($s['widget']['lead_form'])) ? $s['widget']['lead_form'] : [];
    return [
        'enabled'         => (bool)($lf['enabled'] ?? false),
        'allow_skip'      => (bool)($lf['allow_skip'] ?? false),
        'consent_enabled' => (bool)($lf['consent_enabled'] ?? true),
        'save_contact'    => (bool)($lf['save_contact'] ?? true),
        'title'           => (string)($lf['title']        ?? 'Sebelum mulai chat'),
        'subtitle'        => (string)($lf['subtitle']     ?? 'Isi data singkat berikut supaya kami bisa membantu Anda lebih baik.'),
        'name_label'      => (string)($lf['name_label']   ?? 'Nama'),
        'phone_label'     => (string)($lf['phone_label']  ?? 'No. HP / WhatsApp'),
        'submit_text'     => (string)($lf['submit_text']  ?? 'Mulai Chat'),
        'skip_text'       => (string)($lf['skip_text']    ?? 'Lewati'),
        'consent_text'    => (string)($lf['consent_text'] ?? 'Saya bersedia dihubungi melalui WhatsApp.'),
    ];
}

define('WEB_VISITOR_LIMIT', 5000);

/* ======================================================================
 * v1.2.111: blokir-total — status lisensi 'blocked' (di atas suspended).
 * Seluruh URL tenant (dashboard, login, widget, aset, API) menjawab 403:
 *  - root .htaccess diberi blok RewriteRule ^ - [F] (otomatis, bertanda);
 *  - API menolak semua action kecuali panggilan pusat yang lolos
 *    X-Tenant-Id + X-License-Key (license_push / cron_tick / stats_pull),
 *    supaya pusat tetap bisa MEMBUKA blokir.
 * Efek samping suspended (backup + kosongkan token) ikut berlaku.
 * ==================================================================== */
define('LIC_BLOCK_FLAG', DATA_DIR . '/.dei-blocked');
define('LIC_BLOCK_MARK_A', '# DEI-BLOCKED-START v1.2.111 (otomatis dari lisensi pusat - jangan diedit)');
define('LIC_BLOCK_MARK_B', '# DEI-BLOCKED-END');
function deiLicOff($st) { return $st === 'suspended' || $st === 'blocked'; }
function deiHtaccessBlock($on) {
    $p = dirname(__DIR__) . '/.htaccess';
    $s = is_file($p) ? (string)@file_get_contents($p) : '';
    $has = strpos($s, LIC_BLOCK_MARK_A) !== false;
    if ($on === $has) return true;
    $re = '/' . preg_quote(LIC_BLOCK_MARK_A, '/') . '.*?' . preg_quote(LIC_BLOCK_MARK_B, '/') . '\R?/s';
    $clean = (string)preg_replace($re, '', $s);
    if ($on) $clean = LIC_BLOCK_MARK_A . "\n<IfModule mod_rewrite.c>\nRewriteEngine On\nRewriteRule ^ - [F,L]\n</IfModule>\n" . LIC_BLOCK_MARK_B . "\n" . $clean;
    $perm = is_file($p) ? (@fileperms($p) & 0777) : 0;
    if ($perm && !is_writable($p)) @chmod($p, 0644);   // .htaccess 0444 di sebagian hosting
    $ok = @file_put_contents($p, $clean, LOCK_EX) !== false;
    if ($perm && !($perm & 0200)) @chmod($p, $perm);
    return $ok;
}
function deiSyncBlock($st) {
    $on = ($st === 'blocked');
    if ($on) { if (!is_file(LIC_BLOCK_FLAG)) @file_put_contents(LIC_BLOCK_FLAG, gmdate('c')); }
    elseif (is_file(LIC_BLOCK_FLAG)) @unlink(LIC_BLOCK_FLAG);
    return deiHtaccessBlock($on);
}
function deiBlockedOut() {
    while (ob_get_level()) @ob_end_clean();
    if (!headers_sent()) {
        header_remove();
        http_response_code(403);
        header('Content-Type: text/html; charset=iso-8859-1');
        header('Cache-Control: no-store');
    }
    echo "<!DOCTYPE HTML PUBLIC \"-//IETF//DTD HTML 2.0//EN\">\n<html><head>\n<title>403 Forbidden</title>\n</head><body>\n<h1>Forbidden</h1>\n<p>You don't have permission to access this resource.</p>\n</body></html>\n";
    exit;
}
function deiCentralAuthOk() {
    $cs = getSettings()['central_server'] ?? [];
    $tidWant = (string)($cs['tenant_id'] ?? ''); $licWant = (string)($cs['license_key'] ?? '');
    if ($tidWant === '' || $licWant === '') return false;
    $tidGot = (string)($_SERVER['HTTP_X_TENANT_ID']   ?? ($_GET['tenant_id']   ?? ''));
    $licGot = (string)($_SERVER['HTTP_X_LICENSE_KEY'] ?? ($_GET['license_key'] ?? ''));
    return hash_equals($tidWant, strtolower(trim($tidGot))) && hash_equals($licWant, trim($licGot));
}
/* Pusat mendorong status lisensi (header X-Dei-License di cron_tick / action license_push).
 * Mengembalikan status yang diterapkan, atau null bila data tidak valid. */
function deiApplyLicensePush($raw, $settings) {
    $j = is_array($raw) ? $raw : json_decode((string)$raw, true);
    if (!is_array($j)) return null;
    $st = strtolower(trim((string)($j['status'] ?? $j['license_status'] ?? '')));
    if (!in_array($st, ['active', 'expired', 'suspended', 'blocked'], true)) return null;
    $msg = trim((string)($j['message'] ?? $j['suspend_message'] ?? ''));
    if ($msg === '') $msg = LIC_DEFAULT_SUSPEND_MSG;
    $old = readJson(LIC_CACHE_FILE, []);
    $exp = (string)($j['expires_at'] ?? ($old['expires_at'] ?? ''));
    $changed = ($old['status'] ?? null) !== $st || ($old['message'] ?? '') !== $msg || ($old['expires_at'] ?? '') !== $exp;
    if ($changed || (time() - (int)($old['cached_at'] ?? 0)) > 3600) {
        writeJson(LIC_CACHE_FILE, ['status' => $st, 'message' => $msg, 'expires_at' => $exp,
            'days_left' => $j['days_left'] ?? ($old['days_left'] ?? null), 'cached_at' => time(), 'source' => 'push']);
    }
    if (!deiLicOff($old['status'] ?? null) && deiLicOff($st)) applyStatusSideEffects($st, $settings);
    $GLOBALS['dei_block_ht'] = deiSyncBlock($st);
    return $st;
}

/* Penjaga: tenant diblokir -> semua request ditolak 403 (kecuali pusat yang sah). */
if (PHP_SAPI !== 'cli' && is_file(LIC_BLOCK_FLAG)) {
    if (!(in_array($action, ['license_push', 'cron_tick', 'stats_pull'], true) && deiCentralAuthOk())) {
        // cek ulang ke pusat maks. tiap 10 menit -> blokir terbuka sendiri bila pusat sudah mengaktifkan lagi
        if (time() - (int)@filemtime(LIC_BLOCK_FLAG) > 600) {
            @touch(LIC_BLOCK_FLAG);
            try { getLicenseStatus(getSettings(), true); } catch (\Throwable $e) {}
        }
        if (is_file(LIC_BLOCK_FLAG)) { deiHtaccessBlock(true); deiBlockedOut(); }
    }
}

switch ($action) {

    /* v1.2.111: blokir-total — pusat mendorong status lisensi (langsung saat admin mengubah status) */
    case 'license_push': {
        if (PHP_SAPI !== 'cli' && !deiCentralAuthOk()) {
            if (is_file(LIC_BLOCK_FLAG)) deiBlockedOut();
            jsonOut(['ok' => false, 'error' => 'Kredensial pusat tidak cocok.'], 401);
        }
        $raw = $_SERVER['HTTP_X_DEI_LICENSE'] ?? '';
        if ($raw === '') $raw = (string)file_get_contents('php://input');
        $st = deiApplyLicensePush($raw, getSettings());
        if ($st === null) jsonOut(['ok' => false, 'error' => 'Data lisensi tidak valid.'], 400);
        jsonOut(['ok' => true, 'version' => DEI_VERSION, 'license_status' => $st,
            'blocked' => is_file(LIC_BLOCK_FLAG), 'htaccess_ok' => (bool)($GLOBALS['dei_block_ht'] ?? true)]);
    }


    /* ---------- PUBLIC: widget bootstrap (no secrets) ---------- */
    case 'bootstrap': {
        $s = getSettings();
        jsonOut([
            'ok' => true,
            'config' => [
                'chatbot_enabled'  => (bool)($s['widget']['chatbot_enabled'] ?? true),
                'whatsapp_enabled' => (bool)($s['widget']['whatsapp_enabled'] ?? true),
                'whatsapp_number'  => $s['widget']['whatsapp_number'] ?? '',
                'whatsapp_message' => $s['widget']['whatsapp_message'] ?? '',
                'lead_form'        => deiLeadFormConfig($s),   // v1.2.53
                'branding'         => deiBranding($s),          // v1.2.58: white-label
                'auto_closing'     => (function ($ac) { return ['enabled' => $ac['enabled'], 'minutes' => $ac['minutes']]; })(deiAcConf($s)),   // v1.2.56
                'bot' => [
                    'bot_name'      => $s['bot']['bot_name'] ?? 'Assistant',
                    'greeting'      => $s['bot']['greeting'] ?? 'Halo!',
                    'quick_replies' => $s['bot']['quick_replies'] ?? [],
                ],
                'appearance' => [
                    'primary_color' => $s['appearance']['primary_color'] ?? '#140383',
                    'avatar_type'      => $s['appearance']['avatar_type']      ?? ($s['appearance']['avatar_image'] ?? '' ? 'image' : 'emoji'),
                    'avatar_emoji'     => $s['appearance']['avatar_emoji']     ?? '🤖',
                    'avatar_icon_name' => $s['appearance']['avatar_icon_name'] ?? 'bot',
                    'avatar_image'     => $s['appearance']['avatar_image']     ?? '',
                    'position'      => $s['appearance']['position'] ?? 'right',
                    'offset_bottom' => (int)($s['appearance']['offset_bottom'] ?? 24),
                    'offset_right'  => (int)($s['appearance']['offset_right'] ?? 24),
                ],
            ],
        ]);
        break;
    }

    /* ---------- PUBLIC: chat ---------- */
    case 'chat': {
        if ($_SERVER['REQUEST_METHOD'] !== 'POST') jsonOut(['ok' => false, 'error' => 'Method not allowed'], 405);
        $s = getSettings();
        // v1.2.4: silent auth check — kalau admin dashboard test (via X-Auth-Token), skip chatbot_enabled check
        $adminTestUser = getAuthenticatedUserSilent();
        $isAdminTest = $adminTestUser && in_array(($adminTestUser['role'] ?? ''), ['super_admin', 'admin', 'wa_agent'], true);
        if (!$isAdminTest && !($s['widget']['chatbot_enabled'] ?? true)) {
            jsonOut(['ok' => false, 'error' => 'Chatbot sedang dinonaktifkan.'], 403);
        }

        // v1.1.3: license enforcement (cache 24h, lazy refresh)
        $lic = getLicenseStatus($s);
        if (deiLicOff($lic['status'])) {   // v1.2.111
            jsonOut(['ok' => true, 'answer' => $lic['message'] ?: LIC_DEFAULT_SUSPEND_MSG, 'kb_used' => 0, 'suspended' => true]);
        }
        // v1.1.4: cap enforcement (cache 24h, tiered: 90%=graceful, 100%=halt total)
        $cap = getCapStatus($s);
        if ($cap['reached'] || $cap['warning']) {
            // Both 90%+ and 100%+ get the cap message (no Claude call → no token cost)
            // The difference: 100% also halts (already true since we return here), 90-99% returns same message
            jsonOut(['ok' => true, 'answer' => $cap['message'] ?: CAP_DEFAULT_MSG, 'kb_used' => 0, 'cap_reached' => true]);
        }
        // 'expired' = still serves chat normally (banner shown in dashboard, not to visitors)
        // 'active' = normal flow

        $ip = clientIp();
        $limit = (int)($s['api']['rate_limit'] ?? 20);
        // v1.2.86: Tes Chatbot dari dashboard (pengguna login) tidak dihitung batas per IP
        if (!getAuthenticatedUserSilent() && !checkRateLimit($ip, $limit)) {
            jsonOut(['ok' => false, 'error' => 'Terlalu banyak permintaan. Coba lagi nanti.'], 429);
        }

        $in = bodyInput();
        $message = trim($in['message'] ?? '');
        if ($message === '') jsonOut(['ok' => false, 'error' => 'Pesan kosong.'], 400);
        if (mb_strlen($message) > 2000) $message = mb_substr($message, 0, 2000);

        $history = is_array($in['history'] ?? null) ? $in['history'] : [];
        $utm = is_array($in['utm'] ?? null) ? $in['utm'] : [];

        // v1.2.45: web conversations — kalau ada conversation_id, ambil history dari session file
        $convId = trim($in['conversation_id'] ?? '');
        $visitorId = trim($in['visitor_id'] ?? '');
        if ($convId !== '') {
            // Ambil history dari conversation session (lebih akurat dari yang dikirim widget)
            $convHistory = webConvLoadMessages($convId);
            if (!empty($convHistory)) {
                $history = array_map(function ($m) {
                    return ['role' => $m['role'], 'content' => $m['content']];
                }, array_slice($convHistory, -8));
            }
        }

        list($ok, $answer, $kbUsed, $usage) = generateAnswer($s, $message, $history);
        // v1.2.5: strip markdown kalau rule no_asterisk aktif
        $answer = stripMarkdownIfEnabled($answer, $s);
        if (!$ok) {
            // v1.2.17: sebelumnya kegagalan AI di chat web LANGSUNG jsonOut tanpa
            // menulis log — kejadiannya hilang tanpa jejak. Sekarang dicatat.
            try {
                logPrepend([
                    'ts'       => date('Y-m-d H:i:s'),
                    'q'        => $message,
                    'a'        => $answer,
                    'ip'       => $ip ?? '',
                    'channel'  => 'web',
                    'ai_error' => true,
                ], (int)($s['api']['log_limit'] ?? 500));
            } catch (\Throwable $e) { error_log('log ai_error web: ' . $e->getMessage()); }
            jsonOut(['ok' => false, 'error' => 'Maaf, terjadi gangguan. ' . $answer], 502);
        }
        recordUsage($usage);

        // Log the conversation with UTM
        $logRow = [
            'ts'           => date('Y-m-d H:i:s'),
            'q'            => $message,
            'a'            => $answer,
            'ip'           => $ip,
            'channel'      => 'web',
            'utm_source'   => substr((string)($utm['utm_source'] ?? ''), 0, 120),
            'utm_medium'   => substr((string)($utm['utm_medium'] ?? ''), 0, 120),
            'utm_campaign' => substr((string)($utm['utm_campaign'] ?? ''), 0, 120),
            'page'         => substr((string)($utm['page'] ?? ''), 0, 300),
            'referrer'     => substr((string)($utm['referrer'] ?? ''), 0, 300),
        ];
        $logLimit = (int)($s['api']['log_limit'] ?? 500);
        $logs = logPrepend($logRow, $logLimit);   // v1.2.58: kunci

        // v1.2.45: simpan ke web conversation session
        if ($convId !== '') {
            $convMsgs = webConvLoadMessages($convId);
            $convMsgs[] = ['role' => 'user', 'content' => $message, 'ts' => date('Y-m-d H:i:s')];
            $convMsgs[] = ['role' => 'assistant', 'content' => $answer, 'ts' => date('Y-m-d H:i:s')];
            webConvSaveMessages($convId, $convMsgs);

            // Update metadata di web-conversations.json
            $convs = webConvReadAll();
            $idx = webConvFind($convs, $convId);
            if ($idx >= 0) {
                $convs[$idx]['last_ts'] = date('Y-m-d H:i:s');
                $convs[$idx]['last_message'] = mb_substr($message, 0, 120);
                $convs[$idx]['last_answer'] = mb_substr($answer, 0, 120);
                $convs[$idx]['message_count'] = count($convMsgs);
                // v1.2.46: ID percakapan = IP + kota (bukan teks pesan).
                // Isi kalau belum ada, atau kalau masih judul lama berbasis pesan.
                // v1.2.53: judul hasil Form Data Pengunjung tidak boleh ditimpa label IP
                $needLabel = empty($convs[$idx]['lead_phone'])
                    && (empty($convs[$idx]['ip']) || ($convs[$idx]['title'] ?? '') === 'Percakapan baru');
                if ($needLabel) {
                    $ipC = $convs[$idx]['ip'] ?? clientIp();
                    $cityC = $convs[$idx]['city'] ?? deiGeoCity($ipC);
                    $convs[$idx]['ip'] = $ipC;
                    $convs[$idx]['city'] = $cityC;
                    $convs[$idx]['title'] = deiWebConvLabel($ipC, $cityC);
                }
                webConvWrite($convs);
            }
        }

        // v1.2.11: push notif chat web masuk (tiap pesan) — tiru pola WA (Fase 3)
        try {
            $deiWebPushFile = DATA_DIR . '/push-subs.json';
            if (file_exists($deiWebPushFile)) {
                $deiWebSubs = json_decode(file_get_contents($deiWebPushFile), true);
                if (is_array($deiWebSubs) && !empty($deiWebSubs)) {
                    $deiWebPreview = mb_substr(trim($message), 0, 80);
                    $deiWebTopic = detectTopicFromMessage($message);  // v1.2.12: auto-assign by topic
                    $deiWebTargets = getPushTargetsByTopic($deiWebTopic, array_keys($deiWebSubs));
                    sendPushToUsers($deiWebTargets, 'Chat web baru', $deiWebPreview, deiDashboardUrl());
                }
            }
        } catch (\Throwable $e) { error_log('web push hook: ' . $e->getMessage()); }

        $tg = is_array($s['telegram'] ?? null) ? $s['telegram'] : [];
        if (!empty($tg['notify_web'])) {
            tgNotify($s, "\xF0\x9F\x93\xA9 [Web] " . $ip . ":\n\"" . $message . "\"\n\xE2\x9C\x85 dijawab bot");
        }

        jsonOut(['ok' => true, 'answer' => $answer, 'kb_used' => $kbUsed]);
        break;
    }

    /* ---------- PUBLIC: Web Conversations (v1.2.45) ---------- */
    case 'web_conv_new': {
        if ($_SERVER['REQUEST_METHOD'] !== 'POST') jsonOut(['ok' => false, 'error' => 'Method not allowed'], 405);
        $s = getSettings();
        if (!($s['widget']['chatbot_enabled'] ?? true)) {
            jsonOut(['ok' => false, 'error' => 'Chatbot sedang dinonaktifkan.'], 403);
        }

        $in = bodyInput();
        $visitorId = trim($in['visitor_id'] ?? '');
        if ($visitorId === '') {
            $visitorId = webConvGenVisitor();
        }

        // v1.2.53: kalau Form Data Pengunjung wajib, percakapan baru hanya boleh
        // dibuat setelah lead tersimpan di server (localStorage widget bisa hilang).
        $lfNew = deiLeadFormConfig($s);
        $leadNew = webVisitorGetLead($visitorId);
        if ($lfNew['enabled'] && !$lfNew['allow_skip'] && !$leadNew) {
            jsonOut(['ok' => false, 'code' => 'lead_required', 'error' => 'Lengkapi data diri terlebih dahulu.'], 403);
        }

        // Enforce limits
        $convs = webConvReadAll();
        if (count($convs) >= WEB_CONV_LIMIT_TOTAL) {
            jsonOut(['ok' => false, 'error' => 'Batas percakapan tercapai.'], 429);
        }
        $visitorCount = 0;
        foreach ($convs as $c) {
            if (($c['visitor_id'] ?? '') === $visitorId) $visitorCount++;
        }
        if ($visitorCount >= WEB_CONV_LIMIT_PER_VISITOR) {
            jsonOut(['ok' => false, 'error' => 'Batas percakapan per pengunjung tercapai.'], 429);
        }

        $convId = webConvGenId();
        $greeting = $s['bot']['greeting'] ?? 'Halo! Ada yang bisa saya bantu?';
        $now = date('Y-m-d H:i:s');

        // v1.2.46: ID percakapan = IP + kota (best-effort), bukan teks pesan
        $ipConv = clientIp();
        $cityConv = deiGeoCity($ipConv);
        $title = deiWebConvLabel($ipConv, $cityConv);
        // v1.2.53: kalau pengunjung sudah mengisi form, pakai "Nama - +62xxx" sebagai judul
        $leadTitle = $leadNew ? deiWebLeadLabel($leadNew['name'] ?? '', $leadNew['phone'] ?? '') : '';
        if ($leadTitle !== '') $title = $leadTitle;

        // Create metadata entry
        $convs[] = [
            'id'            => $convId,
            'visitor_id'    => $visitorId,
            'title'         => mb_substr($title, 0, 120),
            'lead_name'     => (string)($leadNew['name'] ?? ''),    // v1.2.53
            'lead_phone'    => (string)($leadNew['phone'] ?? ''),   // v1.2.53
            'lead_consent'  => (bool)($leadNew['consent'] ?? false),// v1.2.53
            'ip'            => $ipConv,
            'city'          => $cityConv,
            'created_at'    => $now,
            'last_ts'       => $now,
            'last_message'  => '',
            'last_answer'   => mb_substr($greeting, 0, 120),
            'message_count' => 1,
        ];
        webConvWrite($convs);

        // Create session file with greeting
        webConvSaveMessages($convId, [
            ['role' => 'assistant', 'content' => $greeting, 'ts' => $now],
        ]);

        jsonOut([
            'ok'              => true,
            'conversation_id' => $convId,
            'visitor_id'      => $visitorId,
            'greeting'        => $greeting,
        ]);
        break;
    }

    /* ---------- PUBLIC: simpan data pengunjung sebelum chat (v1.2.53) ---------- */
    case 'web_lead_save': {
        if ($_SERVER['REQUEST_METHOD'] !== 'POST') jsonOut(['ok' => false, 'error' => 'Method not allowed'], 405);
        $s = getSettings();
        if (!($s['widget']['chatbot_enabled'] ?? true)) {
            jsonOut(['ok' => false, 'error' => 'Chatbot sedang dinonaktifkan.'], 403);
        }
        $lf = deiLeadFormConfig($s);
        if (!$lf['enabled']) {
            jsonOut(['ok' => false, 'error' => 'Form data pengunjung tidak aktif.'], 403);
        }

        // Endpoint publik -> pakai rate limit yang sama dengan chat.
        $ipLead = clientIp();
        if (!checkRateLimit($ipLead, (int)($s['api']['rate_limit'] ?? 20))) {
            jsonOut(['ok' => false, 'error' => 'Terlalu banyak permintaan. Coba lagi nanti.'], 429);
        }

        $in = bodyInput();
        $visitorId = trim((string)($in['visitor_id'] ?? ''));
        if ($visitorId === '' || !preg_match('/^wv_[a-f0-9]{8,64}$/', $visitorId)) {
            $visitorId = webConvGenVisitor();
        }

        $name = trim((string)($in['name'] ?? ''));
        if ($name !== '') $name = mb_substr(preg_replace('/\s+/u', ' ', $name), 0, 100);
        $phone   = deiNormalizePhone($in['phone'] ?? '');
        $consent = !empty($in['consent']);

        if ($name === '') {
            jsonOut(['ok' => false, 'field' => 'name', 'error' => 'Nama wajib diisi.'], 400);
        }
        if ($phone === '') {
            jsonOut(['ok' => false, 'field' => 'phone', 'error' => 'Nomor HP/WhatsApp tidak valid.'], 400);
        }
        if ($lf['consent_enabled'] && !$consent) {
            jsonOut(['ok' => false, 'field' => 'consent', 'error' => 'Centang persetujuan untuk melanjutkan.'], 400);
        }

        $now  = date('Y-m-d H:i:s');
        $lead = [
            'name'    => $name,
            'phone'   => $phone,
            'consent' => $consent,
            'ts'      => $now,
            'ip'      => $ipLead,
            'page'    => mb_substr((string)($in['page'] ?? ''), 0, 300),
        ];
        webVisitorSaveLead($visitorId, $lead);

        // Masuk ke daftar Kontak supaya bisa di-follow up / blast WhatsApp.
        if ($lf['save_contact']) {
            try {
                waContactUpdate($phone, function (&$c, $isNew) use ($name, $consent, $now) {   // v1.2.71
                    if ($isNew) $c['stage'] = 'new';
                    // Koreksi manual agent tidak ditimpa.
                    if (trim((string)($c['name_manual'] ?? '')) === '') $c['name_manual'] = $name;
                    $c['last_seen']   = $now;
                    $c['web_consent'] = $consent;
                    if (empty($c['source'])) $c['source'] = 'web_widget';
                });
            } catch (\Throwable $e) { error_log('web_lead_save contact: ' . $e->getMessage()); }
        }

        // Kalau dikirim dari percakapan yang sudah berjalan, perbarui judulnya.
        $convIdLead = trim((string)($in['conversation_id'] ?? ''));
        if ($convIdLead !== '') {
            $convsL = webConvReadAll();
            $iL = webConvFind($convsL, $convIdLead);
            if ($iL >= 0 && ($convsL[$iL]['visitor_id'] ?? '') === $visitorId) {
                $convsL[$iL]['lead_name']    = $name;
                $convsL[$iL]['lead_phone']   = $phone;
                $convsL[$iL]['lead_consent'] = $consent;
                $convsL[$iL]['title']        = mb_substr(deiWebLeadLabel($name, $phone), 0, 120);
                webConvWrite($convsL);
            }
        }

        // Notifikasi lead baru (Telegram, kalau notify_web aktif).
        try {
            $tgL = is_array($s['telegram'] ?? null) ? $s['telegram'] : [];
            if (!empty($tgL['notify_web'])) {
                tgNotify($s, "\xF0\x9F\x91\xA4 [Lead Web] " . $name . "\n+" . $phone);
            }
        } catch (\Throwable $e) { error_log('web_lead_save tg: ' . $e->getMessage()); }

        jsonOut([
            'ok'         => true,
            'visitor_id' => $visitorId,
            'lead'       => ['name' => $name, 'phone' => $phone, 'consent' => $consent],
        ]);
        break;
    }

    case 'web_conv_list': {
        if ($_SERVER['REQUEST_METHOD'] !== 'GET') jsonOut(['ok' => false, 'error' => 'Method not allowed'], 405);
        $visitorId = trim($_GET['visitor_id'] ?? '');
        if ($visitorId === '') jsonOut(['ok' => false, 'error' => 'visitor_id required'], 400);

        $convs = webConvReadAll();
        $mine = [];
        foreach ($convs as $c) {
            if (($c['visitor_id'] ?? '') === $visitorId) {
                $mine[] = $c;
            }
        }
        // Sort by last_ts descending (newest first)
        usort($mine, function ($a, $b) {
            return strcmp($b['last_ts'] ?? '', $a['last_ts'] ?? '');
        });

        jsonOut(['ok' => true, 'conversations' => $mine]);
        break;
    }

    case 'web_conv_thread': {
        if ($_SERVER['REQUEST_METHOD'] !== 'GET') jsonOut(['ok' => false, 'error' => 'Method not allowed'], 405);
        $convId = trim($_GET['conversation_id'] ?? '');
        $visitorId = trim($_GET['visitor_id'] ?? '');
        if ($convId === '' || $visitorId === '') {
            jsonOut(['ok' => false, 'error' => 'conversation_id and visitor_id required'], 400);
        }

        // Verify ownership
        $convs = webConvReadAll();
        $idx = webConvFind($convs, $convId);
        if ($idx < 0 || ($convs[$idx]['visitor_id'] ?? '') !== $visitorId) {
            jsonOut(['ok' => false, 'error' => 'Conversation not found'], 404);
        }

        $messages = webConvLoadMessages($convId);
        jsonOut([
            'ok'       => true,
            'conversation' => $convs[$idx],
            'messages' => $messages,
        ]);
        break;
    }

    /* ---------- ADMIN: Web Conversations Dashboard (v1.2.45) ---------- */
    case 'web_conversations_admin': {
        $u = requireAuth(['super_admin', 'admin', 'wa_agent']);
        $convs = webConvReadAll();

        // Sort by last_ts descending
        usort($convs, function ($a, $b) {
            return strcmp($b['last_ts'] ?? '', $a['last_ts'] ?? '');
        });

        // Pagination
        $page = max(1, (int)($_GET['page'] ?? 1));
        $perPage = min(50, max(10, (int)($_GET['per_page'] ?? 20)));
        $total = count($convs);
        $slice = array_slice($convs, ($page - 1) * $perPage, $perPage);

        jsonOut([
            'ok'            => true,
            'conversations' => $slice,
            'total'         => $total,
            'page'          => $page,
            'per_page'      => $perPage,
            'total_pages'   => (int)ceil($total / $perPage),
        ]);
        break;
    }

    case 'web_thread_admin': {
        $u = requireAuth(['super_admin', 'admin', 'wa_agent']);
        $convId = trim($_GET['conversation_id'] ?? '');
        if ($convId === '') jsonOut(['ok' => false, 'error' => 'conversation_id required'], 400);

        $convs = webConvReadAll();
        $idx = webConvFind($convs, $convId);
        if ($idx < 0) jsonOut(['ok' => false, 'error' => 'Conversation not found'], 404);

        $messages = webConvLoadMessages($convId);
        jsonOut([
            'ok'           => true,
            'conversation' => $convs[$idx],
            'messages'     => $messages,
        ]);
        break;
    }

    /* ---------- ADMIN: Migrasi chat lama -> Percakapan Web (v1.2.45) ---------- */
    case 'web_conv_migrate': {
        requireAuth(['super_admin', 'admin']);
        $markerFile = DATA_DIR . '/web-migrated.flag';
        $force = !empty($_GET['force']);
        if (file_exists($markerFile) && !$force) {
            jsonOut(['ok' => false, 'error' => 'Migrasi sudah pernah dijalankan. Tambahkan &force=1 untuk mengulang.'], 409);
        }

        $logs = logReadAll();
        // Kelompokkan entri channel 'web' per IP per hari
        $groups = [];
        foreach ($logs as $e) {
            if (($e['channel'] ?? '') !== 'web') continue;
            if (($e['q'] ?? '') === '' && ($e['a'] ?? '') === '') continue;
            $ip  = (string)($e['ip'] ?? 'unknown');
            $ts  = (string)($e['ts'] ?? '');
            $day = substr($ts, 0, 10) ?: 'nodate';
            $groups[$ip . '|' . $day][] = $e;
        }

        $convs = webConvReadAll();
        // v1.2.46: kalau force -> buang hasil impor lama (migrated) + file sesinya,
        // supaya rebuild memakai judul baru (IP+kota) tanpa duplikat.
        if ($force) {
            $kept = [];
            foreach ($convs as $cv) {
                if (!empty($cv['migrated'])) {
                    @unlink(webConvSessionFile($cv['id']));
                } else {
                    $kept[] = $cv;
                }
            }
            $convs = $kept;
        }
        $created = 0;
        foreach ($groups as $key => $entries) {
            // log tersimpan terbaru-dulu; urutkan menaik berdasarkan waktu
            usort($entries, function ($a, $b) { return strcmp($a['ts'] ?? '', $b['ts'] ?? ''); });
            $parts = explode('|', $key, 2);
            $ip = $parts[0];
            $convId = webConvGenId();
            $visitorId = 'wv_mig_' . substr(md5($ip), 0, 12);
            $msgs = [];
            foreach ($entries as $e) {
                if (($e['q'] ?? '') !== '') $msgs[] = ['role' => 'user', 'content' => $e['q'], 'ts' => $e['ts'] ?? ''];
                if (($e['a'] ?? '') !== '') $msgs[] = ['role' => 'assistant', 'content' => $e['a'], 'ts' => $e['ts'] ?? ''];
            }
            if (empty($msgs)) continue;
            webConvSaveMessages($convId, $msgs);
            $first = $entries[0];
            $last  = $entries[count($entries) - 1];
            $cityMig = deiGeoCity($ip);
            $convs[] = [
                'id'            => $convId,
                'visitor_id'    => $visitorId,
                'title'         => deiWebConvLabel($ip, $cityMig),
                'ip'            => $ip,
                'city'          => $cityMig,
                'created_at'    => $first['ts'] ?? date('Y-m-d H:i:s'),
                'last_ts'       => $last['ts'] ?? ($first['ts'] ?? date('Y-m-d H:i:s')),
                'last_message'  => mb_substr((string)($last['q'] ?? ''), 0, 120),
                'last_answer'   => mb_substr((string)($last['a'] ?? ''), 0, 120),
                'message_count' => count($msgs),
                'migrated'      => true,
            ];
            $created++;
        }
        webConvWrite($convs);
        @file_put_contents($markerFile, date('Y-m-d H:i:s') . " migrated=$created\n");
        jsonOut(['ok' => true, 'migrated' => $created, 'total_conversations' => count($convs)]);
        break;
    }

    /* ---------- ADMIN: Blast WA (v1.2.47) ---------- */
    case 'wa_templates': {
        requireAuth(['super_admin', 'admin', 'supervisor']);
        $wa = waConf(getSettings());
        $wa = waChanConf($wa, preg_replace('/[^A-Za-z0-9_]/', '', (string)($_GET['ch'] ?? '')));   // v1.2.98: multi-nomor (template per WABA nomor)
        if (($wa['provider'] ?? 'meta') !== 'meta') {
            jsonOut(['ok' => false, 'error' => 'Blast template hanya untuk penyedia Meta Cloud API resmi.'], 400);
        }
        $res = waFetchTemplates($wa);
        if (!$res['ok']) jsonOut($res, 502);
        $out = [];
        foreach ($res['templates'] as $t) {
            $body = '';
            foreach (($t['components'] ?? []) as $comp) {
                if (strtoupper($comp['type'] ?? '') === 'BODY') { $body = $comp['text'] ?? ''; break; }
            }
            $out[] = [
                'name'     => $t['name'] ?? '',
                'language' => $t['language'] ?? '',
                'status'   => $t['status'] ?? '',
                'category' => $t['category'] ?? '',
                'body'     => $body,
                'var_count'=> waTemplateVarCount($t),
            ];
        }
        $s0 = getSettings();
        jsonOut(['ok' => true, 'templates' => $out, 'ch' => (string)$wa['_ch'],
                 'channels' => waMultiOn(waConf($s0), $s0) ? waChannels($s0) : []]);   // v1.2.98: multi-nomor
        break;
    }

    case 'wa_blast_start': {
        $u = requireAuth(['super_admin', 'admin', 'supervisor']);
        $wa = waConf(getSettings());
        if (($wa['provider'] ?? 'meta') !== 'meta') jsonOut(['ok' => false, 'error' => 'Hanya untuk Meta Cloud API resmi.'], 400);
        $in = bodyInput();
        $tmpl = trim($in['template_name'] ?? '');
        $lang = trim($in['language'] ?? 'id');
        $vars = is_array($in['vars'] ?? null) ? array_values($in['vars']) : [];
        $source = $in['source'] ?? 'contacts';   // contacts | csv
        if ($tmpl === '') jsonOut(['ok' => false, 'error' => 'Template belum dipilih.'], 400);

        // Bangun daftar penerima
        $recips = [];
        if ($source === 'csv') {
            $nums = is_array($in['numbers'] ?? null) ? $in['numbers'] : [];
            $contacts = waGetContacts();
            foreach ($nums as $n) {
                $num = waNormNum($n);
                if (strlen($num) < 8) continue;
                $recips[$num] = waContactName($num, $contacts);
            }
        } else {
            $stage = trim($in['stage'] ?? '');   // filter opsional
            $contacts = waGetContacts();
            foreach ($contacts as $num => $meta) {
                $num = waNormNum($num);
                if (strlen($num) < 8) continue;
                if ($stage !== '' && (($meta['stage'] ?? '') !== $stage)) continue;
                $recips[$num] = waContactName($num, $contacts);
            }
        }
        if (empty($recips)) jsonOut(['ok' => false, 'error' => 'Tidak ada penerima yang valid.'], 400);

        $rows = [];
        foreach ($recips as $num => $nm) {
            $rows[] = ['num' => $num, 'name' => $nm, 'status' => 'pending', 'error' => ''];
        }
        $job = [
            'id'            => waBlastGenId(),
            'created_at'    => date('Y-m-d H:i:s'),
            'by'            => $u['username'] ?? '',
            'template_name' => $tmpl,
            'language'      => $lang,
            'vars'          => $vars,
            'source'        => $source,
            'ch'            => (string)waChanConf($wa, preg_replace('/[^A-Za-z0-9_]/', '', (string)($in['ch'] ?? '')))['_ch'],   // v1.2.98: multi-nomor
            'total'         => count($rows),
            'sent'          => 0,
            'failed'        => 0,
            'status'        => 'running',
            'recipients'    => $rows,
        ];
        $all = waBlastReadAll();
        array_unshift($all, $job);
        // simpan maksimal 100 blast terakhir
        $all = array_slice($all, 0, 100);
        waBlastWrite($all);
        jsonOut(['ok' => true, 'job_id' => $job['id'], 'total' => $job['total']]);
        break;
    }

    case 'wa_blast_run': {
        requireAuth(['super_admin', 'admin', 'supervisor']);
        $wa = waConf(getSettings());
        $in = bodyInput();
        $jobId = trim($in['job_id'] ?? '');
        $size  = max(1, min(20, (int)($in['size'] ?? 10)));
        $all = waBlastReadAll();
        $idx = waBlastFind($all, $jobId);
        if ($idx < 0) jsonOut(['ok' => false, 'error' => 'Blast tidak ditemukan.'], 404);
        $job = $all[$idx];

        $done = 0;
        for ($i = 0; $i < count($job['recipients']) && $done < $size; $i++) {
            if (($job['recipients'][$i]['status'] ?? '') !== 'pending') continue;
            $row = $job['recipients'][$i];
            $vars = array_map(function ($v) use ($row) { return waBlastFillVar($v, $row['name']); }, $job['vars']);
            $r = waSendTemplate(waChanConf($wa, (string)($job['ch'] ?? 'utama')), $row['num'], $job['template_name'], $job['language'], $vars);   // v1.2.98: multi-nomor
            if ($r['ok']) { $job['recipients'][$i]['status'] = 'sent'; $job['sent']++; }
            else { $job['recipients'][$i]['status'] = 'failed'; $job['recipients'][$i]['error'] = mb_substr($r['error'] ?? '', 0, 160); $job['failed']++; }
            $done++;
            usleep(200000); // 0.2s jeda antar kirim
        }
        $remaining = 0;
        foreach ($job['recipients'] as $rr) if (($rr['status'] ?? '') === 'pending') $remaining++;
        if ($remaining === 0) $job['status'] = 'done';
        $all[$idx] = $job;
        waBlastWrite($all);
        jsonOut(['ok' => true, 'sent' => $job['sent'], 'failed' => $job['failed'], 'remaining' => $remaining, 'total' => $job['total'], 'done' => $remaining === 0]);
        break;
    }

    case 'wa_blast_history': {
        requireAuth(['super_admin', 'admin', 'supervisor']);
        $all = waBlastReadAll();
        $out = [];
        foreach ($all as $b) {
            $out[] = [
                'id' => $b['id'], 'created_at' => $b['created_at'], 'by' => $b['by'] ?? '',
                'template_name' => $b['template_name'], 'total' => $b['total'],
                'sent' => $b['sent'], 'failed' => $b['failed'], 'status' => $b['status'],
            ];
        }
        jsonOut(['ok' => true, 'blasts' => array_slice($out, 0, 50)]);
        break;
    }

    case 'wa_blast_get': {
        requireAuth(['super_admin', 'admin', 'supervisor']);
        $jobId = trim($_GET['job_id'] ?? '');
        $all = waBlastReadAll();
        $idx = waBlastFind($all, $jobId);
        if ($idx < 0) jsonOut(['ok' => false, 'error' => 'Blast tidak ditemukan.'], 404);
        jsonOut(['ok' => true, 'blast' => $all[$idx]]);
        break;
    }

    /* ---------- PUBLIC: WhatsApp Cloud API webhook ---------- */
    case 'wa_webhook': {
        $s  = getSettings();
        $wa = waConf($s);

        // GET — Meta verification handshake (hub.* arrive as hub_* in PHP).
        if ($_SERVER['REQUEST_METHOD'] === 'GET') {
            $mode      = $_GET['hub_mode'] ?? '';
            $token     = $_GET['hub_verify_token'] ?? '';
            $challenge = $_GET['hub_challenge'] ?? '';
            $expected  = (string)($wa['verify_token'] ?? '');
            if ($mode === 'subscribe' && $expected !== '' && hash_equals($expected, (string)$token)) {
                header('Content-Type: text/plain');
                echo $challenge;
                exit;
            }
            http_response_code(403);
            echo 'Forbidden';
            exit;
        }

        if ($_SERVER['REQUEST_METHOD'] !== 'POST') { http_response_code(405); exit; }

        $raw = file_get_contents('php://input');
        if (!waVerifySignature($raw, $wa['app_secret'] ?? '')) {
            http_response_code(403);
            echo 'bad signature';
            exit;
        }

        // v1.2.71: mode antrean — simpan & antre, Meta langsung dapat 200; worker yang memproses.
        // Kalau Redis bermasalah, jatuh ke pemrosesan langsung (perilaku lama).
        if (deiQueueRedis()) {
            try {
                deiDebounceBuffer(json_decode($raw, true));   // v1.2.72: catat teks per nomor sebelum diantre
                deiRedis()->lPush('q:wa', json_encode(['raw' => $raw, 'at' => time(), 'try' => 0]));
                http_response_code(200);
                echo 'EVENT_RECEIVED';
                exit;
            } catch (\Throwable $e) { error_log('antrean WA gagal, proses langsung: ' . $e->getMessage()); }
        }

        // Acknowledge Meta right away on PHP-FPM, then keep working in the
        // background. On other SAPIs, process synchronously and reply at the end
        // (fast enough for Meta's window since Haiku replies in a few seconds).
        $earlyAck = function_exists('fastcgi_finish_request') || function_exists('litespeed_finish_request');   // v1.2.71
        if ($earlyAck) respondAndContinue('EVENT_RECEIVED');
        @set_time_limit(90);   // v1.2.96: jeda-balasan

        // v1.2.93: wa-bot-off: bot mati tidak lagi membuang pesan — tetap dicatat, AI tidak membalas
        // v1.2.36: tenant ini memakai penyedia lain — abaikan kiriman Meta,
        // supaya pesan tidak masuk lewat satu nomor lalu dibalas dari nomor lain.
        if (($wa['provider'] ?? 'meta') !== 'meta') { if (!$earlyAck) { echo 'EVENT_RECEIVED'; } exit; }

        waHandleMetaPayload($s, $wa, json_decode($raw, true));   // v1.2.71: isi loop pindah ke fungsi bersama
        if (!$earlyAck) { echo 'EVENT_RECEIVED'; }
        exit;
    }

    /* ---------- v1.2.76: WAHA — PUBLIC webhook gateway WhatsApp Web sendiri ---------- */
    case 'wa_webhook_waha': {
        $s  = getSettings();
        $wa = waConf($s);
        if ($_SERVER['REQUEST_METHOD'] !== 'POST') { http_response_code(405); echo 'method not allowed'; exit; }
        // LAPIS 1 — kunci di URL. LAPIS 2 — HMAC SHA-512 (WAHA menandatangani badan kiriman).
        $kunci = (string)($wa['waha_webhook_key'] ?? '');
        if ($kunci === '' || !hash_equals($kunci, (string)($_GET['key'] ?? ''))) { http_response_code(403); echo 'forbidden'; exit; }
        $raw  = file_get_contents('php://input');
        $hmac = strtolower(trim((string)($_SERVER['HTTP_X_WEBHOOK_HMAC'] ?? '')));
        if ($hmac !== '' && !hash_equals(hash_hmac('sha512', $raw, $kunci), $hmac)) { http_response_code(403); echo 'bad hmac'; exit; }

        $evt = json_decode($raw, true);
        if (!is_array($evt) || ($wa['provider'] ?? 'meta') !== 'waha') { echo 'OK'; exit; }   // v1.2.93: wa-bot-off
        $waCh = waWahaChanBySession($wa, (string)($evt['session'] ?? ''));   // v1.2.98: multi-nomor
        if ($waCh === null) {
            error_log('waha: sesi tidak cocok (' . mb_substr((string)($evt['session'] ?? ''), 0, 40) . ')');
            echo 'OK'; exit;
        }
        $wa = $waCh;
        if (!empty($wa['waha_debug'])) error_log('waha mentah: ' . mb_substr($raw, 0, 800));
        // v1.2.104: skor-risiko-wa — status sesi & centang untuk skor kesehatan nomor
        if ((string)($evt['event'] ?? '') === 'session.status') { whStatus($wa, $evt); echo 'OK'; exit; }
        if ((string)($evt['event'] ?? '') === 'message.ack') { whAck($wa, is_array($evt['payload'] ?? null) ? $evt['payload'] : []); echo 'OK'; exit; }
        if ((string)($evt['event'] ?? '') === 'call.received') { try { wcHandle($wa, $evt); } catch (\Throwable $e) { error_log('telepon: ' . $e->getMessage()); } echo 'OK'; exit; }   // v1.2.108: tolak-telepon
        if (!in_array((string)($evt['event'] ?? ''), ['message', 'message.any'], true)) { echo 'OK'; exit; }

        $payload = wahaToMetaPayload($wa, $evt);
        if ($payload === null) { echo 'OK'; exit; }
        if (!empty($wa['_ch'])) $payload['entry'][0]['changes'][0]['value']['metadata'] = ['_dei_ch' => (string)$wa['_ch']];   // v1.2.98: multi-nomor (ikut ke antrean)

        // Mode antrean (server sendiri): jalur sama dengan webhook Meta.
        if (deiQueueRedis()) {
            try {
                deiDebounceBuffer($payload);
                deiRedis()->lPush('q:wa', json_encode(['raw' => json_encode($payload, JSON_UNESCAPED_UNICODE), 'at' => time(), 'try' => 0]));
                echo 'OK'; exit;
            } catch (\Throwable $e) { error_log('antrean WAHA gagal, proses langsung: ' . $e->getMessage()); }
        }
        $earlyAck = function_exists('fastcgi_finish_request') || function_exists('litespeed_finish_request');
        if ($earlyAck) respondAndContinue('OK');
        @set_time_limit(90);   // v1.2.96: jeda-balasan
        waHandleMetaPayload($s, $wa, $payload);
        if (!$earlyAck) { echo 'OK'; }
        exit;
    }

    /* ---------- PUBLIC: webhook Fonnte (penyedia alternatif) ---------- */
    // Jalur TERPISAH dari webhook Meta. Kalau bagian ini bermasalah, tenant
    // yang memakai Meta tidak ikut terganggu.
    case 'wa_webhook_fonnte': {
        $s  = getSettings();
        $wa = waConf($s);

        if ($_SERVER['REQUEST_METHOD'] !== 'POST') { http_response_code(405); echo 'method not allowed'; exit; }

        // LAPIS 1 — kunci rahasia di URL.
        // Fonnte tidak menandatangani kirimannya seperti Meta, jadi alamat ini
        // harus dijaga sendiri. Tanpa penjagaan, siapa pun yang tahu alamatnya
        // bisa menyuntikkan percakapan palsu: memakan kuota klien dan mengotori
        // data leads.
        $kunci = (string)($wa['fonnte_webhook_key'] ?? '');
        if ($kunci === '' || !hash_equals($kunci, (string)($_GET['key'] ?? ''))) {
            http_response_code(403); echo 'forbidden'; exit;
        }

        $raw = file_get_contents('php://input');

        $earlyAck = function_exists('fastcgi_finish_request') || function_exists('litespeed_finish_request');   // v1.2.71
        if ($earlyAck) respondAndContinue('OK');
        @set_time_limit(60);

        if (($wa['provider'] ?? 'meta') !== 'fonnte') { if (!$earlyAck) { echo 'OK'; } exit; }
        // v1.2.93: wa-bot-off: bot mati tetap dicatat (Mode Manual)

        // Fonnte dapat mengirim JSON maupun form biasa — terima keduanya.
        $d = json_decode($raw, true);
        if (!is_array($d)) $d = is_array($_POST) ? $_POST : [];

        // Bentuk medan belum diverifikasi langsung, jadi dibaca longgar.
        // Nyalakan fonnte_debug di pengaturan untuk melihat kiriman mentahnya.
        if (!empty($wa['fonnte_debug'])) {
            error_log('fonnte mentah: ' . mb_substr($raw !== '' ? $raw : json_encode($_POST), 0, 500));
        }

        // Pesan GRUP diabaikan. Nomor bot yang dimasukkan ke grup akan menjawab
        // setiap pesan di sana — berisik, memakan kuota klien, dan pola semacam
        // itu justru yang meningkatkan risiko pemblokiran nomor.
        if (!empty($d['isgroup'])) {
            if (!$earlyAck) { echo 'OK'; }
            exit;
        }

        // Medan sesuai format Fonnte yang sudah diverifikasi.
        // CATATAN: medan 'text' SENGAJA TIDAK dipakai — isinya keterangan jenis
        // pesan ("non-button message"), bukan isi pesan tamu.
        $from = '';
        foreach (['sender', 'pengirim'] as $k) {
            if (!empty($d[$k])) { $from = preg_replace('/\D/', '', (string)$d[$k]); break; }
        }
        $text = '';
        foreach (['message', 'pesan'] as $k) {
            if (isset($d[$k]) && trim((string)$d[$k]) !== '') { $text = trim((string)$d[$k]); break; }
        }
        $nama = '';
        foreach (['name', 'pushname'] as $k) {
            if (!empty($d[$k])) { $nama = trim((string)$d[$k]); break; }
        }

        // Fonnte memakai mode "lid" (pengenal privasi WhatsApp). Kalau suatu saat
        // 'sender' berisi LID alih-alih nomor, tolak daripada memasukkan data
        // sampah ke log percakapan.
        if ($from === '' || !preg_match('/^\d{8,15}$/', $from)) {
            error_log('fonnte: nomor pengirim tidak wajar - ' . mb_substr($raw !== '' ? $raw : json_encode($_POST), 0, 300));
            if (!$earlyAck) { echo 'OK'; }
            exit;
        }

        // Pesan non-teks dibalas sama seperti jalur Meta.
        $jenis = trim((string)($d['type'] ?? ''));
        if (deiIsManual($s) && (($jenis !== '' && $jenis !== 'text') || $text === '')) {
            // v1.2.58: mode Manual — catat sebagai pesan non-teks, tanpa balasan otomatis
            $text = ($text !== '' ? $text . "\n" : '') . deiNonTextLabel($jenis);
            $jenis = 'text';
        }
        if (($jenis !== '' && $jenis !== 'text') || $text === '') {
            waSend($wa, $from, 'Maaf, untuk saat ini saya hanya bisa membalas pesan teks.');
            if (!$earlyAck) { echo 'OK'; }
            exit;
        }

        // LAPIS 2 — cocokkan nomor perangkat kalau tersimpan.
        $devTersimpan = preg_replace('/\D/', '', (string)($wa['fonnte_device'] ?? ''));
        if ($devTersimpan !== '') {
            $devKiriman = preg_replace('/\D/', '', (string)($d['device'] ?? ''));
            if ($devKiriman !== '' && $devKiriman !== $devTersimpan) {
                error_log('fonnte: perangkat tidak cocok (' . $devKiriman . ')');
                if (!$earlyAck) { echo 'OK'; }
                exit;
            }
        }

        // Alur pemrosesan sama persis dengan Meta (Fase 1).
        // $metaInfo dikosongkan sehingga tracker WA-to-Ads tidak aktif di sini.
        waProcessIncoming($s, $wa, $from, $text, $nama, []);

        if (!$earlyAck) { echo 'OK'; }
        exit;
    }

    /* ---------- ADMIN: WhatsApp conversations (handoff inbox) ---------- */
    case 'wa_conversations': {
        requireAuth(['super_admin','admin','wa_agent']);
        $logs = logReadAll();
        $byNum = [];
        foreach ($logs as $e) {                       // logs are newest-first
            if (($e['channel'] ?? '') !== 'whatsapp') continue;
            $num = waNormNum($e['ip'] ?? '');
            if ($num === '') continue;
            if (!isset($byNum[$num])) {
                $byNum[$num] = [
                    'number'          => $num,
                    'last_ts'         => $e['ts'] ?? '',
                    'last_text'       => ($e['q'] ?? '') !== '' ? $e['q'] : (wcLabel($e) !== '' ? wcLabel($e) : ($e['a'] ?? '')),   // v1.2.108: tolak-telepon
                    'awaiting'        => !empty($e['awaiting']),
                    'last_inbound_ts' => null,
                ];
            }
            if ($byNum[$num]['last_inbound_ts'] === null && ($e['q'] ?? '') !== '') {
                $byNum[$num]['last_inbound_ts'] = $e['ts'] ?? '';
            }
        }
        $out = [];
        foreach ($byNum as $num => $c) {
            $c['mode'] = waGetMode($num);
            $inTs = $c['last_inbound_ts'] ? strtotime($c['last_inbound_ts']) : 0;
            $c['window_open'] = waWindowSelaluTerbuka() || ($inTs > 0 && (time() - $inTs) <= 24 * 3600);   // v1.2.36
            unset($c['last_inbound_ts']);
            $out[] = $c;
        }
        usort($out, function ($a, $b) { return strcmp($b['last_ts'], $a['last_ts']); });
        jsonOut(['ok' => true, 'conversations' => array_slice($out, 0, 50)]);
        break;
    }

    /* ---------- ADMIN: one WhatsApp thread ---------- */
    /* ---------- v1.2.22: daftar harga ---------- */
    case 'get_pricelist': {
        requireAuth(['super_admin', 'admin']);
        $pl = pricelistGet();
        jsonOut(['ok' => true, 'items' => $pl['items'], 'updated_at' => $pl['updated_at'], 'updated_by' => $pl['updated_by']]);
        break;
    }

    case 'save_pricelist': {
        $me = requireAuth(['super_admin', 'admin']);
        $in = bodyInput();
        $items = is_array($in['items'] ?? null) ? $in['items'] : [];
        $clean = [];
        foreach ($items as $it) {
            if (!is_array($it)) continue;
            $nama = trim((string)($it['item'] ?? ''));
            if ($nama === '') continue;   // baris tanpa nama dibuang
            $clean[] = [
                'id'    => (string)($it['id'] ?? ('pr_' . substr(md5(uniqid('', true)), 0, 8))),
                'item'  => mb_substr($nama, 0, 150),
                'price' => mb_substr(trim((string)($it['price'] ?? '')), 0, 100),
                'note'  => mb_substr(trim((string)($it['note'] ?? '')), 0, 200),
            ];
        }
        writeJson(PRICELIST_FILE, [
            'items'      => $clean,
            'updated_at' => date('Y-m-d H:i:s'),
            'updated_by' => (string)($me['username'] ?? ''),
        ]);
        jsonOut(['ok' => true, 'count' => count($clean)]);
        break;
    }

    /* ---------- v1.2.20: leads ---------- */
    case 'get_leads': {
        // v1.2.29: agent boleh melihat — merekalah yang menindaklanjuti
        requireAuth(['super_admin', 'admin', 'wa_agent']);
        $all = leadsGetAll();
        $contacts = waGetContacts();
        $out = [];
        foreach ($all as $num => $l) {
            if (!is_array($l)) continue;
            $nm = waContactName($num, $contacts);
            if ($nm === '') $nm = trim((string)($l['extracted']['nama'] ?? ''));
            $out[] = [
                'number'        => (string)$num,
                'name'          => $nm,
                'status'        => (string)($l['status'] ?? 'baru'),
                'note'          => (string)($l['note'] ?? ''),
                'extracted'     => is_array($l['extracted'] ?? null) ? $l['extracted'] : [],
                'analyzed_at'   => (string)($l['analyzed_at'] ?? ''),
                'updated_at'    => (string)($l['updated_at'] ?? ''),
                'contact_stage' => waContactStage($num, $contacts),   // v1.2.39
                'contact_vip'   => waContactVip($num, $contacts),     // v1.2.39
            ];
        }
        usort($out, function ($a, $b) { return strcmp($b['updated_at'], $a['updated_at']); });
        jsonOut(['ok' => true, 'leads' => $out, 'count' => count($out)]);
        break;
    }

    case 'save_lead': {
        // v1.2.29: agent boleh mengubah status & menulis catatan
        requireAuth(['super_admin', 'admin', 'wa_agent']);
        $in  = bodyInput();
        $num = preg_replace('/\D/', '', (string)($in['number'] ?? ''));
        if ($num === '') jsonOut(['ok' => false, 'error' => 'Nomor tidak valid.'], 400);
        $all = leadsGetAll();
        if (!isset($all[$num]) || !is_array($all[$num])) {
            jsonOut(['ok' => false, 'error' => 'Lead tidak ditemukan.'], 404);
        }
        if (isset($in['status'])) {
            $st = (string)$in['status'];
            if (!leadStatusValid($st)) jsonOut(['ok' => false, 'error' => 'Status tidak dikenal.'], 400);
            $all[$num]['status'] = $st;
        }
        if (isset($in['note'])) {
            $all[$num]['note'] = mb_substr(trim((string)$in['note']), 0, 1000);
        }
        $all[$num]['updated_at'] = date('Y-m-d H:i:s');
        writeJson(LEADS_FILE, $all);
        jsonOut(['ok' => true]);
        break;
    }

    case 'analyze_lead': {
        // Analisa manual (mis. percakapan lama sebelum fitur ini ada, atau
        // percakapan yang sudah berkembang jauh sejak analisa pertama).
        requireAuth(['super_admin', 'admin', 'supervisor']);
        $in  = bodyInput();
        $num = preg_replace('/\D/', '', (string)($in['number'] ?? ''));
        if ($num === '') jsonOut(['ok' => false, 'error' => 'Nomor tidak valid.'], 400);
        $s = getSettings();
        $aiProv = $s['api']['provider'] ?? 'anthropic';
        $aiKeyEmpty = ($aiProv === 'openrouter') ? empty($s['api']['openrouter_api_key']) : empty($s['api']['claude_api_key']);
        if ($aiKeyEmpty) {
            jsonOut(['ok' => false, 'error' => 'API key AI belum dikonfigurasi.'], 400);
        }
        $done = leadAnalyzeNumber($s, $num, null, true);
        if (!$done) jsonOut(['ok' => false, 'error' => 'Analisa gagal atau percakapan kosong.'], 500);
        jsonOut(['ok' => true]);
        break;
    }

    /* ---------- v1.2.31: pemeriksaan sesi ---------- */
    case 'auth_check': {
        // Sengaja seringan mungkin: tidak membaca berkas data apa pun selain
        // yang sudah dibaca requireAuth. Dipakai login.html untuk memastikan
        // token masih sah SEBELUM mengalihkan ke dashboard — tanpa ini, token
        // kedaluwarsa membuat halaman berputar antara login dan dashboard.
        // Tanpa daftar peran = berlaku untuk semua peran yang sudah login.
        $u = requireAuth();
        jsonOut(['ok' => true, 'username' => $u['username'] ?? '', 'role' => $u['role'] ?? '']);
        break;
    }

    /* ---------- v1.2.19: kontak WA ---------- */
    case 'get_contacts': {
        requireAuth(['super_admin', 'admin', 'wa_agent']);
        $all = waGetContacts();
        $out = [];
        foreach ($all as $num => $c) {
            if (!is_array($c)) continue;
            $out[] = [
                'number'      => (string)$num,
                'name'        => waContactName($num, $all),
                'name_wa'     => (string)($c['name_wa'] ?? ''),
                'name_manual' => (string)($c['name_manual'] ?? ''),
                'first_seen'  => (string)($c['first_seen'] ?? ''),
                'last_seen'   => (string)($c['last_seen'] ?? ''),
                'stage'       => waContactStage($num, $all),   // v1.2.39
                'vip'         => waContactVip($num, $all),     // v1.2.39
                'cust_name'   => (string)($c['cust_name'] ?? ''),   // v1.2.39 fase4
                'cust_dob'    => (string)($c['cust_dob'] ?? ''),    // v1.2.39 fase4
                'imp'         => (isset($c['imp']) && is_array($c['imp'])) ? $c['imp'] : null,   // v1.2.113
            ];
        }
        // terbaru dulu
        usort($out, function ($a, $b) { return strcmp($b['last_seen'], $a['last_seen']); });
        jsonOut(['ok' => true, 'contacts' => $out, 'count' => count($out)]);
        break;
    }

    case 'export_contacts': {
        // Ekspor menarik data pribadi customer keluar sistem -> dibatasi ke
        // super_admin/admin saja, dan dicatat jejaknya.
        $me = requireAuth(['super_admin', 'admin', 'supervisor']);

        // Kumpulkan SEMUA nomor WA yang pernah muncul di log (bukan hanya yang
        // sudah punya nama), lalu gabungkan dengan nama dari wa-contacts.json.
        $seen = [];
        foreach (logReadAll() as $e) {
            if (($e['channel'] ?? '') !== 'whatsapp') continue;
            $n = preg_replace('/\D/', '', (string)($e['ip'] ?? ''));
            if ($n !== '' && !isset($seen[$n])) $seen[$n] = ($e['ts'] ?? '');
        }
        $contacts = waGetContacts();
        foreach ($contacts as $n => $c) {
            $n = preg_replace('/\D/', '', (string)$n);
            if ($n !== '' && !isset($seen[$n])) $seen[$n] = (string)($c['last_seen'] ?? '');
        }

        // Escape sesuai spesifikasi vCard: backslash, koma, titik-koma.
        $vEsc = function ($str) {
            $str = str_replace('\\', '\\\\', (string)$str);
            $str = str_replace(';', '\\;', $str);
            $str = str_replace(',', '\\,', $str);
            return str_replace(["\r", "\n"], ' ', $str);
        };

        $vcf = '';
        $n = 0;
        foreach ($seen as $num => $lastTs) {
            $nama = waContactName($num, $contacts);
            if ($nama === '') $nama = '+' . $num;   // tanpa nama -> pakai nomor
            $note = 'Kontak WhatsApp chatbot';
            if ($lastTs !== '') $note .= ' - terakhir aktif ' . substr($lastTs, 0, 10);
            // CRLF wajib per spesifikasi vCard
            $vcf .= "BEGIN:VCARD\r\n";
            $vcf .= "VERSION:3.0\r\n";
            $vcf .= 'FN:' . $vEsc($nama) . "\r\n";
            $vcf .= 'N:' . $vEsc($nama) . ";;;\r\n";
            $vcf .= 'TEL;TYPE=CELL:+' . $num . "\r\n";
            $vcf .= 'NOTE:' . $vEsc($note) . "\r\n";
            $vcf .= "END:VCARD\r\n";
            $n++;
        }

        error_log('export_contacts: ' . ($me['username'] ?? '?') . ' mengekspor ' . $n . ' kontak');
        jsonOut(['ok' => true, 'vcf' => $vcf, 'count' => $n]);
        break;
    }

    case 'import_contacts': {   // v1.2.113: import-kontak
        // Data pribadi masuk dalam jumlah besar -> hanya Super Admin & Admin.
        $me = requireAuth(['super_admin', 'admin']);
        if (($_SERVER['REQUEST_METHOD'] ?? 'GET') !== 'POST') jsonOut(['ok' => false, 'error' => 'Gunakan POST.'], 405);
        $in = bodyInput();
        $rows = $in['rows'] ?? null;
        if (!is_array($rows) || !$rows) jsonOut(['ok' => false, 'error' => 'Tidak ada baris untuk diimpor.'], 400);
        if (count($rows) > 1000) jsonOut(['ok' => false, 'error' => 'Maksimal 1.000 kontak per kiriman.'], 400);
        $overwrite = !empty($in['overwrite']);
        $src = mb_substr(trim((string)($in['file'] ?? '')), 0, 80);
        $now = date('Y-m-d H:i:s');

        // Normalisasi + gabung nomor ganda (tahap tertinggi menang, jumlah dijumlah).
        $clean = []; $invalid = 0;
        foreach ($rows as $r) {
            if (!is_array($r)) { $invalid++; continue; }
            $num = contactImportNormNum($r['n'] ?? '');
            if ($num === '') { $invalid++; continue; }
            $stage = (string)($r['stage'] ?? '');
            if ($stage !== '' && !contactStageValid($stage)) $stage = '';
            $nm = trim(preg_replace('/\s+/u', ' ', (string)($r['name'] ?? '')));
            $item = ['stage' => $stage, 'name' => mb_substr($nm, 0, 100),
                     'st' => mb_substr(trim((string)($r['st'] ?? '')), 0, 60),
                     'cnt' => max(1, min(9999, (int)($r['cnt'] ?? 1))), 'src' => $src];
            if (!isset($clean[$num])) { $clean[$num] = $item; continue; }
            $old = $clean[$num];
            $item['cnt'] += $old['cnt'];
            if (contactImportRank($old['stage']) >= contactImportRank($stage)) { $old['cnt'] = $item['cnt']; $item = $old; }
            if ($item['name'] === '') $item['name'] = $old['name'];
            $clean[$num] = $item;
        }

        $cnt = ['created' => 0, 'updated' => 0, 'kept' => 0];
        $byStage = [];
        if (!deiStorageMysql()) {
            // Mode berkas: satu kunci + satu tulis untuk seluruh kiriman.
            deiWithLock('wa-contacts', function () use ($clean, $overwrite, $now, &$cnt) {
                $all = waGetContacts();
                foreach ($clean as $num => $r) {
                    $isNew = !isset($all[$num]) || !is_array($all[$num]);
                    $c = $isNew ? waContactDefaults() : $all[$num];
                    $res = 'updated';
                    contactImportApply($c, $isNew, $r, $overwrite, $now, $res);
                    $all[$num] = $c;
                    $cnt[$res]++;
                }
                writeJson(CONTACTS_FILE, $all);
            });
        } else {
            foreach ($clean as $num => $r) {
                $res = 'updated';
                waContactUpdate($num, function (&$c, $isNew) use ($r, $overwrite, $now, &$res) {
                    contactImportApply($c, $isNew, $r, $overwrite, $now, $res);
                });
                $cnt[$res]++;
            }
        }
        foreach ($clean as $r) { $k = $r['stage'] === '' ? 'none' : $r['stage']; $byStage[$k] = ($byStage[$k] ?? 0) + 1; }
        try { waAuditLog('contacts_import', $me['username'] ?? '?', '', ['file' => $src, 'n' => count($clean)] + $cnt); } catch (\Throwable $e) {}
        error_log('import_contacts: ' . ($me['username'] ?? '?') . ' ' . count($clean) . ' kontak dari ' . $src . ' ' . json_encode($cnt));
        jsonOut(['ok' => true, 'total' => count($clean), 'invalid' => $invalid, 'by_stage' => $byStage] + $cnt);
        break;
    }

    case 'save_contact': {
        requireAuth(['super_admin', 'admin', 'wa_agent']);
        $in  = bodyInput();
        $num = preg_replace('/\D/', '', (string)($in['number'] ?? ''));
        if ($num === '') jsonOut(['ok' => false, 'error' => 'Nomor tidak valid.'], 400);
        $nm  = trim((string)($in['name'] ?? ''));
        if (mb_strlen($nm) > 100) $nm = mb_substr($nm, 0, 100);
        waContactUpdate($num, function (&$c) use ($nm) { $c['name_manual'] = $nm; });   // v1.2.71; kosong = kembali pakai nama profil WA
        jsonOut(['ok' => true, 'number' => $num, 'name' => waContactName($num)]);
        break;
    }

    case 'save_contact_stage': {
        requireAuth(['super_admin', 'admin', 'wa_agent']);
        $in  = bodyInput();
        $num = preg_replace('/\D/', '', (string)($in['number'] ?? ''));
        if ($num === '') jsonOut(['ok' => false, 'error' => 'Nomor tidak valid.'], 400);
        $stage = (string)($in['stage'] ?? '');
        if (!contactStageValid($stage)) jsonOut(['ok' => false, 'error' => 'Tag tidak dikenal.'], 400);
        $vip = !empty($in['vip']);
        waSetContactStage($num, $stage, $vip);
        $all = waGetContacts();
        jsonOut([
            'ok'     => true,
            'number' => $num,
            'stage'  => waContactStage($num, $all),
            'vip'    => waContactVip($num, $all),
        ]);
        break;
    }

    case 'save_contact_info': {
        requireAuth(['super_admin', 'admin', 'wa_agent']);
        $in  = bodyInput();
        $num = preg_replace('/\D/', '', (string)($in['number'] ?? ''));
        if ($num === '') jsonOut(['ok' => false, 'error' => 'Nomor tidak valid.'], 400);
        $custName = null; $custDob = null;
        if (isset($in['cust_name'])) $custName = (string)$in['cust_name'];
        if (isset($in['cust_dob'])) {
            $d = trim((string)$in['cust_dob']);
            if ($d !== '' && !preg_match('/^\d{4}-\d{2}-\d{2}$/', $d)) {
                jsonOut(['ok' => false, 'error' => 'Format tanggal lahir tidak valid (YYYY-MM-DD).'], 400);
            }
            $custDob = $d;
        }
        waSetContactInfo($num, $custName, $custDob);
        $all = waGetContacts();
        $c = $all[$num] ?? [];
        jsonOut([
            'ok'        => true,
            'number'    => $num,
            'cust_name' => (string)($c['cust_name'] ?? ''),
            'cust_dob'  => (string)($c['cust_dob'] ?? ''),
        ]);
        break;
    }

    case 'get_birthday_config': {
        // v1.2.39 fase8: dipakai halaman Kontak untuk tahu apakah fitur
        // ulang tahun boleh tampil, sekaligus mengambil template ucapan.
        // Dibuat terpisah dari get_settings karena get_settings dibatasi
        // super_admin/admin, sementara halaman Kontak juga dibuka wa_agent.
        // Tidak mengandung rahasia apa pun (cuma status aktif + teks ucapan).
        requireAuth(['super_admin', 'admin', 'wa_agent']);
        $s = getSettings();
        jsonOut([
            'ok'                => true,
            'wa_enabled'        => !empty($s['whatsapp_api']['enabled']) || deiWaConnected($s['whatsapp_api'] ?? []),   // v1.2.93: wa-bot-off
            // v1.2.39 fase8b: fitur ulang tahun hanya untuk Fonnte -- Meta
            // menolak teks bebas di luar jendela 24 jam, jadi ucapan hampir
            // selalu gagal kirim kalau providernya Meta.
            'provider'          => (string)($s['whatsapp_api']['provider'] ?? 'meta'),
            'birthday_greeting' => (string)($s['bot']['birthday_greeting'] ?? ''),
        ]);
        break;
    }

    /* ---------- v1.2.94: wa-media: file media WA (login wajib; token boleh di query untuk <img>/<video>) ---------- */
    case 'wa_media': {
        $u = requireAuth(['super_admin','admin','wa_agent']);
        $f = (string)($_GET['f'] ?? '');
        if (!preg_match('#^(\d{6,20})/([a-f0-9]{20}\.[a-z0-9]{1,5})$#', $f, $mf)) { http_response_code(400); header('Content-Type: text/plain'); echo 'bad request'; exit; }
        deiGuardAgentPrivate($u, $mf[1]);
        $p = WA_MEDIA_DIR . '/' . $mf[1] . '/' . $mf[2];
        if (!is_file($p)) { http_response_code(404); header('Content-Type: text/plain'); echo 'Media sudah tidak tersedia'; exit; }
        deiWaMediaOutput($p, !empty($_GET['dl']));
        exit;
    }

    case 'wa_thread': {
        $u = requireAuth(['super_admin','admin','wa_agent']);
        $num = waNormNum($_GET['number'] ?? '');
        if ($num === '') jsonOut(['ok' => false, 'error' => 'number wajib'], 400);
        deiGuardAgentPrivate($u, $num);   // v1.2.58
        $logs = logReadAll();
        $msgs = [];
        $lastInbound = 0;
        $s116 = getSettings(); $curCh116 = waCurCh($num, $s116); $winCh116 = waWinCh($num, $s116);   // v1.2.116: pindah-nomor
        foreach ($logs as $e) {
            if (($e['channel'] ?? '') !== 'whatsapp') continue;
            if (waNormNum($e['ip'] ?? '') !== $num) continue;
            if ($lastInbound === 0 && ($e['q'] ?? '') !== '' && waInboundOnCh($e, $winCh116)) $lastInbound = strtotime($e['ts']);   // v1.2.116
            $msgs[] = ['ts' => $e['ts'] ?? '', 'q' => $e['q'] ?? '', 'a' => $e['a'] ?? '', 'dir' => $e['dir'] ?? '', 'awaiting' => !empty($e['awaiting']),
                       'media' => is_array($e['media'] ?? null) ? $e['media'] : null,   // v1.2.94: wa-media
                       'media_out' => is_array($e['media_out'] ?? null) ? $e['media_out'] : null,   // v1.2.95: kb-foto
                       'call_txt' => wcLabel($e),   // v1.2.108: tolak-telepon
                       'ch' => (string)($e['wa_ch'] ?? '')];   // v1.2.98: multi-nomor
        }
        $msgs = array_reverse(array_slice($msgs, 0, 60)); // oldest → newest
        jsonOut([
            'ok' => true,
            'number' => $num,
            'mode' => waGetMode($num),
            'history' => (function () use ($num) { try { return wiThreadPublic($num, !empty($_GET['imp_all'])); } catch (\Throwable $e) { return null; } })(),   // v1.2.105: riwayat-wa-waha
            'conv' => (function () use ($num) { try { return convPublic(convStoreGet($num)); } catch (\Throwable $e) { return null; } })(),   // v1.2.101
            'window_open' => waWindowSelaluTerbuka() || ($lastInbound > 0 && (time() - $lastInbound) <= 24 * 3600),   // v1.2.36
            'messages' => $msgs,
            'channels' => (function () { $s0 = getSettings(); return waMultiOn(waConf($s0), $s0) ? waChannels($s0) : []; })(),   // v1.2.98: multi-nomor
            'ch' => $curCh116, 'win_per_ch' => $winCh116 !== '',   // v1.2.116: pindah-nomor
            'wa_prov' => (string)(waConf($s116)['provider'] ?? 'meta'),
        ]);
        break;
    }

    /* ---------- ADMIN: take over / return to bot ---------- */
    case 'wa_set_mode': {
        $u = requireAuth(['super_admin','admin','wa_agent']);
        $in = bodyInput();
        $num = waNormNum($in['number'] ?? '');
        $mode = (($in['mode'] ?? '') === 'human') ? 'human' : 'bot';
        if ($num === '') jsonOut(['ok' => false, 'error' => 'number wajib'], 400);
        deiGuardSpvScope($u, $num);   // v1.2.59
        waSetMode($num, $mode, 'takeover');   // v1.2.101
        jsonOut(['ok' => true, 'number' => $num, 'mode' => $mode]);
        break;
    }

    /* ---------- ADMIN: send a manual WhatsApp reply ---------- */
    case 'wa_send_manual': {
        $u = requireAuth(['super_admin','admin','wa_agent']);
        $s = getSettings();
        $wa = waConf($s);
        $in = bodyInput();
        $num = waNormNum($in['number'] ?? '');
        $text = trim($in['text'] ?? '');
        if ($num === '' || $text === '') jsonOut(['ok' => false, 'error' => 'number & text wajib'], 400);
        if (mb_strlen($text) > 4000) $text = mb_substr($text, 0, 4000);
        deiGuardSpvScope($u, $num);   // v1.2.59
        // v1.2.58: agent tidak boleh membalas chat yang dipegang agent lain
        if ($u['role'] === 'wa_agent') {
            $cl58 = waClaimGet($num);
            if ($cl58 && ($cl58['agent_username'] ?? '') !== $u['username']) {
                jsonOut(['ok' => false, 'error' => 'Chat ini dipegang ' . ($cl58['agent_username'] ?? 'agent lain') . '. Minta take-over dulu.'], 403);
            }
        }

        $logs = logReadAll();
        $lastInbound = 0;
        $winCh116 = waWinCh($num, $s);   // v1.2.116: pindah-nomor — jendela Meta per nomor bisnis
        foreach ($logs as $e) {
            if (($e['channel'] ?? '') === 'whatsapp' && waNormNum($e['ip'] ?? '') === $num && ($e['q'] ?? '') !== '' && waInboundOnCh($e, $winCh116)) {
                $lastInbound = strtotime($e['ts']); break;
            }
        }
        if ($lastInbound <= 0 || (time() - $lastInbound) > 24 * 3600) {
            if (!waWindowSelaluTerbuka()) jsonOut(['ok' => false, 'error' => 'Jendela 24 jam tertutup' . ($winCh116 !== '' ? ' untuk nomor ini' : '') . ' — WhatsApp tidak mengizinkan balasan teks bebas. Pelanggan harus mengirim pesan lagi terlebih dulu' . ($winCh116 !== '' ? ' ke nomor ini (atau kirim template lewat Blast dari nomor ini).' : '.')], 409);
        }

        $GLOBALS['dei_out_src'] = 'agent';   // v1.2.104: skor-risiko-wa
        if (!waSend($wa, $num, $text)) {
            $wr = trim((string)($GLOBALS['wa_last_error'] ?? ''));
            $emsg = ($wr !== '') ? ('Gagal mengirim via WhatsApp: ' . $wr)
                                 : 'Gagal mengirim via WhatsApp. Cek Access Token / Phone Number ID.';
            jsonOut(['ok' => false, 'error' => $emsg], 502);
        }
        waSetMode($num, 'human', 'agent_reply'); // replying manually = taking over
        deiRecordAgentReply($num, $u['username'], 'dashboard');   // v1.2.58 (sebelum convReply)
        convReply($num, 'agent');   // v1.2.56
        if ($wa['keep_context'] ?? true) {
            $h = waLoadHistory($num);
            $h[] = ['role' => 'assistant', 'content' => $text];
            waSaveHistory($num, $h);
        }
        // v1.2.58: baca ulang di bawah kunci — $logs di atas dibaca SEBELUM waSend
        // (panggilan jaringan), jadi pesan yang masuk selama itu dulu ikut tertimpa.
        logPrepend([
            'ts' => date('Y-m-d H:i:s'), 'q' => '', 'a' => $text, 'ip' => $num,
            'channel' => 'whatsapp', 'dir' => 'manual',
            'utm_source' => 'whatsapp', 'utm_medium' => 'manual', 'utm_campaign' => '', 'page' => '', 'referrer' => '',
        ], (int)($s['api']['log_limit'] ?? 500));
        jsonOut(['ok' => true]);
        break;
    }

    /* ---------- AUTH: login ---------- */
    /* v1.2.90: masuk sekali pakai dari pusat (pendaftaran mandiri / "Masuk sebagai Super Admin").
     * sso = base64url(json) . hmac_sha256(base64url(json), license_key). Berlaku <= 15 menit, sekali pakai. */
    case 'sso_login': {
        $in  = bodyInput();
        $tok = trim((string)($in['sso'] ?? ''));
        $s   = getSettings();
        $cs  = $s['central_server'] ?? [];
        $key = (string)($cs['license_key'] ?? '');
        $bad = 'Tautan masuk tidak valid. Silakan login dengan email & password.';
        if ($key === '' || substr_count($tok, '.') !== 1) jsonOut(['ok' => false, 'error' => $bad], 400);
        list($b64, $sig) = explode('.', $tok, 2);
        if (!hash_equals(hash_hmac('sha256', $b64, $key), $sig)) jsonOut(['ok' => false, 'error' => $bad], 403);
        $p = json_decode((string)base64_decode(strtr($b64, '-_', '+/')), true);
        $now = time();
        if (!is_array($p) || strtolower((string)($p['t'] ?? '')) !== strtolower((string)($cs['tenant_id'] ?? ''))) jsonOut(['ok' => false, 'error' => $bad], 403);
        $exp = (int)($p['exp'] ?? 0);
        if ($exp < $now || $exp - $now > 900) jsonOut(['ok' => false, 'error' => 'Tautan masuk sudah kedaluwarsa. Silakan login dengan email & password.'], 403);
        $nonce = preg_replace('/[^a-f0-9]/', '', (string)($p['n'] ?? ''));
        if (strlen($nonce) < 16) jsonOut(['ok' => false, 'error' => $bad], 403);
        $nf = DATA_DIR . '/sso-used.json';
        $usedN = array_filter((array)readJson($nf, []), function ($e) use ($now) { return (int)$e >= $now; });
        if (isset($usedN[$nonce])) jsonOut(['ok' => false, 'error' => 'Tautan masuk sudah dipakai. Silakan login dengan email & password.'], 403);
        $usedN[$nonce] = $exp;
        writeJson($nf, $usedN);

        $uname = trim((string)($p['u'] ?? ''));
        $wantSa = !empty($p['sa']);
        $users = readJson(USERS_FILE, []);
        $found = null;
        foreach ($users as $x) { if (($x['username'] ?? '') === $uname) { $found = $x; break; } }
        if (!$found && $wantSa && $uname !== '') {
            // Akun internal DEI dibuat saat pertama kali dipakai (tanpa password yang diketahui siapa pun)
            $found = ['username' => $uname, 'name' => (string)($p['name'] ?? 'Tim DEI'),
                      'password' => password_hash(bin2hex(random_bytes(24)), PASSWORD_DEFAULT),
                      'role' => 'super_admin', 'migrated_3role' => true, 'internal' => true];
            $users[] = $found;
            writeJson(USERS_FILE, $users);
        }
        if (!$found) { deiLoginLog($uname, false, 'sso', 'unknown_user'); jsonOut(['ok' => false, 'error' => 'Akun tidak ditemukan.'], 401); }   // v1.2.112
        $role = (string)($found['role'] ?? '');
        if ($wantSa && $role !== 'super_admin') { deiLoginLog($uname, false, 'sso', 'not_sa', ['role' => $role]); jsonOut(['ok' => false, 'error' => 'Akun ini bukan Super Admin.'], 403); }
        if (!in_array($role, ['super_admin', 'admin'], true)) { deiLoginLog($uname, false, 'sso', 'not_admin', ['role' => $role]); jsonOut(['ok' => false, 'error' => 'Masuk otomatis hanya untuk Admin.'], 403); }
        lockoutClear($uname);
        deiLoginLog($uname, true, 'sso', '', ['name' => $found['name'] ?? $uname, 'role' => $role] + (!empty($found['internal']) ? ['in' => 1] : []));
        jsonOut(['ok' => true, 'token' => makeToken($uname), 'user' => [
            'username' => $uname, 'name' => $found['name'] ?? $uname, 'role' => $role,
            'tour_seen' => (int)($found['tour_seen'] ?? 0)]]);
        break;
    }

    /* v1.2.90: kartu "Mulai Cepat" (tenant hasil pendaftaran mandiri) */
    case 'onboarding_status': {
        requireAuth(['super_admin', 'admin']);
        $s  = getSettings();
        $ob = (array)($s['onboarding'] ?? []);
        $cap = getCapStatus($s);
        $kb  = readJson(KB_FILE, []);
        $bot = (array)($s['bot'] ?? []);
        $wa  = waConf($s);
        $calls = 0;
        foreach ((array)readJson(DATA_DIR . '/usage.json', []) as $d) { if (is_array($d)) $calls += (int)($d['calls'] ?? 0); }
        $botSig = md5((string)($bot['system_prompt'] ?? '') . '|' . (string)($bot['bot_name'] ?? '') . '|' . (string)($bot['greeting'] ?? ''));
        $waOn = (($wa['provider'] ?? '') === 'waha') ? ((string)($wa['waha_number'] ?? '') !== '')
              : deiWaConnected($wa);   // v1.2.93: wa-bot-off
        jsonOut(['ok' => true,
            'enabled'   => !empty($ob['enabled']),
            'dismissed' => !empty($ob['dismissed']),
            'business'  => (string)($ob['business'] ?? ''),
            'steps'     => [
                'bot'  => !empty($ob['bot_sig']) ? ($botSig !== $ob['bot_sig']) : true,
                'kb'   => is_array($kb) && count($kb) > 0,
                'wa'   => $waOn,
                'test' => $calls > 0,
            ],
            'trial'     => $cap['trial'] ?? null,
        ]);
        break;
    }
    case 'onboarding_dismiss': {
        requireAuth(['super_admin', 'admin']);
        $s = getSettings();
        if (!isset($s['onboarding']) || !is_array($s['onboarding'])) $s['onboarding'] = [];
        $s['onboarding']['dismissed'] = !array_key_exists('dismiss', bodyInput()) || !empty(bodyInput()['dismiss']);
        writeJson(SETTINGS_FILE, $s);
        jsonOut(['ok' => true]);
        break;
    }

    /* v1.2.91: wa-api — permintaan bantuan koneksi WhatsApp API resmi (Meta) ke tim DEI (lewat pusat) */
    case 'wa_api_request': {
        $u  = requireAuth(['super_admin', 'admin']);
        $s  = getSettings();
        $cs = $s['central_server'] ?? [];
        $in = bodyInput();
        $op = (string)($in['op'] ?? 'status');
        if (empty($cs['url']) || empty($cs['tenant_id']) || empty($cs['license_key'])) jsonOut(['ok' => false, 'error' => 'Server pusat belum dikonfigurasi.'], 400);
        $payload = ['tenant_id' => $cs['tenant_id'], 'license_key' => $cs['license_key'], 'op' => $op];
        if ($op === 'send') {
            $phone = preg_replace('/\D/', '', (string)($in['phone'] ?? ''));
            if (strpos($phone, '0') === 0) $phone = '62' . substr($phone, 1);
            if (strlen($phone) < 10 || strlen($phone) > 15) jsonOut(['ok' => false, 'error' => 'Nomor WhatsApp bisnis tidak valid.'], 400);
            $payload += [
                'phone'   => $phone,
                'contact' => mb_substr(trim((string)($in['contact'] ?? ($u['name'] ?? ''))), 0, 60),
                'contact_phone' => mb_substr(preg_replace('/[^\d+]/', '', (string)($in['contact_phone'] ?? '')), 0, 20),
                'meta_bm' => in_array(($in['meta_bm'] ?? ''), ['ya', 'tidak', 'tidak_tahu'], true) ? $in['meta_bm'] : 'tidak_tahu',
                'number_in_app' => in_array(($in['number_in_app'] ?? ''), ['ya', 'tidak'], true) ? $in['number_in_app'] : 'tidak',
                'note'    => mb_substr(trim((string)($in['note'] ?? '')), 0, 500),
                'by'      => (string)($u['username'] ?? ''),
                'business'=> (string)($s['onboarding']['business'] ?? ($s['bot']['persona_company'] ?? '')),
            ];
        }
        $ch = curl_init(rtrim($cs['url'], '/') . '/backend/index.php?action=wa_api_request');
        curl_setopt_array($ch, [CURLOPT_RETURNTRANSFER => true, CURLOPT_POST => true, CURLOPT_TIMEOUT => 15,
            CURLOPT_POSTFIELDS => json_encode($payload), CURLOPT_HTTPHEADER => ['Content-Type: application/json']]);
        $resp = curl_exec($ch); $code = (int)curl_getinfo($ch, CURLINFO_HTTP_CODE); curl_close($ch);
        $j = json_decode((string)$resp, true);
        if (!is_array($j)) jsonOut(['ok' => false, 'error' => 'Server pusat tidak merespons (HTTP ' . $code . '). Coba lagi nanti.'], 502);
        if ($op === 'send' && !empty($j['ok'])) { try { waAuditLog('wa_api_request', $u['username'], '', []); } catch (\Throwable $e) {} }
        jsonOut($j, $code ?: 200);
        break;
    }

    case 'login': {
        $in = bodyInput();
        $username = trim($in['username'] ?? '');
        $password = (string)($in['password'] ?? '');
        if ($username === '' || $password === '') {
            jsonOut(['ok' => false, 'error' => 'Username dan password wajib diisi.'], 400);
        }
        $remaining = lockoutCheck($username);
        if ($remaining > 0) {
            $mins = (int)ceil($remaining / 60);
            deiLoginLog($username, false, 'password', 'locked');   // v1.2.112
            jsonOut(['ok' => false, 'error' => "Terlalu banyak percobaan. Coba lagi dalam $mins menit.", 'locked' => true, 'retry_after' => $remaining], 429);
        }
        $users = readJson(USERS_FILE, []);
        $llFound = false;   // v1.2.112
        foreach ($users as $idx => $u) {
            if (($u['username'] ?? '') !== $username) continue;
            $llFound = true;
            $stored = (string)($u['password'] ?? '');
            $valid = false;
            if (strpos($stored, '$2y$') === 0 || strpos($stored, '$argon') === 0) {
                $valid = password_verify($password, $stored);
            } else {
                // Legacy plaintext — verify then upgrade to bcrypt
                $valid = hash_equals($stored, $password);
                if ($valid) {
                    $users[$idx]['password'] = password_hash($password, PASSWORD_DEFAULT);
                    writeJson(USERS_FILE, $users);
                }
            }
            if ($valid) {
                lockoutClear($username);
                // role migration on login too (so token carries new role)
                $role = $u['role'] ?? 'admin';
                if ($role === 'admin' && empty($u['migrated_3role'])) {
                    $users[$idx]['role'] = 'super_admin';
                    $users[$idx]['migrated_3role'] = true;
                    writeJson(USERS_FILE, $users);
                    $role = 'super_admin';
                } elseif ($role === 'editor' && empty($u['migrated_3role'])) {
                    $users[$idx]['role'] = 'admin';
                    $users[$idx]['migrated_3role'] = true;
                    writeJson(USERS_FILE, $users);
                    $role = 'admin';
                }
                // v1.2.58: batas kursi agent/supervisor dari paket
                if (($role === 'wa_agent' || $role === 'supervisor') && !deiSeatAllowed($username, $role, $users)) {
                    deiLoginLog($username, false, 'password', 'seat_limit', ['name' => $u['name'] ?? $username, 'role' => $role]);   // v1.2.112
                    jsonOut(['ok' => false, 'error' => deiSeatMsg($role, deiFeatures())], 403);
                }
                deiLoginLog($username, true, 'password', '', ['name' => $u['name'] ?? $username, 'role' => $role] + (!empty($u['internal']) ? ['in' => 1] : []));   // v1.2.112
                jsonOut([
                    'ok' => true,
                    'token' => makeToken($username),
                    'user' => [
                        'username' => $username,
                        'name'     => $u['name'] ?? $username,
                        'role'     => $role,
                        'tour_seen' => (int)($u['tour_seen'] ?? 0),   // v1.2.74
                    ],
                ]);
            }
            break;
        }
        $left = lockoutRecordFail($username);   // v1.2.115
        deiLoginLog($username, false, 'password', $llFound ? 'wrong_password' : 'unknown_user');   // v1.2.112
        if ($left <= 0) {
            jsonOut(['ok' => false, 'error' => 'Username atau password salah. Terlalu banyak percobaan — coba lagi dalam ' . (int)(LOCKOUT_WINDOW_SEC / 60) . ' menit.', 'locked' => true, 'retry_after' => LOCKOUT_WINDOW_SEC], 429);
        }
        jsonOut(['ok' => false, 'error' => 'Username atau password salah. Sisa ' . $left . ' percobaan sebelum dikunci ' . (int)(LOCKOUT_WINDOW_SEC / 60) . ' menit.', 'tries_left' => $left], 401);
        break;
    }

    /* ---------- AUTH: validate session ---------- */
    case 'me': {
        $u = requireAuth();
        jsonOut(['ok' => true, 'user' => [
            'username' => $u['username'],
            'name'     => $u['name'] ?? $u['username'],
            'role'     => $u['role'] ?? 'editor',
            'tour_seen' => (int)($u['tour_seen'] ?? 0),   // v1.2.74
        ]]);
        break;
    }

    /* ---------- get settings (super_admin + admin) ---------- */
    case 'get_settings': {
        $u = requireAuth(['super_admin', 'admin']);
        $role = $u['role'];
        $raw = getSettings();
        deiRememberApiUrl();   // v1.2.56
        $s = $raw;
        // mask the API key
        $s['api']['claude_api_key'] = maskKey($raw['api']['claude_api_key'] ?? '');
        $s['api']['key_is_set'] = !empty($raw['api']['claude_api_key']);
        // v1.2.49: OpenRouter key (rahasia)
        $s['api']['openrouter_api_key'] = maskKey($raw['api']['openrouter_api_key'] ?? '');
        $s['api']['openrouter_key_is_set'] = !empty($raw['api']['openrouter_api_key']);
        $sfb = deiServerConf()['ai_fallback'] ?? null;   // v1.2.80: info cadangan bawaan server
        $s['api']['server_fallback'] = (is_array($sfb) && !empty($sfb['model'])) ? (string)$sfb['model'] : '';
        // mask WhatsApp secrets
        if (isset($s['whatsapp_api']) && is_array($s['whatsapp_api'])) {
            $s['whatsapp_api']['access_token'] = maskKey($raw['whatsapp_api']['access_token'] ?? '');
            $s['whatsapp_api']['app_secret']   = maskKey($raw['whatsapp_api']['app_secret'] ?? '');
            $s['whatsapp_api']['token_is_set'] = !empty($raw['whatsapp_api']['access_token']);
            // v1.2.36: token Fonnte diperlakukan sama seperti token Meta
            $s['whatsapp_api']['fonnte_token']        = maskKey($raw['whatsapp_api']['fonnte_token'] ?? '');
            $s['whatsapp_api']['fonnte_token_is_set'] = !empty($raw['whatsapp_api']['fonnte_token']);
            $s['whatsapp_api']['waha_api_key']        = maskKey($raw['whatsapp_api']['waha_api_key'] ?? '');   // v1.2.76
            $s['whatsapp_api']['waha_api_key_is_set'] = !empty($raw['whatsapp_api']['waha_api_key']);
        }
        if (isset($s['telegram']) && is_array($s['telegram'])) {
            $s['telegram']['bot_token'] = maskKey($raw['telegram']['bot_token'] ?? '');
            $s['telegram']['token_is_set'] = !empty($raw['telegram']['bot_token']);
        }
        // v1.2.56: token aplikasi Pushover = rahasia
        if (isset($s['escalation']) && is_array($s['escalation'])) {
            $s['escalation']['pushover_app_token'] = maskKey($raw['escalation']['pushover_app_token'] ?? '');
            $s['escalation']['pushover_token_is_set'] = !empty($raw['escalation']['pushover_app_token']);
        }
        // For admin (non super), also strip verify_token + phone_number_id values to placeholders
        // so the field can't be inspected even though Admin can't edit it.
        if ($role !== 'super_admin' && isset($s['whatsapp_api'])) {
            $s['whatsapp_api']['verify_token']    = $s['whatsapp_api']['verify_token']    ? '••••' : '';
            // phone_number_id is not a secret per se, but Admin can't edit; keep visibility off too.
            $s['whatsapp_api']['phone_number_id'] = $s['whatsapp_api']['phone_number_id'] ? '••••' : '';
            // v1.2.36: kunci webhook Fonnte juga rahasia — hanya super_admin yang perlu melihatnya
            $s['whatsapp_api']['fonnte_webhook_key'] = !empty($s['whatsapp_api']['fonnte_webhook_key']) ? '••••' : '';
            $s['whatsapp_api']['waha_webhook_key']   = !empty($s['whatsapp_api']['waha_webhook_key']) ? '••••' : '';   // v1.2.76
        }
        unset($s['wa_numbers']);   // v1.2.98: multi-nomor — dikelola lewat wa_numbers (token tidak dikirim)
        jsonOut(['ok' => true, 'settings' => $s, 'role' => $role]);
        break;
    }

    /* ---------- save settings (3-role policy) ---------- */
    case 'save_settings': {
        $u = requireAuth(['super_admin', 'admin']);
        $role = $u['role'];
        $in = bodyInput();
        $incoming = is_array($in['settings'] ?? null) ? $in['settings'] : [];
        unset($incoming['wa_numbers']);   // v1.2.98: multi-nomor — hanya lewat action wa_numbers
        $current = getSettings();
        $merged  = $current;

        // Super Admin: full edit, preserve masked secrets.
        if ($role === 'super_admin') {
            // Preserve Claude API key if masked/empty submitted.
            if (isset($incoming['api']['claude_api_key'])) {
                $v = $incoming['api']['claude_api_key'];
                if (strpos($v, '•') !== false || $v === '') {
                    $incoming['api']['claude_api_key'] = $current['api']['claude_api_key'] ?? '';
                }
            }
            // v1.2.49: preserve OpenRouter key kalau masked/empty
            if (isset($incoming['api']['openrouter_api_key'])) {
                $v = $incoming['api']['openrouter_api_key'];
                if (strpos($v, '•') !== false || $v === '') {
                    $incoming['api']['openrouter_api_key'] = $current['api']['openrouter_api_key'] ?? '';
                }
            }
            // v1.2.92: fonnte-off — Fonnte tidak bisa dipilih lagi; tenant yang sudah memakainya tetap jalan sampai dipindah
            if (($incoming['whatsapp_api']['provider'] ?? '') === 'fonnte' && (($current['whatsapp_api']['provider'] ?? '') !== 'fonnte')) {
                jsonOut(['ok' => false, 'error' => 'Fonnte sudah dihentikan. Pilih WAHA (scan QR) atau Meta Cloud API.'], 400);
            }
            // Preserve WhatsApp secrets when masked/empty.
            foreach (['access_token', 'app_secret', 'fonnte_token', 'waha_api_key'] as $secf) {   // v1.2.36, v1.2.76
                if (isset($incoming['whatsapp_api'][$secf])) {
                    $v = $incoming['whatsapp_api'][$secf];
                    if (strpos($v, '•') !== false || $v === '') {
                        $incoming['whatsapp_api'][$secf] = $current['whatsapp_api'][$secf] ?? '';
                    }
                }
            }
            // v1.2.36: kunci webhook Fonnte dibuat otomatis saat penyedia ini
            // dipilih pertama kali, supaya tidak perlu dibuat manual di server.
            if (($incoming['whatsapp_api']['provider'] ?? '') === 'fonnte'
                && empty($incoming['whatsapp_api']['fonnte_webhook_key'])
                && empty($current['whatsapp_api']['fonnte_webhook_key'])) {
                $incoming['whatsapp_api']['fonnte_webhook_key'] = bin2hex(random_bytes(16));
            }
            // v1.2.76: WAHA — kunci webhook (juga kunci HMAC) dibuat otomatis; rapikan URL & nama sesi
            if (($incoming['whatsapp_api']['provider'] ?? '') === 'waha'
                && empty($incoming['whatsapp_api']['waha_webhook_key'])
                && empty($current['whatsapp_api']['waha_webhook_key'])) {
                $incoming['whatsapp_api']['waha_webhook_key'] = bin2hex(random_bytes(24));
            }
            if (isset($incoming['whatsapp_api']['waha_url'])) {
                $wu = rtrim(trim((string)$incoming['whatsapp_api']['waha_url']), '/');
                $incoming['whatsapp_api']['waha_url'] = preg_match('#^https?://#i', $wu) ? $wu : '';
            }
            if (isset($incoming['whatsapp_api']['waha_session'])) {
                $incoming['whatsapp_api']['waha_session'] = preg_replace('/[^A-Za-z0-9_-]/', '', (string)$incoming['whatsapp_api']['waha_session']);
            }

            // Preserve verify_token / phone_number_id when masked.
            foreach (['verify_token', 'phone_number_id', 'fonnte_webhook_key', 'waha_webhook_key'] as $f) {   // v1.2.36, v1.2.76
                if (isset($incoming['whatsapp_api'][$f])) {
                    $v = (string)$incoming['whatsapp_api'][$f];
                    if (strpos($v, '•') !== false) {
                        $incoming['whatsapp_api'][$f] = $current['whatsapp_api'][$f] ?? '';
                    }
                }
            }
            // Preserve Telegram bot token when masked/empty.
            if (isset($incoming['telegram']['bot_token'])) {
                $v = $incoming['telegram']['bot_token'];
                if (strpos($v, '•') !== false || $v === '') {
                    $incoming['telegram']['bot_token'] = $current['telegram']['bot_token'] ?? '';
                }
            }
            // v1.2.56: token Pushover tersamar/kosong -> pertahankan yang lama
            if (isset($incoming['escalation']['pushover_app_token'])) {
                $v = (string)$incoming['escalation']['pushover_app_token'];
                if (strpos($v, '•') !== false || $v === '') $incoming['escalation']['pushover_app_token'] = $current['escalation']['pushover_app_token'] ?? '';
            }
            // v1.2.53: dulu array_replace_recursive() -> daftar tidak bisa menyusut
            $merged = deiMergeSettings($current, $incoming);
        } else {
            // Admin: bot persona, appearance, widget toggles (non-secret), handoff. NO secrets / NO WA / NO Telegram.
            // v1.2.3: extend with structured form fields (additive, backward-compat)
            $allowedBot = ['bot_name', 'greeting', 'quick_replies', 'system_prompt', 'persona_company',
                           'user_address', 'language_style', 'languages', 'language_prompt_behavior',
                           'response_rules', 'fallback_behavior', 'birthday_greeting'];
            foreach ($allowedBot as $f) {
                if (isset($incoming['bot'][$f])) $merged['bot'][$f] = $incoming['bot'][$f];
            }
            if (isset($incoming['appearance']) && is_array($incoming['appearance'])) {
                $merged['appearance'] = array_replace($current['appearance'] ?? [], $incoming['appearance']);
            }
            // Widget toggles + WhatsApp floating button (non-secret). NOT whatsapp_api (Cloud API).
            $allowedWidget = ['chatbot_enabled', 'whatsapp_enabled', 'whatsapp_number', 'whatsapp_message', 'lead_form'];   // v1.2.53
            foreach ($allowedWidget as $f) {
                if (isset($incoming['widget'][$f])) $merged['widget'][$f] = $incoming['widget'][$f];
            }
            // Handoff keywords + on/off.
            if (isset($incoming['handoff']) && is_array($incoming['handoff'])) {
                foreach (['enabled', 'keywords'] as $f) {
                    if (isset($incoming['handoff'][$f])) $merged['handoff'][$f] = $incoming['handoff'][$f];
                }
            }
            // Admin MAY tweak some api block items that aren't secrets (model, rate_limit, log_limit, max_tokens, kb_max_results).
            $allowedApi = ['model', 'max_tokens', 'rate_limit', 'kb_max_results', 'log_limit'];
            foreach ($allowedApi as $f) {
                if (isset($incoming['api'][$f])) $merged['api'][$f] = $incoming['api'][$f];
            }
            // v1.2.56: Admin boleh atur Auto-Closing & Eskalasi (token Pushover tetap milik super_admin)
            if (isset($incoming['auto_closing']) && is_array($incoming['auto_closing'])) {
                $merged['auto_closing'] = deiMergeSettings($current['auto_closing'] ?? [], $incoming['auto_closing']);
            }
            if (isset($incoming['routing']) && is_array($incoming['routing'])) {   // v1.2.100: routing
                $merged['routing'] = deiMergeSettings($current['routing'] ?? [], $incoming['routing']);
            }
            if (isset($incoming['ai_limit']) && is_array($incoming['ai_limit'])) {   // v1.2.97: batas-ai
                $merged['ai_limit'] = deiMergeSettings($current['ai_limit'] ?? [], $incoming['ai_limit']);
            }
            if (isset($incoming['reply_delay']) && is_array($incoming['reply_delay'])) {   // v1.2.96: jeda-balasan
                $merged['reply_delay'] = deiMergeSettings($current['reply_delay'] ?? [], $incoming['reply_delay']);
            }
            if (isset($incoming['wa_hemat']) && is_array($incoming['wa_hemat'])) {   // v1.2.89
                $merged['wa_hemat'] = deiMergeSettings($current['wa_hemat'] ?? [], $incoming['wa_hemat']);
            }
            if (isset($incoming['escalation']) && is_array($incoming['escalation'])) {
                $escIn = $incoming['escalation'];
                unset($escIn['pushover_app_token']);
                $merged['escalation'] = deiMergeSettings($current['escalation'] ?? [], $escIn);
            }
            // EXPLICITLY ignore: api.claude_api_key, whatsapp_api.*, telegram.*
            // v1.2.58: reply.*, team.*, white_label.* hanya Super Admin
        }
        // v1.2.58: rapikan nilai mode balasan, tim, white-label
        if (isset($merged['reply']) || isset($incoming['reply'])) {
            $merged['reply'] = ['mode' => ((($merged['reply']['mode'] ?? 'ai') === 'manual') ? 'manual' : 'ai')];
        }
        if (isset($merged['team']) && is_array($merged['team'])) {
            $merged['team'] = ['agent_private' => !empty($merged['team']['agent_private'])];
        }
        if (isset($merged['white_label']) && is_array($merged['white_label'])) {
            $wl = $merged['white_label'];
            $logo = trim((string)($wl['header_logo'] ?? ''));
            if ($logo !== '' && !preg_match('#^(https?://|/|\./|\.\./)#i', $logo)) $logo = '';
            $merged['white_label'] = [
                'subtitle'      => mb_substr(trim((string)($wl['subtitle'] ?? '')), 0, 60),
                'header_logo'   => mb_substr($logo, 0, 500),
                'hide_branding' => !empty($wl['hide_branding']),
            ];
        }
        if (isset($merged['ai_limit']) && is_array($merged['ai_limit'])) $merged['ai_limit'] = deiAiLimitConf($merged);   // v1.2.97: batas-ai
        if (isset($merged['routing']) && is_array($merged['routing'])) $merged['routing'] = deiRoutingConf($merged);   // v1.2.100: routing
        if (isset($merged['reply_delay']) && is_array($merged['reply_delay'])) {   // v1.2.96: jeda-balasan
            $merged['reply_delay'] = deiReplyDelayConf($merged);
        }
        $modeLama = deiReplyMode($current);
        writeJson(SETTINGS_FILE, $merged);
        unset($GLOBALS['dei_reply_mode_cache']);
        if ($modeLama !== deiReplyMode($merged)) {
            try { waAuditLog('reply_mode_' . deiReplyMode($merged), $u['username'], '', []); } catch (\Throwable $e) {}
        }
        jsonOut(['ok' => true]);
        break;
    }

    /* ---------- v1.2.54: Embedded Signup coexistence — tukar code jadi token ---------- */
    case 'wa_es_exchange': {
        requireAuth(['super_admin']);
        $in   = bodyInput();
        $code = trim((string)($in['code'] ?? ''));
        $pnid = preg_replace('/\D/', '', (string)($in['phone_number_id'] ?? ''));
        $waba = preg_replace('/\D/', '', (string)($in['waba_id'] ?? ''));
        if ($code === '') jsonOut(['ok' => false, 'error' => 'code kosong'], 400);

        $cur    = getSettings();
        $wa     = is_array($cur['whatsapp_api'] ?? null) ? $cur['whatsapp_api'] : [];
        $appId  = trim((string)($wa['es_app_id'] ?? ''));
        $secret = (string)($wa['app_secret'] ?? '');
        $ver    = trim((string)($wa['es_graph_version'] ?? '')) ?: 'v21.0';
        if ($appId === '' || $secret === '') {
            jsonOut(['ok' => false, 'error' => 'App ID / App Secret belum diisi di pengaturan WhatsApp.'], 400);
        }

        // 1) Tukar authorization code -> access token bisnis (long-lived dari Embedded Signup).
        $exUrl = 'https://graph.facebook.com/' . rawurlencode($ver) . '/oauth/access_token?'
               . http_build_query(['client_id' => $appId, 'client_secret' => $secret, 'code' => $code]);
        $ch   = curl_init($exUrl);
        curl_setopt_array($ch, [CURLOPT_RETURNTRANSFER => true, CURLOPT_TIMEOUT => 25]);
        $resp = curl_exec($ch);
        $hc   = curl_getinfo($ch, CURLINFO_HTTP_CODE);
        curl_close($ch);
        $d     = json_decode((string)$resp, true);
        $token = is_array($d) ? (string)($d['access_token'] ?? '') : '';
        if ($hc < 200 || $hc >= 300 || $token === '') {
            error_log('wa_es_exchange tukar token gagal HTTP ' . $hc . ': ' . mb_substr((string)$resp, 0, 300));
            $emsg = (is_array($d) && isset($d['error']['message'])) ? (string)$d['error']['message'] : 'Tukar token gagal.';
            jsonOut(['ok' => false, 'error' => $emsg], 502);
        }

        // 2) Langganan app ke WABA supaya webhook (termasuk echo/sync coexistence) mengalir.
        $subMsg = '';
        if ($waba !== '') {
            $subUrl = 'https://graph.facebook.com/' . rawurlencode($ver) . '/' . rawurlencode($waba) . '/subscribed_apps';
            $ch2 = curl_init($subUrl);
            curl_setopt_array($ch2, [
                CURLOPT_RETURNTRANSFER => true,
                CURLOPT_POST           => true,
                CURLOPT_TIMEOUT        => 25,
                CURLOPT_HTTPHEADER     => ['Authorization: Bearer ' . $token],
                CURLOPT_POSTFIELDS     => '',
            ]);
            $sresp = curl_exec($ch2);
            $shc   = curl_getinfo($ch2, CURLINFO_HTTP_CODE);
            curl_close($ch2);
            if ($shc < 200 || $shc >= 300) {
                error_log('wa_es_exchange subscribed_apps HTTP ' . $shc . ': ' . mb_substr((string)$sresp, 0, 300));
                $subMsg = 'Token tersimpan, tetapi subscribe app ke WABA gagal — subscribe manual di Meta lalu ulangi.';
            }
        }

        // 3) Simpan kredensial + aktifkan provider Meta.
        $cur['whatsapp_api'] = array_merge($wa, [
            'provider'        => 'meta',
            'enabled'         => true,
            'access_token'    => $token,
            'phone_number_id' => ($pnid !== '' ? $pnid : ($wa['phone_number_id'] ?? '')),
            'waba_id'         => ($waba !== '' ? $waba : ($wa['waba_id'] ?? '')),
        ]);
        writeJson(SETTINGS_FILE, $cur);

        jsonOut([
            'ok'              => true,
            'phone_number_id' => $cur['whatsapp_api']['phone_number_id'],
            'waba_id'         => $cur['whatsapp_api']['waba_id'],
            'warning'         => $subMsg,
        ]);
        break;
    }

    /* ---------- knowledge base (admin only) ---------- */
    case 'get_kb': {
        requireAuth(['super_admin','admin']);
        jsonOut(['ok' => true, 'kb' => readJson(KB_FILE, [])]);
        break;
    }

    /* ---------- v1.2.13: kelola kategori notif ---------- */
    case 'get_categories': {
        requireAuth(['super_admin', 'admin', 'supervisor']);
        jsonOut([
            'ok'         => true,
            'fixed'      => deiFixedCategories(),
            'custom'     => deiCustomCategories(),
            'categories' => deiAllCategories(),
        ]);
        break;
    }

    case 'add_category': {
        requireAuth(['super_admin']);
        $in  = bodyInput();
        $cat = trim((string)($in['category'] ?? ''));
        if ($cat === '') jsonOut(['ok' => false, 'error' => 'Nama kategori wajib diisi.'], 400);
        if (mb_strlen($cat) > 30) jsonOut(['ok' => false, 'error' => 'Nama kategori maksimal 30 karakter.'], 400);
        foreach (deiAllCategories() as $exist) {
            if (mb_strtolower($exist) === mb_strtolower($cat)) {
                jsonOut(['ok' => false, 'error' => 'Kategori "' . $exist . '" sudah ada.'], 400);
            }
        }
        $custom   = deiCustomCategories();
        $custom[] = $cat;
        writeJson(PUSH_CATEGORIES_FILE, array_values($custom));
        jsonOut(['ok' => true, 'categories' => deiAllCategories()]);
        break;
    }

    case 'delete_category': {
        requireAuth(['super_admin']);
        $in  = bodyInput();
        $cat = trim((string)($in['category'] ?? ''));
        if ($cat === '') jsonOut(['ok' => false, 'error' => 'Kategori tidak valid.'], 400);
        if (in_array($cat, deiFixedCategories(), true)) {
            jsonOut(['ok' => false, 'error' => 'Kategori bawaan tidak dapat dihapus.'], 400);
        }
        $custom = deiCustomCategories();
        if (!in_array($cat, $custom, true)) {
            jsonOut(['ok' => false, 'error' => 'Kategori tidak ditemukan.'], 404);
        }
        // Blokir kalau masih dipakai — hindari routing "mati diam-diam".
        $use = deiCategoryUsage($cat);
        if ($use['kb'] > 0 || $use['users'] > 0) {
            jsonOut(['ok' => false, 'error' => 'Tidak dapat dihapus: masih dipakai ' . $use['kb'] . ' entri KB dan ' . $use['users'] . ' pengguna. Lepaskan dulu pemakaiannya.'], 409);
        }
        $custom = array_values(array_filter($custom, function ($x) use ($cat) { return $x !== $cat; }));
        writeJson(PUSH_CATEGORIES_FILE, $custom);
        jsonOut(['ok' => true, 'categories' => deiAllCategories()]);
        break;
    }

    /* ---------- v1.2.24: pertanyaan yang belum terjawab ---------- */
    case 'kb_find_gaps': {
        requireAuth(['super_admin', 'admin']);

        // Frasa "menyerah" yang dipakai bot saat tidak punya informasi.
        $frasa = [
            'belum tersedia', 'tidak tersedia', 'belum ada informasi',
            'tidak ada informasi', 'tidak memiliki informasi',
            'hubungi tim', 'menghubungi tim', 'hubungi admin', 'kontak resmi',
            'tim kami akan', 'silakan hubungi', 'tidak dapat menemukan',
            'belum memiliki data', 'informasi lebih lanjut',
        ];
        // Kata umum yang dibuang saat menyusun kunci kelompok.
        $stop = ['yang','untuk','dengan','pada','dari','apakah','bagaimana','berapa',
                 'tolong','mohon','saya','ingin','tahu','bisa','bisakah','boleh',
                 'ada','adalah','itu','ini','dan','atau','di','ke','nya','kah',
                 'informasi','tentang','mengenai','jelaskan','ceritakan','berikan'];

        // Judul KB yang sudah ada — supaya tidak menyarankan yang sudah dipunyai.
        $kbAda = [];
        foreach (readJson(KB_FILE, []) as $e) {
            $t = mb_strtolower(trim((string)($e['title'] ?? '')));
            $t = preg_replace('/[^a-z0-9\s]/u', ' ', $t);
            $t = preg_replace('/\s+/', ' ', trim($t));
            if ($t !== '') $kbAda[$t] = true;
        }

        $grup = [];
        $dipindai = 0;
        foreach (logReadAll() as $e) {
            // kegagalan SISTEM bukan lubang pengetahuan — jangan ikut dihitung
            if (!empty($e['cap_reached']) || !empty($e['suspended']) || !empty($e['ai_error'])) continue;
            if (in_array(($e['dir'] ?? ''), ['manual', 'closing'], true)) continue;   // balasan agent, bukan bot

            $q = trim((string)($e['q'] ?? ''));
            $a = mb_strtolower(trim((string)($e['a'] ?? '')));
            if ($q === '' || $a === '') continue;
            $dipindai++;

            $gagal = false;
            foreach ($frasa as $f) {
                if (mb_strpos($a, $f) !== false) { $gagal = true; break; }
            }
            if (!$gagal) continue;

            // kunci kelompok: kata penting, diurutkan -> tahan beda urutan kata
            $norm = mb_strtolower($q);
            $norm = preg_replace('/[^a-z0-9\s]/u', ' ', $norm);
            $kata = preg_split('/\s+/', trim($norm));
            $penting = [];
            foreach ($kata as $w) {
                if (mb_strlen($w) < 3) continue;
                if (in_array($w, $stop, true)) continue;
                $penting[] = $w;
            }
            if (!$penting) continue;
            sort($penting);
            $kunci = implode(' ', $penting);

            // lewati kalau judul serupa sudah ada di KB
            $cekKb = implode(' ', $penting);
            if (isset($kbAda[$cekKb])) continue;

            if (!isset($grup[$kunci])) {
                // v1.2.25: key dipakai untuk menyembunyikan; sample_a untuk penyaringan AI
                $grup[$kunci] = ['key' => $kunci, 'count' => 0, 'question' => $q,
                                 'sample_a' => mb_substr(trim((string)($e['a'] ?? '')), 0, 200),
                                 'last_ts' => '', 'channels' => []];
            }
            $grup[$kunci]['count']++;
            // wakil kelompok: pertanyaan TERPENDEK (paling ringkas)
            if (mb_strlen($q) < mb_strlen($grup[$kunci]['question'])) $grup[$kunci]['question'] = $q;
            $ts = (string)($e['ts'] ?? '');
            if ($ts > $grup[$kunci]['last_ts']) $grup[$kunci]['last_ts'] = $ts;
            $ch = (string)($e['channel'] ?? '');
            if ($ch !== '' && !in_array($ch, $grup[$kunci]['channels'], true)) $grup[$kunci]['channels'][] = $ch;
        }

        // v1.2.25: buang yang sudah disembunyikan (kecuali diminta ditampilkan)
        $sembunyi = readJson(GAPS_DISMISSED_FILE, []);
        if (!is_array($sembunyi)) $sembunyi = [];
        $tampilkanSembunyi = !empty($_GET['show_hidden']);
        $jmlSembunyi = 0;
        if (!$tampilkanSembunyi) {
            foreach ($grup as $k => $v) {
                if (in_array($k, $sembunyi, true)) { unset($grup[$k]); $jmlSembunyi++; }
            }
        }

        $hasil = array_values($grup);
        usort($hasil, function ($a, $b) {
            if ($b['count'] !== $a['count']) return $b['count'] - $a['count'];
            return strcmp($b['last_ts'], $a['last_ts']);
        });
        jsonOut([
            'ok'        => true,
            'scanned'   => $dipindai,
            'found'     => count($hasil),
            'hidden'    => $jmlSembunyi,           // v1.2.25
            'gaps'      => array_slice($hasil, 0, 40),
        ]);
        break;
    }

    case 'kb_verify_gaps': {
        // AI MEMILAH saja — tidak menulis jawaban, tidak menghapus apa pun.
        // Satu panggilan untuk seluruh daftar (bukan per baris).
        requireAuth(['super_admin', 'admin']);
        $s = getSettings();
        $aiProv = $s['api']['provider'] ?? 'anthropic';
        $aiKeyEmpty = ($aiProv === 'openrouter') ? empty($s['api']['openrouter_api_key']) : empty($s['api']['claude_api_key']);
        if ($aiKeyEmpty) {
            jsonOut(['ok' => false, 'error' => 'API key AI belum dikonfigurasi.'], 400);
        }
        $in = bodyInput();
        $items = is_array($in['items'] ?? null) ? $in['items'] : [];
        if (!$items) jsonOut(['ok' => false, 'error' => 'Tidak ada yang disaring.'], 400);
        $items = array_slice($items, 0, 40);

        $daftar = '';
        foreach ($items as $i => $it) {
            $q = trim((string)($it['question'] ?? ''));
            $a = trim((string)($it['sample_a'] ?? ''));
            $daftar .= $i . '. TANYA: ' . mb_substr($q, 0, 200) . "\n";
            $daftar .= '   JAWAB BOT: ' . mb_substr($a, 0, 200) . "\n\n";
        }

        $sys = "Anda memeriksa mutu jawaban chatbot customer service.\n"
             . "Untuk tiap nomor, tentukan apakah bot BENAR-BENAR GAGAL menjawab pertanyaannya.\n\n"
             . "GAGAL = bot tidak memberi informasi yang diminta (menyatakan tidak tahu,\n"
             . "belum tersedia, atau hanya melempar ke tim/admin tanpa isi).\n"
             . "TIDAK GAGAL = bot sudah memberi informasi yang diminta, walaupun di akhir\n"
             . "menambahkan ajakan menghubungi tim. Ajakan sopan di akhir BUKAN kegagalan.\n\n"
             . "Kembalikan HANYA JSON: {\"gagal\":[nomor, nomor, ...]}\n"
             . "Berisi nomor yang BENAR-BENAR gagal saja. Tanpa penjelasan apa pun.";

        list($okAi, $answer, $usage) = callClaude($s, $sys, [['role' => 'user', 'content' => $daftar]]);
        if (!$okAi) jsonOut(['ok' => false, 'error' => 'Analisa AI gagal.'], 502);
        recordUsage($usage);   // masuk kuota, sepola dengan analisa lead

        $raw = trim((string)$answer);
        $raw = preg_replace('/^```[a-zA-Z]*\s*/', '', $raw);
        $raw = preg_replace('/```\s*$/', '', $raw);
        $data = json_decode(trim($raw), true);
        if (!is_array($data) || !isset($data['gagal']) || !is_array($data['gagal'])) {
            error_log('kb_verify_gaps: respons bukan JSON: ' . mb_substr($raw, 0, 200));
            jsonOut(['ok' => false, 'error' => 'Jawaban AI tidak terbaca.'], 502);
        }
        $gagal = [];
        foreach ($data['gagal'] as $n) { $gagal[] = (int)$n; }
        jsonOut(['ok' => true, 'failed' => $gagal, 'total' => count($items)]);
        break;
    }

    case 'kb_dismiss_gap': {
        requireAuth(['super_admin', 'admin']);
        $in  = bodyInput();
        $keys = is_array($in['keys'] ?? null) ? $in['keys'] : [];
        if (isset($in['key'])) $keys[] = (string)$in['key'];
        $keys = array_filter(array_map('trim', $keys));
        if (!$keys) jsonOut(['ok' => false, 'error' => 'Tidak ada yang disembunyikan.'], 400);

        $sembunyi = readJson(GAPS_DISMISSED_FILE, []);
        if (!is_array($sembunyi)) $sembunyi = [];
        foreach ($keys as $k) {
            if (!in_array($k, $sembunyi, true)) $sembunyi[] = $k;
        }
        writeJson(GAPS_DISMISSED_FILE, array_values($sembunyi));
        jsonOut(['ok' => true, 'hidden_total' => count($sembunyi)]);
        break;
    }

    case 'kb_restore_gaps': {
        // kosongkan daftar sembunyi — untuk meninjau ulang kalau ada salah klik
        requireAuth(['super_admin', 'admin']);
        writeJson(GAPS_DISMISSED_FILE, []);
        jsonOut(['ok' => true]);
        break;
    }

    case 'kb_add_gap': {
        requireAuth(['super_admin', 'admin']);
        $in = bodyInput();
        $q  = trim((string)($in['question'] ?? ''));
        if ($q === '') jsonOut(['ok' => false, 'error' => 'Pertanyaan kosong.'], 400);
        $kb = readJson(KB_FILE, []);
        // isi sengaja DIKOSONGKAN — jawabannya harus ditulis manusia.
        // Entri tanpa isi tidak dikirim ke bot (lihat perbaikan di generateAnswer).
        array_unshift($kb, [
            'id'       => 'kb_' . substr(md5(uniqid('', true)), 0, 8),
            'category' => 'Perlu Diisi',
            'title'    => mb_substr($q, 0, 300),
            'content'  => '',
            'topic'    => '',
        ]);
        writeJson(KB_FILE, $kb);
        jsonOut(['ok' => true, 'count' => count($kb)]);
        break;
    }

    /* ---------- v1.2.23: analisa & gabung duplikat KB ---------- */
    case 'kb_find_duplicates': {
        requireAuth(['super_admin', 'admin']);
        $kb = readJson(KB_FILE, []);
        $grup = [];
        $tanpaIsi = 0;
        foreach ($kb as $e) {
            $isi = trim((string)($e['content'] ?? ''));
            if ($isi === '') { $tanpaIsi++; continue; }
            $k = md5($isi);
            if (!isset($grup[$k])) $grup[$k] = [];
            $grup[$k][] = $e;
        }
        $kelompok = [];
        $bentrok = [];
        foreach ($grup as $anggota) {
            if (count($anggota) < 2) continue;
            // judul terpendek = biasanya bentuk dasar pertanyaan
            $judul = '';
            foreach ($anggota as $a) {
                $t = (string)($a['title'] ?? '');
                if ($judul === '' || mb_strlen($t) < mb_strlen($judul)) $judul = $t;
            }
            $topik = [];
            foreach ($anggota as $a) {
                $tp = trim((string)($a['topic'] ?? ''));
                if ($tp !== '' && !in_array($tp, $topik, true)) $topik[] = $tp;
            }
            if (count($topik) > 1) $bentrok[] = ['title' => $judul, 'topics' => $topik];
            $kelompok[] = ['count' => count($anggota), 'title' => mb_substr($judul, 0, 80)];
        }
        usort($kelompok, function ($a, $b) { return $b['count'] - $a['count']; });
        $unik = count($grup) + $tanpaIsi;
        jsonOut([
            'ok'        => true,
            'total'     => count($kb),
            'unique'    => $unik,
            'removed'   => max(0, count($kb) - $unik),
            'no_content'=> $tanpaIsi,
            'groups'    => array_slice($kelompok, 0, 15),
            'group_count'=> count($kelompok),
            'conflicts' => $bentrok,
        ]);
        break;
    }

    case 'kb_merge_duplicates': {
        requireAuth(['super_admin', 'admin']);
        $kb = readJson(KB_FILE, []);
        if (!is_array($kb) || !$kb) jsonOut(['ok' => false, 'error' => 'Knowledge Base kosong.'], 400);

        // cadangan dulu — penggabungan menghapus entri, harus bisa dipulihkan
        $bak = KB_FILE . '.bak-dedup-' . date('Ymd-His');
        @copy(KB_FILE, $bak);

        $grup = [];
        $tanpaIsi = [];
        foreach ($kb as $e) {
            $isi = trim((string)($e['content'] ?? ''));
            if ($isi === '') { $tanpaIsi[] = $e; continue; }
            $k = md5($isi);
            if (!isset($grup[$k])) $grup[$k] = [];
            $grup[$k][] = $e;
        }

        $hasil = [];
        foreach ($grup as $anggota) {
            $terpilih = $anggota[0];
            foreach ($anggota as $a) {
                if (mb_strlen((string)($a['title'] ?? '')) < mb_strlen((string)($terpilih['title'] ?? ''))) {
                    $terpilih = $a;
                }
            }
            // pertahankan tag topik dari duplikat mana pun yang punya
            $topik = '';
            foreach ($anggota as $a) {
                $tp = trim((string)($a['topic'] ?? ''));
                if ($tp !== '') { $topik = $tp; break; }
            }
            // kategori: dari terpilih, kalau kosong ambil dari duplikat yang terisi
            $kat = trim((string)($terpilih['category'] ?? ''));
            if ($kat === '') {
                foreach ($anggota as $a) {
                    $c = trim((string)($a['category'] ?? ''));
                    if ($c !== '') { $kat = $c; break; }
                }
            }
            $hasil[] = [
                'id'       => (string)($terpilih['id'] ?? ('kb_' . substr(md5(uniqid('', true)), 0, 8))),
                'category' => $kat,
                'title'    => (string)($terpilih['title'] ?? ''),
                'content'  => trim((string)($terpilih['content'] ?? '')),
                'topic'    => $topik,
                'images'   => deiKbFotoClean(array_merge(...array_map(function ($a) { return (array)($a['images'] ?? []); }, $anggota))),   // v1.2.95: kb-foto
            ];
        }
        foreach ($tanpaIsi as $e) $hasil[] = $e;

        if (count($hasil) === 0) {
            jsonOut(['ok' => false, 'error' => 'Hasil kosong — dibatalkan demi keamanan.'], 500);
        }
        writeJson(KB_FILE, $hasil);
        error_log('kb_merge_duplicates: ' . count($kb) . ' -> ' . count($hasil) . ', cadangan: ' . $bak);
        jsonOut(['ok' => true, 'before' => count($kb), 'after' => count($hasil), 'backup' => basename($bak)]);
        break;
    }

    case 'kb_from_text': {
        // v1.2.62: potongan teks dokumen (hasil ekstrak PDF di browser) -> entri KB via AI.
        // Tidak menyimpan apa pun; hasil dikembalikan ke dashboard untuk diperiksa dulu.
        requireAuth(['super_admin', 'admin']);
        @set_time_limit(150);
        $s = getSettings();
        $aiProv = $s['api']['provider'] ?? 'anthropic';
        $aiKeyEmpty = ($aiProv === 'openrouter') ? empty($s['api']['openrouter_api_key']) : empty($s['api']['claude_api_key']);
        if ($aiKeyEmpty) jsonOut(['ok' => false, 'error' => 'API key AI belum dikonfigurasi.'], 400);
        $in = bodyInput();
        $text = trim((string)($in['text'] ?? ''));
        $src  = mb_substr(trim((string)($in['source'] ?? 'Dokumen')), 0, 80);
        if (mb_strlen($text) < 40) jsonOut(['ok' => true, 'entries' => []]);
        $text = mb_substr($text, 0, 12000);

        $sys = "Anda menyusun Knowledge Base untuk chatbot customer service dari potongan dokumen.\n"
             . "Ubah teks menjadi entri-entri KB yang berdiri sendiri.\n\n"
             . "ATURAN:\n"
             . "- title: pertanyaan singkat yang mungkin ditanyakan customer (mis. \"Jam check-in berapa?\").\n"
             . "- content: jawaban lengkap & faktual, HANYA dari teks. Salin angka, harga, jam, alamat, nama persis apa adanya. Jangan mengarang atau menambah info.\n"
             . "- category: 1-3 kata pengelompokan (mis. Fasilitas, Harga, Kebijakan, Lokasi, Layanan).\n"
             . "- Satu topik per entri. Gabungkan info yang berkaitan, jangan pecah terlalu kecil.\n"
             . "- Abaikan daftar isi, header/footer, nomor halaman, dan teks yang tidak berguna bagi customer.\n"
             . "- Gunakan bahasa yang sama dengan dokumen.\n"
             . "- Jika tidak ada info berguna, kembalikan entries kosong.\n\n"
             . "Kembalikan HANYA JSON: {\"entries\":[{\"category\":\"...\",\"title\":\"...\",\"content\":\"...\"}]}";

        $s['api']['max_tokens'] = 4096;
        $s['api']['_timeout']   = 120;
        list($okAi, $answer, $usage) = callClaude($s, $sys, [['role' => 'user', 'content' => "Dokumen: " . $src . "\n\n" . $text]]);
        if (!$okAi) jsonOut(['ok' => false, 'error' => 'AI gagal: ' . $answer], 502);
        recordUsage($usage);

        $raw = trim((string)$answer);
        $a = strpos($raw, '{'); $b = strrpos($raw, '}');
        $data = ($a !== false && $b !== false) ? json_decode(substr($raw, $a, $b - $a + 1), true) : null;
        if (!is_array($data) || !isset($data['entries']) || !is_array($data['entries'])) {
            error_log('kb_from_text: respons bukan JSON: ' . mb_substr($raw, 0, 200));
            jsonOut(['ok' => false, 'error' => 'Jawaban AI tidak terbaca (mungkin terpotong).'], 502);
        }
        $out = [];
        foreach ($data['entries'] as $e) {
            $t = trim((string)($e['title'] ?? '')); $c = trim((string)($e['content'] ?? ''));
            if ($c === '') continue;
            $out[] = ['category' => trim((string)($e['category'] ?? '')), 'title' => $t, 'content' => $c];
        }
        jsonOut(['ok' => true, 'entries' => $out]);
        break;
    }

    /* ---------- v1.2.95: kb-foto: unggah foto entri KB (JPG/PNG, maks 5 MB; dikecilkan di browser) ---------- */
    case 'kb_image_upload': {
        requireAuth(['super_admin','admin']);
        $in = bodyInput();
        if (!preg_match('#^data:image/(jpeg|png);base64,(.+)$#s', (string)($in['data'] ?? ''), $mi)) jsonOut(['ok' => false, 'error' => 'Foto harus JPG atau PNG.'], 400);
        $bin = base64_decode($mi[2], true);
        if ($bin === false || $bin === '') jsonOut(['ok' => false, 'error' => 'Data foto rusak.'], 400);
        if (strlen($bin) > 5 * 1024 * 1024) jsonOut(['ok' => false, 'error' => 'Foto maksimal 5 MB.'], 400);
        $info = @getimagesizefromstring($bin);
        if (!$info || !in_array($info[2], [IMAGETYPE_JPEG, IMAGETYPE_PNG], true)) jsonOut(['ok' => false, 'error' => 'File bukan gambar JPG/PNG yang valid.'], 400);
        if (!is_dir(KB_MEDIA_DIR)) @mkdir(KB_MEDIA_DIR, 0755, true);
        $fn = substr(sha1($bin . microtime(true) . mt_rand()), 0, 20) . ($info[2] === IMAGETYPE_PNG ? '.png' : '.jpg');
        if (@file_put_contents(KB_MEDIA_DIR . '/' . $fn, $bin) === false) jsonOut(['ok' => false, 'error' => 'Gagal menyimpan foto di server.'], 500);
        jsonOut(['ok' => true, 'file' => $fn, 'w' => (int)$info[0], 'h' => (int)$info[1], 'size' => strlen($bin)]);
        break;
    }
    case 'kb_media': {
        requireAuth(['super_admin','admin']);
        $f = (string)($_GET['f'] ?? '');
        if (!preg_match('/^[a-f0-9]{20}\.(jpg|png)$/', $f) || !is_file(KB_MEDIA_DIR . '/' . $f)) { http_response_code(404); header('Content-Type: text/plain'); echo 'not found'; exit; }
        deiWaMediaOutput(KB_MEDIA_DIR . '/' . $f);
        exit;
    }

    case 'save_kb': {
        requireAuth(['super_admin','admin']);
        $in = bodyInput();
        $kb = is_array($in['kb'] ?? null) ? $in['kb'] : [];
        // sanitize entries
        $clean = [];
        foreach ($kb as $e) {
            $clean[] = [
                'id'       => $e['id'] ?? ('kb_' . substr(md5(uniqid('', true)), 0, 8)),
                'category' => trim((string)($e['category'] ?? '')),
                'title'    => trim((string)($e['title'] ?? '')),
                'content'  => trim((string)($e['content'] ?? '')),
                'topic'    => trim((string)($e['topic'] ?? '')),  // v1.2.12 Fase 3: topic tag untuk routing
                'images'   => deiKbFotoClean($e['images'] ?? []),   // v1.2.95: kb-foto
            ];
        }
        writeJson(KB_FILE, $clean);
        try {   // v1.2.95: kb-foto: foto yang tidak dipakai entri mana pun & berumur > 1 hari dihapus
            $refs = [];
            foreach ($clean as $c) { foreach ($c['images'] as $im) $refs[$im['file']] = true; }
            foreach ((array)glob(KB_MEDIA_DIR . '/*') as $f) {
                $b = basename($f);
                if (preg_match('/^[a-f0-9]{20}\.(jpg|png)$/', $b) && !isset($refs[$b]) && time() - (int)@filemtime($f) > 86400) @unlink($f);
            }
        } catch (\Throwable $e) {}
        jsonOut(['ok' => true, 'count' => count($clean)]);
        break;
    }

    /* ---------- logs (admin only) ---------- */
    case 'get_logs': {
        requireAuth(['super_admin', 'admin', 'supervisor']);
        $logs = logReadAll();
        $limit = (int)($_GET['limit'] ?? 200);
        if ($limit > 0) $logs = array_slice($logs, 0, $limit);
        jsonOut(['ok' => true, 'logs' => $logs]);
        break;
    }

    /* ---------- report / stats with UTM aggregation (admin only) ---------- */
    case 'report': {
        requireAuth(['super_admin', 'admin', 'supervisor']);
        $logs = logReadAll();
        $kb = readJson(KB_FILE, []);
        $today = date('Y-m-d');

        $from = isset($_GET['from']) ? substr((string)$_GET['from'], 0, 10) : '';
        $to   = isset($_GET['to'])   ? substr((string)$_GET['to'], 0, 10)   : '';
        $chFilter = $_GET['channel'] ?? 'all';   // all | web | whatsapp

        $todayCount = 0; $ips = []; $total = 0;
        $bySource = []; $byMedium = []; $bySrcMed = []; $byCampaign = []; $byChannel = [];
        $srcU = []; $medU = []; $smU = []; $cmpU = [];
        $daily = [];

        foreach ($logs as $l) {
            if (in_array(($l['dir'] ?? ''), ['manual', 'closing'], true)) continue;          // skip admin manual replies
            $ts = (string)($l['ts'] ?? '');
            $d  = substr($ts, 0, 10);
            if ($from !== '' && $d !== '' && $d < $from) continue;  // date range
            if ($to   !== '' && $d !== '' && $d > $to)   continue;

            $ch = ($l['channel'] ?? '') !== '' ? $l['channel'] : 'web';
            $byChannel[$ch] = ($byChannel[$ch] ?? 0) + 1;           // channel breakdown (pre channel-filter)
            if ($chFilter !== 'all' && $ch !== $chFilter) continue; // channel filter for the rest

            $total++;
            if ($d === $today) $todayCount++;
            $ip = $l['ip'] ?? '';
            if ($ip !== '') $ips[$ip] = true;

            $src = ($l['utm_source'] ?? '') !== '' ? $l['utm_source'] : '(direct)';
            $med = ($l['utm_medium'] ?? '') !== '' ? $l['utm_medium'] : '(none)';
            $cmp = ($l['utm_campaign'] ?? '') !== '' ? $l['utm_campaign'] : '(none)';
            $sm  = $src . ' / ' . $med;

            $bySource[$src]   = ($bySource[$src] ?? 0) + 1;
            $byMedium[$med]   = ($byMedium[$med] ?? 0) + 1;
            $bySrcMed[$sm]    = ($bySrcMed[$sm] ?? 0) + 1;
            $byCampaign[$cmp] = ($byCampaign[$cmp] ?? 0) + 1;
            if ($ip !== '') { $srcU[$src][$ip] = 1; $medU[$med][$ip] = 1; $smU[$sm][$ip] = 1; $cmpU[$cmp][$ip] = 1; }

            if (!isset($daily[$d])) $daily[$d] = ['count' => 0, 'users' => []];
            $daily[$d]['count']++;
            if ($ip !== '') $daily[$d]['users'][$ip] = 1;
        }

        arsort($bySource); arsort($byMedium); arsort($bySrcMed); arsort($byCampaign); arsort($byChannel);

        $fmt = function ($assoc, $users = null) {
            $out = [];
            foreach ($assoc as $k => $v) {
                $row = ['label' => $k, 'count' => $v];
                if ($users !== null) $row['users'] = isset($users[$k]) ? count($users[$k]) : 0;
                $out[] = $row;
            }
            return $out;
        };

        ksort($daily);
        $trend = [];
        foreach ($daily as $d => $o) $trend[] = ['date' => $d, 'count' => $o['count'], 'users' => count($o['users'])];

        jsonOut([
            'ok' => true,
            'range' => ['from' => $from, 'to' => $to, 'channel' => $chFilter],
            'stats' => [
                'total'      => $total,
                'today'      => $todayCount,
                'kb_entries' => count($kb),
                'unique_ips' => count($ips),
            ],
            'by_channel'       => $fmt($byChannel),
            'by_source'        => $fmt($bySource, $srcU),
            'by_medium'        => $fmt($byMedium, $medU),
            'by_source_medium' => $fmt($bySrcMed, $smU),
            'by_campaign'      => $fmt($byCampaign, $cmpU),
            'trend'            => $trend,
        ]);
        break;
    }

    /* ---------- export logs to CSV with date range (admin only) ---------- */
    /* ---------- v1.2.66: log percakapan terstruktur ---------- */
    /* ---------- v1.2.67: Scan Topik Percakapan ---------- */
    case 'topic_scan_get': {
        requireAuth(['super_admin', 'admin', 'supervisor']);
        $all = readJson(TOPIC_SCANS_FILE, []);
        $s = getSettings();
        jsonOut(['ok' => true, 'scans' => is_array($all) ? $all : new stdClass(), 'periods' => deiTopicPeriods(),
                 'log_limit' => (int)($s['api']['log_limit'] ?? 500), 'quota' => deiTopicQuota()]);
        break;
    }

    case 'topic_scan_run': {
        $tpUser = requireAuth(['super_admin', 'admin']);
        @set_time_limit(150);
        $in = bodyInput();
        $days = (int)($in['days'] ?? 30);
        if (!in_array($days, deiTopicPeriods(), true)) jsonOut(['ok' => false, 'error' => 'Periode tidak valid.'], 400);
        $channel = (string)($in['channel'] ?? '');
        if (!in_array($channel, ['', 'web', 'whatsapp'], true)) $channel = '';
        $s = getSettings();
        $aiProv = $s['api']['provider'] ?? 'anthropic';
        if (($aiProv === 'openrouter') ? empty($s['api']['openrouter_api_key']) : empty($s['api']['claude_api_key'])) {
            jsonOut(['ok' => false, 'error' => 'API key AI belum dikonfigurasi (menu Widget & API).'], 400);
        }
        list($units, $meta) = deiTopicUnits($days, $channel);
        $total = count($units);
        $base = ['days' => $days, 'channel' => $channel, 'from' => $meta['from'], 'to' => $meta['to'],
                 'oldest_log' => $meta['oldest'], 'log_entries' => $meta['log_entries'],
                 'scanned_at' => wibDate('Y-m-d H:i:s'), 'total' => $total];
        $base['by_channel'] = ['web' => 0, 'whatsapp' => 0];
        foreach ($units as $u) $base['by_channel'][$u['ch']] = ($base['by_channel'][$u['ch']] ?? 0) + 1;
        if ($total < 3) {
            $res = $base + ['sampled' => $total, 'topics' => [], 'insight' => '', 'empty' => true];
            $all = readJson(TOPIC_SCANS_FILE, []); if (!is_array($all)) $all = [];
            $all[deiTopicKey($days, $channel)] = $res; writeJson(TOPIC_SCANS_FILE, $all);
            jsonOut(['ok' => true, 'scan' => $res, 'quota' => deiTopicQuota()]);
        }
        // v1.2.68: cek kuota sebelum memanggil AI
        $q = deiTopicQuota();
        if ($q['limit'] > 0 && $q['used'] >= $q['limit']) {
            jsonOut(['ok' => false, 'quota' => $q, 'error' => 'Kuota scan topik bulan ini sudah habis (' . $q['used'] . '/' . $q['limit'] . '). Kuota direset ' . $q['reset'] . '. Hubungi ' . deiBrandVendor() . ' untuk menambah kuota.'], 429);
        }
        $sample = deiTopicSample($units, TOPIC_SAMPLE_MAX);
        $list = '';
        foreach ($sample as $i => $u) $list .= $i . '. [' . ($u['ch'] === 'whatsapp' ? 'WA' : 'Web') . '] ' . $u['text'] . "\n";

        $hint = [];
        foreach (readJson(KB_FILE, []) as $e) { $c = trim((string)($e['category'] ?? '')); if ($c !== '') $hint[$c] = true; }
        $bot = trim((string)($s['bot']['persona_company'] ?? '')) ?: trim((string)($s['bot']['bot_name'] ?? ''));
        $sys = "Anda analis customer service. Di bawah ada daftar percakapan pelanggan dengan chatbot"
             . ($bot !== '' ? " \"" . $bot . "\"" : '') . " (hanya pesan pelanggan, digabung dengan \" / \").\n"
             . "Kelompokkan SEMUA percakapan ke dalam 4-10 topik utama berdasarkan maksud/kebutuhan pelanggan.\n\n"
             . "ATURAN:\n"
             . "- name: nama topik 2-5 kata, spesifik (mis. \"Harga & paket kamar\", \"Jadwal & rute bus\"), bukan generik seperti \"Pertanyaan umum\".\n"
             . "- Sapaan/basa-basi tanpa maksud jelas masuk topik \"Sapaan & basa-basi\". Yang tidak cocok mana pun masuk \"Lainnya\".\n"
             . "- ids: nomor percakapan yang termasuk topik itu. Setiap nomor tepat di SATU topik.\n"
             . "- summary: 1 kalimat apa yang paling sering ditanyakan.\n"
             . "- sentiment: positif | netral | negatif (nada umum pelanggan di topik itu).\n"
             . "- action: 1 kalimat saran konkret untuk bisnis/admin (mis. tambah info X ke Knowledge Base, buat promo, perbaiki proses).\n"
             . "- examples: 2-3 nomor percakapan yang paling mewakili.\n"
             . "- insight: 2-3 kalimat kesimpulan keseluruhan periode ini.\n"
             . ($hint ? "- Bila cocok, pakai istilah kategori bisnis ini: " . implode(', ', array_slice(array_keys($hint), 0, 20)) . ".\n" : '')
             . "- Tulis dalam Bahasa Indonesia.\n\n"
             . "Kembalikan HANYA JSON: {\"topics\":[{\"name\":\"\",\"summary\":\"\",\"sentiment\":\"\",\"action\":\"\",\"ids\":[0,1],\"examples\":[0]}],\"insight\":\"\"}";

        $s['api']['max_tokens'] = 4096;
        $s['api']['_timeout']   = 120;
        list($okAi, $answer, $usage) = callClaude($s, $sys, [['role' => 'user', 'content' => "Periode: " . $meta['from'] . " s/d " . $meta['to'] . "\n\n" . $list]]);
        if (!$okAi) jsonOut(['ok' => false, 'error' => 'AI gagal: ' . $answer], 502);
        recordUsage($usage);
        deiTopicQuotaUse((string)($tpUser['username'] ?? ''), $days, $channel, $usage);   // v1.2.68: dihitung walau jawaban tak terbaca (token tetap terpakai)
        $raw = trim((string)$answer);
        $a = strpos($raw, '{'); $b = strrpos($raw, '}');
        $data = ($a !== false && $b !== false) ? json_decode(substr($raw, $a, $b - $a + 1), true) : null;
        if (!is_array($data) || !is_array($data['topics'] ?? null)) {
            error_log('topic_scan_run: respons bukan JSON: ' . mb_substr($raw, 0, 200));
            jsonOut(['ok' => false, 'error' => 'Jawaban AI tidak terbaca (mungkin terpotong). Coba periode lebih pendek.'], 502);
        }
        $n = count($sample);
        $used = [];
        $topics = [];
        foreach ($data['topics'] as $t) {
            if (!is_array($t)) continue;
            $name = mb_substr(trim((string)($t['name'] ?? '')), 0, 60);
            if ($name === '') continue;
            $ids = [];
            foreach ((array)($t['ids'] ?? []) as $id) { $id = (int)$id; if ($id >= 0 && $id < $n && !isset($used[$id])) { $ids[] = $id; $used[$id] = true; } }
            if (!$ids) continue;
            $ch = ['web' => 0, 'whatsapp' => 0];
            foreach ($ids as $id) $ch[$sample[$id]['ch']]++;
            $ex = [];
            foreach (array_merge((array)($t['examples'] ?? []), $ids) as $id) {
                $id = (int)$id;
                if (!in_array($id, $ids, true) || isset($ex[$id])) continue;
                $ex[$id] = ['text' => mb_substr($sample[$id]['text'], 0, 200), 'ch' => $sample[$id]['ch'], 'day' => $sample[$id]['day']];
                if (count($ex) >= 3) break;
            }
            $sent = in_array(($t['sentiment'] ?? ''), ['positif', 'netral', 'negatif'], true) ? $t['sentiment'] : 'netral';
            $topics[] = [
                'name' => $name,
                'summary' => mb_substr(trim((string)($t['summary'] ?? '')), 0, 300),
                'action'  => mb_substr(trim((string)($t['action'] ?? '')), 0, 300),
                'sentiment' => $sent,
                'count' => count($ids),
                'pct' => round(count($ids) * 100 / $n, 1),
                'est' => (int)round(count($ids) * $total / $n),
                'by_channel' => $ch,
                'examples' => array_values($ex),
            ];
        }
        $rest = $n - count($used);
        if ($rest > 0) {
            $found = false;
            foreach ($topics as &$t) {
                if (mb_strtolower($t['name']) === 'lainnya') { $t['count'] += $rest; $found = true; }
            }
            unset($t);
            if (!$found) $topics[] = ['name' => 'Lainnya', 'summary' => 'Percakapan yang tidak masuk topik mana pun.', 'action' => '', 'sentiment' => 'netral',
                                      'count' => $rest, 'pct' => 0, 'est' => 0, 'by_channel' => ['web' => 0, 'whatsapp' => 0], 'examples' => [], 'unassigned' => true];
            foreach ($topics as &$t) { $t['pct'] = round($t['count'] * 100 / $n, 1); $t['est'] = (int)round($t['count'] * $total / $n); }
            unset($t);
        }
        usort($topics, function ($x, $y) {
            $lx = in_array(mb_strtolower($x['name']), ['lainnya'], true) ? 1 : 0; $ly = in_array(mb_strtolower($y['name']), ['lainnya'], true) ? 1 : 0;
            return $lx !== $ly ? $lx - $ly : $y['count'] - $x['count'];
        });
        $res = $base + ['sampled' => $n, 'topics' => $topics, 'insight' => mb_substr(trim((string)($data['insight'] ?? '')), 0, 800)];
        $all = readJson(TOPIC_SCANS_FILE, []); if (!is_array($all)) $all = [];
        $all[deiTopicKey($days, $channel)] = $res;
        writeJson(TOPIC_SCANS_FILE, $all);
        jsonOut(['ok' => true, 'scan' => $res, 'quota' => deiTopicQuota()]);
        break;
    }

    case 'logs_query': {
        requireAuth(['super_admin', 'admin', 'supervisor']);
        $f = deiLogParams($_GET);
        $per  = (int)($_GET['per'] ?? 25);
        if (!in_array($per, [25, 50, 100], true)) $per = 25;
        $page = max(1, (int)($_GET['page'] ?? 1));
        $logs = deiLogWithNames(logReadAll());
        usort($logs, function ($a, $b) { return strcmp((string)($b['ts'] ?? ''), (string)($a['ts'] ?? '')); });

        $rows = [];
        $fac = ['channel' => [], 'source' => [], 'medium' => [], 'campaign' => [], 'status' => []];
        foreach ($logs as $e) {
            if (deiLogMatch($e, $f)) $rows[] = $e;
            foreach ($fac as $dim => $_) {
                if (!deiLogMatch($e, $f, $dim)) continue;
                $v = $dim === 'channel' ? ($e['channel'] ?? 'web') : ($dim === 'status' ? deiLogStatus($e) : deiLogDim($e, $dim));
                $fac[$dim][$v] = ($fac[$dim][$v] ?? 0) + 1;
            }
        }
        $facets = [];
        foreach ($fac as $dim => $m) {
            arsort($m);
            $facets[$dim] = [];
            foreach (array_slice($m, 0, 200, true) as $v => $n) $facets[$dim][] = ['value' => (string)$v, 'count' => $n];
        }
        $total = count($rows);
        $pages = max(1, (int)ceil($total / $per));
        if ($page > $pages) $page = $pages;
        $out = [];
        foreach (array_slice($rows, ($page - 1) * $per, $per) as $e) {
            $out[] = [
                'ts'       => (string)($e['ts'] ?? ''),
                'channel'  => (string)($e['channel'] ?? 'web'),
                'status'   => deiLogStatus($e),
                'q'        => mb_substr((string)($e['q'] ?? ''), 0, 4000),
                'a'        => mb_substr((string)($e['a'] ?? ''), 0, 6000),
                'call_txt' => wcLabel($e),   // v1.2.108: tolak-telepon
                'who'      => (string)($e['ip'] ?? ''),
                'name'     => (string)($e['_name'] ?? ''),
                'source'   => deiLogDim($e, 'source'),
                'medium'   => deiLogDim($e, 'medium'),
                'campaign' => deiLogDim($e, 'campaign'),
                'page'     => (string)($e['page'] ?? ''),
                'referrer' => (string)($e['referrer'] ?? ''),
            ];
        }
        $first = $logs ? substr((string)end($logs)['ts'], 0, 10) : '';
        jsonOut(['ok' => true, 'rows' => $out, 'total' => $total, 'page' => $page, 'pages' => $pages, 'per' => $per,
                 'facets' => $facets, 'filters' => $f, 'oldest' => $first, 'all_total' => count($logs)]);
        break;
    }

    case 'export_logs': {
        requireAuth(['super_admin', 'admin', 'supervisor']);
        // v1.2.66: filter sama dengan logs_query (channel/source/medium/campaign/status/cari)
        $f = deiLogParams($_GET);
        $from = $f['from']; $to = $f['to'];
        $logs = deiLogWithNames(logReadAll());

        $rows = [];
        foreach ($logs as $l) {
            if (deiLogMatch($l, $f)) $rows[] = $l;
        }

        $fname = 'chatbot-log';
        if ($from || $to) $fname .= '_' . ($from ?: 'awal') . '_to_' . ($to ?: 'akhir');
        $fname .= '.csv';

        header('Content-Type: text/csv; charset=utf-8');
        header('Content-Disposition: attachment; filename="' . $fname . '"');
        $out = fopen('php://output', 'w');
        // UTF-8 BOM so Excel reads Indonesian characters correctly
        fwrite($out, "\xEF\xBB\xBF");
        fputcsv($out, ['Waktu', 'Channel', 'Pertanyaan', 'Jawaban AI', 'Pengirim/IP', 'UTM Source', 'UTM Medium', 'UTM Campaign', 'Halaman', 'Referrer', 'Nama', 'Status']);
        foreach ($rows as $l) {
            fputcsv($out, [
                $l['ts'] ?? '',
                $l['channel'] ?? 'web',
                $l['q'] ?? '',
                $l['a'] ?? '',
                $l['ip'] ?? '',
                $l['utm_source'] ?? '',
                $l['utm_medium'] ?? '',
                $l['utm_campaign'] ?? '',
                $l['page'] ?? '',
                $l['referrer'] ?? '',
                $l['_name'] ?? '',
                deiLogStatusLabel(deiLogStatus($l)),
            ]);
        }
        fclose($out);
        exit;
    }

    /* ---------- user management (admin only) ---------- */
    /* ============================================================
     * v1.2.8: push subscription endpoints (Web Push + PWA)
     * ============================================================ */
    case 'get_push_config': {
        // Semua user authenticated boleh ambil VAPID public key
        requireAuth(['super_admin', 'admin', 'wa_agent']);
        $vapidFile = DATA_DIR . '/vapid-keys.json';
        if (!file_exists($vapidFile)) {
            jsonOut(['ok' => false, 'error' => 'VAPID keys belum di-setup.'], 500);
        }
        $vapid = json_decode(file_get_contents($vapidFile), true);
        jsonOut(['ok' => true, 'publicKey' => $vapid['publicKey'] ?? '']);
        break;
    }

    case 'save_push_subscription': {
        $me = requireAuth(['super_admin', 'admin', 'wa_agent']);
        $in = bodyInput();
        $sub = $in['subscription'] ?? null;
        if (!$sub || empty($sub['endpoint'])) {
            jsonOut(['ok' => false, 'error' => 'Subscription tidak valid.'], 400);
        }
        $ua = substr((string)($in['ua'] ?? ''), 0, 120);
        $subsFile = DATA_DIR . '/push-subs.json';
        $all = file_exists($subsFile) ? (json_decode(file_get_contents($subsFile), true) ?: []) : [];
        $username = $me['username'];
        if (!isset($all[$username]) || !is_array($all[$username])) $all[$username] = [];
        // Dedup: hapus subscription lama dengan endpoint sama
        $all[$username] = array_values(array_filter($all[$username], function ($s) use ($sub) {
            return ($s['endpoint'] ?? '') !== $sub['endpoint'];
        }));
        $all[$username][] = [
            'endpoint' => $sub['endpoint'],
            'keys'     => $sub['keys'] ?? [],
            'added'    => date('Y-m-d H:i:s'),
            'ua'       => $ua,
        ];
        writeJson($subsFile, $all);
        jsonOut(['ok' => true]);
        break;
    }

    case 'delete_push_subscription': {
        $me = requireAuth(['super_admin', 'admin', 'wa_agent']);
        $in = bodyInput();
        $endpoint = (string)($in['endpoint'] ?? '');
        $subsFile = DATA_DIR . '/push-subs.json';
        $all = file_exists($subsFile) ? (json_decode(file_get_contents($subsFile), true) ?: []) : [];
        $username = $me['username'];
        if (isset($all[$username]) && is_array($all[$username])) {
            if ($endpoint !== '') {
                $all[$username] = array_values(array_filter($all[$username], function ($s) use ($endpoint) {
                    return ($s['endpoint'] ?? '') !== $endpoint;
                }));
            } else {
                $all[$username] = [];  // hapus semua kalau endpoint kosong
            }
            writeJson($subsFile, $all);
        }
        jsonOut(['ok' => true]);
        break;
    }
    // === /v1.2.8 push subscription ===

    case 'refresh_seats': {
        // v1.2.60: tarik ulang batas kursi dari pusat sekarang (tanpa tunggu cache 24 jam)
        requireAuth(['super_admin', 'admin', 'supervisor']);
        $sR = getSettings();
        $cap = getCapStatus($sR, true);
        unset($GLOBALS['dei_features_cache']);
        $users = readJson(USERS_FILE, []);
        $src = $cap['source'] ?? '';
        jsonOut(['ok' => true, 'seats' => deiSeatInfo($users),
                 'note' => $src === 'no-central' ? 'Server Pusat belum diisi di Widget & API.' : ($src === 'refreshed' ? '' : 'Server pusat tidak bisa dihubungi (' . $src . ').')]);
        break;
    }

    case 'get_users': {
        // v1.2.14: admin ikut boleh (kelola wa_agent). Data aman: tanpa password/hash.
        // Pembatasan tetap di save_user/delete_user (admin cuma boleh target wa_agent).
        $meU = requireAuth(['super_admin', 'admin', 'supervisor']);
        $users = readJson(USERS_FILE, []);
        $safe = array_map(function ($u) {
            return [
                'username'   => $u['username'] ?? '',
                'name'       => $u['name'] ?? '',
                'role'       => $u['role'] ?? 'editor',
                'categories' => $u['categories'] ?? [],  // v1.2.12 Fase 2: categories
            ];
        }, $users);
        // v1.2.58: kursi paket + status terkunci per akun
        foreach ($safe as $i => $su) {
            $safe[$i]['seat_locked'] = !deiSeatAllowed($su['username'], $su['role'], $users);
            $safe[$i]['supervisor'] = ($su['role'] === 'wa_agent') ? deiAgentSpv($users[$i], $users) : '';   // v1.2.59
        }
        // v1.2.59: supervisor hanya melihat dirinya + agent timnya (+ agent tanpa supervisor)
        $llLastMap = deiLoginLastMap();   // v1.2.112
        foreach ($safe as $i => $su) { $safe[$i]['last_login'] = $llLastMap[$su['username']]['ts'] ?? ''; }
        $scU = deiSpvScope($meU, $users);
        if ($scU !== null) $safe = array_values(array_filter($safe, function ($x) use ($scU) { return isset($scU[$x['username']]); }));
        // v1.2.90: akun internal DEI (Super Admin via pusat) tidak tampil untuk Admin/Supervisor
        if (($meU['role'] ?? '') !== 'super_admin') { $intl = []; foreach ($users as $x) if (!empty($x['internal'])) $intl[$x['username'] ?? ''] = 1;
            $safe = array_values(array_filter($safe, function ($x) use ($intl) { return !isset($intl[$x['username']]); })); }
        jsonOut(['ok' => true, 'users' => $safe, 'seats' => deiSeatInfo($users)]);
        break;
    }

    case 'save_user': {
        $me = requireAuth(['super_admin', 'admin', 'supervisor']);
        $in = bodyInput();
        $username = trim($in['username'] ?? '');
        $name     = trim($in['name'] ?? $username);
        $roleIn   = (string)($in['role'] ?? 'admin');
        $role     = in_array($roleIn, ['super_admin', 'admin', 'supervisor', 'wa_agent'], true) ? $roleIn : 'admin';   // v1.2.58
        $password = (string)($in['password'] ?? '');
        // v1.2.12 Fase 2: categories (multi-select untuk routing push by topic)
        $categories = [];
        if (isset($in['categories']) && is_array($in['categories'])) {
            foreach ($in['categories'] as $c) {
                $c = trim((string)$c);
                if ($c !== '') $categories[] = $c;
            }
            $categories = array_values(array_unique($categories));
        }
        if ($username === '') jsonOut(['ok' => false, 'error' => 'Username wajib diisi.'], 400);

        // === v1.2.6: admin restriction — cuma boleh manage wa_agent ===
        // v1.2.58: supervisor diperlakukan sama (kelola akun agent saja)
        // v1.2.61: Admin boleh kelola WA Agent + Supervisor; Supervisor hanya WA Agent
        if ($me['role'] === 'admin' || $me['role'] === 'supervisor') {
            $bolehPeran = ($me['role'] === 'admin') ? ['wa_agent', 'supervisor'] : ['wa_agent'];
            if (!in_array($role, $bolehPeran, true)) {
                jsonOut(['ok' => false, 'error' => ($me['role'] === 'supervisor'
                    ? 'Supervisor hanya dapat mengelola user dengan peran WA Agent.'
                    : 'Admin hanya dapat mengelola user dengan peran WA Agent atau Supervisor.')], 403);
            }
            if ($username === $me['username']) jsonOut(['ok' => false, 'error' => 'Akun Anda sendiri tidak bisa diubah di sini — gunakan menu Profil Saya.'], 403);
            $chkUsers = readJson(USERS_FILE, []);
            foreach ($chkUsers as $chkU) {
                if (($chkU['username'] ?? '') === $username && !in_array(($chkU['role'] ?? ''), $bolehPeran, true)) {
                    jsonOut(['ok' => false, 'error' => 'Username "' . $username . '" sudah dipakai akun dengan peran lebih tinggi.'], 403);
                }
            }
        }
        // === /v1.2.6 ===
        // Enforce password strength only when a new password is being set.
        if ($password !== '') {
            $weak = checkPasswordStrength($password);
            if ($weak) jsonOut(['ok' => false, 'error' => $weak], 400);
        }

        $users = readJson(USERS_FILE, []);
        // v1.2.59: supervisor atasan (khusus WA Agent). null = pertahankan nilai lama.
        $spvSet = null;
        if ($role === 'wa_agent') {
            if ($me['role'] === 'supervisor') {
                foreach ($users as $su) {
                    if (($su['username'] ?? '') !== $username || ($su['role'] ?? '') !== 'wa_agent') continue;
                    $curSpv = deiAgentSpv($su, $users);
                    if ($curSpv !== '' && $curSpv !== $me['username']) jsonOut(['ok' => false, 'error' => 'Agent ini berada di tim supervisor ' . $curSpv . '.'], 403);
                }
                $spvSet = $me['username'];   // agent yang dibuat/diedit supervisor masuk timnya
            } elseif (array_key_exists('supervisor', $in)) {
                $spvSet = trim((string)$in['supervisor']);
                if ($spvSet !== '') {
                    $okSpv = false;
                    foreach ($users as $su) { if (($su['username'] ?? '') === $spvSet && ($su['role'] ?? '') === 'supervisor') { $okSpv = true; break; } }
                    if (!$okSpv) jsonOut(['ok' => false, 'error' => 'Supervisor "' . $spvSet . '" tidak ditemukan.'], 400);
                }
            }
        }
        // v1.2.58: batas kursi paket (agent & supervisor). Dihitung tanpa akun
        // yang sedang diedit, jadi mengedit akun yang sudah ada tetap boleh.
        if ($role === 'wa_agent' || $role === 'supervisor') {
            $fSeat = deiFeatures();
            $maxSeat = ($role === 'wa_agent') ? (int)$fSeat['max_agents'] : (int)$fSeat['max_supervisors'];
            if ($maxSeat > 0) {
                $pakai = 0; $sudahPeran = false;
                foreach ($users as $su) {
                    if (($su['role'] ?? '') !== $role) continue;
                    if (($su['username'] ?? '') === $username) { $sudahPeran = true; continue; }
                    $pakai++;
                }
                if (!$sudahPeran && $pakai >= $maxSeat) jsonOut(['ok' => false, 'error' => deiSeatMsg($role, $fSeat)], 400);
            }
        }
        $found = false;
        foreach ($users as $i => $u) {
            if (($u['username'] ?? '') === $username) {
                $users[$i]['name'] = $name;
                $users[$i]['role'] = $role;
                $users[$i]['categories'] = $categories;  // v1.2.12 Fase 2
                if ($role !== 'wa_agent') unset($users[$i]['supervisor']);            // v1.2.59
                elseif ($spvSet !== null) $users[$i]['supervisor'] = $spvSet;
                if ($password !== '') $users[$i]['password'] = password_hash($password, PASSWORD_DEFAULT);
                $found = true;
                break;
            }
        }
        if (!$found) {
            if ($password === '') jsonOut(['ok' => false, 'error' => 'Password wajib diisi untuk user baru.'], 400);
            $users[] = [
                'username' => $username,
                'password' => password_hash($password, PASSWORD_DEFAULT),
                'role'     => $role,
                'name'     => $name,
                'categories' => $categories,
                'migrated_3role' => true,
            ];
            if ($role === 'wa_agent' && $spvSet !== null && $spvSet !== '') $users[count($users) - 1]['supervisor'] = $spvSet;   // v1.2.59
        }
        writeJson(USERS_FILE, $users);
        jsonOut(['ok' => true]);
        break;
    }

    case 'delete_user': {
        $me = requireAuth(['super_admin', 'admin', 'supervisor']);
        $in = bodyInput();
        $username = trim($in['username'] ?? '');
        if ($username === $me['username']) jsonOut(['ok' => false, 'error' => 'Tidak dapat menghapus akun Anda sendiri.'], 400);
        // === v1.2.6: admin restriction — cuma boleh delete wa_agent ===
        if ($me['role'] === 'admin' || $me['role'] === 'supervisor') {   // v1.2.58
            $delUsers = readJson(USERS_FILE, []);
            $delTargetRole = '';
            foreach ($delUsers as $du) {
                if (($du['username'] ?? '') === $username) { $delTargetRole = $du['role'] ?? ''; break; }
            }
            $bolehHapus = ($me['role'] === 'admin') ? ['wa_agent', 'supervisor'] : ['wa_agent'];   // v1.2.61
            if (!in_array($delTargetRole, $bolehHapus, true)) {
                jsonOut(['ok' => false, 'error' => ($me['role'] === 'admin'
                    ? 'Admin hanya dapat menghapus user dengan peran WA Agent atau Supervisor.'
                    : 'Supervisor hanya dapat menghapus user dengan peran WA Agent.')], 403);
            }
        }
        // === /v1.2.6 ===
        $users = readJson(USERS_FILE, []);
        $scDel = deiSpvScope($me, $users);   // v1.2.59
        if ($scDel !== null && !isset($scDel[$username])) jsonOut(['ok' => false, 'error' => 'Agent ini berada di luar tim Anda.'], 403);
        $remaining = array_values(array_filter($users, function ($u) use ($username) {
            return ($u['username'] ?? '') !== $username;
        }));
        $admins = array_filter($remaining, function ($u) { return ($u['role'] ?? '') === 'super_admin'; });
        if (count($admins) === 0) jsonOut(['ok' => false, 'error' => 'Minimal harus ada satu Super Admin.'], 400);
        writeJson(USERS_FILE, $remaining);
        jsonOut(['ok' => true]);
        break;
    }

    case 'update_own_password': {
        // v1.2.2: user self-service password change (semua role)
        $u = requireAuth(['super_admin', 'admin', 'wa_agent']);
        $in = bodyInput();
        $currentPw = (string)($in['current_password'] ?? '');
        $newPw     = (string)($in['new_password']     ?? '');

        if ($currentPw === '' || $newPw === '') {
            jsonOut(['ok' => false, 'error' => 'Password lama & baru wajib diisi.'], 400);
        }
        if ($currentPw === $newPw) {
            jsonOut(['ok' => false, 'error' => 'Password baru tidak boleh sama dengan yang lama.'], 400);
        }

        $weak = checkPasswordStrength($newPw);
        if ($weak) jsonOut(['ok' => false, 'error' => $weak], 400);

        $users = readJson(USERS_FILE, []);
        $found = false;
        foreach ($users as $i => $usr) {
            if (($usr['username'] ?? '') === $u['username']) {
                if (!password_verify($currentPw, $usr['password'] ?? '')) {
                    jsonOut(['ok' => false, 'error' => 'Password lama salah.'], 400);
                }
                // Update password ONLY — jangan touch role/name/username (prevent privilege escalation)
                $users[$i]['password'] = password_hash($newPw, PASSWORD_DEFAULT);
                $found = true;
                break;
            }
        }
        if (!$found) jsonOut(['ok' => false, 'error' => 'User tidak ditemukan.'], 404);

        writeJson(USERS_FILE, $users);
        jsonOut(['ok' => true, 'message' => 'Password berhasil diganti. Silakan login ulang.']);
        break;
    }

    /* ============================================================
     * Central Server — auto-update (super_admin only)
     * ============================================================ */

    case 'usage_summary': {
        requireAuth(['super_admin', 'admin', 'supervisor']);
        $all = readJson(DATA_DIR . '/usage.json', []);
        ksort($all);
        // last 30 days
        $cut = date('Y-m-d', strtotime('-29 days'));
        $rows = [];
        $sum = ['calls' => 0, 'input' => 0, 'output' => 0, 'cache_write' => 0, 'cache_read' => 0];
        foreach ($all as $day => $d) {
            if ($day < $cut) continue;
            $rows[] = ['date' => $day] + $d;
            foreach (['calls','input','output','cache_write','cache_read'] as $k) $sum[$k] += $d[$k] ?? 0;
        }
        $cost30 = round(
            ($sum['input']/1e6 * 1.00) +
            ($sum['output']/1e6 * 5.00) +
            ($sum['cache_write']/1e6 * 1.25) +
            ($sum['cache_read']/1e6 * 0.10),
        4);
        // Estimated cost WITHOUT caching (counter-factual: all cache_read + cache_write would be normal input)
        $cost30_no_cache = round(
            (($sum['input'] + $sum['cache_write'] + $sum['cache_read'])/1e6 * 1.00) +
            ($sum['output']/1e6 * 5.00),
        4);
        $saved = round($cost30_no_cache - $cost30, 4);
        $saved_pct = $cost30_no_cache > 0 ? round($saved / $cost30_no_cache * 100, 1) : 0;
        jsonOut([
            'ok' => true,
            'daily' => $rows,
            'summary_30d' => [
                'calls'           => $sum['calls'],
                'tokens_input'    => $sum['input'],
                'tokens_output'   => $sum['output'],
                'cache_write'     => $sum['cache_write'],
                'cache_read'      => $sum['cache_read'],
                'cost_usd'        => $cost30,
                'cost_no_cache'   => $cost30_no_cache,
                'saved_by_cache'  => $saved,
                'saved_pct'       => $saved_pct,
            ],
        ]);
        break;
    }

    case 'upload_avatar': {
        // v1.1.6: server-side avatar validate + save.
        // Client already resized to 96×96 PNG via Canvas, but we re-validate
        // (1) MIME type from magic bytes (2) max raw size 1 MB after client resize
        // (3) re-encode with GD as 96×96 PNG to strip any payload (4) save to data/uploads/
        requireAuth(['super_admin', 'admin']);
        if (empty($_FILES['avatar']['tmp_name'])) {
            jsonOut(['ok' => false, 'error' => 'Tidak ada file diupload.'], 400);
        }
        $tmp = $_FILES['avatar']['tmp_name'];
        $size = (int)$_FILES['avatar']['size'];
        if ($size <= 0 || $size > 1024 * 1024) {  // 1 MB cap after client resize (much smaller than 2 MB raw)
            jsonOut(['ok' => false, 'error' => 'Ukuran file tidak valid (maks 1 MB setelah resize).'], 400);
        }

        // Detect MIME from magic bytes
        $finfo = function_exists('finfo_open') ? finfo_open(FILEINFO_MIME_TYPE) : null;
        $mime = $finfo ? finfo_file($finfo, $tmp) : mime_content_type($tmp);
        if ($finfo) finfo_close($finfo);
        if (!in_array($mime, ['image/png', 'image/jpeg', 'image/webp'], true)) {
            jsonOut(['ok' => false, 'error' => 'Format harus PNG, JPG, atau WEBP. Terdeteksi: ' . $mime], 400);
        }

        if (!function_exists('imagecreatetruecolor')) {
            jsonOut(['ok' => false, 'error' => 'GD library tidak tersedia di server.'], 500);
        }

        // Load source image
        $src = null;
        switch ($mime) {
            case 'image/png':  $src = @imagecreatefrompng($tmp); break;
            case 'image/jpeg': $src = @imagecreatefromjpeg($tmp); break;
            case 'image/webp': $src = function_exists('imagecreatefromwebp') ? @imagecreatefromwebp($tmp) : null; break;
        }
        if (!$src) jsonOut(['ok' => false, 'error' => 'Gagal membaca gambar.'], 400);

        $sw = imagesx($src); $sh = imagesy($src);
        if ($sw <= 0 || $sh <= 0 || $sw > 4096 || $sh > 4096) {
            imagedestroy($src);
            jsonOut(['ok' => false, 'error' => 'Dimensi gambar tidak valid.'], 400);
        }

        // Resize/crop to 96×96 (center crop)
        $cropSize = min($sw, $sh);
        $cropX = (int)(($sw - $cropSize) / 2);
        $cropY = (int)(($sh - $cropSize) / 2);
        $dst = imagecreatetruecolor(96, 96);
        imagesavealpha($dst, true);
        $transparent = imagecolorallocatealpha($dst, 0, 0, 0, 127);
        imagefill($dst, 0, 0, $transparent);
        imagecopyresampled($dst, $src, 0, 0, $cropX, $cropY, 96, 96, $cropSize, $cropSize);
        imagedestroy($src);

        // Ensure uploads dir exists
        $uploadsDir = DATA_DIR . '/uploads';
        if (!is_dir($uploadsDir)) @mkdir($uploadsDir, 0755, true);
        if (!is_dir($uploadsDir) || !is_writable($uploadsDir)) {
            imagedestroy($dst);
            jsonOut(['ok' => false, 'error' => 'Folder uploads tidak bisa ditulis (' . $uploadsDir . ').'], 500);
        }

        // Filename: avatar-<timestamp>.png (collision-safe + cache-busting)
        $fname = 'avatar-' . time() . '.png';
        $fpath = $uploadsDir . '/' . $fname;
        $ok = imagepng($dst, $fpath, 6);
        imagedestroy($dst);
        if (!$ok || !file_exists($fpath)) {
            jsonOut(['ok' => false, 'error' => 'Gagal menulis file.'], 500);
        }
        @chmod($fpath, 0644);

        // Delete previous avatar files (keep only latest)
        foreach (glob($uploadsDir . '/avatar-*.png') as $old) {
            if ($old !== $fpath) @unlink($old);
        }

        // Public URL (relative from dashboard's parent dir)
        $url = 'data/uploads/' . $fname;
        jsonOut(['ok' => true, 'url' => $url, 'size' => filesize($fpath)]);
        break;
    }

    case 'license_status': {
        requireAuth(['super_admin', 'admin', 'supervisor']);
        $s = getSettings();
        $lic = getLicenseStatus($s);
        jsonOut(['ok' => true, 'license' => $lic]);
        break;
    }

    case 'cap_status': {
        // Available to all roles (super_admin, admin, wa_agent) for banner
        requireAuth(['super_admin', 'admin', 'wa_agent']);
        $s = getSettings();
        $cap = getCapStatus($s);
        jsonOut(['ok' => true, 'cap' => $cap]);
        break;
    }

    case 'usage_dashboard': {
        // v1.1.5: combined endpoint for the Usage card in Reports tab
        // Returns: tier/status/cap + this-month stats + 30-day daily breakdown
        requireAuth(['super_admin', 'admin', 'wa_agent']);
        $s = getSettings();
        $cap = getCapStatus($s);
        $lic = getLicenseStatus($s);

        // 30-day daily breakdown from usage.json
        $usage = readJson(DATA_DIR . '/usage.json', []);
        ksort($usage);
        $daily = [];
        $cutoff = wibDate('Y-m-d', time() - 29 * 86400);
        foreach ($usage as $day => $d) {
            if ($day < $cutoff) continue;
            $daily[] = ['date' => $day, 'calls' => (int)($d['calls'] ?? 0)];
        }

        // Days remaining until next reset (1st of next month, WIB)
        $todayW = wibToday();
        list($curY, $curM) = explode('-', $todayW);
        $nextResetTs = mktime(0, 0, 0, (int)$curM + 1, 1, (int)$curY) - 7 * 3600;   // 1st of next month 00:00 WIB
        $daysLeftMonth = (int)ceil(($nextResetTs - time()) / 86400);

        // Month stats (same calc as in computeMonthStats but expose more fields)
        $monthKey = wibDate('Y-m');
        $mIn = 0; $mOut = 0; $mCW = 0; $mCR = 0; $mCalls = 0; $mCost = 0.0;
        foreach ($usage as $day => $d) {
            if (strpos($day, $monthKey) !== 0) continue;
            $mCalls += (int)($d['calls'] ?? 0);
            $mIn    += (int)($d['input'] ?? 0);
            $mOut   += (int)($d['output'] ?? 0);
            $mCW    += (int)($d['cache_write'] ?? 0);
            $mCR    += (int)($d['cache_read'] ?? 0);
            $mCost  += deiDayCost($d);   // v1.2.69
        }
        $costUsd = round($mCost, 5);

        jsonOut([
            'ok' => true,
            'tier'           => $cap['tier'] ?? 'starter',
            'license_status' => $lic['status'] ?? 'active',
            'expires_at'     => $lic['expires_at'] ?? '',
            'chats_used'     => $mCalls,   // v1.2.57: hitungan langsung (cache cap bisa basi s/d 24 jam)
            'wa_out'         => (function () { $s0 = getSettings(); $w = waConf($s0); $o = waOutMonth();
                                    return ['enabled' => !empty($w['enabled']), 'provider' => $w['provider'] ?? 'meta',
                                            'service' => $o['service'], 'template' => $o['template'], 'saved' => $o['saved'],   // v1.2.89
                                            'by_ch' => (function () use ($s0, $w, $o) {   // v1.2.98: multi-nomor
                                                if (!waMultiOn($w, $s0)) return [];
                                                $r = [];
                                                foreach (waChannels($s0) as $c) $r[] = ['id' => $c['id'], 'label' => $c['label'],
                                                    'service' => (int)($o['ch'][$c['id']]['service'] ?? 0), 'template' => (int)($o['ch'][$c['id']]['template'] ?? 0)];
                                                return $r; })(),
                                            'free_quota' => WA_FREE_SERVICE_QUOTA]; })(),
            'chat_cap'       => $cap['cap'] ?? 0,
            'usage_pct'      => $cap['pct'] ?? 0,
            'cap_reached'    => !empty($cap['reached']),
            'cap_warning'    => !empty($cap['warning']),
            'trial'          => $cap['trial'] ?? null,   // v1.2.90
            'days_left_month'=> $daysLeftMonth,
            'cost_this_month_usd' => $costUsd,
            'daily_30d'      => $daily,
            'month_key'      => $monthKey,
            'today_wib'      => $todayW,
        ]);
        break;
    }

    case 'update_status': {
        requireAuth(['super_admin']);
        $s = getSettings();
        $cs = $s['central_server'] ?? [];
        $vp = DATA_DIR . '/version.json';
        $ver = file_exists($vp) ? readJson($vp, []) : [];
        jsonOut([
            'ok' => true,
            'central' => [
                'url'         => $cs['url'] ?? '',
                'tenant_id'   => $cs['tenant_id'] ?? '',
                'license_set' => !empty($cs['license_key']),
                'license_key' => !empty($cs['license_key']) ? maskKey($cs['license_key']) : '',
                'auto_update' => !empty($cs['auto_update']),
                'last_check'  => $cs['last_check'] ?? '',
                'last_result' => $cs['last_result'] ?? '',
            ],
            'installed_version' => $ver['version'] ?? 'v1.1.0',
            'installed_at'      => $ver['installed_at'] ?? '',
        ]);
        break;
    }

    case 'save_central': {
        requireAuth(['super_admin']);
        $in = bodyInput();
        $url   = trim($in['url']         ?? '');
        $tid   = strtolower(trim($in['tenant_id'] ?? ''));   // v1.1.2: always lowercase
        $lic   = trim($in['license_key'] ?? '');
        $auto  = !empty($in['auto_update']);

        $s = getSettings();
        $cur = $s['central_server'] ?? [];

        // Preserve license_key when masked/empty sent in
        if ($lic === '' || strpos($lic, '•') !== false) $lic = $cur['license_key'] ?? '';

        $s['central_server'] = [
            'url'         => rtrim($url, '/'),
            'tenant_id'   => $tid,
            'license_key' => $lic,
            'auto_update' => $auto,
            'last_check'  => $cur['last_check'] ?? '',
            'last_result' => $cur['last_result'] ?? '',
        ];
        writeJson(SETTINGS_FILE, $s);
        jsonOut(['ok' => true]);
        break;
    }

    /* ---------- v1.2.48: tarikan statistik oleh server pusat (AdInsight) ----
     * Server-to-server, dipanggil terjadwal oleh pusat. TIDAK memakai sesi
     * login: pusat membuktikan diri dengan tenant_id + license_key yang sama
     * persis dengan yang tersimpan di settings.central_server.
     *
     * Yang dikirim HANYA agregat: jumlah chat per hari, pengunjung unik,
     * rincian UTM, dan kartu lead. Token dan biaya API sengaja TIDAK ikut,
     * itu angka internal dan bukan konsumsi tenant.
     *
     * Kenapa mengirim deret harian, bukan potret hari ini saja: chatbot-log
     * dipangkas ke log_limit entri terakhir, jadi riwayat lama hilang di sini.
     * Pusat yang jadi arsipnya. Dengan deret harian, pusat bisa upsert per
     * tanggal sehingga sync yang terlewat sehari otomatis tertambal pada
     * panggilan berikutnya, dan panggilan berulang tidak menggandakan angka.
     * -------------------------------------------------------------------- */
    case 'stats_pull': {
        $s  = getSettings();
        $cs = $s['central_server'] ?? [];
        $tidWant = (string)($cs['tenant_id']   ?? '');
        $licWant = (string)($cs['license_key'] ?? '');
        if ($tidWant === '' || $licWant === '') {
            jsonOut(['ok' => false, 'error' => 'Server pusat belum dikonfigurasi.'], 403);
        }

        // Kredensial lewat header (disarankan, tidak nyangkut di access log)
        // atau query string sebagai cadangan.
        $tidGot = (string)($_SERVER['HTTP_X_TENANT_ID']   ?? ($_GET['tenant_id']   ?? ''));
        $licGot = (string)($_SERVER['HTTP_X_LICENSE_KEY'] ?? ($_GET['license_key'] ?? ''));
        // hash_equals: pembandingan waktu-tetap supaya kunci tidak bisa
        // ditebak per karakter lewat pengukuran waktu respons.
        $okTid = hash_equals($tidWant, strtolower(trim($tidGot)));
        $okLic = hash_equals($licWant, trim($licGot));
        if (!$okTid || !$okLic) {
            jsonOut(['ok' => false, 'error' => 'Kredensial pusat tidak cocok.'], 401);
        }

        // Rentang tanggal dalam WIB. Default 90 hari terakhir.
        $to   = substr((string)($_GET['to']   ?? ''), 0, 10);
        $from = substr((string)($_GET['from'] ?? ''), 0, 10);
        if (!preg_match('/^\d{4}-\d{2}-\d{2}$/', $to))   $to   = wibToday();
        if (!preg_match('/^\d{4}-\d{2}-\d{2}$/', $from)) $from = wibDate('Y-m-d', time() - 89 * 86400);
        if ($from > $to) { $swapD = $from; $from = $to; $to = $swapD; }

        $logs = logReadAll();
        if (!is_array($logs)) $logs = [];

        $daily = [];   // tanggal => pencacah
        $utmAgg = [];  // kunci gabungan => pencacah
        $ipsD = [];    // tanggal => [ip => 1], untuk pengunjung unik
        $ipsU = [];    // kunci utm => [ip => 1]

        foreach ($logs as $l) {
            if (!is_array($l)) continue;
            // balasan manual agent bukan percakapan bot, jangan dihitung
            if (in_array(($l['dir'] ?? ''), ['manual', 'closing'], true)) continue;
            $d = substr((string)($l['ts'] ?? ''), 0, 10);
            if ($d === '' || $d < $from || $d > $to) continue;

            $ch = ((string)($l['channel'] ?? '')) !== '' ? (string)$l['channel'] : 'web';
            $ip = (string)($l['ip'] ?? '');

            if (!isset($daily[$d])) {
                $daily[$d] = ['chats_total' => 0, 'chats_web' => 0, 'chats_wa' => 0, 'ai_errors' => 0, 'hourly' => array_fill(0, 24, 0)];
                $ipsD[$d] = [];
            }
            $daily[$d]['chats_total']++;
            // Sebaran per jam (WIB, ts log sudah WIB). Dikirim per tanggal
            // supaya pusat bisa menjumlahkan untuk periode apa pun.
            $hh = substr((string)($l['ts'] ?? ''), 11, 2);
            if (ctype_digit($hh) && (int)$hh < 24) $daily[$d]['hourly'][(int)$hh]++;
            if ($ch === 'whatsapp') $daily[$d]['chats_wa']++;
            else                    $daily[$d]['chats_web']++;
            if (!empty($l['ai_error'])) $daily[$d]['ai_errors']++;
            if ($ip !== '') $ipsD[$d][$ip] = 1;

            $src = ((string)($l['utm_source']   ?? '')) !== '' ? (string)$l['utm_source']   : '(direct)';
            $med = ((string)($l['utm_medium']   ?? '')) !== '' ? (string)$l['utm_medium']   : '(none)';
            $cmp = ((string)($l['utm_campaign'] ?? '')) !== '' ? (string)$l['utm_campaign'] : '(none)';
            // Channel ikut jadi dimensi: tiap chat WhatsApp otomatis diberi
            // utm_source=whatsapp/utm_medium=chat yang sintetis, bukan
            // atribusi kampanye sungguhan. Tanpa penanda ini pusat tidak bisa
            // memisahkan UTM asli dari widget web dan tabel atribusinya jadi
            // didominasi baris yang tidak berarti.
            // Pemisah unit (0x1F) supaya nilai UTM yang mengandung tanda baca
            // biasa tidak bisa menabrak batas kunci.
            $k = $d . "\x1F" . $ch . "\x1F" . $src . "\x1F" . $med . "\x1F" . $cmp;
            if (!isset($utmAgg[$k])) {
                $utmAgg[$k] = ['date' => $d, 'channel' => $ch, 'source' => $src, 'medium' => $med, 'campaign' => $cmp, 'chats' => 0, 'users' => 0];
                $ipsU[$k] = [];
            }
            $utmAgg[$k]['chats']++;
            if ($ip !== '') $ipsU[$k][$ip] = 1;
        }

        ksort($daily);
        $dailyOut = [];
        foreach ($daily as $d => $row) {
            $dailyOut[] = [
                'date'            => $d,
                'chats_total'     => $row['chats_total'],
                'chats_web'       => $row['chats_web'],
                'chats_wa'        => $row['chats_wa'],
                'unique_visitors' => count($ipsD[$d]),
                'ai_errors'       => $row['ai_errors'],
                'hourly'          => $row['hourly'],
            ];
        }

        // Hasil Scan Topik (AI) yang tersimpan, satu per kombinasi periode
        // dan channel. Contoh percakapan (examples) sengaja TIDAK dikirim:
        // isinya kutipan pesan pelanggan, dan laporan pusat cukup memakai
        // agregatnya.
        $scansOut = [];
        $scansAll = defined('TOPIC_SCANS_FILE') ? readJson(TOPIC_SCANS_FILE, []) : [];
        if (is_array($scansAll)) {
            foreach ($scansAll as $sk => $sc) {
                if (!is_array($sc) || !empty($sc['empty']) || empty($sc['topics']) || !is_array($sc['topics'])) continue;
                $tps = [];
                foreach ($sc['topics'] as $tp) {
                    if (!is_array($tp)) continue;
                    $tps[] = [
                        'name'       => (string)($tp['name'] ?? ''),
                        'summary'    => (string)($tp['summary'] ?? ''),
                        'action'     => (string)($tp['action'] ?? ''),
                        'sentiment'  => (string)($tp['sentiment'] ?? 'netral'),
                        'count'      => (int)($tp['count'] ?? 0),
                        'pct'        => (float)($tp['pct'] ?? 0),
                        'est'        => (int)($tp['est'] ?? 0),
                        'by_channel' => (isset($tp['by_channel']) && is_array($tp['by_channel'])) ? $tp['by_channel'] : ['web' => 0, 'whatsapp' => 0],
                    ];
                }
                if (!$tps) continue;
                $scansOut[] = [
                    'key'        => (string)$sk,
                    'days'       => (int)($sc['days'] ?? 0),
                    'channel'    => (string)($sc['channel'] ?? ''),
                    'from'       => (string)($sc['from'] ?? ''),
                    'to'         => (string)($sc['to'] ?? ''),
                    'scanned_at' => (string)($sc['scanned_at'] ?? ''),
                    'total'      => (int)($sc['total'] ?? 0),
                    'sampled'    => (int)($sc['sampled'] ?? 0),
                    'insight'    => (string)($sc['insight'] ?? ''),
                    'topics'     => $tps,
                ];
            }
        }

        ksort($utmAgg);
        $utmOut = [];
        foreach ($utmAgg as $k => $row) {
            $row['users'] = count($ipsU[$k]);
            $utmOut[] = $row;
        }

        // Kartu lead hasil analisa AI. Saat ini analisa hanya berjalan untuk
        // percakapan WhatsApp (lihat LEAD_TRIGGER_MSGS), chat widget web
        // belum menghasilkan lead. Ditandai eksplisit di field channel supaya
        // pusat tidak salah menyimpulkan web tidak menghasilkan prospek.
        $leadsOut = [];
        foreach (leadsGetAll() as $num => $ld) {
            if (!is_array($ld)) continue;
            // Disaring dengan created_at ATAU updated_at: lead lama yang
            // status follow-up nya baru diubah agent harus tetap terkirim,
            // kalau tidak perubahan status itu tidak akan pernah sampai ke
            // pusat. Untuk tarikan pertama, pusat cukup meminta rentang lebar
            // supaya seluruh kartu lead ikut terbawa sekali jalan.
            $ldC = substr((string)($ld['created_at'] ?? ''), 0, 10);
            $ldU = substr((string)($ld['updated_at'] ?? ''), 0, 10);
            $ldNewest = ($ldU > $ldC) ? $ldU : $ldC;
            if ($ldNewest !== '' && ($ldNewest < $from || $ldC > $to)) continue;
            $ex = (isset($ld['extracted']) && is_array($ld['extracted'])) ? $ld['extracted'] : [];
            $leadsOut[] = [
                'key'        => (string)($ld['number'] ?? $num),
                'name'       => (string)($ld['name'] ?? ''),
                'channel'    => 'whatsapp',
                'status'     => (string)($ld['status'] ?? 'baru'),
                'nama'       => (string)($ex['nama']      ?? ''),
                'kebutuhan'  => (string)($ex['kebutuhan'] ?? ''),
                'waktu'      => (string)($ex['waktu']     ?? ''),
                'anggaran'   => (string)($ex['anggaran']  ?? ''),
                'ringkasan'  => (string)($ex['ringkasan'] ?? ''),
                'created_at' => (string)($ld['created_at'] ?? ''),
                'updated_at' => (string)($ld['updated_at'] ?? ''),
            ];
        }

        // log_window: entri terlama yang MASIH tersisa di log. Pusat memakai
        // ini untuk tahu sampai mana angka harian boleh dipercaya. Tanggal
        // sebelum oldest_ts sudah terpangkas log_limit, jadi kalau pusat
        // belum pernah menyimpannya, angka hari itu memang tidak lengkap dan
        // tidak akan pernah bisa direkonstruksi dari sini.
        $oldest = '';
        foreach ($logs as $l) {
            if (!is_array($l)) continue;
            $t = substr((string)($l['ts'] ?? ''), 0, 10);
            if ($t === '') continue;
            if ($oldest === '' || $t < $oldest) $oldest = $t;
        }

        jsonOut([
            'ok'           => true,
            'tenant_id'    => $tidWant,
            'code_version' => defined('DEI_VERSION') ? DEI_VERSION : '',
            'generated_at' => wibDate('Y-m-d H:i:s'),
            'range'        => ['from' => $from, 'to' => $to],
            'log_window'   => [
                'oldest_ts' => $oldest,
                'entries'   => count($logs),
                'limit'     => (int)($s['api']['log_limit'] ?? 500),
            ],
            'daily' => $dailyOut,
            'utm'   => $utmOut,
            'leads' => $leadsOut,
            'topic_scans' => $scansOut,
        ]);
        break;
    }

    case 'update_check': {
        if (PHP_SAPI !== 'cli') requireAuth(['super_admin']);   // v1.2.71: CLI = admin server
        $s = getSettings();
        $cs = $s['central_server'] ?? [];
        if (empty($cs['url']) || empty($cs['tenant_id']) || empty($cs['license_key'])) {
            jsonOut(['ok' => false, 'error' => 'Server pusat belum dikonfigurasi.'], 400);
        }
        $vp = DATA_DIR . '/version.json';
        $ver = file_exists($vp) ? readJson($vp, []) : [];
        $current = $ver['version'] ?? 'v1.1.0';

        // v1.2.57: statistik dari deiCollectStats()

        $body = [
            'tenant_id'   => $cs['tenant_id'],
            'license_key' => $cs['license_key'],
            'current'     => $current,
            'version'     => $current,
            // v1.2.43: versi dari konstanta di berkas ini (tidak bisa
            // berbohong), berdampingan dengan 'current' dari version.json.
            // Pusat membandingkan keduanya: kalau beda -> update gagal senyap.
            'code_version' => defined('DEI_VERSION') ? DEI_VERSION : '',
            'api_url'      => deiSelfApiUrl(),   // v1.2.56: dipakai pusat untuk cron_tick
            'lic_caps'     => ['blocked'],   // v1.2.111
            'stats' => deiCollectStats(),
            'health' => [
                'claude_key_set' => (($s['api']['provider'] ?? 'anthropic') === 'openrouter') ? !empty($s['api']['openrouter_api_key'] ?? '') : !empty($s['api']['claude_api_key'] ?? ''),
                'wa_enabled'     => !empty($s['whatsapp_api']['enabled'] ?? false),
                'wa_responding'  => !empty($s['whatsapp_api']['access_token'] ?? '') && !empty($s['whatsapp_api']['phone_number_id'] ?? ''),
            ],
        ];

        // Two parallel calls collapsed into two sequential ones (simpler) — report_back first, then check_update.
        $headers = ['Content-Type: application/json'];
        $reportUrl = $cs['url'] . '/backend/index.php?action=report_back';
        $checkUrl  = $cs['url'] . '/backend/index.php?action=check_update';

        $payload = json_encode($body);

        // report_back
        $ch = curl_init($reportUrl);
        curl_setopt_array($ch, [CURLOPT_RETURNTRANSFER => true, CURLOPT_TIMEOUT => 15,
            CURLOPT_POST => true, CURLOPT_POSTFIELDS => $payload, CURLOPT_HTTPHEADER => $headers]);
        @curl_exec($ch);
        curl_close($ch);

        // check_update
        $ch = curl_init($checkUrl);
        curl_setopt_array($ch, [CURLOPT_RETURNTRANSFER => true, CURLOPT_TIMEOUT => 15,
            CURLOPT_POST => true, CURLOPT_POSTFIELDS => $payload, CURLOPT_HTTPHEADER => $headers]);
        $resp = curl_exec($ch);
        $code = curl_getinfo($ch, CURLINFO_HTTP_CODE);
        $err  = curl_error($ch);
        curl_close($ch);

        $now = wibDate('Y-m-d H:i:s');   // v1.2.42: WIB, bukan UTC
        if ($resp === false || $code !== 200) {
            $s['central_server']['last_check']  = $now;
            $s['central_server']['last_result'] = "Gagal terhubung ($code) " . ($err ?: '');
            writeJson(SETTINGS_FILE, $s);
            jsonOut(['ok' => false, 'error' => 'Gagal hubungi pusat: HTTP ' . $code . ' ' . $err], 502);
        }
        $data = json_decode($resp, true) ?: [];
        $s['central_server']['last_check']  = $now;
        $s['central_server']['last_result'] = !empty($data['ok']) ? 'OK' : ('Gagal: ' . ($data['error'] ?? 'unknown'));
        writeJson(SETTINGS_FILE, $s);

        if (!($data['ok'] ?? false)) {
            jsonOut(['ok' => false, 'error' => $data['error'] ?? 'Respon pusat tidak ok'], 400);
        }

        // v1.1.3: refresh license cache from central response (no need for separate refresh call)
        $newStatus = $data['license_status'] ?? 'active';
        $msg = trim($data['suspend_message'] ?? '');
        if ($msg === '') $msg = LIC_DEFAULT_SUSPEND_MSG;
        $cacheBefore = readJson(LIC_CACHE_FILE, []);
        $oldStatus = $cacheBefore['status'] ?? null;
        $newCache = [
            'status'     => $newStatus,
            'message'    => $msg,
            'expires_at' => $data['expires_at'] ?? '',
            'days_left'  => $data['days_left']  ?? null,
            'cached_at'  => time(),
        ];
        writeJson(LIC_CACHE_FILE, $newCache);
        if (!deiLicOff($oldStatus) && deiLicOff($newStatus)) {   // v1.2.111
            applyStatusSideEffects($newStatus, $s);
        }
        deiSyncBlock($newStatus);   // v1.2.111: blokir-total

        // v1.1.4: also cache cap_info if present in response
        if (!empty($data['cap_info'])) {
            $cap = $data['cap_info'];
            $capMsg = trim($cap['cap_message'] ?? '');
            if ($capMsg === '') $capMsg = CAP_DEFAULT_MSG;
            $capCache = [
                'reached'   => !empty($cap['cap_reached']),
                'warning'   => !empty($cap['cap_warning']),
                'pct'       => (float)($cap['usage_pct'] ?? 0),
                'tier'      => $cap['tier'] ?? '',
                'cap'       => (int)($cap['monthly_chat_cap'] ?? 0),
                'used'      => (int)($cap['chats_this_month'] ?? 0),
                'message'   => $capMsg,
                'features'  => deiFeaturesFromCap($cap),   // v1.2.58
                'cached_at' => time(),
            ];
            writeJson(CAP_CACHE_FILE, $capCache);
        }

        // v1.2.71: `php api/index.php action=update_cli` -> langsung pasang, tanpa dashboard
        if (!empty($GLOBALS['dei_cli_chain'])) {
            if (empty($data['update_available'])) { echo "update_cli: sudah versi terbaru ($current)\n"; exit(0); }
            $GLOBALS['dei_cli_update'] = ['zip_url' => $data['zip_url'] ?? '', 'manifest_url' => $data['manifest_url'] ?? '', 'target' => $data['latest'] ?? ''];
            goto dei_cli_update_apply;
        }
        jsonOut([
            'ok'               => true,
            'current'          => $current,
            'latest'           => $data['latest'] ?? null,
            'update_available' => !empty($data['update_available']),
            'zip_url'          => $data['zip_url']     ?? '',
            'manifest_url'     => $data['manifest_url']?? '',
            'changelog'        => $data['changelog']   ?? '',
            'released_at'      => $data['released_at'] ?? '',
            'license_status'   => $newStatus,
            'expires_at'       => $data['expires_at']  ?? '',
            'days_left'        => $data['days_left']   ?? null,
        ]);
        break;
    }

    case 'update_apply': {
        dei_cli_update_apply:   // v1.2.71: tujuan lompatan update_cli
        if (PHP_SAPI === 'cli' && !empty($GLOBALS['dei_cli_update'])) { $in = $GLOBALS['dei_cli_update']; }
        else { requireAuth(['super_admin']); $in = bodyInput(); }
        $zipUrl      = (string)($in['zip_url']      ?? '');
        $manifestUrl = (string)($in['manifest_url'] ?? '');
        $target      = (string)($in['target']       ?? '');     // expected version, mis. "v1.1.1"
        if ($zipUrl === '' || $target === '') jsonOut(['ok' => false, 'error' => 'zip_url & target wajib'], 400);

        // === v1.2.1 fix: Downgrade prevention =====================
        $s = getSettings();
        $currentVer = $s['central_server']['target_last_ver'] ?? '';
        if ($target !== '' && $currentVer !== '' &&
            version_compare(ltrim($target,'v'), ltrim($currentVer,'v'), '<')) {
            jsonOut([
                'ok' => false,
                'error' => 'Downgrade dicegah: target ' . $target . ' lebih rendah dari current ' . $currentVer . '. Manual intervention diperlukan.',
                'current' => $currentVer,
                'target' => $target,
            ], 400);
        }
        // === /v1.2.1 fix ==========================================


        $s = getSettings();
        $csUrl = $s['central_server']['url'] ?? '';
        // Safety: zip_url must be on the configured central server URL
        if ($csUrl === '' || strpos($zipUrl, rtrim($csUrl, '/')) !== 0) {
            jsonOut(['ok' => false, 'error' => 'zip_url tidak cocok dengan server pusat.'], 400);
        }

        // Download manifest (optional but recommended for md5 verification)
        $manifest = null;
        if ($manifestUrl !== '') {
            $ch = curl_init($manifestUrl);
            curl_setopt_array($ch, [CURLOPT_RETURNTRANSFER => true, CURLOPT_TIMEOUT => 20]);
            $mResp = curl_exec($ch); curl_close($ch);
            if ($mResp) $manifest = json_decode($mResp, true);
        }

        // Download ZIP to temp
        $tmpZip = sys_get_temp_dir() . '/dei-update-' . bin2hex(random_bytes(6)) . '.zip';
        $fh = @fopen($tmpZip, 'w');
        if (!$fh) jsonOut(['ok' => false, 'error' => 'Tidak bisa membuat file sementara.'], 500);
        $ch = curl_init($zipUrl);
        curl_setopt_array($ch, [CURLOPT_RETURNTRANSFER => false, CURLOPT_TIMEOUT => 60,
            CURLOPT_FILE => $fh, CURLOPT_FOLLOWLOCATION => true]);
        $ok = curl_exec($ch);
        $code = curl_getinfo($ch, CURLINFO_HTTP_CODE);
        curl_close($ch); fclose($fh);
        if (!$ok || $code !== 200 || filesize($tmpZip) < 100) {
            @unlink($tmpZip);
            jsonOut(['ok' => false, 'error' => "Gagal unduh ZIP (HTTP $code, size " . filesize($tmpZip) . ")."], 502);
        }

        // Extract to temp dir
        $tmpDir = sys_get_temp_dir() . '/dei-update-' . bin2hex(random_bytes(6));
        @mkdir($tmpDir, 0755, true);
        $extracted = false;
        if (class_exists('ZipArchive')) {
            $zip = new ZipArchive();
            if ($zip->open($tmpZip) === true) {
                $zip->extractTo($tmpDir);
                $zip->close();
                $extracted = true;
            }
        }
        if (!$extracted && function_exists('exec')) {
            $cmd = 'unzip -o ' . escapeshellarg($tmpZip) . ' -d ' . escapeshellarg($tmpDir) . ' 2>&1';
            @exec($cmd, $exo, $rc);
            $extracted = ($rc === 0) && is_dir($tmpDir) && count(scandir($tmpDir)) > 2;
        }
        if (!$extracted) {
            @unlink($tmpZip);
            jsonOut(['ok' => false, 'error' => 'Tidak bisa ekstrak ZIP (ZipArchive & unzip tidak tersedia).'], 500);
        }
        @unlink($tmpZip);

        // Find the payload root: prefer 'dei-update/' folder, else use tmpDir directly.
        // v1.2.41 BUG 1: dulu hanya mengenali akar ZIP atau folder
        // 'dei-update/'. Master ZIP sekarang membungkus di 'dei-chatbot-ai/',
        // jadi $root salah dan SEMUA berkas gagal ditemukan -> update no-op
        // senyap sejak v1.2.1. Sekarang root dicari otomatis berdasarkan
        // keberadaan api/index.php, jadi tahan kalau kemasan ZIP berubah lagi.
        $root = deiCariRootPayload($tmpDir);
        if ($root === null) {
            $isi = @scandir($tmpDir);
            $isi = is_array($isi) ? array_values(array_diff($isi, ['.', '..'])) : [];
            $rmrfEarly = function ($p) use (&$rmrfEarly) {
                if (is_dir($p)) {
                    foreach (scandir($p) as $c) {
                        if ($c === '.' || $c === '..') continue;
                        $rmrfEarly($p . '/' . $c);
                    }
                    @rmdir($p);
                } else { @unlink($p); }
            };
            $rmrfEarly($tmpDir);
            jsonOut([
                'ok'    => false,
                'error' => 'Struktur ZIP update tidak dikenali: api/index.php tidak ditemukan. Isi ZIP: ' . implode(', ', array_slice($isi, 0, 10)),
            ], 500);
        }

        // Whitelist of paths we will replace. NEVER touch data/.
        $allowed = [
            'api/index.php',
            'dashboard/chatbot-ai/app.js',
            'dashboard/chatbot-ai/index.html',
            'dashboard/chatbot-ai/login.html',
            'assets/js/chat-widget.js',
        ];

        // Verify md5 against manifest where possible
        $verified = [];
        // === v1.2.2 fix: track whether manifest has per-file MD5 (for skip guard below) ===
        $hasFilesManifest = is_array($manifest) && !empty($manifest['files']);
        // === /v1.2.2 fix ===
        if ($hasFilesManifest) {
            foreach ($manifest['files'] as $f) {
                $p = $f['path'] ?? ''; $md5 = $f['md5'] ?? '';
                if (!in_array($p, $allowed, true)) continue;
                $local = $root . '/' . $p;
                if (file_exists($local) && $md5 && md5_file($local) === $md5) $verified[$p] = true;
            }
            // If we have a manifest, require every file we plan to replace to be verified.
        }

        // Backup before replace
        $backupDir = dirname(__DIR__) . '/backup-pre-update/' . wibDate('Ymd-His') . '-to-' . preg_replace('/[^a-z0-9.]/i', '', $target);
        @mkdir($backupDir, 0755, true);
        $replaced = []; $skipped = [];
        foreach ($allowed as $rel) {
            $src = $root . '/' . $rel;
            if (!file_exists($src)) { $skipped[] = $rel; continue; }
            // === v1.2.2 fix: only require MD5 verification if manifest has 'files' array ===
            // Backward compat: manifests without 'files' array → skip MD5 check → replace all
            if ($hasFilesManifest && !isset($verified[$rel])) { $skipped[] = $rel . ' (md5-mismatch)'; continue; }
            // === /v1.2.2 fix ===
            $dst = dirname(__DIR__) . '/' . $rel;
            if (file_exists($dst)) {
                $bdst = $backupDir . '/' . $rel;
                @mkdir(dirname($bdst), 0755, true);
                @copy($dst, $bdst);
            }
            @mkdir(dirname($dst), 0755, true);
            if (@copy($src, $dst)) $replaced[] = $rel; else $skipped[] = $rel . ' (copy-failed)';
        }

        // Cleanup temp
        $rmrf = function ($p) use (&$rmrf) {
            if (is_dir($p)) {
                foreach (scandir($p) as $c) {
                    if ($c === '.' || $c === '..') continue;
                    $rmrf($p . '/' . $c);
                }
                @rmdir($p);
            } else { @unlink($p); }
        };
        $rmrf($tmpDir);

        // v1.2.41 BUG 2 & 3: dulu version.json ditulis dengan $target dan
        // respons selalu ok=true WALAU tidak satu berkas pun tergantikan.
        // Akibatnya dashboard memajang versi baru padahal nol berkas berubah,
        // dan masalahnya tidak terdeteksi hampir sebulan. Sekarang: kalau
        // $replaced kosong -> ERROR, dan version.json TIDAK ditulis, supaya
        // versi terpasang selalu mencerminkan kode yang benar-benar ada.
        if (empty($replaced)) {
            @rmdir($backupDir);   // backup kosong, tidak perlu disimpan
            jsonOut([
                'ok'      => false,
                'error'   => 'Update GAGAL: tidak satu berkas pun tergantikan. Versi terpasang tidak diubah.',
                'skipped' => $skipped,
            ], 500);
        }
        // Update version.json
        writeJson(DATA_DIR . '/version.json', [
            'version'      => $target,
            'installed_at' => wibDate('Y-m-d H:i:s'),   // v1.2.42: WIB
            'replaced'     => $replaced,
            'skipped'      => $skipped,
            'backup'       => basename($backupDir),
        ]);

        jsonOut([
            'ok' => true,
            'version'  => $target,
            'replaced' => $replaced,
            'skipped'  => $skipped,
            'backup'   => basename($backupDir),
        ]);
        break;
    }



    /* ============================================================
     *  v1.2.0 WA CLAIM — Endpoints: claim, release, list v2
     * ============================================================ */

    /* ---------- v1.2.56: CRON TICK (dipanggil dei-pusat tiap menit, atau CLI) ---------- */
    /* ---------- v1.2.65: halaman Pembaruan (catatan rilis) — khusus admin ---------- */
    case 'release_notes': {
        $u = requireAuth(['super_admin', 'admin']);
        $n = deiFetchReleaseNotes(!empty($_GET['refresh']));
        $rel = array_values(array_filter($n['releases'] ?? [], function ($r) use ($u) { return deiRelVisible($r, $u['role'] ?? ''); }));   // v1.2.74
        $latest = $rel[0]['version'] ?? null;
        $seen = '';
        foreach (readJson(USERS_FILE, []) as $x) {
            if (($x['username'] ?? '') === $u['username']) { $seen = (string)($x['release_seen'] ?? ''); break; }
        }
        $unread = 0;
        if ($latest) {
            if (!deiVerOk($seen)) $unread = 1;   // belum pernah membuka: tandai rilis terakhir saja
            else foreach ($rel as $r) { if (deiVerCmp($r['version'], $seen) > 0) $unread++; }
        }
        jsonOut([
            'ok'                => true,
            'releases'          => !empty($_GET['summary']) ? array_slice($rel, 0, 1) : $rel,
            'latest'            => $latest,
            'installed_version' => DEI_VERSION,
            'seen'              => $seen,
            'unread'            => $unread,
            'fetched_at_wib'    => $n['fetched_at_wib'] ?? '',
            'stale'             => !empty($n['stale']),
            'error'             => $n['error'] ?? '',
        ]);
        break;
    }

    /* ---------- v1.2.74: Panduan — tandai versi tur yang sudah dilihat (semua peran) ---------- */
    case 'tour_seen': {
        $u = requireAuth();
        $in = bodyInput();
        $v = max(0, min(999, (int)($in['ver'] ?? 0)));
        if ($v < 1) jsonOut(['ok' => false, 'error' => 'Versi panduan tidak valid.'], 400);
        $users = readJson(USERS_FILE, []);
        foreach ($users as $i => $x) {
            if (($x['username'] ?? '') !== $u['username']) continue;
            if ((int)($x['tour_seen'] ?? 0) < $v) { $users[$i]['tour_seen'] = $v; writeJson(USERS_FILE, $users); }
            break;
        }
        jsonOut(['ok' => true, 'tour_seen' => $v]);
        break;
    }

    case 'release_seen': {
        $u = requireAuth(['super_admin', 'admin']);
        $in = bodyInput();
        $v = (string)($in['version'] ?? '');
        if (!deiVerOk($v)) jsonOut(['ok' => false, 'error' => 'Versi tidak valid.'], 400);
        $users = readJson(USERS_FILE, []);
        foreach ($users as $i => $x) {
            if (($x['username'] ?? '') !== $u['username']) continue;
            $cur = (string)($x['release_seen'] ?? '');
            if (!deiVerOk($cur) || deiVerCmp($v, $cur) > 0) { $users[$i]['release_seen'] = $v; writeJson(USERS_FILE, $users); }
            break;
        }
        jsonOut(['ok' => true, 'seen' => $v]);
        break;
    }

    /* ---------- CLI (v1.2.71): worker antrean WA — mode queue=redis ----------
     * Dijalankan supervisord: php api/index.php action=wa_worker slot=<n>
     * Berhenti sendiri setelah max_jobs / max_sec supaya memori selalu segar. */
    case 'wa_worker': {
        if (PHP_SAPI !== 'cli') jsonOut(['ok' => false, 'error' => 'Hanya lewat CLI.'], 403);
        if (!deiQueueRedis()) { fwrite(STDERR, "wa_worker: queue bukan redis (lihat data/server.php)\n"); exit(1); }
        @set_time_limit(0);
        $slot    = preg_replace('/[^0-9a-z_-]/i', '', (string)($_GET['slot'] ?? '0'));
        if ($slot === '') $slot = '0';
        $maxJobs = max(1, (int)($_GET['max_jobs'] ?? 500));
        $maxSec  = max(5, (int)($_GET['max_sec'] ?? 3600));
        $rq   = deiRedis();
        $proc = 'q:wa:proc:' . $slot;
        $GLOBALS['dei_worker_slot'] = 'w' . $slot;
        // Job yang tertinggal dari proses slot ini sebelumnya (mati di tengah jalan) -> antre ulang di depan.
        while (($left = $rq->rPop($proc)) !== false && $left !== null) {
            $lj = json_decode($left, true);
            deiNumLockRelease($lj, 'w' . $slot);   // kunci nomor yang ditinggal proses mati
            $lj['try'] = (int)($lj['try'] ?? 0) + 1;
            if ($lj['try'] >= 3) { $rq->lPush('q:wa:dead', $left); $rq->lTrim('q:wa:dead', 0, 999); continue; }
            $rq->rPush('q:wa', json_encode($lj));
            error_log("wa_worker[$slot]: job tertinggal diantre ulang (percobaan {$lj['try']})");
        }
        $t0 = time(); $done = 0;
        while ($done < $maxJobs && (time() - $t0) < $maxSec) {
            $rq->set('w:hb:' . $slot, time(), ['ex' => 30]);
            $job = $rq->brPopLPush('q:wa', $proc, 5);
            if ($job === false || $job === null || $job === '') continue;
            $done++;
            $j = json_decode($job, true);
            unset($GLOBALS['dei_reply_mode_cache'], $GLOBALS['dei_features_cache']);   // settings bisa berubah antar job
            try {
                $s  = getSettings();
                $wa = waConf($s);
                waHandleMetaPayload($s, $wa, json_decode((string)($j['raw'] ?? ''), true));
            } catch (\Throwable $e) {
                error_log("wa_worker[$slot]: " . $e->getMessage());
                $try = (int)($j['try'] ?? 0) + 1;
                if ($try < 3) { $j['try'] = $try; $rq->lPush('q:wa', json_encode($j)); }
                else { $rq->lPush('q:wa:dead', $job); $rq->lTrim('q:wa:dead', 0, 999); }
            }
            $rq->lRem($proc, $job, 1);
        }
        exit(0);
    }

    /* ---------- CLI (v1.2.71): status antrean untuk pemantauan ---------- */
    case 'wa_queue_status': {
        if (PHP_SAPI !== 'cli') jsonOut(['ok' => false, 'error' => 'Hanya lewat CLI.'], 403);
        $out = ['ok' => true, 'version' => DEI_VERSION, 'storage' => deiServerConf()['storage'], 'queue' => deiServerConf()['queue'],
                'queue_active' => deiQueueRedis(), 'debounce_sec' => deiDebounceSec(),
                'ai_fallback' => (string)((deiAiFallback(getSettings()) ?? [])['model'] ?? ''), 'ai_fail_handoff' => !empty(deiServerConf()['ai_fail_handoff'])];   // v1.2.72
        if (deiServerConf()['queue'] === 'redis' && !deiQueueRedis()) {
            $out['ok'] = false;
            $out['warning'] = 'Redis tidak terjangkau: antrean TIDAK aktif, pesan diproses langsung oleh webhook.';
        }
        if (deiQueueRedis()) {
            $rq = deiRedis();
            $out['pending'] = (int)$rq->lLen('q:wa');
            $out['dead']    = (int)$rq->lLen('q:wa:dead');
            $alive = 0;
            for ($i = 0; $i < 64; $i++) { if ($rq->exists('w:hb:' . $i)) $alive++; }
            $out['workers_alive'] = $alive;
        }
        echo json_encode($out, JSON_PRETTY_PRINT | JSON_UNESCAPED_SLASHES) . "\n";
        exit(0);
    }

    /* ---------- CLI (v1.2.88): periksa pasangan kota redBus -> data/redbus-routes.json ---------- */
    case 'redbus_scan': {
        if (PHP_SAPI !== 'cli') jsonOut(['ok' => false, 'error' => 'Hanya lewat CLI.'], 403);
        $c = deiRedbusConf();
        if (!$c || empty($c['op_id'])) { fwrite(STDERR, "redbus_scan: 'redbus' (cities + op_id) belum diisi di data/server.php\n"); exit(1); }
        $ops = array_filter(array_map('trim', explode(',', (string)$c['op_id'])));
        $cities = [];
        foreach ($c['cities'] as $k => $v) if (is_int($v) || ctype_digit((string)$v)) $cities[(string)$v] = $k;
        $only = trim((string)($_GET['only'] ?? ''));
        $onlyId = '';
        if ($only !== '') { $oc = deiRedbusCity($only); if (!$oc) { fwrite(STDERR, "redbus_scan: kota '$only' tidak ada di tabel\n"); exit(1); } $onlyId = $oc[1]; }
        $delay = max(200, (int)($_GET['delay'] ?? 700)) * 1000;
        $dry = !empty($_GET['dry']);
        $fetch = function ($a, $b) {
            $u = 'https://www.redbus.id/tiket-bus/' . deiRedbusSlug($a) . '-ke-' . deiRedbusSlug($b);
            $ch = curl_init($u);
            curl_setopt_array($ch, [CURLOPT_RETURNTRANSFER => true, CURLOPT_FOLLOWLOCATION => true, CURLOPT_TIMEOUT => 25,
                CURLOPT_USERAGENT => 'Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/126.0 Safari/537.36',
                CURLOPT_HTTPHEADER => ['Accept: text/html', 'Accept-Language: id-ID,id;q=0.9']]);
            $html = (string)curl_exec($ch); $code = (int)curl_getinfo($ch, CURLINFO_HTTP_CODE); curl_close($ch);
            return [$code, $html];
        };
        $hasOp = function ($html) use ($ops) {
            if (!preg_match_all('/opId=((?:[0-9]|,|%2C)+)/i', $html, $m)) return false;
            foreach ($m[1] as $v) { $ids = explode(',', str_ireplace('%2C', ',', $v)); if (array_intersect($ops, $ids)) return true; }
            return false;
        };
        $old = is_file(deiRedbusRoutesFile()) ? (json_decode((string)file_get_contents(deiRedbusRoutesFile()), true) ?: []) : [];   // cek-storage: boleh
        $pairs = array_fill_keys(is_array($old['pairs'] ?? null) ? $old['pairs'] : [], true);
        $ids = array_keys($cities); $n = 0; $hit = 0; $okPages = 0;
        for ($i = 0; $i < count($ids); $i++) for ($j = $i + 1; $j < count($ids); $j++) {
            $a = (string)$ids[$i]; $b = (string)$ids[$j];
            if ($onlyId !== '' && $a !== $onlyId && $b !== $onlyId) continue;
            $key = deiRedbusPairKey($a, $b); $found = false; $n++;
            foreach ([[$cities[$a], $cities[$b]], [$cities[$b], $cities[$a]]] as $dir) {
                list($code, $html) = $fetch($dir[0], $dir[1]); usleep($delay);
                if ($code === 200 && strlen($html) > 5000) $okPages++;
                if ($code === 200 && $hasOp($html)) { $found = true; break; }
            }
            if ($found) { $pairs[$key] = true; $hit++; } else unset($pairs[$key]);
            echo ($found ? '  ADA   ' : '  -     ') . $cities[$a] . ' – ' . $cities[$b] . "\n";
        }
        if ($okPages === 0) { fwrite(STDERR, "redbus_scan: tidak ada halaman redBus yang terbaca (diblokir/jaringan?) — berkas tidak diubah\n"); exit(1); }
        echo "\nDiperiksa $n pasangan, ada rute: $hit. Total pasangan tersimpan: " . count($pairs) . "\n";
        if ($dry) { echo "(dry=1: berkas tidak ditulis)\n"; exit(0); }
        $names = [];
        foreach (array_keys($pairs) as $k) { list($x, $y) = explode('-', $k); if (isset($cities[$x], $cities[$y])) $names[] = $cities[$x] . ' – ' . $cities[$y]; }
        sort($names);
        file_put_contents(deiRedbusRoutesFile(), json_encode(['updated_at' => wibDate('Y-m-d H:i:s'), 'op_id' => (string)$c['op_id'],
            'pairs' => array_keys($pairs), 'routes' => $names], JSON_PRETTY_PRINT | JSON_UNESCAPED_UNICODE | JSON_UNESCAPED_SLASHES));   // cek-storage: boleh
        echo "Tersimpan: " . deiRedbusRoutesFile() . "\n";
        exit(0);
    }

    /* ---------- CLI (v1.2.71): buat tabel MySQL ---------- */
    case 'db_init': {
        if (PHP_SAPI !== 'cli') jsonOut(['ok' => false, 'error' => 'Hanya lewat CLI.'], 403);
        if (!deiStorageMysql()) { fwrite(STDERR, "db_init: storage bukan mysql (lihat data/server.php)\n"); exit(1); }
        foreach (deiDbSchema() as $sql) deiDb()->exec($sql);
        echo "db_init: OK (" . count(deiDbSchema()) . " tabel)\n";
        exit(0);
    }

    /* ---------- CLI (v1.2.71): pindahkan data JSON lama ke MySQL ----------
     * Sekali saat tenant pindah ke server sendiri. Tabel harus kosong kecuali force=1. */
    case 'db_import': {
        if (PHP_SAPI !== 'cli') jsonOut(['ok' => false, 'error' => 'Hanya lewat CLI.'], 403);
        if (!deiStorageMysql()) { fwrite(STDERR, "db_import: storage bukan mysql\n"); exit(1); }
        $db = deiDb();
        foreach (deiDbSchema() as $sql) $db->exec($sql);
        $force = !empty($_GET['force']);
        $res = [];
        if ($force || !(int)$db->query('SELECT COUNT(*) FROM dei_log')->fetchColumn()) {
            $old = readJson(LOG_FILE, []);   // cek-storage: boleh (impor sekali)
            $db->beginTransaction();
            foreach (array_reverse(is_array($old) ? $old : []) as $e) { if (is_array($e)) logDbInsert($e); }
            $db->commit();
            $res['log'] = is_array($old) ? count($old) : 0;
        } else $res['log'] = 'dilewati (tabel tidak kosong)';
        if ($force || !(int)$db->query('SELECT COUNT(*) FROM dei_contacts')->fetchColumn()) {
            $old = readJson(CONTACTS_FILE, []);   // cek-storage: boleh (impor sekali)
            $up = $db->prepare('INSERT INTO dei_contacts (num, body) VALUES (?, ?) ON DUPLICATE KEY UPDATE body = VALUES(body)');
            $n = 0;
            foreach ((is_array($old) ? $old : []) as $num => $c) {
                $num = preg_replace('/\D/', '', (string)$num);
                if ($num === '' || !is_array($c)) continue;
                $up->execute([$num, logEncode($c)]); $n++;
            }
            $res['contacts'] = $n;
        } else $res['contacts'] = 'dilewati (tabel tidak kosong)';
        $n = 0;
        $up = $db->prepare('INSERT INTO dei_wa_sessions (num, ts, turns) VALUES (?, ?, ?) ON DUPLICATE KEY UPDATE ts = VALUES(ts), turns = VALUES(turns)');
        foreach ((array)glob(WA_SESSIONS_DIR . '/*.json') as $f) {   // cek-storage: boleh (impor sekali)
            $d = json_decode((string)@file_get_contents($f), true);
            if (!is_array($d) || empty($d['turns'])) continue;
            $up->execute([basename($f, '.json'), (int)($d['ts'] ?? 0), logEncode($d['turns'])]); $n++;
        }
        $res['sessions'] = $n;
        $n = 0;
        $up = $db->prepare('INSERT INTO dei_conv_state (num, last_at, body) VALUES (?, ?, ?) ON DUPLICATE KEY UPDATE last_at = VALUES(last_at), body = VALUES(body)');
        foreach ((array)readJson(CONV_STATE_FILE, []) as $num => $st) {   // cek-storage: boleh (impor sekali)
            $num = waNormNum($num);
            if ($num === '' || !is_array($st)) continue;
            $up->execute([$num, (int)($st['last_at'] ?? 0), logEncode($st)]); $n++;
        }
        $res['conv_state'] = $n;
        // v1.2.107: db-import-percakapan — convs/*.jsonl (baris terakhir per id) lalu conv-open.json (paling baru)
        if ($force || !(int)$db->query('SELECT COUNT(*) FROM dei_conversations')->fetchColumn()) {
            $all = [];
            $files = (array)glob(CONV_DIR . '/*.jsonl');   // cek-storage: boleh (impor sekali)
            sort($files);
            foreach ($files as $f) {
                $fh = @fopen($f, 'r');
                if (!$fh) continue;
                while (($line = fgets($fh)) !== false) {
                    $c = json_decode($line, true);
                    if (is_array($c) && !empty($c['id'])) $all[(string)$c['id']] = $c;
                }
                fclose($fh);
            }
            foreach ((array)readJson(CONV_OPEN_FILE, []) as $c) {   // cek-storage: boleh (impor sekali)
                if (is_array($c) && !empty($c['id'])) $all[(string)$c['id']] = $c;
            }
            $n = 0;
            $db->beginTransaction();
            foreach ($all as $c) {
                if (empty($c['num']) || empty($c['opened_at']) || empty($c['status'])) continue;
                convDbSave($c); $n++;
            }
            $db->commit();
            $res['conversations'] = $n;
        } else $res['conversations'] = 'dilewati (tabel tidak kosong)';
        echo 'db_import: ' . json_encode($res) . "\n";
        exit(0);
    }

    /* ---------- PUBLIC (v1.2.73): brand per instalasi untuk dashboard ----------
     * Dimuat sinkron di <head> index.html/login.html. Tanpa brand: hanya `window.DEI_BRAND=null`. */
    case 'brand_js': {
        header('Content-Type: application/javascript; charset=utf-8');
        header('Cache-Control: no-cache');
        $b = deiBrand();
        if (!$b) { echo "window.DEI_BRAND=null;\n"; exit; }
        $css = ':root{';
        foreach ((array)($b['css'] ?? []) as $k => $v) {
            if (preg_match('/^--[a-z0-9-]+$/', (string)$k) && preg_match('/^[#0-9a-zA-Z,. ()%-]+$/', (string)$v)) $css .= $k . ':' . $v . ';';
        }
        $css .= '}';
        $pub = ['key' => $b['key'] ?? '', 'vendor' => $b['vendor'], 'product' => $b['product'], 'theme' => $b['theme'] ?? '',
                'c1' => $b['c1'] ?? '', 'c2' => $b['c2'] ?? '', 'palette' => array_values((array)($b['palette'] ?? []))];
        $J = JSON_UNESCAPED_UNICODE | JSON_UNESCAPED_SLASHES | JSON_HEX_TAG;
        echo 'window.DEI_BRAND=' . json_encode($pub, $J) . ";\n";
        echo 'document.write(' . json_encode('<style id="dei-brand-css">' . $css . '</style>', $J) . ");\n";
        echo <<<'JS'
(function (B) {
  function swap(t) { return String(t).replace(/DEI Chatbot/g, B.product).replace(/\bDEI\b/g, B.vendor); }
  document.title = swap(document.title);
  function apply() {
    document.title = swap(document.title);
    var m = document.querySelector('meta[name="theme-color"]'); if (m && B.theme) m.setAttribute('content', B.theme);
    var el = document.querySelectorAll('[data-brand-text]'); for (var i = 0; i < el.length; i++) el[i].innerHTML = swap(el[i].innerHTML);
    var im = document.querySelectorAll('img[alt="DEI"]'); for (var j = 0; j < im.length; j++) im[j].alt = B.vendor;
  }
  if (document.readyState === 'loading') document.addEventListener('DOMContentLoaded', apply); else apply();
})(window.DEI_BRAND);
JS;
        exit;
    }

    case 'cron_tick': {
        $s = getSettings();
        if (PHP_SAPI !== 'cli') {
            // kredensial sama dengan stats_pull: tenant_id + license_key pusat
            $cs = $s['central_server'] ?? [];
            $tidWant = (string)($cs['tenant_id']   ?? '');
            $licWant = (string)($cs['license_key'] ?? '');
            if ($tidWant === '' || $licWant === '') jsonOut(['ok' => false, 'error' => 'Server pusat belum dikonfigurasi.'], 403);
            $tidGot = (string)($_SERVER['HTTP_X_TENANT_ID']   ?? ($_GET['tenant_id']   ?? ''));
            $licGot = (string)($_SERVER['HTTP_X_LICENSE_KEY'] ?? ($_GET['license_key'] ?? ''));
            if (!hash_equals($tidWant, strtolower(trim($tidGot))) || !hash_equals($licWant, trim($licGot))) {
                jsonOut(['ok' => false, 'error' => 'Kredensial pusat tidak cocok.'], 401);
            }
        }
        deiRememberApiUrl();
        if (PHP_SAPI !== 'cli' && !empty($_SERVER['HTTP_X_DEI_FEATURES'])) deiApplyPushedFeatures($_SERVER['HTTP_X_DEI_FEATURES']);   // v1.2.60
        if (PHP_SAPI !== 'cli' && !empty($_SERVER['HTTP_X_DEI_LICENSE'])) deiApplyLicensePush($_SERVER['HTTP_X_DEI_LICENSE'], $s);   // v1.2.111: blokir-total
        if (is_file(LIC_BLOCK_FLAG)) { deiHtaccessBlock(true); jsonOut(['ok' => true, 'version' => DEI_VERSION, 'blocked' => true, 'closed' => [], 'escalated' => []]); }
        $cronLock = @fopen(DATA_DIR . '/cron.lock', 'c');
        if ($cronLock && !@flock($cronLock, LOCK_EX | LOCK_NB)) {
            jsonOut(['ok' => true, 'version' => DEI_VERSION, 'skipped' => 'tick lain masih berjalan']);
        }
        @ignore_user_abort(true);
        @set_time_limit(55);
        $t0 = microtime(true);
        $GLOBALS['dei_dry'] = !empty($_GET['dry']);
        $GLOBALS['esc_dry_log'] = [];
        $r = ['ok' => true, 'version' => DEI_VERSION, 'dry' => $GLOBALS['dei_dry']];
        // v1.2.65: pusat mengirim versi rilis terbaru -> push "Pembaruan baru" ke admin (sekali per rilis)
        if (PHP_SAPI !== 'cli' && !empty($_SERVER['HTTP_X_DEI_LATEST'])) {
            try { $relN = deiReleaseNotify(trim((string)$_SERVER['HTTP_X_DEI_LATEST'])); if ($relN) $r['release'] = $relN; }
            catch (\Throwable $e) { $r['err_release'] = $e->getMessage(); }
        }
        try {
            list($rel, $appr) = waClaimAutoProcess();
            $r['claims_released'] = $rel;
            $r['mode_swept'] = waModeSweepIdle();
        } catch (\Throwable $e) { $r['err_sweep'] = $e->getMessage(); }
        try { $r['closed'] = autoClosingSweep($s); }   catch (\Throwable $e) { $r['closed'] = []; $r['err_closing'] = $e->getMessage(); }
        try { $r['escalated'] = escalationSweep($s); } catch (\Throwable $e) { $r['escalated'] = []; $r['err_escalation'] = $e->getMessage(); }
        try { $r['sessions_purged'] = deiPurgeSessions(); } catch (\Throwable $e) { $r['err_purge'] = $e->getMessage(); }   // v1.2.71
        try { $r['media_purged'] = deiWaMediaSweep(); } catch (\Throwable $e) { $r['err_media'] = $e->getMessage(); }   // v1.2.94: wa-media
        try { $r['conv'] = convSweep(); } catch (\Throwable $e) { $r['err_conv'] = $e->getMessage(); }   // v1.2.101: percakapan
        try { $r['routed'] = deiRouteDrain(20, $s); } catch (\Throwable $e) { $r['err_routing'] = $e->getMessage(); }   // v1.2.100: routing
        try { $wsr = wsRun($s, PHP_SAPI === 'cli' ? 25 : 15); if ($wsr) $r['wa_history'] = $wsr; } catch (\Throwable $e) { $r['err_wa_history'] = $e->getMessage(); }   // v1.2.105: riwayat-wa-waha
        try { $whc = whEnsureCfgCron($s); if ($whc) $r['wa_health_cfg'] = $whc; $whs = whScoreAll($s, false); if ($whs) $r['wa_health'] = count($whs['nums'] ?? []); } catch (\Throwable $e) { $r['err_wa_health'] = $e->getMessage(); }   // v1.2.104: skor-risiko-wa
        // v1.2.71: di server sendiri cron (CLI) yang menyegarkan cache pusat, bukan pesan masuk
        if (PHP_SAPI === 'cli') { try { getLicenseStatus($s); getCapStatus($s); } catch (\Throwable $e) {} }
        if ($GLOBALS['dei_dry']) $r['dry_log'] = $GLOBALS['esc_dry_log'];
        try { $r['stats'] = deiCollectStats(); } catch (\Throwable $e) {}   // v1.2.57: pusat menyimpan sbg statistik terbaru
        $r['ms'] = (int)round((microtime(true) - $t0) * 1000);
        @file_put_contents(DATA_DIR . '/cron-last.json', json_encode([
            'at' => time(), 'at_wib' => wibDate('Y-m-d H:i:s'), 'via' => PHP_SAPI === 'cli' ? 'cli' : 'http',
            'closed' => count($r['closed']), 'escalated' => count($r['escalated']), 'ms' => $r['ms'], 'dry' => $r['dry'],
        ]));
        if ($cronLock) { @flock($cronLock, LOCK_UN); @fclose($cronLock); }
        jsonOut($r);
        break;
    }

    /* ---------- v1.2.56: link "Saya tangani" dari notifikasi darurat (publik, token sekali pakai) ---------- */
    case 'esc_ack': {
        $tok = preg_replace('/[^a-f0-9]/', '', (string)($_GET['t'] ?? ''));
        $res = ($tok === '') ? null : escMutate(function (&$db) use ($tok) {
            $t = $db['tokens'][$tok] ?? null;
            if (!$t || (int)($t['exp'] ?? 0) < time()) return ['err' => 'Link sudah kedaluwarsa atau tidak valid.'];
            $inc = $db['incidents'][$t['inc']] ?? null;
            if (!$inc) return ['err' => 'Insiden tidak ditemukan.'];
            if (!empty($inc['resolved_at'])) return ['done' => true, 'inc' => $inc, 'name' => $t['name'], 'already' => 'Percakapan ini sudah dibalas (' . ($inc['resolved_by'] ?? '-') . ').'];
            if (!empty($inc['ack_at'])) return ['done' => true, 'inc' => $inc, 'name' => $t['name'], 'already' => 'Sudah ditangani oleh ' . $inc['ack_by'] . '.'];
            $db['incidents'][$t['inc']]['ack_by'] = $t['name'];
            $db['incidents'][$t['inc']]['ack_at'] = time();
            return ['done' => true, 'inc' => $db['incidents'][$t['inc']], 'name' => $t['name'], 'incId' => $t['inc']];
        });
        $ok = is_array($res) && !empty($res['done']);
        if ($ok && !empty($res['incId'])) {
            $num = (string)$res['inc']['contact'];
            // hentikan eskalasi; bot mundur supaya tidak menyela orang yang menangani
            convStateMutate(function (&$a) use ($num) { if (isset($a[$num])) $a[$num]['esc_acked'] = 1; }, $num);
            try { waSetMode($num, 'human', 'escalation'); } catch (\Throwable $e) {}
            try { waAuditLog('escalation_ack', $res['name'], $num, ['incident' => $res['incId']]); } catch (\Throwable $e) {}
        }
        $dash = deiDashboardUrl();
        header('Content-Type: text/html; charset=utf-8');
        $h = function ($x) { return htmlspecialchars((string)$x, ENT_QUOTES, 'UTF-8'); };
        echo '<!doctype html><meta charset="utf-8"><meta name="viewport" content="width=device-width,initial-scale=1"><title>Eskalasi</title>'
           . '<body style="font-family:system-ui,sans-serif;max-width:480px;margin:40px auto;padding:0 16px;color:#1b1b1f">';
        if (!$ok) {
            echo '<h2>&#9888;&#65039; Tidak bisa diproses</h2><p>' . $h($res['err'] ?? 'Token tidak valid.') . '</p>';
        } else {
            $num = (string)$res['inc']['contact'];
            echo '<h2>&#9989; ' . (!empty($res['already']) ? $h($res['already']) : 'Ditandai: ' . $h($res['name']) . ' menangani') . '</h2>'
               . '<p>Kontak: <b>+' . $h($num) . '</b><br>Pesan: &ldquo;' . $h($res['inc']['message'] ?? '') . '&rdquo;</p>'
               . '<p>Eskalasi dihentikan dan bot berhenti membalas nomor ini. Segera balas tamu lewat dashboard atau WhatsApp.</p>'
               . '<p><a href="' . $h($dash) . '" style="display:inline-block;background:#140383;color:#fff;padding:10px 16px;border-radius:8px;text-decoration:none">Buka Dashboard</a> '
               . '<a href="https://wa.me/' . $h($num) . '" style="display:inline-block;background:#25d366;color:#fff;padding:10px 16px;border-radius:8px;text-decoration:none">Chat via WhatsApp</a></p>';
        }
        echo '</body>';
        exit;
    }

    /* ---------- v1.2.56: kirim alarm uji ke kontak eskalasi ---------- */
    case 'esc_test': {
        requireAuth(['super_admin', 'admin']);
        $s = getSettings();
        $in = bodyInput();
        $GLOBALS['dei_dry'] = !empty($in['dry']);
        $GLOBALS['esc_dry_log'] = [];
        $ec = deiEscConf($s);
        $level = (int)($in['level'] ?? 1) === 2 ? 2 : 1;
        $contacts = $level === 1 ? $ec['l1'] : $ec['l2'];
        if (empty($contacts)) jsonOut(['ok' => false, 'error' => 'Belum ada kontak di Level ' . $level . '.'], 400);
        $tenant = deiTenantName($s);
        $text = "\xF0\x9F\xA7\xAA TES ALARM \xE2\x80\x94 " . $tenant . "\nIni uji notifikasi eskalasi Level " . $level . ". Tidak ada tamu yang menunggu.";
        $res = escNotifyContacts($s, $ec, $contacts, 'TES ALARM - ' . $tenant, $text, [$tenant, '0', 'TES', 'Uji notifikasi'], '');
        jsonOut(['ok' => true, 'results' => $res, 'dry_log' => $GLOBALS['esc_dry_log']]);
        break;
    }

    /* ---------- v1.2.56: daftar insiden + status cron (dashboard) ---------- */
    case 'esc_incidents': {
        requireAuth(['super_admin', 'admin', 'supervisor']);
        $db = readJson(ESC_FILE, []);
        $list = [];
        foreach ((array)($db['incidents'] ?? []) as $id => $inc) {
            $inc['id'] = $id;
            $inc['contact_name'] = waContactName($inc['contact'] ?? '');
            $end = (int)($inc['ack_at'] ?: $inc['resolved_at']);
            $inc['response_sec'] = $end > 0 ? max(0, $end - (int)$inc['opened_at']) : null;
            $list[] = $inc;
        }
        usort($list, function ($a, $b) { return (int)$b['opened_at'] - (int)$a['opened_at']; });
        $done = array_filter($list, function ($x) { return $x['response_sec'] !== null; });
        $avg = count($done) ? (int)round(array_sum(array_column($done, 'response_sec')) / count($done)) : null;
        $sebelumL2 = count(array_filter($list, function ($x) { return (int)$x['level'] < 2; }));
        jsonOut(['ok' => true, 'incidents' => array_slice($list, 0, 100), 'cron' => readJson(DATA_DIR . '/cron-last.json', null),
                 'summary' => ['total' => count($list), 'avg_response_sec' => $avg, 'handled_before_l2' => $sebelumL2]]);
        break;
    }

    /* ---------- v1.2.56: PUBLIC — closing di widget web (dipicu timer browser) ---------- */
    case 'web_closing': {
        if ($_SERVER['REQUEST_METHOD'] !== 'POST') jsonOut(['ok' => false, 'error' => 'Method not allowed'], 405);
        $s = getSettings();
        $ac = deiAcConf($s);
        if (!$ac['enabled'] || !deiInHours($ac['hours'])) jsonOut(['ok' => true, 'skip' => 'off']);
        $in = bodyInput();
        $convId = trim((string)($in['conversation_id'] ?? ''));
        $visitorId = trim((string)($in['visitor_id'] ?? ''));
        if ($convId === '' || $visitorId === '') jsonOut(['ok' => false, 'error' => 'conversation_id and visitor_id required'], 400);
        $convs = webConvReadAll();
        $idx = webConvFind($convs, $convId);
        if ($idx < 0 || ($convs[$idx]['visitor_id'] ?? '') !== $visitorId) jsonOut(['ok' => false, 'error' => 'Conversation not found'], 404);
        $msgs = webConvLoadMessages($convId);
        $last = end($msgs);
        if (!$last || ($last['role'] ?? '') !== 'assistant' || !empty($last['closing'])) jsonOut(['ok' => true, 'skip' => 'not_due']);
        $lastTs = strtotime((string)($last['ts'] ?? '')) ?: 0;
        if ($lastTs > 0 && (time() - $lastTs) < $ac['minutes'] * 60 - 30) jsonOut(['ok' => true, 'skip' => 'too_early']);
        $lastUser = '';
        for ($i = count($msgs) - 1; $i >= 0; $i--) { if (($msgs[$i]['role'] ?? '') === 'user') { $lastUser = (string)$msgs[$i]['content']; break; } }
        if ($lastUser === '' || deiIsClosingPhrase($lastUser)) jsonOut(['ok' => true, 'skip' => 'guest_bye']);
        $lang = deiDeteksiBahasa($lastUser);
        $text = deiAcText($ac, $lang === 'en' ? 'en' : 'id');
        $msgs[] = ['role' => 'assistant', 'content' => $text, 'ts' => date('Y-m-d H:i:s'), 'closing' => true];
        webConvSaveMessages($convId, $msgs);
        jsonOut(['ok' => true, 'text' => $text, 'phone' => $ac['phone']]);
        break;
    }

    case 'wa_claim': {
        $u = requireAuth(['super_admin','admin','wa_agent']);
        $in = bodyInput();
        $num = waNormNum($in['number'] ?? '');
        if ($num === '') jsonOut(['ok' => false, 'error' => 'number wajib'], 400);

        // Run auto-process dulu supaya state fresh
        waClaimAutoProcess();

        // Cek current claim (mungkin sudah expired dan baru saja di-auto-release)
        $current = waClaimGet($num);
        if ($current) {
            $owner = $current['agent_username'] ?? '';
            if ($owner !== '' && $owner !== $u['username']) {
                jsonOut([
                    'ok' => false,
                    'error' => 'Chat sudah di-claim oleh ' . $owner . '. Gunakan take-over kalau butuh.',
                    'current_owner' => $owner,
                    'claimed_at' => $current['claimed_at'] ?? null,
                ], 409);
            }
        }

        $claim = [
            'agent_username' => $u['username'],
            'claimed_at' => time(),
            'last_agent_activity' => time(),
        ];
        if (!waClaimSet($num, $claim)) {
            jsonOut(['ok' => false, 'error' => 'Gagal menyimpan claim state'], 500);
        }
        waAuditLog('claim', $u['username'], $num);
        agentEvent('claim', $u['username'], $num);   // v1.2.58
        jsonOut([
            'ok' => true,
            'number' => $num,
            'claim' => $claim,
            'mode' => 'human',
        ]);
        break;
    }

    case 'wa_release': {
        $u = requireAuth(['super_admin','admin','wa_agent']);
        $in = bodyInput();
        $num = waNormNum($in['number'] ?? '');
        if ($num === '') jsonOut(['ok' => false, 'error' => 'number wajib'], 400);

        $current = waClaimGet($num);
        if (!$current) {
            jsonOut([
                'ok' => true,
                'number' => $num,
                'note' => 'Sudah tidak claimed (bot mode)',
                'mode' => 'bot',
            ]);
            break;
        }

        deiGuardSpvScope($u, $num);   // v1.2.59
        // Admin bisa release siapa saja, wa_agent hanya release milik sendiri
        $isAdmin = in_array($u['role'], ['super_admin','admin','supervisor']);   // v1.2.58
        $owner = $current['agent_username'] ?? '';
        if (!$isAdmin && $owner !== $u['username']) {
            jsonOut([
                'ok' => false,
                'error' => 'Chat bukan milik Anda. Hanya admin yang bisa release chat agent lain.',
                'current_owner' => $owner,
            ], 403);
        }

        if (!waClaimSet($num, null)) {
            jsonOut(['ok' => false, 'error' => 'Gagal release'], 500);
        }
        $action = ($owner === $u['username']) ? 'release' : 'admin_release';
        waAuditLog($action, $u['username'], $num, ['from_agent' => $owner]);
        agentEvent('release', $owner, $num, ['by' => $u['username']]);   // v1.2.58
        jsonOut([
            'ok' => true,
            'number' => $num,
            'released_by' => $u['username'],
            'mode' => 'bot',
        ]);
        break;
    }

    /* v1.2.101: percakapan — endpoint */
    /* ---------- v1.2.101: percakapan — tandai selesai (tombol "Selesai" di thread) ---------- */
    case 'wa_resolve': {
        $u = requireAuth(['super_admin', 'admin', 'wa_agent']);
        $in = bodyInput();
        $num = waNormNum($in['number'] ?? '');
        if ($num === '') jsonOut(['ok' => false, 'error' => 'number wajib'], 400);
        deiGuardSpvScope($u, $num);
        $cl = waClaimGet($num);
        $owner = $cl ? (string)($cl['agent_username'] ?? '') : '';
        $isAdmin = in_array($u['role'], ['super_admin', 'admin', 'supervisor'], true);
        if (!$isAdmin && $owner !== '' && $owner !== $u['username']) {
            jsonOut(['ok' => false, 'error' => 'Chat ini dipegang ' . $owner . '. Hanya pemegang chat atau admin yang bisa menandai selesai.'], 403);
        }
        $ok = convTrack($num, 'resolve', ['agent' => $u['username']]);
        $c = convStoreGet($num);
        if (!$ok && !convIsFinal($c)) jsonOut(['ok' => false, 'error' => 'Tidak ada percakapan aktif untuk nomor ini.'], 409);
        // selesai = chat dilepas: Mode AI kembali ke bot, Mode Manual kembali ke antrean untuk pesan berikutnya
        if ($cl) {
            waClaimSet($num, null);
            agentEvent('release', $owner, $num, ['by' => $u['username'], 'resolve' => 1]);
        } else {
            waSetMode($num, 'bot');
        }
        try { convStateMutate(function (&$a) use ($num, $u) {
            $st = is_array($a[$num] ?? null) ? $a[$num] : ['last_at' => time()];
            $st['res_at'] = time(); $st['res_by'] = $u['username']; $st['guest_waiting_since'] = 0;
            $st['esc_level'] = 0; $st['esc_inc'] = '';
            $a[$num] = $st;
        }, $num); } catch (\Throwable $e) { error_log('wa_resolve conv-state: ' . $e->getMessage()); }
        waAuditLog('resolve', $u['username'], $num, ['from_agent' => $owner]);
        jsonOut(['ok' => true, 'number' => $num, 'conv' => convPublic($c)]);
        break;
    }

    /* ---------- v1.2.101: laporan kinerja layanan (dari record percakapan) ---------- */
    case 'conv_report':
    case 'conv_list':
    case 'conv_export': {
        $u = requireAuth(['super_admin', 'admin', 'supervisor']);
        $todayWib = wibToday();
        $fromD = (string)($_GET['from'] ?? wibDate('Y-m-01'));
        $toD   = (string)($_GET['to'] ?? $todayWib);
        $fromTs = wibDayStart($fromD); $toTs = wibDayStart($toD);
        if ($fromTs === null || $toTs === null || $toTs < $fromTs) jsonOut(['ok' => false, 'error' => 'Rentang tanggal tidak valid (YYYY-MM-DD).'], 400);
        $days = (int)(($toTs - $fromTs) / 86400) + 1;
        if ($days > 93) jsonOut(['ok' => false, 'error' => 'Rentang maksimal 93 hari (3 bulan).'], 400);
        $toTs += 86399;
        $ch = (string)($_GET['ch'] ?? '');
        $s = getSettings();
        $chLabels = [];
        foreach (waChannels($s) as $x) $chLabels[(string)$x['id']] = (string)$x['label'];
        $filt = function ($recs) use ($ch) {
            if ($ch === '') return $recs;
            return array_values(array_filter($recs, function ($c) use ($ch) { return ((string)($c['ch'] ?? '') ?: 'utama') === $ch; }));
        };
        $recs = $filt(convStoreRange($fromTs, $toTs));

        if ($action === 'conv_report') {
            $cur = convStats($recs, $fromTs, $toTs, $chLabels);
            $pTo = $fromTs - 1; $pFrom = $fromTs - $days * 86400;
            $prevRecs = $filt(convStoreRange($pFrom, $pTo));
            $prev = convStats($prevRecs, $pFrom, $pTo, $chLabels);
            $users = readJson(USERS_FILE, []); $names = [];
            foreach ((array)$users as $us) $names[$us['username'] ?? ''] = $us['name'] ?? ($us['username'] ?? '');
            foreach ($cur['agents'] as &$r) $r['name'] = $names[$r['agent']] ?? $r['agent'];
            unset($r);
            jsonOut(['ok' => true, 'from' => $fromD, 'to' => $toD, 'days' => $days,
                'prev' => ['from' => wibDate('Y-m-d', $pFrom), 'to' => wibDate('Y-m-d', $pTo), 'totals' => $prev['totals'], 'avg' => $prev['avg'], 'has_data' => count($prevRecs) > 0],
                'channels_all' => count($chLabels) > 1 ? array_map(function ($k, $v) { return ['id' => $k, 'label' => $v]; }, array_keys($chLabels), $chLabels) : [],
                'tracking_since' => convTrackingSince(),
                'timeout_hours' => (int)(CONV_TIMEOUT_SEC / 3600), 'reopen_minutes' => (int)(CONV_REOPEN_SEC / 60),
            ] + $cur);
        }

        // daftar / CSV
        $kind = (string)($_GET['kind'] ?? '');
        $keep = function ($c) use ($kind) {
            $st = (string)($c['status'] ?? '');
            $hand = (int)($c['handover_at'] ?? 0); $bot = (int)($c['bot_msgs'] ?? 0) > 0;
            switch ($kind) {
                case 'unassigned':   return $st === 'handover';
                case 'in_progress':  return in_array($st, ['open', 'handover', 'assigned'], true);
                case 'assigned':     return (int)($c['assigned_at'] ?? 0) > 0;
                case 'resolved':     return $st === 'resolved';
                case 'bot_resolved': return $st === 'resolved' && $bot && !$hand && (int)($c['agent_msgs'] ?? 0) === 0;
                case 'to_agent':     return $bot && $hand;
                case 'expired':      return $st === 'expired';
                default:             return true;
            }
        };
        $agentF = (string)($_GET['agent'] ?? '');
        $rows = [];
        foreach (array_reverse($recs) as $c) {
            if (!$keep($c)) continue;
            if ($agentF !== '' && (string)($c['agent'] ?? '') !== $agentF) continue;
            $rows[] = $c;
        }
        if ($action === 'conv_export') {
            $names = convContactNames($rows);
            header('Content-Type: text/csv; charset=utf-8');
            header('Content-Disposition: attachment; filename="percakapan-' . $fromD . '_' . $toD . '.csv"');
            $out = fopen('php://output', 'w');
            fwrite($out, "\xEF\xBB\xBF");
            $tgl = function ($t) { return $t ? wibDate('Y-m-d H:i:s', (int)$t) : ''; };
            $dur = function ($a, $b) { return ($a && $b && $b >= $a) ? ($b - $a) : ''; };
            fputcsv($out, ['ID', 'Nomor', 'Nama', 'Nomor bisnis', 'Asal', 'Status', 'Dibuka', 'Balasan pertama', 'Serah ke agent', 'Alasan serah', 'Di-assign', 'Agent', 'Balasan agent pertama', 'Selesai', 'Diselesaikan oleh',
                           'Pesan pelanggan', 'Pesan bot', 'Pesan agent', 'FRT (dtk)', 'FRT agent (dtk)', 'Waktu antre (dtk)', 'Waktu selesai (dtk)', 'Dibuka ulang']);
            foreach ($rows as $c) {
                $rb = (string)($c['resolved_by'] ?? '');
                fputcsv($out, [$c['id'], '+' . $c['num'], $names[$c['num']] ?? '', $chLabels[(string)($c['ch'] ?? '') ?: 'utama'] ?? ($c['ch'] ?? ''), $c['origin'] ?? '', $c['status'],
                    $tgl($c['opened_at']), $tgl($c['first_reply_at']), $tgl($c['handover_at']), $c['handover_reason'] ?? '', $tgl($c['assigned_at']), $c['agent'] ?? '', $tgl($c['first_agent_at']),
                    $tgl($c['resolved_at']), $rb === 'agent' ? ('agent: ' . ($c['resolver'] ?? '')) : $rb,
                    (int)$c['guest_msgs'], (int)$c['bot_msgs'], (int)$c['agent_msgs'],
                    $dur($c['opened_at'], $c['first_reply_at']), $dur(max((int)$c['handover_at'], (int)$c['opened_at']), $c['first_agent_at']),
                    $dur($c['handover_at'], $c['assigned_at']), $dur($c['opened_at'], $c['resolved_at']), (int)($c['reopen_n'] ?? 0)]);
            }
            fclose($out);
            exit;
        }
        $per = max(10, min(200, (int)($_GET['per'] ?? 50)));
        $page = max(1, (int)($_GET['page'] ?? 1));
        $slice = array_slice($rows, ($page - 1) * $per, $per);
        $names = convContactNames($slice);
        $list = [];
        foreach ($slice as $c) { $p = convPublic($c); $p['name'] = $names[$c['num']] ?? ''; $p['ch_label'] = $chLabels[(string)($c['ch'] ?? '') ?: 'utama'] ?? ''; $list[] = $p; }
        jsonOut(['ok' => true, 'total' => count($rows), 'page' => $page, 'per' => $per, 'rows' => $list]);
        break;
    }

    case 'wa_conversations_v2': {
        $u = requireAuth(['super_admin','admin','wa_agent']);
        $me = $u['username'];
        $isAdmin = in_array($u['role'], ['super_admin','admin','supervisor']);   // v1.2.58

        // Auto-process expired claims + takeover requests
        list($autoReleased, $autoApproved) = waClaimAutoProcess();
        waModeSweepIdle();   // v1.2.37: supaya lencana status tidak basi

        $filter = $_GET['filter'] ?? 'all';  // all|mine|unclaimed|others|takeover_requests

        // Read chat log untuk dapatkan list nomor + last message
        $logs = logReadAll();
        $numbers = [];  // num => {last_ts, last_q, last_a, count, awaiting}
        foreach ($logs as $e) {
            if (($e['channel'] ?? '') !== 'whatsapp') continue;
            $num = waNormNum($e['ip'] ?? '');
            if ($num === '') continue;
            if (!isset($numbers[$num])) {
                $numbers[$num] = [
                    'last_ts' => $e['ts'] ?? '',
                    'last_q' => $e['q'] ?? '',
                    'last_a' => $e['a'] ?? '',
                    'count' => 0,
                    'awaiting' => !empty($e['awaiting']),
                    // v1.2.17: dipakai filter "Perlu Perhatian". Entri pertama yang
                    // ditemui = entri TERAKHIR (log disimpan terbaru-dulu).
                    'last_dir' => $e['dir'] ?? '',
                    'bot_failed' => (!empty($e['cap_reached']) || !empty($e['suspended']) || !empty($e['ai_error'])),
                    'has_manual' => false,   // v1.2.58
                ];
            }
            $numbers[$num]['count']++;
            if (($e['dir'] ?? '') === 'manual') $numbers[$num]['has_manual'] = true;
        }
        // v1.2.105: riwayat-wa-waha — nomor yang hanya punya riwayat sebelum terhubung ikut tampil (status Selesai)
        $wiIx = []; try { $wiIx = wiIndexAll(); } catch (\Throwable $e) {}
        foreach ($wiIx as $wiNum => $wiR) {
            $wiNum = (string)$wiNum;
            if (isset($numbers[$wiNum]) || !is_array($wiR)) continue;
            $wiIn = (($wiR['last_d'] ?? '') === 'in');
            $numbers[$wiNum] = ['last_ts' => (string)($wiR['last_ts'] ?? ''), 'last_q' => $wiIn ? (string)($wiR['last_t'] ?? '') : '',
                                'last_a' => $wiIn ? '' : (string)($wiR['last_t'] ?? ''), 'count' => (int)($wiR['count'] ?? 0),
                                'awaiting' => false, 'last_dir' => 'history', 'bot_failed' => false, 'has_manual' => true, 'history_only' => true];
        }

        // v1.2.58: flag status + privasi agent + daftar agent untuk assign
        $s58 = getSettings();
        $isManual = deiIsManual($s58);
        $agentPrivate = deiTeamConf($s58)['agent_private'] && $u['role'] === 'wa_agent';
        $spvScope = deiSpvScope($u);   // v1.2.59: supervisor hanya lihat chat timnya
        $convState = convStateReadAll();
        if (!is_array($convState)) $convState = [];
        $agentReplied = waAgentRepliedAll();
        $nowTs = time();

        // Get semua claim state sekaligus (1 file read)
        $allClaims = waClaimGetAll();
        $allContacts = waGetContacts();   // v1.2.19: 1 file read untuk semua nomor
        $chMulti = waMultiOn(waConf($s58), $s58);   // v1.2.98: multi-nomor
        $chList = $chMulti ? waChannels($s58) : [];
        $chMap = []; foreach ($chList as $chx) $chMap[$chx['id']] = $chx['label'];
        $chF = preg_replace('/[^A-Za-z0-9_]/', '', (string)($_GET['ch'] ?? ''));
        if (!isset($chMap[$chF])) $chF = '';
        $allLeads = leadsGetAll();        // v1.2.21: tandai nomor yang sudah punya kartu lead

        // Build result with claim state
        $result = [];
        $cntToday = 0; $cntAttention = 0;   // v1.2.17
        $cntFlag = ['unreplied' => 0, 'done' => 0, 'full_bot' => 0, 'active' => 0];   // v1.2.58
        $visible = [];                      // v1.2.58: nomor yang boleh dilihat user ini
        $todayStr = date('Y-m-d');          // sejam dengan penulisan log (date(), bukan WIB helper)
        foreach ($numbers as $num => $meta) {
            $claim = $allClaims[$num] ?? null;
            // v1.2.58: agent hanya melihat chat yang belum diklaim + miliknya
            // (+ chat yang sedang ia minta take-over).
            if ($agentPrivate && $claim && ($claim['agent_username'] ?? '') !== $me
                && (($claim['takeover_request']['requester'] ?? '') !== $me)) continue;
            if ($spvScope !== null && !deiSpvSeesOwner($spvScope, (string)($claim['agent_username'] ?? ''))) continue;   // v1.2.59
            $numCh = '';   // v1.2.98: multi-nomor
            if ($chMulti) { $cc = (string)($allContacts[$num]['wa_ch'] ?? ''); $numCh = isset($chMap[$cc]) ? $cc : 'utama'; }
            if ($chF !== '' && $numCh !== $chF) continue;
            $visible[$num] = true;
            $fl = deiChatFlag((string)$num, $meta, $convState, $agentReplied, $nowTs);
            if ($isManual) $fl['full_bot'] = false;   // tidak ada bot di mode Manual
            if (!empty($meta['history_only'])) $fl = ['flag' => 'done', 'flag_note' => 'Riwayat sebelum terhubung', 'waiting_sec' => 0, 'last_from' => $fl['last_from'], 'full_bot' => false];   // v1.2.105
            $cntFlag[$fl['flag']]++;
            if ($fl['full_bot']) $cntFlag['full_bot']++;
            $mode = $claim ? 'human' : waGetMode($num);  // fallback ke waGetMode kalau tidak claimed
            $status = 'bot';
            if ($claim) {
                $status = 'claimed';
                if (!empty($claim['takeover_request'])) $status = 'takeover_requested';
            } elseif ($mode === 'human') {
                // human mode tapi tidak ada claim (auto-handoff via keyword, atau legacy)
                $status = 'human_unclaimed';
            }

            // v1.2.17: perlu perhatian = belum dibalas manual DAN (bot gagal ATAU menggantung ke manusia)
            $isToday = (substr((string)$meta['last_ts'], 0, 10) === $todayStr) && empty($meta['history_only']);   // v1.2.105
            $needsAttention = false;
            if (($meta['last_dir'] ?? '') !== 'manual') {
                if (!empty($meta['bot_failed'])) {
                    $needsAttention = true;
                } elseif ($status === 'human_unclaimed' || !empty($meta['awaiting'])) {
                    $needsAttention = true;
                }
            }
            if ($isToday) $cntToday++;
            if ($needsAttention) $cntAttention++;

            $item = [
                'number' => $num,
                'name' => waContactName($num, $allContacts),   // v1.2.19
                'has_lead' => isset($allLeads[$num]),          // v1.2.21
                'stage' => waContactStage($num, $allContacts), // v1.2.39
                'vip' => waContactVip($num, $allContacts),     // v1.2.39
                'last_ts' => $meta['last_ts'],
                'needs_attention' => $needsAttention,
                'last_q' => mb_substr($meta['last_q'] ?? '', 0, 200),
                'last_a' => mb_substr($meta['last_a'] ?? '', 0, 100),
                'count' => $meta['count'],
                'awaiting' => $meta['awaiting'],
                'mode' => $mode,
                'status' => $status,
                'claim' => $claim,
                'flag' => $fl['flag'],              // v1.2.58: unreplied|done|active
                'flag_note' => $fl['flag_note'],
                'waiting_sec' => $fl['waiting_sec'],
                'full_bot' => $fl['full_bot'],
                'last_from' => $fl['last_from'],
                'ch' => $numCh, 'ch_label' => $numCh !== '' ? $chMap[$numCh] : '',   // v1.2.98: multi-nomor
                'has_history' => isset($wiIx[$num]), 'history_only' => !empty($meta['history_only']),   // v1.2.105: riwayat-wa-waha
            ];

            // Apply filter
            $show = false;
            switch ($filter) {
                case 'mine':
                    $show = $claim && ($claim['agent_username'] ?? '') === $me;
                    break;
                case 'unclaimed':
                    // Termasuk bot mode DAN human tanpa claim (menunggu di-pick up)
                    $show = !$claim;
                    break;
                case 'others':
                    $show = $claim && ($claim['agent_username'] ?? '') !== $me;
                    break;
                case 'takeover_requests':
                    // Filter untuk Phase 3 — sekarang belum ada takeover, return kosong
                    if ($claim && !empty($claim['takeover_request'])) {
                        $req = $claim['takeover_request'];
                        $isTarget = ($claim['agent_username'] ?? '') === $me;
                        $isRequester = ($req['requester'] ?? '') === $me;
                        $show = $isAdmin || $isTarget || $isRequester;
                    }
                    break;
                case 'today':               // v1.2.17
                    $show = $isToday;
                    break;
                case 'attention':           // v1.2.17
                    $show = $needsAttention;
                    break;
                case 'unreplied':           // v1.2.58
                case 'done':
                    $show = ($fl['flag'] === $filter);
                    break;
                case 'full_bot':
                    $show = $fl['full_bot'];
                    break;
                case 'all':
                default:
                    $show = true;
            }
            if ($show) $result[] = $item;
        }

        // Sort by last_ts desc
        usort($result, function ($a, $b) {
            return strcmp($b['last_ts'] ?? '', $a['last_ts'] ?? '');
        });

        // Counts per filter (untuk badge)
        $counts = ['all' => count($visible), 'mine' => 0, 'unclaimed' => 0, 'others' => 0, 'takeover_requests' => 0, 'today' => $cntToday, 'attention' => $cntAttention,
                   'unreplied' => $cntFlag['unreplied'], 'done' => $cntFlag['done'], 'full_bot' => $cntFlag['full_bot']];  // v1.2.17 + v1.2.58
        foreach ($numbers as $num => $meta) {
            if (!isset($visible[$num])) continue;   // v1.2.58
            $claim = $allClaims[$num] ?? null;
            if (!$claim) {
                $counts['unclaimed']++;
            } elseif (($claim['agent_username'] ?? '') === $me) {
                $counts['mine']++;
            } else {
                $counts['others']++;
            }
            if ($claim && !empty($claim['takeover_request'])) {
                $req = $claim['takeover_request'];
                if ($isAdmin || ($claim['agent_username'] ?? '') === $me || ($req['requester'] ?? '') === $me) {
                    $counts['takeover_requests']++;
                }
            }
        }

        jsonOut([
            'ok' => true,
            'conversations' => $result,
            'counts' => $counts,
            'auto_processed' => ['released' => $autoReleased, 'approved' => $autoApproved],
            'me' => $me,
            'is_admin' => $isAdmin,
            'filter' => $filter,
            // v1.2.58
            'role' => $u['role'],
            'reply_mode' => $isManual ? 'manual' : 'ai',
            'agent_private' => $agentPrivate,
            'spv_team' => $spvScope !== null,   // v1.2.59
            'channels' => $chList, 'ch' => $chF,   // v1.2.98: multi-nomor
            'agents' => deiIsLead($u['role']) ? deiAssignableUsers($u) : [],
        ]);
        break;
    }

    /* ============================================================
     *  v1.2.0 WA CLAIM — Endpoint: audit log viewer
     * ============================================================ */

    /* ============================================================
     *  v1.2.0 WA CLAIM — Endpoints: take-over workflow (Phase 3)
     * ============================================================ */

    case 'wa_takeover_request': {
        // Hanya wa_agent yang request; admin pakai wa_admin_takeover
        $u = requireAuth(['wa_agent']);
        $in = bodyInput();
        $num = waNormNum($in['number'] ?? '');
        $reason = trim((string)($in['reason'] ?? ''));
        if (mb_strlen($reason) > 500) $reason = mb_substr($reason, 0, 500);
        if ($num === '') jsonOut(['ok' => false, 'error' => 'number wajib'], 400);

        waClaimAutoProcess();

        $current = waClaimGet($num);
        if (!$current) {
            jsonOut(['ok' => false, 'error' => 'Chat tidak claimed. Silakan claim langsung dengan wa_claim.'], 400);
        }
        if (($current['agent_username'] ?? '') === $u['username']) {
            jsonOut(['ok' => false, 'error' => 'Chat sudah milik Anda.'], 400);
        }
        if (!empty($current['takeover_request'])) {
            $existing = $current['takeover_request'];
            if (($existing['requester'] ?? '') === $u['username']) {
                jsonOut([
                    'ok' => true,
                    'note' => 'Request Anda masih pending',
                    'requested_at' => $existing['requested_at'] ?? null,
                    'auto_approve_in_seconds' => max(0, 300 - (time() - ($existing['requested_at'] ?? time()))),
                ]);
                break;
            } else {
                jsonOut([
                    'ok' => false,
                    'error' => 'Sudah ada request take-over pending dari ' . ($existing['requester'] ?? 'agent lain'),
                ], 409);
            }
        }

        // Set request
        $current['takeover_request'] = [
            'requester' => $u['username'],
            'requested_at' => time(),
            'reason' => $reason,
        ];
        if (!waClaimSet($num, $current)) {
            jsonOut(['ok' => false, 'error' => 'Gagal simpan request'], 500);
        }
        waAuditLog('takeover_request', $u['username'], $num, [
            'target_agent' => $current['agent_username'] ?? '',
            'reason' => $reason,
        ]);
        jsonOut([
            'ok' => true,
            'number' => $num,
            'target_agent' => $current['agent_username'] ?? '',
            'auto_approve_in_seconds' => 300,
            'note' => 'Request pending. Kalau owner tidak respond dalam 5 menit, request auto-approved.',
        ]);
        break;
    }

    case 'wa_takeover_respond': {
        $u = requireAuth(['super_admin','admin','wa_agent']);
        $in = bodyInput();
        $num = waNormNum($in['number'] ?? '');
        $decisionRaw = strtolower(trim((string)($in['decision'] ?? '')));
        if ($num === '') jsonOut(['ok' => false, 'error' => 'number wajib'], 400);
        if (!in_array($decisionRaw, ['approve', 'deny'])) {
            jsonOut(['ok' => false, 'error' => 'decision harus "approve" atau "deny"'], 400);
        }

        $current = waClaimGet($num);
        if (!$current || empty($current['takeover_request'])) {
            jsonOut(['ok' => false, 'error' => 'Tidak ada take-over request untuk nomor ini'], 404);
        }
        $req = $current['takeover_request'];
        $owner = $current['agent_username'] ?? '';
        $isAdmin = in_array($u['role'], ['super_admin','admin','supervisor']);   // v1.2.58

        // Only owner atau admin yang boleh respond
        if (!$isAdmin && $owner !== $u['username']) {
            jsonOut(['ok' => false, 'error' => 'Hanya owner chat atau admin yang bisa respond request'], 403);
        }

        if ($decisionRaw === 'approve') {
            $current['agent_username'] = $req['requester'];
            $current['claimed_at'] = time();
            $current['last_agent_activity'] = time();
            unset($current['takeover_request']);
            waClaimSet($num, $current);
            waAuditLog('takeover_approve', $u['username'], $num, [
                'from_agent' => $owner,
                'to_agent' => $req['requester'],
                'requester_reason' => $req['reason'] ?? '',
            ]);
            jsonOut([
                'ok' => true,
                'number' => $num,
                'decision' => 'approve',
                'new_owner' => $req['requester'],
                'from_agent' => $owner,
            ]);
        } else {
            unset($current['takeover_request']);
            waClaimSet($num, $current);
            waAuditLog('takeover_deny', $u['username'], $num, [
                'requester' => $req['requester'],
                'kept_owner' => $owner,
            ]);
            jsonOut([
                'ok' => true,
                'number' => $num,
                'decision' => 'deny',
                'requester' => $req['requester'],
                'kept_owner' => $owner,
            ]);
        }
        break;
    }

    case 'wa_admin_takeover': {
        $u = requireAuth(['super_admin', 'admin', 'supervisor']);
        $in = bodyInput();
        $num = waNormNum($in['number'] ?? '');
        $reason = trim((string)($in['reason'] ?? 'admin_action'));
        if (mb_strlen($reason) > 500) $reason = mb_substr($reason, 0, 500);
        if ($num === '') jsonOut(['ok' => false, 'error' => 'number wajib'], 400);

        deiGuardSpvScope($u, $num);   // v1.2.59
        $current = waClaimGet($num);
        $oldAgent = $current['agent_username'] ?? '(none)';

        // Force claim untuk admin ini
        $claim = [
            'agent_username' => $u['username'],
            'claimed_at' => time(),
            'last_agent_activity' => time(),
        ];
        if (!waClaimSet($num, $claim)) {
            jsonOut(['ok' => false, 'error' => 'Gagal admin_takeover'], 500);
        }
        waAuditLog('admin_takeover', $u['username'], $num, [
            'from_agent' => $oldAgent,
            'reason' => $reason,
        ]);
        jsonOut([
            'ok' => true,
            'number' => $num,
            'from_agent' => $oldAgent,
            'new_owner' => $u['username'],
            'reason' => $reason,
        ]);
        break;
    }

    /* ============================================================
     *  v1.2.58: TIM — assign chat, info tim, laporan per agent
     * ============================================================ */
    case 'wa_assign': {
        $u = requireAuth(['super_admin', 'admin', 'supervisor']);
        $in = bodyInput();
        $num = waNormNum($in['number'] ?? '');
        $to  = trim((string)($in['agent'] ?? ''));
        if ($num === '' || $to === '') jsonOut(['ok' => false, 'error' => 'number & agent wajib'], 400);
        $target = null;
        foreach (deiAssignableUsers($u) as $au) { if ($au['username'] === $to) { $target = $au; break; } }
        if (!$target) jsonOut(['ok' => false, 'error' => 'Agent tidak ditemukan, di luar tim Anda, atau di luar batas paket.'], 404);
        deiGuardSpvScope($u, $num);   // v1.2.59
        waClaimAutoProcess();
        $current = waClaimGet($num);
        $from = $current['agent_username'] ?? '';
        if ($from === $to) jsonOut(['ok' => true, 'number' => $num, 'agent' => $to, 'note' => 'Sudah dipegang agent ini']);
        $claim = [
            'agent_username'      => $to,
            'claimed_at'          => time(),
            'last_agent_activity' => time(),
            'assigned_by'         => $u['username'],
        ];
        if (!waClaimSet($num, $claim)) jsonOut(['ok' => false, 'error' => 'Gagal menyimpan assign'], 500);
        waAuditLog('assign', $u['username'], $num, ['from_agent' => $from !== '' ? $from : '(none)', 'to_agent' => $to]);
        agentEvent('assign', $to, $num, ['by' => $u['username'], 'from' => $from]);
        try {
            $nm = waContactName($num);
            sendPushToUsers([$to], 'Chat diserahkan ke Anda', '+' . $num . ($nm ? ' (' . $nm . ')' : '') . ' — dari ' . $u['username'], deiDashboardUrl());
        } catch (\Throwable $e) { error_log('wa_assign push: ' . $e->getMessage()); }
        jsonOut(['ok' => true, 'number' => $num, 'agent' => $to, 'from_agent' => $from]);
        break;
    }

    case 'wa_set_ch': {   // v1.2.116: pindah-nomor — ganti nomor bisnis pengirim chat
        $u = requireAuth(['super_admin', 'admin', 'supervisor']);
        $in = bodyInput();
        $num = waNormNum($in['number'] ?? '');
        $ch = trim((string)($in['ch'] ?? ''));
        if ($num === '' || $ch === '') jsonOut(['ok' => false, 'error' => 'number & ch wajib'], 400);
        $s = getSettings();
        if (!waMultiOn(waConf($s), $s)) jsonOut(['ok' => false, 'error' => 'Akun ini hanya punya satu nomor WhatsApp.'], 409);
        $lab = [];
        foreach (waChannels($s) as $x) $lab[$x['id']] = $x['label'];
        if (!isset($lab[$ch])) jsonOut(['ok' => false, 'error' => 'Nomor tujuan tidak ditemukan atau di luar paket.'], 404);
        deiGuardSpvScope($u, $num);
        $from = waCurCh($num, $s);
        if ($from === $ch) jsonOut(['ok' => true, 'number' => $num, 'ch' => $ch, 'label' => $lab[$ch], 'note' => 'Chat sudah di nomor ini']);
        waContactUpdate($num, function (&$r) use ($ch) { $r['wa_ch'] = $ch; });
        waAuditLog('ch_move', $u['username'], $num, ['from_ch' => $from, 'to_ch' => $ch]);
        $agent = '';
        if (!waClaimGet($num) && (deiIsManual($s) || waGetMode($num) === 'human')) $agent = (string)deiRouteAssign($num, $ch, $s);
        jsonOut(['ok' => true, 'number' => $num, 'ch' => $ch, 'from_ch' => $from, 'label' => $lab[$ch], 'agent' => $agent]);
        break;
    }

    case 'team_info': {
        $u = requireAuth(['super_admin', 'admin', 'supervisor', 'wa_agent']);
        $s = getSettings();
        $users = readJson(USERS_FILE, []);
        $f = deiFeatures($s);
        jsonOut([
            'ok'          => true,
            'role'        => $u['role'],
            'reply_mode'  => deiReplyModeSetting($s),   // v1.2.93: wa-bot-off
            'team'        => deiTeamConf($s),
            'routing'     => deiRoutingConf($s),   // v1.2.100
            'teams'       => deiTeamsList($users),
            'features'    => ['max_agents' => (int)$f['max_agents'], 'max_supervisors' => (int)$f['max_supervisors'],
                              'white_label' => !empty($f['white_label']), 'source' => $f['source'] ?? 'default'],
            'seats'       => deiSeatInfo($users),
            'wa_provider' => (string)($s['whatsapp_api']['provider'] ?? 'meta'),
            'wa_enabled'  => !empty($s['whatsapp_api']['enabled']) || deiWaConnected($s['whatsapp_api'] ?? []),   // v1.2.93: wa-bot-off
        ]);
        break;
    }

    case 'agent_report': {
        $u = requireAuth(['super_admin', 'admin', 'supervisor', 'wa_agent']);
        $todayWib = wibToday();
        $fromD = (string)($_GET['from'] ?? wibDate('Y-m-01'));
        $toD   = (string)($_GET['to'] ?? $todayWib);
        $fromTs = wibDayStart($fromD); $toTs = wibDayStart($toD);
        if ($fromTs === null || $toTs === null || $toTs < $fromTs) jsonOut(['ok' => false, 'error' => 'Rentang tanggal tidak valid (YYYY-MM-DD).'], 400);
        if ($toTs - $fromTs > 370 * 86400) jsonOut(['ok' => false, 'error' => 'Rentang maksimal 1 tahun.'], 400);
        $toTs += 86399;
        $onlyMe = ($u['role'] === 'wa_agent') ? $u['username'] : null;
        $spvScope = deiSpvScope($u);   // v1.2.59: supervisor hanya timnya

        $users = readJson(USERS_FILE, []);
        $names = [];
        $rows = [];
        $blank = function ($un, $nm, $rl) {
            return ['agent' => $un, 'name' => $nm, 'role' => $rl, 'replies' => 0, 'chats' => 0,
                    'first_responses' => 0, 'frt_sum' => 0, 'resp_n' => 0, 'resp_sum' => 0,
                    'claims' => 0, 'assigned_in' => 0, 'unreplied_now' => 0, 'holding_now' => 0, '_nums' => []];
        };
        foreach ((array)$users as $us) {
            $r = $us['role'] ?? '';
            $un = $us['username'] ?? '';
            $names[$un] = $us['name'] ?? $un;
            if ($r !== 'wa_agent' && $r !== 'supervisor') continue;   // admin/super_admin muncul kalau punya aktivitas
            if ($onlyMe !== null && $un !== $onlyMe) continue;
            if ($spvScope !== null && !isset($spvScope[$un])) continue;
            $rows[$un] = $blank($un, $us['name'] ?? $un, $r);
        }
        $incoming = 0; $inNums = [];
        foreach (agentEventsRead($fromTs, $toTs) as $ev) {
            $e = (string)($ev['ev'] ?? '');
            if ($e === 'in') { $incoming++; $inNums[(string)($ev['num'] ?? '')] = 1; continue; }
            $ag = (string)($ev['agent'] ?? '');
            if ($ag === '') continue;
            if ($onlyMe !== null && $ag !== $onlyMe) continue;
            if ($spvScope !== null && !isset($spvScope[$ag])) continue;
            if (!isset($rows[$ag])) {
                $rl = '';
                foreach ((array)$users as $us) { if (($us['username'] ?? '') === $ag) { $rl = $us['role'] ?? ''; break; } }
                $rows[$ag] = $blank($ag, $names[$ag] ?? $ag, $rl !== '' ? $rl : ($ag === '(HP)' ? 'hp' : ''));
            }
            $R = &$rows[$ag];
            if ($e === 'reply') {
                $R['replies']++;
                $R['_nums'][(string)($ev['num'] ?? '')] = 1;
                if (isset($ev['wait'])) {
                    $R['resp_n']++; $R['resp_sum'] += (int)$ev['wait'];
                    if (!empty($ev['first'])) { $R['first_responses']++; $R['frt_sum'] += (int)$ev['wait']; }
                }
            } elseif ($e === 'claim') {
                $R['claims']++;
            } elseif ($e === 'assign') {
                $R['assigned_in']++;
            }
            unset($R);
        }
        // Snapshot saat ini: chat yang dipegang & belum dibalas per agent
        $claims = waClaimGetAll();
        $cs = convStateReadAll();
        $unrepliedTotal = 0; $unrepliedUnassigned = 0;
        foreach ((array)$cs as $num => $st) {
            if (!is_array($st) || ($st['last_from'] ?? '') !== 'guest' || !empty($st['guest_bye'])) continue;
            $owner = $claims[$num]['agent_username'] ?? '';
            if ($onlyMe !== null && $owner !== $onlyMe) continue;
            if ($spvScope !== null && $owner !== '' && !isset($spvScope[$owner])) continue;
            $unrepliedTotal++;
            if ($owner === '') { $unrepliedUnassigned++; continue; }
            if (isset($rows[$owner])) $rows[$owner]['unreplied_now']++;
        }
        foreach ((array)$claims as $num => $cl) {
            $owner = $cl['agent_username'] ?? '';
            if (isset($rows[$owner])) $rows[$owner]['holding_now']++;
        }
        $out = [];
        $tot = ['replies' => 0, 'chats' => 0, 'frt_sum' => 0, 'first_responses' => 0, 'resp_sum' => 0, 'resp_n' => 0];
        $allNums = [];
        foreach ($rows as $R) {
            $R['chats'] = count($R['_nums']);
            foreach ($R['_nums'] as $n => $_) $allNums[$n] = 1;
            $R['frt_avg_sec']  = $R['first_responses'] > 0 ? (int)round($R['frt_sum'] / $R['first_responses']) : null;
            $R['resp_avg_sec'] = $R['resp_n'] > 0 ? (int)round($R['resp_sum'] / $R['resp_n']) : null;
            foreach (['replies', 'frt_sum', 'first_responses', 'resp_sum', 'resp_n'] as $k) $tot[$k] += $R[$k];
            unset($R['_nums'], $R['frt_sum'], $R['resp_sum']);
            $out[] = $R;
        }
        usort($out, function ($a, $b) { return $b['replies'] <=> $a['replies'] ?: strcmp($a['agent'], $b['agent']); });
        jsonOut([
            'ok'     => true,
            'from'   => $fromD,
            'to'     => $toD,
            'agents' => $out,
            'totals' => [
                'incoming_msgs'        => $incoming,          // tercatat hanya saat mode manusia/manual
                'incoming_numbers'     => count($inNums),
                'replies'              => $tot['replies'],
                'chats_handled'        => count($allNums),
                'frt_avg_sec'          => $tot['first_responses'] > 0 ? (int)round($tot['frt_sum'] / $tot['first_responses']) : null,
                'resp_avg_sec'         => $tot['resp_n'] > 0 ? (int)round($tot['resp_sum'] / $tot['resp_n']) : null,
                'unreplied_now'        => $unrepliedTotal,
                'unreplied_unassigned' => $unrepliedUnassigned,
            ],
            'self_only' => $onlyMe !== null,
            'team_only' => $spvScope !== null,   // v1.2.59
        ]);
        break;
    }

    /* ---------- v1.2.75: koneksi perangkat Fonnte dari dashboard (scan QR) ---------- */
    // Token Fonnte tetap di server & hanya diisi Super Admin. Admin klien cukup
    // menekan Hubungkan lalu scan QR (atau kode tautan) dari HP-nya.
    case 'fonnte_conn': {
        $u  = requireAuth(['super_admin', 'admin']);
        $in = bodyInput();
        $op = (string)($in['op'] ?? 'status');
        $s  = getSettings();
        $wa = waConf($s);
        if (($wa['provider'] ?? 'meta') !== 'fonnte') jsonOut(['ok' => false, 'error' => 'Penyedia WhatsApp bukan Fonnte.'], 400);
        $tok = (string)($wa['fonnte_token'] ?? '');
        if ($tok === '') jsonOut(['ok' => false, 'error' => 'Token Fonnte belum diisi Super Admin.'], 400);

        if ($op === 'status') {
            $d = fonnteApi($tok, 'device');
            if (empty($d['status'])) jsonOut(['ok' => false, 'error' => fonnteReason($d, 'Gagal membaca status perangkat.')]);
            $dev = preg_replace('/\D/', '', (string)($d['device'] ?? ''));
            // Nomor perangkat dipakai menyaring webhook — isi otomatis kalau masih kosong.
            if ($dev !== '' && trim((string)($wa['fonnte_device'] ?? '')) === '') {
                $s2 = getSettings();
                $s2['whatsapp_api']['fonnte_device'] = $dev;
                writeJson(SETTINGS_FILE, $s2);
            }
            jsonOut([
                'ok'        => true,
                'connected' => (strtolower((string)($d['device_status'] ?? '')) === 'connect'),
                'device'    => $dev,
                'name'      => (string)($d['name'] ?? ''),
                'package'   => (string)($d['package'] ?? ''),
                'quota'     => $d['quota'] ?? null,
                'expired'   => (string)($d['expired'] ?? ''),
            ]);
        }

        if ($op === 'qr') {
            $f = [];
            if (($in['type'] ?? 'qr') === 'code') {
                $num = preg_replace('/\D/', '', (string)($in['whatsapp'] ?? ''));
                if (strpos($num, '0') === 0) $num = '62' . substr($num, 1);
                if (strlen($num) < 9 || strlen($num) > 15) jsonOut(['ok' => false, 'error' => 'Nomor WhatsApp tidak valid.'], 400);
                $f = ['type' => 'code', 'whatsapp' => $num];
            }
            $d = fonnteApi($tok, 'qr', $f);
            if (!empty($d['status'])) {
                $out = ['ok' => true, 'connected' => false];
                $img = preg_replace('/[^A-Za-z0-9+\/=]/', '', (string)($d['url'] ?? ''));
                if ($img !== '') $out['qr'] = 'data:image/png;base64,' . $img;
                if (!empty($d['code'])) $out['code'] = (string)$d['code'];
                jsonOut($out);
            }
            $r = fonnteReason($d, 'Gagal mengambil QR.');
            if (stripos($r, 'already connect') !== false) jsonOut(['ok' => true, 'connected' => true]);
            jsonOut(['ok' => false, 'error' => $r]);
        }

        if ($op === 'disconnect') {
            $d = fonnteApi($tok, 'disconnect');
            $r = fonnteReason($d, 'Gagal memutuskan.');
            $ok = !empty($d['status']) || stripos($r, 'already disconnect') !== false;
            if ($ok) { try { waAuditLog('fonnte_disconnect', $u['username'], '', []); } catch (\Throwable $e) {} }
            jsonOut($ok ? ['ok' => true] : ['ok' => false, 'error' => $r]);
        }

        if ($op === 'webhook') {
            if (($u['role'] ?? '') !== 'super_admin') jsonOut(['ok' => false, 'error' => 'Khusus Super Admin.'], 403);
            $key = (string)($wa['fonnte_webhook_key'] ?? '');
            if ($key === '') jsonOut(['ok' => false, 'error' => 'Kunci webhook belum ada — simpan pengaturan dengan penyedia Fonnte dulu.'], 400);
            $base = deiSelfApiUrl();
            if (strpos($base, 'https://') !== 0) jsonOut(['ok' => false, 'error' => 'Webhook butuh alamat https publik. Alamat saat ini: ' . $base], 400);
            $p    = fonnteApi($tok, 'device');
            $name = trim((string)($p['name'] ?? ''));
            if (mb_strlen($name) < 2) $name = deiTenantName($s);
            $hook = $base . '?action=wa_webhook_fonnte&key=' . rawurlencode($key);
            $f = ['name' => mb_substr($name, 0, 30), 'webhook' => $hook];
            $dev = preg_replace('/\D/', '', (string)($p['device'] ?? ''));
            if ($dev !== '') $f['device'] = $dev;
            $d = fonnteApi($tok, 'update-device', $f);
            if (empty($d['status'])) jsonOut(['ok' => false, 'error' => fonnteReason($d, 'Gagal memasang webhook.')]);
            try { waAuditLog('fonnte_webhook_set', $u['username'], '', []); } catch (\Throwable $e) {}
            jsonOut(['ok' => true, 'webhook' => $base . '?action=wa_webhook_fonnte&key=••••']);
        }

        jsonOut(['ok' => false, 'error' => 'op tidak dikenal'], 400);
        break;
    }

    /* ---------- v1.2.76: WAHA — koneksi sesi dari dashboard (scan QR / kode tautan) ---------- */
    /* ---------- v1.2.100: routing — status agent (heartbeat Tersedia/Istirahat) ---------- */
    case 'agent_presence': {
        $u  = requireAuth(['super_admin', 'admin', 'supervisor', 'wa_agent']);
        $in = bodyInput();
        $op = (string)($in['op'] ?? 'ping');
        if ($op === 'list') {
            if (!deiIsLead($u['role'] ?? '')) jsonOut(['ok' => false, 'error' => 'Tidak diizinkan.'], 403);
            $users = readJson(USERS_FILE, []);
            $pres = deiPresenceAll();
            $scope = deiSpvScope($u, $users);
            $act = [];
            foreach (waClaimGetAll() as $c) { $a = (string)($c['agent_username'] ?? ''); if ($a !== '') $act[$a] = ($act[$a] ?? 0) + 1; }
            $rows = [];
            foreach ((array)$users as $x) {
                $r = (string)($x['role'] ?? ''); $un = (string)($x['username'] ?? '');
                if (!in_array($r, ['wa_agent', 'supervisor'], true)) continue;
                if ($scope !== null && !isset($scope[$un])) continue;
                $p = $pres[$un] ?? null;
                $rows[] = ['username' => $un, 'name' => (string)($x['name'] ?? $un), 'role' => $r,
                           'team' => $r === 'supervisor' ? $un : deiAgentSpv($x, $users),
                           'online' => deiPresenceOnline($p), 'status' => is_array($p) ? (string)($p['status'] ?? 'available') : 'available',
                           'seen' => is_array($p) ? (int)($p['seen'] ?? 0) : 0, 'active' => (int)($act[$un] ?? 0),
                           'seat_ok' => deiSeatAllowed($un, $r, $users)];
            }
            jsonOut(['ok' => true, 'agents' => $rows, 'routing' => deiRoutingConf(), 'now' => time()]);
        }
        $status = ($op === 'set') ? ((($in['status'] ?? '') === 'away') ? 'away' : 'available') : null;
        list($was, $isOn) = deiPresenceTouch((string)$u['username'], $status);
        $assigned = 0;
        if ($isOn && in_array($u['role'] ?? '', ['wa_agent', 'supervisor'], true)) $assigned = deiRouteDrain(5);
        $row = deiPresenceAll()[(string)$u['username']] ?? [];
        jsonOut(['ok' => true, 'status' => (string)($row['status'] ?? 'available'), 'online' => $isOn, 'assigned' => $assigned]);
        break;
    }

    /* ---------- v1.2.98: multi-nomor — kelola nomor WhatsApp tambahan ---------- */
    /* ---------- v1.2.104: skor-risiko-wa — panel Kesehatan nomor (WAHA) ---------- */
    /* ---------- v1.2.108: tolak-telepon — pengaturan tolak telepon per nomor (WAHA) ---------- */
    /* ---------- v1.2.109: guest-comment / v1.2.110: customer-feedback — form publik (QR di meja/kasir/kamar) ---------- */
    case 'gc_form': {
        $s = getSettings();
        header('Content-Type: text/html; charset=utf-8');
        header('Cache-Control: no-store');
        header('X-Robots-Tag: noindex');
        $room = mb_substr(preg_replace('/[^A-Za-z0-9 -]/', '', (string)($_GET['room'] ?? '')), 0, 20);
        $act = false;
        try { $act = gcActive(); } catch (\Throwable $e) { error_log('gc_form: ' . $e->getMessage()); }
        echo gcFormHtml($s, $act, $room);
        exit;
    }

    case 'gc_submit': {
        if ($_SERVER['REQUEST_METHOD'] !== 'POST') jsonOut(['ok' => false, 'error' => 'Method not allowed'], 405);
        if (!gcActive()) jsonOut(['ok' => false, 'error' => 'Form feedback belum tersedia.'], 403);
        $in = bodyInput();
        if (trim((string)($in['hp'] ?? '')) !== '') jsonOut(['ok' => true]);   // jebakan bot spam
        if (!checkRateLimit('gc:' . clientIp(), 8)) jsonOut(['ok' => false, 'error' => 'Terlalu banyak kiriman. Silakan coba lagi nanti.'], 429);
        $conf = gcConf();
        $rIn = is_array($in['ratings'] ?? null) ? $in['ratings'] : [];
        $r = [];
        foreach ($conf['aspects'] as $a) { $v = (int)($rIn[$a['id']] ?? 0); if ($v >= 1 && $v <= 5) $r[$a['id']] = $v; }
        if (count($r) < count($conf['aspects'])) jsonOut(['ok' => false, 'error' => (($in['lang'] ?? '') === 'en' ? 'Please rate every aspect.' : 'Mohon beri nilai untuk semua aspek.')], 400);
        $phone = mb_substr(preg_replace('/[^0-9+]/', '', (string)($in['phone'] ?? '')), 0, 20);
        gcStore(['channel' => 'web',
                 'name'    => $conf['ask_name'] ? mb_substr(trim((string)($in['name'] ?? '')), 0, 60) : '',
                 'room'    => $conf['ask_room'] ? mb_substr(trim(preg_replace('/[^\p{L}\p{N} -]/u', '', (string)($in['room'] ?? ''))), 0, 20) : '',
                 'phone'   => $conf['ask_phone_web'] ? $phone : '',
                 'lang'    => (($in['lang'] ?? '') === 'en') ? 'en' : 'id',
                 'ratings' => $r,
                 'comment' => mb_substr(trim(str_replace("\r", '', (string)($in['comment'] ?? ''))), 0, 2000)]);
        jsonOut(['ok' => true]);
    }

    /* ---------- v1.2.109: guest-comment — dashboard ---------- */
    case 'gc_admin': {
        $u  = requireAuth(['super_admin', 'admin', 'supervisor']);
        $in = bodyInput();
        $op = (string)($in['op'] ?? ($_GET['op'] ?? 'get'));
        $canEdit = in_array(($u['role'] ?? ''), ['super_admin', 'admin'], true);
        $plan = gcPlan();
        if ($op === 'get') {
            $s = getSettings();
            $wl = [];
            foreach (waChannels($s) as $c) { if ((string)$c['number'] !== '') $wl[] = ['label' => $c['label'], 'number' => $c['number']]; }
            jsonOut(['ok' => true, 'plan' => $plan, 'locked' => !$plan['ok'], 'locked_msg' => gcLockedMsg(), 'conf' => gcConf(),
                     'can_edit' => $canEdit, 'form_url' => gcFormUrl(), 'wa' => $wl, 'count' => count(gcAll())]);
        }
        if ($op === 'save') {
            if (!$canEdit) jsonOut(['ok' => false, 'error' => 'Khusus Super Admin / Admin.'], 403);
            $c = gcClean(is_array($in['conf'] ?? null) ? $in['conf'] : []);
            if ($c['enabled'] && !$plan['ok']) jsonOut(['ok' => false, 'error' => gcLockedMsg(), 'locked' => true], 403);
            writeJson(GC_CONF_FILE, $c);
            unset($GLOBALS['dei_gc_conf']);
            try { waAuditLog('gc_conf_set', $u['username'], '', ['enabled' => $c['enabled'], 'aspects' => count($c['aspects'])]); } catch (\Throwable $e) {}
            jsonOut(['ok' => true, 'conf' => gcConf()]);
        }
        if ($op === 'list') {
            $from = preg_match('/^\d{4}-\d{2}-\d{2}$/', (string)($in['from'] ?? '')) ? $in['from'] : '';
            $to   = preg_match('/^\d{4}-\d{2}-\d{2}$/', (string)($in['to'] ?? '')) ? $in['to'] : '';
            $chan = (string)($in['channel'] ?? 'all');
            $rate = (string)($in['rating'] ?? 'all');
            $stat = (string)($in['status'] ?? 'all');
            $q    = mb_strtolower(trim((string)($in['q'] ?? '')), 'UTF-8');
            $conf = gcConf();
            $rows = [];
            $agg = []; $n = 0; $sumAvg = 0.0; $lowN = 0; $byCh = ['whatsapp' => 0, 'web' => 0]; $dist = [1 => 0, 2 => 0, 3 => 0, 4 => 0, 5 => 0];
            foreach (gcAll() as $e) {
                $d = substr((string)($e['ts'] ?? ''), 0, 10);
                if ($from !== '' && $d < $from) continue;
                if ($to !== '' && $d > $to) continue;
                if ($chan !== 'all' && ($e['channel'] ?? '') !== $chan) continue;
                if ($rate === 'low' && empty($e['low'])) continue;
                if ($rate === 'high' && (float)($e['avg'] ?? 0) < 4) continue;
                if ($stat !== 'all' && ($e['status'] ?? 'baru') !== $stat) continue;
                if ($q !== '') {
                    $hay = mb_strtolower(($e['name'] ?? '') . ' ' . ($e['room'] ?? '') . ' ' . ($e['num'] ?? '') . ' ' . ($e['phone'] ?? '') . ' ' . ($e['comment'] ?? '') . ' ' . ($e['note'] ?? ''), 'UTF-8');
                    if (mb_strpos($hay, $q) === false) continue;
                }
                $rows[] = $e;
                $n++; $sumAvg += (float)($e['avg'] ?? 0);
                if (!empty($e['low'])) $lowN++;
                $ch = ($e['channel'] ?? '') === 'whatsapp' ? 'whatsapp' : 'web';
                $byCh[$ch]++;
                $ra = (int)round((float)($e['avg'] ?? 0)); if ($ra >= 1 && $ra <= 5) $dist[$ra]++;
                foreach ((array)($e['ratings'] ?? []) as $k => $v) {
                    if (!isset($agg[$k])) $agg[$k] = [0, 0];
                    $agg[$k][0] += (int)$v; $agg[$k][1]++;
                }
            }
            $asp = []; $known = [];
            foreach ($conf['aspects'] as $a) {
                $known[$a['id']] = 1;
                $x = $agg[$a['id']] ?? [0, 0];
                $asp[] = ['id' => $a['id'], 'label' => $a['label'], 'avg' => $x[1] ? round($x[0] / $x[1], 2) : 0, 'n' => $x[1]];
            }
            foreach ($agg as $k => $x) {   // aspek lama yang sudah dihapus dari pengaturan
                if (isset($known[$k])) continue;
                $lbl = $k;
                foreach ($rows as $e) { if (!empty($e['labels'][$k])) { $lbl = $e['labels'][$k]; break; } }
                $asp[] = ['id' => $k, 'label' => $lbl, 'avg' => round($x[0] / $x[1], 2), 'n' => $x[1], 'old' => true];
            }
            $all = !empty($in['all']);
            $off = max(0, (int)($in['offset'] ?? 0));
            $lim = $all ? GC_MAX : max(1, min(200, (int)($in['limit'] ?? 50)));
            jsonOut(['ok' => true, 'total' => $n, 'items' => array_slice($rows, $all ? 0 : $off, $lim),
                     'stats' => ['n' => $n, 'avg' => $n ? round($sumAvg / $n, 2) : 0, 'low' => $lowN, 'by_channel' => $byCh, 'dist' => $dist, 'aspects' => $asp],
                     'low_th' => $conf['low']]);
        }
        if ($op === 'update' || $op === 'delete') {
            $id = preg_replace('/[^a-z0-9]/', '', (string)($in['id'] ?? ''));
            if ($id === '') jsonOut(['ok' => false, 'error' => 'id kosong'], 400);
            if ($op === 'delete' && !$canEdit) jsonOut(['ok' => false, 'error' => 'Khusus Super Admin / Admin.'], 403);
            $status = (string)($in['status'] ?? '');
            if ($op === 'update' && !in_array($status, ['baru', 'ditindak', 'selesai'], true)) jsonOut(['ok' => false, 'error' => 'Status tidak dikenal.'], 400);
            $note = mb_substr(trim(str_replace("\r", '', (string)($in['note'] ?? ''))), 0, 1000);
            $who = (string)($u['username'] ?? '');
            $res = deiWithLock('gc', function () use ($id, $op, $status, $note, $who) {
                $all = gcAll();
                foreach ($all as $i => $e) {
                    if (($e['id'] ?? '') !== $id) continue;
                    if ($op === 'delete') { array_splice($all, $i, 1); writeJson(GC_FILE, $all); return ['deleted' => true]; }
                    $all[$i]['status'] = $status;
                    $all[$i]['note'] = $note;
                    $all[$i]['handled_by'] = $who;
                    $all[$i]['handled_at'] = wibDate('Y-m-d H:i:s');
                    writeJson(GC_FILE, $all);
                    return $all[$i];
                }
                return null;
            });
            if ($res === null) jsonOut(['ok' => false, 'error' => 'Entri tidak ditemukan.'], 404);
            jsonOut(['ok' => true, 'item' => $op === 'update' ? $res : null]);
        }
        jsonOut(['ok' => false, 'error' => 'op tidak dikenal'], 400);
    }

    case 'wa_calls': {
        $u  = requireAuth(['super_admin', 'admin', 'supervisor']);
        $in = bodyInput();
        $op = (string)($in['op'] ?? ($_GET['op'] ?? 'get'));
        $s  = getSettings();
        $wa = waConf($s);
        if (!whOn($wa)) jsonOut(['ok' => false, 'error' => 'Tolak telepon otomatis khusus penyedia WAHA.'], 400);
        $ch = preg_replace('/[^A-Za-z0-9_]/', '', (string)($in['ch'] ?? ($_GET['ch'] ?? 'utama')));
        $label = ''; $found = false;
        foreach (whChannels($s) as $c) { if ($c[0] === $ch) { $found = true; $label = $c[1]; } }
        if (!$found) jsonOut(['ok' => false, 'error' => 'Nomor tidak ditemukan atau terkunci.'], 404);
        $canEdit = in_array(($u['role'] ?? ''), ['super_admin', 'admin'], true);
        if ($op === 'save') {
            if (!$canEdit) jsonOut(['ok' => false, 'error' => 'Khusus Super Admin / Admin.'], 403);
            $c = wcClean(is_array($in['conf'] ?? null) ? $in['conf'] : []);
            if ($c['on'] && $c['when'] === 'hours' && !$c['days']) jsonOut(['ok' => false, 'error' => 'Pilih minimal satu hari operasional.'], 400);
            if ($c['on'] && $c['reply_on'] && $c['msg'] === '') jsonOut(['ok' => false, 'error' => 'Pesan balasan masih kosong.'], 400);
            wcSave($ch, $c);
            try { waAuditLog('wa_calls_set', $u['username'], '', ['ch' => $ch, 'on' => $c['on'], 'when' => $c['when']]); } catch (\Throwable $e) {}
            list($rej, $why) = wcDecide($c);
            jsonOut(['ok' => true, 'conf' => $c, 'now_reject' => $rej, 'now_why' => $why]);
        }
        $recent = [];
        foreach (logReadAll() as $e) {
            if ((string)($e['dir'] ?? '') !== 'call' || ($e['channel'] ?? '') !== 'whatsapp') continue;
            $ech = (string)($e['wa_ch'] ?? '');
            if (($ech === '' ? 'utama' : $ech) !== $ch) continue;
            $recent[] = ['ts' => (string)($e['ts'] ?? ''), 'num' => (string)($e['ip'] ?? ''), 'txt' => wcLabel($e), 'replied' => (string)($e['a'] ?? '') !== ''];
            if (count($recent) >= 10) break;
        }
        $d = whRead($ch);
        $conf = wcConf($ch);
        list($rej, $why) = wcDecide($conf);
        jsonOut(['ok' => true, 'label' => $label, 'can_edit' => $canEdit, 'conf' => $conf,
                 'cfg_ok' => (int)($d['cfg_v'] ?? 0) >= WA_HEALTH_CFG_V || !empty($d['call_on']),
                 'now_reject' => $rej, 'now_why' => $why, 'recent' => $recent]);
        break;
    }

    case 'wa_health': {
        $u  = requireAuth(['super_admin', 'admin', 'supervisor']);
        $in = bodyInput();
        $op = (string)($in['op'] ?? ($_GET['op'] ?? 'get'));
        $s  = getSettings();
        $wa = waConf($s);
        if (!whOn($wa)) jsonOut(['ok' => false, 'error' => 'Pemantauan kesehatan nomor khusus penyedia WAHA.'], 400);
        if ($op === 'summary') { $r = whScoreAll($s, false); jsonOut(['ok' => true, 'nums' => is_array($r) ? ($r['nums'] ?? []) : []]); }
        $ch = preg_replace('/[^A-Za-z0-9_]/', '', (string)($in['ch'] ?? ($_GET['ch'] ?? 'utama')));
        $conf = null; $label = '';
        foreach (whChannels($s) as $c) { if ($c[0] === $ch) { $conf = $c[2]; $label = $c[1]; } }
        if ($conf === null) jsonOut(['ok' => false, 'error' => 'Nomor tidak ditemukan atau terkunci.'], 404);
        $canEdit = in_array(($u['role'] ?? ''), ['super_admin', 'admin'], true);
        if ($op === 'apply_cfg') {
            if (!$canEdit) jsonOut(['ok' => false, 'error' => 'Khusus Super Admin / Admin.'], 403);
            list($ok, $err) = whApplyCfg($conf);
            if ($ok) { try { waAuditLog('wa_health_cfg', $u['username'], '', ['ch' => $ch]); } catch (\Throwable $e) {} }
            jsonOut($ok ? ['ok' => true] : ['ok' => false, 'error' => $err]);
        }
        if ($op === 'set_since') {
            if (!$canEdit) jsonOut(['ok' => false, 'error' => 'Khusus Super Admin / Admin.'], 403);
            $dt = trim((string)($in['date'] ?? ''));
            $ts = 0;
            if ($dt !== '') {
                $ts = preg_match('/^\d{4}-\d{2}-\d{2}$/', $dt) ? (int)strtotime($dt . ' 00:00:00 +0700') : 0;
                if ($ts <= 0 || $ts > time()) jsonOut(['ok' => false, 'error' => 'Tanggal tidak valid.'], 400);
            }
            whUpdate($ch, function (&$d) use ($ts) {
                if ($ts > 0) { $d['paired_at'] = $ts; $d['paired_src'] = 'manual'; }
                else unset($d['paired_at'], $d['paired_src']);
            });
            whScoreAll($s, true);
            jsonOut(['ok' => true]);
        }
        whScoreAll($s, false);
        $sc = whScore($ch);
        whStoreRow($ch, $label, $conf, $sc);
        jsonOut(['ok' => true, 'label' => $label, 'can_edit' => $canEdit, 'health' => $sc]);
        break;
    }

    case 'wa_numbers': {
        $u  = requireAuth(['super_admin', 'admin', 'supervisor']);
        $in = bodyInput();
        $op = (string)($in['op'] ?? ($_GET['op'] ?? 'list'));
        $s  = getSettings();
        $wa = waConf($s);
        $prov = (string)($wa['provider'] ?? 'meta');
        $isSa = (($u['role'] ?? '') === 'super_admin');
        if ($op !== 'list' && !$isSa) jsonOut(['ok' => false, 'error' => 'Khusus Super Admin.'], 403);

        if ($op === 'list') {
            // nomor tampil nomor utama (Meta) diambil sekali per Phone Number ID
            $pn0 = (string)($wa['phone_number_id'] ?? '');
            if ($isSa && $prov === 'meta' && $pn0 !== '' && (string)($wa['display_pnid'] ?? '') !== $pn0 && (string)($wa['access_token'] ?? '') !== '') {
                list($okI, $inf) = waMetaPhoneInfo((string)$wa['access_token'], $pn0);
                if ($okI) {
                    $s = getSettings();
                    $s['whatsapp_api']['display_number'] = waNormNum($inf['display_phone_number'] ?? '');
                    $s['whatsapp_api']['display_pnid'] = $pn0;
                    writeJson(SETTINGS_FILE, $s);
                    $wa = waConf($s);
                }
            }
            $rows = [];
            $p = ['id' => 'utama', 'primary' => true, 'label' => (string)($wa['label'] ?? ''), 'number' => waChanNumOf($wa, $prov),
                  'waha_session' => wahaSession($wa)];
            if ($isSa) $p['phone_number_id'] = (string)($wa['phone_number_id'] ?? '');
            $p['team'] = (string)($wa['team'] ?? '');   // v1.2.100: routing
            $rows[] = $p;
            $lim = waNumbersLimit(); $ord = 0;   // v1.2.99: lisensi-nomor
            if (waMultiProv($wa)) {
                foreach (waNumbersRaw($s, true) as $x) {
                    $r = ['id' => (string)$x['id'], 'primary' => false, 'label' => (string)($x['label'] ?? ''), 'locked' => (++$ord > $lim),
                          'number' => waChanNumOf($x, $prov), 'verified_name' => (string)($x['verified_name'] ?? ''),
                          'waha_session' => (string)($x['waha_session'] ?? ''), 'team' => (string)($x['team'] ?? '')];   // v1.2.100
                    if ($isSa) {
                        $r['phone_number_id'] = (string)($x['phone_number_id'] ?? '');
                        $r['waba_id'] = (string)($x['waba_id'] ?? '');
                        $r['token_is_set'] = (string)($x['access_token'] ?? '') !== '';
                        $r['waha_url'] = (string)($x['waha_url'] ?? '');
                        $r['waha_key_is_set'] = (string)($x['waha_api_key'] ?? '') !== '';
                    }
                    $rows[] = $r;
                }
            }
            jsonOut(['ok' => true, 'provider' => $prov, 'supported' => waMultiProv($wa), 'max' => WA_NUMBERS_MAX,
                     'limit' => $lim, 'vendor' => deiBrandVendor(),   // v1.2.99: lisensi-nomor
                     'teams' => deiTeamsList(), 'routing_by_number' => deiRoutingConf($s)['by_number'],   // v1.2.100
                     'channels' => waChannels($s), 'numbers' => $rows,
                     'health' => whOn($wa) ? (object)(readJson(WA_HEALTH_SCORE_FILE, [])['nums'] ?? []) : null]);   // v1.2.104: skor-risiko-wa
        }
        if (!waMultiProv($wa)) jsonOut(['ok' => false, 'error' => 'Nomor tambahan hanya untuk penyedia Meta Cloud API atau WAHA.'], 400);

        // Daftar nomor di WABA (Meta) supaya Phone Number ID tidak perlu dicari manual.
        if ($op === 'meta_phones') {
            if ($prov !== 'meta') jsonOut(['ok' => false, 'error' => 'Hanya untuk Meta Cloud API.'], 400);
            $waba = preg_replace('/\D/', '', (string)($in['waba_id'] ?? '')) ?: (string)($wa['waba_id'] ?? '');
            $tok  = trim((string)($in['access_token'] ?? ''));
            if ($tok === '' || strpos($tok, '•') !== false) $tok = (string)($wa['access_token'] ?? '');
            if ($waba === '' || $tok === '') jsonOut(['ok' => false, 'error' => 'WABA ID / Access Token belum ada.'], 400);
            list($c, $j, , $e) = deiHttpGetCapped('https://graph.facebook.com/v21.0/' . rawurlencode($waba)
                . '/phone_numbers?fields=id,display_phone_number,verified_name&limit=100', ['Authorization: Bearer ' . $tok], 262144);
            $d = json_decode((string)$j, true);
            if ($c < 200 || $c >= 300 || !is_array($d)) jsonOut(['ok' => false, 'error' => 'Gagal membaca nomor di WABA (' . ($e !== '' ? $e : 'HTTP ' . $c) . ').'], 502);
            $used = [(string)($wa['phone_number_id'] ?? '') => 'utama'];
            foreach (waNumbersRaw($s, true) as $x) $used[(string)($x['phone_number_id'] ?? '')] = (string)$x['id'];
            $out = [];
            foreach ((array)($d['data'] ?? []) as $ph) {
                $id = (string)($ph['id'] ?? '');
                if ($id === '') continue;
                $out[] = ['phone_number_id' => $id, 'number' => waNormNum($ph['display_phone_number'] ?? ''),
                          'verified_name' => (string)($ph['verified_name'] ?? ''), 'used_by' => $used[$id] ?? ''];
            }
            jsonOut(['ok' => true, 'waba_id' => $waba, 'phones' => $out]);
        }

        if ($op === 'save') {
            $id    = preg_replace('/[^A-Za-z0-9_]/', '', (string)($in['id'] ?? ''));
            $label = mb_substr(trim((string)($in['label'] ?? '')), 0, 40);
            $teamIn = array_key_exists('team', $in) ? trim((string)$in['team']) : null;   // v1.2.100: routing
            if ($teamIn !== null && $teamIn !== '' && !in_array($teamIn, array_column(deiTeamsList(), 'username'), true)) jsonOut(['ok' => false, 'error' => 'Tim (supervisor) tidak ditemukan.'], 400);
            if ($id === 'utama') {
                $s['whatsapp_api']['label'] = $label;
                if ($teamIn !== null) $s['whatsapp_api']['team'] = $teamIn;
                writeJson(SETTINGS_FILE, $s);
                try { waAuditLog('wa_number_label', $u['username'], '', ['ch' => 'utama', 'label' => $label]); } catch (\Throwable $e) {}
                jsonOut(['ok' => true, 'id' => 'utama']);
            }
            $list = waNumbersRaw($s, true);   // v1.2.99: termasuk yang terkunci
            $idx = -1;
            foreach ($list as $i => $x) { if ((string)$x['id'] === $id) { $idx = $i; break; } }
            if ($id !== '' && $idx < 0) jsonOut(['ok' => false, 'error' => 'Nomor tidak ditemukan.'], 404);
            if ($idx < 0) {   // v1.2.99: lisensi-nomor — cek paket dari pusat
                $lim = waNumbersLimit();
                if (count($list) >= $lim) jsonOut(['ok' => false, 'error' => $lim > 0
                    ? 'Batas paket: maksimal ' . $lim . ' nomor tambahan. Hubungi ' . deiBrandVendor() . ' untuk menambah.'
                    : 'Paket Anda belum termasuk nomor WhatsApp tambahan. Hubungi ' . deiBrandVendor() . ' untuk menambahkan.'], 403);
            }
            $row = $idx >= 0 ? $list[$idx] : ['id' => 'n' . bin2hex(random_bytes(4)), 'created_at' => date('Y-m-d H:i:s')];
            $row['label'] = $label;
            if ($teamIn !== null) $row['team'] = $teamIn;   // v1.2.100
            $warn = '';
            if ($prov === 'meta') {
                $pnid = preg_replace('/\D/', '', (string)($in['phone_number_id'] ?? ''));
                if ($pnid === '') jsonOut(['ok' => false, 'error' => 'Phone Number ID wajib diisi.'], 400);
                if ($pnid === (string)($wa['phone_number_id'] ?? '')) jsonOut(['ok' => false, 'error' => 'Phone Number ID ini sudah dipakai nomor utama.'], 400);
                foreach ($list as $i => $x) {
                    if ($i !== $idx && (string)($x['phone_number_id'] ?? '') === $pnid) jsonOut(['ok' => false, 'error' => 'Phone Number ID ini sudah terdaftar.'], 400);
                }
                $row['phone_number_id'] = $pnid;
                $tok = trim((string)($in['access_token'] ?? ''));
                if (!empty($in['clear_token'])) $row['access_token'] = '';
                elseif ($tok !== '' && strpos($tok, '•') === false) $row['access_token'] = $tok;
                $row['waba_id'] = preg_replace('/\D/', '', (string)($in['waba_id'] ?? ''));
                $useTok = (string)($row['access_token'] ?? '') !== '' ? (string)$row['access_token'] : (string)($wa['access_token'] ?? '');
                list($okInfo, $info) = waMetaPhoneInfo($useTok, $pnid);
                if ($okInfo) {
                    $row['display_number'] = waNormNum($info['display_phone_number'] ?? '');
                    $row['verified_name'] = mb_substr((string)($info['verified_name'] ?? ''), 0, 80);
                } else {
                    $warn = $info;
                }
            } else {
                $sess = preg_replace('/[^A-Za-z0-9_-]/', '', (string)($in['waha_session'] ?? ''));
                if ($sess === '') jsonOut(['ok' => false, 'error' => 'Nama sesi WAHA wajib diisi (satu sesi = satu nomor).'], 400);
                if ($sess === wahaSession($wa)) jsonOut(['ok' => false, 'error' => 'Nama sesi ini sudah dipakai nomor utama.'], 400);
                foreach ($list as $i => $x) {
                    if ($i !== $idx && (string)($x['waha_session'] ?? '') === $sess) jsonOut(['ok' => false, 'error' => 'Nama sesi ini sudah terdaftar.'], 400);
                }
                if ((string)($row['waha_session'] ?? '') !== $sess) $row['waha_number'] = '';
                $row['waha_session'] = $sess;
                $wu = rtrim(trim((string)($in['waha_url'] ?? '')), '/');
                $row['waha_url'] = preg_match('#^https?://#i', $wu) ? $wu : '';
                $key = trim((string)($in['waha_api_key'] ?? ''));
                if (!empty($in['clear_key'])) $row['waha_api_key'] = '';
                elseif ($key !== '' && strpos($key, '•') === false) $row['waha_api_key'] = $key;
            }
            $s = getSettings();   // baca ulang tepat sebelum menulis
            $cur = is_array($s['wa_numbers'] ?? null) ? array_values(array_filter($s['wa_numbers'], 'is_array')) : [];
            $put = false;
            foreach ($cur as $i => $x) { if ((string)($x['id'] ?? '') === $row['id']) { $cur[$i] = $row; $put = true; } }
            if (!$put) $cur[] = $row;
            $s['wa_numbers'] = array_values($cur);
            writeJson(SETTINGS_FILE, $s);
            try { waAuditLog($idx >= 0 ? 'wa_number_edit' : 'wa_number_add', $u['username'], '', ['ch' => $row['id'], 'label' => $label]); } catch (\Throwable $e) {}
            jsonOut(['ok' => true, 'id' => $row['id'], 'warning' => $warn]);
        }

        if ($op === 'delete') {
            $id = preg_replace('/[^A-Za-z0-9_]/', '', (string)($in['id'] ?? ''));
            if ($id === '' || $id === 'utama') jsonOut(['ok' => false, 'error' => 'Nomor utama tidak bisa dihapus dari sini.'], 400);
            $cur = is_array($s['wa_numbers'] ?? null) ? $s['wa_numbers'] : [];
            $n0 = count($cur);
            $cur = array_values(array_filter($cur, function ($x) use ($id) { return !(is_array($x) && (string)($x['id'] ?? '') === $id); }));
            if (count($cur) === $n0) jsonOut(['ok' => false, 'error' => 'Nomor tidak ditemukan.'], 404);
            $s['wa_numbers'] = $cur;
            writeJson(SETTINGS_FILE, $s);
            try { waAuditLog('wa_number_delete', $u['username'], '', ['ch' => $id]); } catch (\Throwable $e) {}
            jsonOut(['ok' => true]);
        }
        jsonOut(['ok' => false, 'error' => 'op tidak dikenal'], 400);
        break;
    }

    case 'waha_conn': {
        $u  = requireAuth(['super_admin', 'admin']);
        $in = bodyInput();
        $op = (string)($in['op'] ?? 'status');
        $s  = getSettings();
        $wa = waConf($s);
        if (($wa['provider'] ?? 'meta') !== 'waha') jsonOut(['ok' => false, 'error' => 'Penyedia WhatsApp bukan WAHA.'], 400);
        $chId = preg_replace('/[^A-Za-z0-9_]/', '', (string)($in['ch'] ?? ''));   // v1.2.98: multi-nomor
        if ($chId !== '' && $chId !== 'utama') {
            $wa = waChanConf($wa, $chId, $s);
            if (($wa['_ch'] ?? '') !== $chId) jsonOut(['ok' => false, 'error' => 'Nomor tidak ditemukan atau terkunci (di luar paket).'], 404);   // v1.2.99
        }
        if (trim((string)($wa['waha_url'] ?? '')) === '' || (string)($wa['waha_api_key'] ?? '') === '') {
            jsonOut(['ok' => false, 'error' => 'URL / API Key WAHA belum diisi Super Admin.'], 400);
        }
        $n  = wahaSession($wa);
        $sp = rawurlencode($n);

        if ($op === 'history') {   // v1.2.105: riwayat-wa-waha
            $do = (string)($in['do'] ?? 'get');
            if ($do === 'start') {
                wsSchedule($wa, (($in['reason'] ?? '') === 'scan') ? 'scan' : 'manual', $u['username']);
                if (($in['reason'] ?? '') !== 'scan') { try { waAuditLog('history_pull', $u['username'], '', ['ch' => whCh($wa)]); } catch (\Throwable $e) {} }
            }
            if ($do === 'run' || $do === 'start') { @set_time_limit(40); try { wsRun($s, 8, whCh($wa)); } catch (\Throwable $e) { error_log('wsRun: ' . $e->getMessage()); } }
            $chk = whCh($wa); $cn = 0; $cm = 0;
            foreach (wiIndexAll() as $ir) { if ((string)($ir['ch'] ?? '') === $chk) { $cn++; $cm += (int)($ir['count'] ?? 0); } }
            jsonOut(['ok' => true, 'history' => wsPublic(wsGet($chk)), 'stored' => ['nums' => $cn, 'msgs' => $cm]]);
        }

        if ($op === 'status') {
            list($c, $d) = wahaApi($wa, 'GET', '/api/sessions/' . $sp);
            if ($c === 404) jsonOut(['ok' => true, 'connected' => false, 'status' => 'BELUM DIBUAT', 'session' => $n]);
            if ($c < 200 || $c >= 300) jsonOut(['ok' => false, 'error' => wahaErr($c, $d)]);
            $st  = (string)($d['status'] ?? '');
            $dev = wahaJidNum(preg_replace('/:\d+@/', '@', (string)($d['me']['id'] ?? '')));
            if ($dev !== '' && (string)($wa['waha_number'] ?? '') !== $dev) waChanSetWahaNumber($wa, $dev);   // v1.2.98: multi-nomor
            jsonOut(['ok' => true, 'connected' => ($st === 'WORKING'), 'status' => $st, 'session' => $n,
                     'device' => $dev, 'name' => (string)($d['me']['pushName'] ?? '')]);
        }

        if ($op === 'qr') {
            list($ok, $d) = wahaEnsureSession($wa);
            if (!$ok) jsonOut(['ok' => false, 'error' => $d]);
            $st = (string)($d['status'] ?? '');
            if ($st === 'WORKING') jsonOut(['ok' => true, 'connected' => true]);
            if ($st !== 'SCAN_QR_CODE') jsonOut(['ok' => true, 'connected' => false, 'wait' => true, 'status' => $st]);
            if (($in['type'] ?? 'qr') === 'code') {
                $num = preg_replace('/\D/', '', (string)($in['whatsapp'] ?? ''));
                if (strpos($num, '0') === 0) $num = '62' . substr($num, 1);
                if (strlen($num) < 9 || strlen($num) > 15) jsonOut(['ok' => false, 'error' => 'Nomor WhatsApp tidak valid.'], 400);
                list($c, $r) = wahaApi($wa, 'POST', '/api/' . $sp . '/auth/request-code', ['phoneNumber' => $num]);
                if ($c >= 200 && $c < 300 && !empty($r['code'])) jsonOut(['ok' => true, 'connected' => false, 'code' => (string)$r['code']]);
                jsonOut(['ok' => false, 'error' => wahaErr($c, $r, 'Kode tautan tidak tersedia, pakai scan QR.')]);
            }
            list($c, $q) = wahaApi($wa, 'GET', '/api/' . $sp . '/auth/qr?format=image');
            $img = ($c >= 200 && $c < 300) ? preg_replace('/[^A-Za-z0-9+\/=]/', '', (string)($q['data'] ?? '')) : '';
            if ($img !== '') {
                $mime = preg_match('#^image/[a-z]+$#', (string)($q['mimetype'] ?? '')) ? $q['mimetype'] : 'image/png';
                jsonOut(['ok' => true, 'connected' => false, 'qr' => 'data:' . $mime . ';base64,' . $img]);
            }
            jsonOut(['ok' => true, 'connected' => false, 'wait' => true, 'status' => $st]);
        }

        if ($op === 'disconnect') {
            whMark($wa, 'manual_at');   // v1.2.104: logout dari dashboard bukan logout paksa
            list($c, $d) = wahaApi($wa, 'POST', '/api/sessions/' . $sp . '/logout');
            if ($c >= 200 && $c < 300) {
                try { waAuditLog('waha_logout', $u['username'], '', []); } catch (\Throwable $e) {}
                jsonOut(['ok' => true]);
            }
            jsonOut(['ok' => false, 'error' => wahaErr($c, $d, 'Gagal memutuskan.')]);
        }

        if ($op === 'webhook') {
            if (($u['role'] ?? '') !== 'super_admin') jsonOut(['ok' => false, 'error' => 'Khusus Super Admin.'], 403);
            if ((string)($wa['waha_webhook_key'] ?? '') === '') jsonOut(['ok' => false, 'error' => 'Kunci webhook belum ada — simpan pengaturan dengan penyedia WAHA dulu.'], 400);
            whMark($wa, 'cfg_at');   // v1.2.104: restart karena PUT bukan sinyal risiko
            list($c, $d) = wahaApi($wa, 'GET', '/api/sessions/' . $sp);
            if ($c === 404) {
                list($c, $d) = wahaApi($wa, 'POST', '/api/sessions', ['name' => $n, 'start' => true, 'config' => wahaSessionConfig($wa)]);
            } elseif ($c >= 200 && $c < 300) {
                list($c, $d) = wahaApi($wa, 'PUT', '/api/sessions/' . $sp, ['name' => $n, 'config' => wahaSessionConfig($wa)]);
            }
            if ($c < 200 || $c >= 300) jsonOut(['ok' => false, 'error' => wahaErr($c, $d, 'Gagal memasang webhook.')]);
            try { waAuditLog('waha_webhook_set', $u['username'], '', []); } catch (\Throwable $e) {}
            jsonOut(['ok' => true]);
        }

        jsonOut(['ok' => false, 'error' => 'op tidak dikenal'], 400);
        break;
    }

    /* ---------- v1.2.112: login-log — riwayat login (Super Admin & Admin) ---------- */
    case 'login_log': {
        $me   = requireAuth(['super_admin', 'admin']);
        $isSa = ($me['role'] ?? '') === 'super_admin';
        $all  = (array)readJson(LOGIN_LOG_FILE, []);
        $intl = [];
        foreach ((array)readJson(USERS_FILE, []) as $x) if (!empty($x['internal'])) $intl[$x['username'] ?? ''] = 1;
        // Admin tidak melihat aktivitas akun internal DEI (sama seperti daftar Pengguna)
        if (!$isSa) $all = array_values(array_filter($all, function ($e) use ($intl) {
            return is_array($e) && empty($e['in']) && !isset($intl[$e['u'] ?? '']);
        }));
        $now = time();
        $ok24 = 0; $fail24 = 0; $names = [];
        foreach ($all as $e) {
            if (!is_array($e)) continue;
            if ((int)($e['t'] ?? 0) >= $now - 86400) { if (!empty($e['ok'])) $ok24++; else $fail24++; }
            $names[(string)($e['u'] ?? '')] = 1;
        }
        unset($names['']);
        $names = array_keys($names); sort($names, SORT_NATURAL | SORT_FLAG_CASE);
        $days   = min(LOGIN_LOG_DAYS, max(1, (int)($_GET['days'] ?? 30)));
        $status = (string)($_GET['status'] ?? '');
        $fu     = trim((string)($_GET['user'] ?? ''));
        $cut    = $now - $days * 86400;
        $rows = array_values(array_filter($all, function ($e) use ($cut, $status, $fu) {
            if (!is_array($e) || (int)($e['t'] ?? 0) < $cut) return false;
            if ($status === 'ok' && empty($e['ok'])) return false;
            if ($status === 'fail' && !empty($e['ok'])) return false;
            if ($fu !== '' && strcasecmp((string)($e['u'] ?? ''), $fu) !== 0) return false;
            return true;
        }));
        $limit = min(1000, max(10, (int)($_GET['limit'] ?? 300)));
        jsonOut(['ok' => true, 'entries' => array_slice($rows, 0, $limit), 'total' => count($rows),
                 'usernames' => $names, 'stats' => ['ok24' => $ok24, 'fail24' => $fail24], 'days' => $days]);
        break;
    }
    /* v1.2.112: riwayat login akun sendiri (Profil Saya) */
    case 'my_login_log': {
        $me = requireAuth();
        $mine = [];
        foreach ((array)readJson(LOGIN_LOG_FILE, []) as $e) {
            if (!is_array($e) || ($e['u'] ?? '') !== ($me['username'] ?? '')) continue;
            unset($e['ua']);
            $mine[] = $e;
            if (count($mine) >= 10) break;
        }
        jsonOut(['ok' => true, 'entries' => $mine]);
        break;
    }

    case 'wa_audit_log': {
        requireAuth(['super_admin', 'admin', 'supervisor']);
        $limit = min(200, max(10, (int)($_GET['limit'] ?? 50)));
        $all = readJson(waAuditLogFile(), []);
        $entries = array_slice($all, 0, $limit);
        jsonOut([
            'ok' => true,
            'entries' => $entries,
            'total' => count($all),
            'shown' => count($entries),
        ]);
        break;
    }

    default:
        jsonOut(['ok' => false, 'error' => 'Unknown action: ' . $action], 404);
}
